import type { ReactNode } from "react";
import { Breadcrumbs, type BreadcrumbItem } from "./Breadcrumbs";
import { TitleSectionBackground } from "./TitleSectionBackground";

export function PageHero({
  eyebrow,
  title,
  description,
  breadcrumbs,
  actions,
}: {
  eyebrow: string;
  title: string;
  description: string;
  breadcrumbs: BreadcrumbItem[];
  actions?: ReactNode;
}) {
  return (
    <section className="vibha-grid relative min-h-[900px] overflow-hidden bg-[#071f49] text-white sm:min-h-[720px] xl:aspect-video xl:min-h-0">
      <TitleSectionBackground />
      <div className="container relative pb-10 pt-44 sm:pb-12 sm:pt-[26rem] xl:py-14">
        <div data-reveal="left" data-mobile-title-load className="w-[62%] sm:w-full sm:max-w-[50%] lg:max-w-[38%]">
          <Breadcrumbs items={breadcrumbs} inverse />
          <div className="mt-5 lg:mt-7">
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#ff9a52] sm:text-sm">{eyebrow}</p>
            <h1 className="mt-3 text-balance text-2xl font-bold leading-[1.08] min-[430px]:text-3xl sm:text-3xl lg:mt-4 lg:text-4xl">{title}</h1>
            <p className="mt-4 text-pretty text-sm leading-6 text-slate-200 lg:mt-5 lg:text-base lg:leading-7">{description}</p>
            {actions ? <div className="mt-5 flex flex-wrap gap-3 lg:mt-7">{actions}</div> : null}
          </div>
        </div>
      </div>
    </section>
  );
}
