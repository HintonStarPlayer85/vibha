import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  certificateDownloadSchema,
  certificateHistorySchema,
  certificatePreviewAcknowledgementSchema,
  certificateCompletionResubmitSchema,
  certificateCompletionReviewSchema,
  certificateApprovalEscalationResendSchema,
  certificateApprovalEscalationReassignSchema,
  certificateGovernanceDashboardSchema,
  certificateGovernanceDashboardExportSchema,
  certificateTemplateTestHistorySchema,
  certificateTemplateTestSendSchema,
  completionNotificationResendSchema,
  certificateIssueSchema,
  certificatePreviewSchema,
  signatureCropSchema,
  certificateProgramProfileSchema,
  certificateReissueSchema,
  certificateRepositoryQuerySchema,
  certificateRevokeSchema,
  certificateVerifySchema,
} from "../../shared/certificates";
import {
  certificateErrors,
  getCertificateById,
  getCertificateProgramProfile,
  getPublicCertificateVerification,
  listCertificateRepository,
  listCertificateApprovalHistory,
  exportCertificateApprovalHistoryCsv,
  listCompletionNotificationHistory,
  listCertificateCompletionReviews,
  listEligibleCertificateRecipients,
  resubmitCertificateCompletion,
  reviewCertificateCompletion,
  listCertificateProgramOptions,
  listCertificateTemplateTestDeliveryHistory,
  upsertCertificateProgramProfile,
  setExecutiveSignature,
  clearExecutiveSignature,
  confirmCertificatePreviewAcknowledgement,
  recordCertificatePreviewAcknowledgement,
} from "../certificateDb";
import { issueCertificate, previewCertificate, reissueCertificate, revokeIssuedCertificate } from "../certificateService";
import { deliverCompletionNotification, resendCompletionNotification } from "../completionNotificationService";
import { getCertificateGovernanceDashboard, listCertificateAdministratorOptions, listCertificateGovernanceNotificationStatus, resendCertificateApprovalEscalation, reassignCertificateApprovalEscalation } from "../certificateApprovalEscalationService";
import { resendCertificatePreviewReminder } from "../certificatePreviewReminderService";
import { generateCertificateApprovalHistoryPdf } from "../certificateApprovalHistoryReportService";
import { generateCertificateGovernanceDashboardCsv, generateCertificateGovernanceDashboardPdf } from "../certificateGovernanceDashboardReportService";
import { sendCertificateTemplateTest } from "../certificateTemplateTestService";
import { storagePut } from "../storage";
import { randomUUID } from "node:crypto";
import { adminProcedure, publicProcedure, router } from "../_core/trpc";

function translateCertificateError(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === certificateErrors.candidateNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "The selected cohort student was not found." });
  if (message === certificateErrors.notFound) throw new TRPCError({ code: "NOT_FOUND", message: "Certificate record not found." });
  if (message === certificateErrors.notEligible) throw new TRPCError({ code: "BAD_REQUEST", message: "Certificates can only be issued when both the cohort and student are marked completed." });
  if (message === certificateErrors.alreadyIssued) throw new TRPCError({ code: "CONFLICT", message: "An active certificate has already been issued for this completed student." });
  if (message === certificateErrors.completionNotApproved) throw new TRPCError({ code: "BAD_REQUEST", message: "This course completion must be approved by an administrator before a certificate can be issued." });
  if (message === certificateErrors.duplicateHighStakesReviewer) throw new TRPCError({ code: "CONFLICT", message: "A second high-stakes approval must be completed by a different administrator." });
  if (message === certificateErrors.previewAcknowledgementRequired) throw new TRPCError({ code: "BAD_REQUEST", message: "Generate and acknowledge a current certificate preview before issuing." });
  if (message === certificateErrors.notIssued) throw new TRPCError({ code: "BAD_REQUEST", message: "Only an active issued certificate can be reissued or revoked." });
  throw error;
}

function requestOrigin(req: { protocol: string; get: (name: string) => string | undefined }) {
  const forwardedProtocol = req.get("x-forwarded-proto")?.split(",")[0];
  const protocol = forwardedProtocol || req.protocol || "https";
  const host = req.get("x-forwarded-host") || req.get("host");
  if (!host) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Certificate verification URL could not be determined." });
  return `${protocol}://${host}`;
}

export const certificateVerificationRouter = router({
  verify: publicProcedure.input(certificateVerifySchema).query(({ input }) => getPublicCertificateVerification(input)),
});

export const adminCertificateRepositoryRouter = router({
  list: adminProcedure.input(certificateRepositoryQuerySchema).query(({ input }) => listCertificateRepository(input)),
  eligible: adminProcedure.query(() => listEligibleCertificateRecipients()),
  completionApprovals: adminProcedure.query(() => listCertificateCompletionReviews()),
  completionNotificationHistory: adminProcedure.query(() => listCompletionNotificationHistory()),
  governanceNotificationStatus: adminProcedure.query(() => listCertificateGovernanceNotificationStatus()),
  administratorOptions: adminProcedure.query(() => listCertificateAdministratorOptions()),
  governanceDashboard: adminProcedure.input(certificateGovernanceDashboardSchema).query(({ ctx, input }) => getCertificateGovernanceDashboard(ctx.user.id, input)),
  exportGovernanceDashboard: adminProcedure.input(certificateGovernanceDashboardExportSchema).mutation(async ({ ctx, input }) => {
    const dashboard = await getCertificateGovernanceDashboard(ctx.user.id, input);
    const exporter = { id: ctx.user.id, name: ctx.user.name ?? "Administrator", openId: ctx.user.openId ?? `administrator-${ctx.user.id}` };
    return input.format === "csv"
      ? generateCertificateGovernanceDashboardCsv({ dashboard, exporter })
      : generateCertificateGovernanceDashboardPdf({ dashboard, exporter });
  }),
  myApprovalWorkload: adminProcedure.query(({ ctx }) => getCertificateGovernanceDashboard(ctx.user.id).then(result => result.workload)),
  templateTestHistory: adminProcedure.input(certificateTemplateTestHistorySchema).query(({ input }) => listCertificateTemplateTestDeliveryHistory(input.certificationId)),
  approvalHistory: adminProcedure.input(certificateHistorySchema).query(({ input }) => listCertificateApprovalHistory(input.certificateId, input.eventTypes)),
  exportApprovalHistory: adminProcedure.input(certificateHistorySchema).mutation(({ input, ctx }) => exportCertificateApprovalHistoryCsv({ certificateId: input.certificateId, eventTypes: input.eventTypes, exporter: { id: ctx.user.id, name: ctx.user.name ?? "Administrator", openId: ctx.user.openId ?? `administrator-${ctx.user.id}` } })),
  exportApprovalHistoryPdf: adminProcedure.input(certificateHistorySchema).mutation(({ input, ctx }) => generateCertificateApprovalHistoryPdf({ certificateId: input.certificateId, eventTypes: input.eventTypes, exporter: { id: ctx.user.id, name: ctx.user.name ?? "Administrator", openId: ctx.user.openId ?? `administrator-${ctx.user.id}` } })),
  reviewCompletion: adminProcedure.input(certificateCompletionReviewSchema).mutation(async ({ input, ctx }) => {
    try {
      const review = await reviewCertificateCompletion(input.cohortStudentId, input.decision, input.notes, ctx.user.id);
      if (review.notification) await deliverCompletionNotification(review.notification.id);
      return review;
    } catch (error) { translateCertificateError(error); }
  }),
  resendCompletionNotification: adminProcedure.input(completionNotificationResendSchema).mutation(async ({ input, ctx }) => {
    try { return await resendCompletionNotification(input.notificationId, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  resendPreviewReminder: adminProcedure.input(z.object({ notificationId: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
    try { return await resendCertificatePreviewReminder(input.notificationId, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  resendApprovalEscalation: adminProcedure.input(certificateApprovalEscalationResendSchema).mutation(async ({ input, ctx }) => {
    try { return await resendCertificateApprovalEscalation(input.escalationId, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  reassignApprovalEscalation: adminProcedure.input(certificateApprovalEscalationReassignSchema).mutation(async ({ input, ctx }) => {
    try { return await reassignCertificateApprovalEscalation(input.escalationId, input.recipientUserId, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  sendTemplateTest: adminProcedure.input(certificateTemplateTestSendSchema).mutation(async ({ input, ctx }) => {
    try { return await sendCertificateTemplateTest({ ...input, actorUserId: ctx.user.id }); } catch (error) { translateCertificateError(error); }
  }),
  resubmitCompletion: adminProcedure.input(certificateCompletionResubmitSchema).mutation(async ({ input, ctx }) => {
    try { return await resubmitCertificateCompletion(input.cohortStudentId, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  programOptions: adminProcedure.query(() => listCertificateProgramOptions()),
  getProgramProfile: adminProcedure.input(certificateProgramProfileSchema.pick({ certificationId: true })).query(({ input }) => getCertificateProgramProfile(input.certificationId)),
  saveProgramProfile: adminProcedure.input(certificateProgramProfileSchema).mutation(({ input, ctx }) => upsertCertificateProgramProfile(input, ctx.user.id)),
  uploadExecutiveSignature: adminProcedure.input(z.object({ certificationId: z.number().int().positive(), fileName: z.string().trim().min(1).max(320), mimeType: z.enum(["image/png", "image/jpeg"]), dataBase64: z.string().min(1).max(3_000_000), crop: signatureCropSchema.optional() })).mutation(async ({ input, ctx }) => {
    const bytes = Buffer.from(input.dataBase64, "base64");
    if (!bytes.length || bytes.length > 2 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "Executive signature images must be PNG or JPEG files no larger than 2 MB." });
    const isPng = bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
    const isJpeg = bytes[0] === 0xff && bytes[1] === 0xd8;
    if ((input.mimeType === "image/png" && !isPng) || (input.mimeType === "image/jpeg" && !isJpeg)) throw new TRPCError({ code: "BAD_REQUEST", message: "The selected file does not match its declared image type." });
    const extension = input.mimeType === "image/png" ? "png" : "jpg";
    const stored = await storagePut(`certificate-executive-signatures/${input.certificationId}/signature.${extension}`, bytes, input.mimeType);
    return setExecutiveSignature({ certificationId: input.certificationId, storageKey: stored.key, url: stored.url, fileName: input.fileName.replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 320), mimeType: input.mimeType, crop: input.crop ?? null, actorUserId: ctx.user.id });
  }),
  removeExecutiveSignature: adminProcedure.input(certificateProgramProfileSchema.pick({ certificationId: true })).mutation(async ({ input, ctx }) => {
    try { return await clearExecutiveSignature(input.certificationId, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  preview: adminProcedure.input(certificatePreviewSchema).mutation(async ({ input, ctx }) => {
    try {
      const result = await previewCertificate(input.cohortStudentId, requestOrigin(ctx.req));
      const acknowledgement = await recordCertificatePreviewAcknowledgement({ cohortStudentId: input.cohortStudentId, certificationId: result.certificationId, acknowledgementToken: randomUUID(), previewFingerprint: result.previewFingerprint, actorUserId: ctx.user.id, expiresAt: new Date(Date.now() + result.expirationMinutes * 60 * 1000) });
      return { ...result, acknowledgement };
    } catch (error) { translateCertificateError(error); }
  }),
  confirmPreviewAcknowledgement: adminProcedure.input(certificatePreviewAcknowledgementSchema).mutation(async ({ input, ctx }) => {
    try { return await confirmCertificatePreviewAcknowledgement(input.acknowledgementToken, input.notes, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  issue: adminProcedure.input(certificateIssueSchema).mutation(async ({ input, ctx }) => {
    try { return await issueCertificate(input.cohortStudentId, input.previewAcknowledgementToken, ctx.user.id, requestOrigin(ctx.req)); } catch (error) { translateCertificateError(error); }
  }),
  reissue: adminProcedure.input(certificateReissueSchema).mutation(async ({ input, ctx }) => {
    try { return await reissueCertificate(input.certificateId, ctx.user.id, requestOrigin(ctx.req)); } catch (error) { translateCertificateError(error); }
  }),
  revoke: adminProcedure.input(certificateRevokeSchema).mutation(async ({ input, ctx }) => {
    try { return await revokeIssuedCertificate(input.certificateId, input.reason, ctx.user.id); } catch (error) { translateCertificateError(error); }
  }),
  download: adminProcedure.input(certificateDownloadSchema).query(async ({ input }) => {
    const certificate = await getCertificateById(input.certificateId);
    if (!certificate) throw new TRPCError({ code: "NOT_FOUND", message: "Certificate record not found." });
    return { certificateNumber: certificate.certificateNumber, documentUrl: certificate.documentUrl, status: certificate.status };
  }),
});
