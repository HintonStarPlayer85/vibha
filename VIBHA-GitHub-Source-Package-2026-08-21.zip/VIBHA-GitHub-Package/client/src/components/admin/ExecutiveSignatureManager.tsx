import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ImagePlus, Loader2, Trash2 } from "lucide-react";
import { ChangeEvent, useEffect, useState } from "react";
import { toast } from "sonner";

type Crop = { x: number; y: number; size: number; zoom: number };
type Source = { fileName: string; dataUrl: string };
type Props = { certificationId: number; signatureUrl: string | null | undefined; onChanged: () => Promise<unknown> | void };

export function ExecutiveSignatureManager({ certificationId, signatureUrl, onChanged }: Props) {
  const [source, setSource] = useState<Source | null>(null);
  const [crop, setCrop] = useState<Crop>({ x: 0.5, y: 0.5, size: 1, zoom: 1 });
  const [croppedSignature, setCroppedSignature] = useState<string | null>(null);
  const upload = trpc.adminCertificates.uploadExecutiveSignature.useMutation();
  const remove = trpc.adminCertificates.removeExecutiveSignature.useMutation();

  useEffect(() => {
    if (!source) { setCroppedSignature(null); return; }
    let active = true;
    const image = new Image();
    image.onload = () => {
      const width = 800; const height = 240; const ratio = width / height; const sourceRatio = image.width / image.height;
      const baseWidth = sourceRatio > ratio ? image.height * ratio : image.width;
      const baseHeight = sourceRatio > ratio ? image.height : image.width / ratio;
      const cropWidth = baseWidth / crop.zoom; const cropHeight = baseHeight / crop.zoom;
      const sx = Math.max(0, Math.min(image.width - cropWidth, (image.width - cropWidth) * crop.x));
      const sy = Math.max(0, Math.min(image.height - cropHeight, (image.height - cropHeight) * crop.y));
      const canvas = document.createElement("canvas"); canvas.width = width; canvas.height = height;
      canvas.getContext("2d")?.drawImage(image, sx, sy, cropWidth, cropHeight, 0, 0, width, height);
      if (active) setCroppedSignature(canvas.toDataURL("image/png"));
    };
    image.src = source.dataUrl;
    return () => { active = false; };
  }, [source, crop]);

  async function chooseFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0] ?? null;
    event.target.value = "";
    if (!file) return;
    if (!(file.type === "image/png" || file.type === "image/jpeg") || file.size > 2 * 1024 * 1024) { toast.error("Select a PNG or JPEG signature image no larger than 2 MB."); return; }
    try {
      const dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onerror = () => reject(new Error("The signature image could not be read.")); reader.onload = () => resolve(String(reader.result)); reader.readAsDataURL(file); });
      setSource({ fileName: file.name, dataUrl }); setCrop({ x: 0.5, y: 0.5, size: 1, zoom: 1 });
    } catch (error) { toast.error(error instanceof Error ? error.message : "The signature image could not be read."); }
  }

  async function save() {
    if (!source || !croppedSignature) return;
    try {
      await upload.mutateAsync({ certificationId, fileName: `${source.fileName.replace(/\.[^.]+$/, "")}-cropped.png`, mimeType: "image/png", dataBase64: croppedSignature.split(",")[1] ?? "", crop });
      setSource(null); await onChanged(); toast.success("Cropped executive signature saved for future certificate issuances.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Executive signature upload failed."); }
  }

  async function clear() { try { await remove.mutateAsync({ certificationId }); await onChanged(); toast.success("Executive signature removed."); } catch (error) { toast.error(error instanceof Error ? error.message : "Executive signature removal failed."); } }

  const pending = upload.isPending || remove.isPending;
  return <section className="rounded-xl border border-[#173b70]/20 bg-[#f7faff] p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Executive signature image</h2><p className="mt-1 max-w-3xl text-sm leading-6 text-slate-600">This optional image appears above the executive name and title in the right certificate signature block. Crop it into a clean signature strip before saving. Existing issued certificates remain unchanged.</p><div className="mt-5 flex flex-col gap-4 sm:flex-row sm:items-center"><div className="flex min-h-20 min-w-48 items-center justify-center rounded-lg border border-dashed border-[#173b70]/30 bg-white p-3">{signatureUrl ? <img src={signatureUrl} alt="Current executive signature" className="max-h-16 max-w-44 object-contain" /> : <span className="text-xs text-slate-500">No executive signature image</span>}</div><div className="flex-1"><Label htmlFor="executive-signature">Upload or replace signature</Label><Input id="executive-signature" className="mt-2" type="file" accept="image/png,image/jpeg" disabled={pending} onChange={event => void chooseFile(event)} /><p className="mt-1 text-xs text-slate-500">PNG or JPEG, up to 2 MB. A cropped PNG will be stored.</p></div></div>{source ? <div className="mt-5 rounded-lg border border-[#173b70]/25 bg-white p-4"><h3 className="font-bold text-[#071f49]">Crop and prepare signature</h3>{croppedSignature ? <img src={croppedSignature} alt="Cropped executive signature preview" className="mt-4 h-20 w-full rounded border border-slate-200 bg-white object-contain" /> : <p className="mt-4 text-sm text-slate-600">Preparing preview…</p>}<div className="mt-4 space-y-3"><div><Label htmlFor="executive-signature-zoom" className="text-xs">Zoom: {crop.zoom.toFixed(1)}×</Label><input id="executive-signature-zoom" type="range" min="1" max="3" step="0.1" value={crop.zoom} onChange={event => setCrop(current => ({ ...current, zoom: Number(event.target.value), size: 1 / Number(event.target.value) }))} className="mt-1 w-full accent-[#071f49]" /></div><div><Label htmlFor="executive-signature-horizontal" className="text-xs">Horizontal position</Label><input id="executive-signature-horizontal" type="range" min="0" max="1" step="0.01" value={crop.x} onChange={event => setCrop(current => ({ ...current, x: Number(event.target.value) }))} className="mt-1 w-full accent-[#071f49]" /></div><div><Label htmlFor="executive-signature-vertical" className="text-xs">Vertical position</Label><input id="executive-signature-vertical" type="range" min="0" max="1" step="0.01" value={crop.y} onChange={event => setCrop(current => ({ ...current, y: Number(event.target.value) }))} className="mt-1 w-full accent-[#071f49]" /></div></div><div className="mt-4 flex flex-wrap gap-2"><Button type="button" variant="outline" onClick={() => setCrop({ x: 0.5, y: 0.5, size: 1, zoom: 1 })}>Reset crop</Button><Button type="button" disabled={pending || !croppedSignature} onClick={() => void save()} className="bg-[#071f49] text-white hover:bg-[#173b70]"><ImagePlus className="mr-1.5 h-4 w-4" />Save cropped signature</Button><Button type="button" variant="ghost" onClick={() => setSource(null)}>Cancel</Button></div></div> : null}<div className="mt-5 flex flex-wrap gap-3">{signatureUrl ? <Button type="button" variant="outline" onClick={() => void clear()} disabled={pending} className="border-red-300 text-red-700 hover:bg-red-50">{remove.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}Remove signature</Button> : null}</div></section>;
}
