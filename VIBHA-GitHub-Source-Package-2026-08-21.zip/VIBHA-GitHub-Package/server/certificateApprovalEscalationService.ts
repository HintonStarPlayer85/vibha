import { and, desc, eq, isNull, sql } from "drizzle-orm";
import { Resend } from "resend";
import {
  administrationAuditEvents,
  certificateApprovalEscalations,
  certificateProgramProfiles,
  certificatePreviewReminderNotifications,
  certificatePreviewAcknowledgements,
  certificatePreviewReminderSchedules,
  certifications,
  cohorts,
  cohortStudents,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";
import { getResendConfiguration, verifyResendSenderDomain } from "./resendCohort";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]!);
}

function renderEscalation(input: { recipientName: string; studentName: string; credentialTitle: string; cohortTitle: string; templateSubject?: string | null; templateBody?: string | null }) {
  const merge = (template: string) => template.replace(/\{\{\s*(administratorName|credentialTitle|cohortTitle|expiresAt|studentName)\s*\}\}/g, (_match, key: string) => ({ administratorName: input.recipientName, credentialTitle: input.credentialTitle, cohortTitle: input.cohortTitle, expiresAt: "", studentName: input.studentName })[key] ?? "");
  const subject = input.templateSubject ? merge(input.templateSubject) : `Action needed: VIBHA completion approval is delayed`;
  const message = `${input.studentName}'s completion for ${input.credentialTitle} in ${input.cohortTitle} is still awaiting administrative approval. Review the Completion Approvals queue to approve or return the record.`;
  const body = input.templateBody ? merge(input.templateBody) : message;
  const html = `<!doctype html><html><body style="margin:0;background:#f6f8fb;font-family:Arial,sans-serif"><div style="max-width:680px;margin:0 auto;padding:28px 16px"><div style="background:#071f49;padding:20px 24px;color:#fff"><strong style="font-size:22px">VIBHA</strong><div style="margin-top:4px;font-size:12px;letter-spacing:.08em">THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH &amp; ADVANCEMENT</div></div><div style="background:#fff;padding:28px 24px;border:1px solid #dce3ec"><h1 style="margin:0 0 18px;font-size:22px;color:#071f49">Delayed completion approval</h1><p style="margin:0;color:#34435a;line-height:1.65">Hello ${escapeHtml(input.recipientName)},</p><p style="margin:16px 0 0;color:#34435a;line-height:1.65">${escapeHtml(body)}</p><p style="margin:28px 0 0;padding-top:18px;border-top:1px solid #dce3ec;color:#667085;font-size:13px;line-height:1.6">This is an automated VIBHA certificate-governance escalation. Review the record promptly or use the certificate administration panel to document the next decision.</p></div></div></body></html>`;
  return { subject, html, text: `Hello ${input.recipientName},\n\n${body}` };
}

type EscalationDelivery = {
  id: number; cohortStudentId: number; recipientName: string; recipientEmail: string; subject: string; idempotencyKey: string; retryCount: number; studentName: string; credentialTitle: string; cohortTitle: string; templateSubject?: string | null; templateBody?: string | null;
};

export async function getCertificateApprovalEscalationDelivery(id: number): Promise<EscalationDelivery | null> {
  const db = await requireDb();
  return (await db.select({
    id: certificateApprovalEscalations.id,
    cohortStudentId: certificateApprovalEscalations.cohortStudentId,
    recipientName: certificateApprovalEscalations.recipientName,
    recipientEmail: certificateApprovalEscalations.recipientEmail,
    subject: certificateApprovalEscalations.subject,
    idempotencyKey: certificateApprovalEscalations.idempotencyKey,
    retryCount: certificateApprovalEscalations.retryCount,
    studentName: cohortStudents.name,
    credentialTitle: certifications.title,
    cohortTitle: cohorts.title,
    templateSubject: certificateProgramProfiles.approvalEscalationEmailSubject,
    templateBody: certificateProgramProfiles.approvalEscalationEmailBody,
  }).from(certificateApprovalEscalations)
    .innerJoin(cohortStudents, eq(certificateApprovalEscalations.cohortStudentId, cohortStudents.id))
    .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
    .innerJoin(certifications, eq(certificateApprovalEscalations.certificationId, certifications.id))
    .leftJoin(certificateProgramProfiles, eq(certifications.id, certificateProgramProfiles.certificationId))
    .where(eq(certificateApprovalEscalations.id, id)).limit(1))[0] ?? null;
}

async function markEscalationAccepted(id: number, providerMessageId: string) {
  const db = await requireDb();
  await db.update(certificateApprovalEscalations).set({ status: "accepted", providerMessageId, sentAt: new Date(), errorCode: null, errorMessage: null }).where(eq(certificateApprovalEscalations.id, id));
}

async function markEscalationFailed(id: number, error: string, retry: boolean) {
  const db = await requireDb();
  const current = (await db.select({ retryCount: certificateApprovalEscalations.retryCount }).from(certificateApprovalEscalations).where(eq(certificateApprovalEscalations.id, id)).limit(1))[0];
  if (!current) return;
  await db.update(certificateApprovalEscalations).set({ status: "failed", retryCount: retry ? current.retryCount + 1 : current.retryCount, errorCode: "resend_error", errorMessage: error }).where(eq(certificateApprovalEscalations.id, id));
}

async function deliverEscalation(delivery: EscalationDelivery, retry: boolean) {
  const config = getResendConfiguration();
  const senderDomain = await verifyResendSenderDomain(true);
  if (!config.readyToSend || !config.apiKey || !config.from || !config.replyTo || !senderDomain.verified) {
    const detail = !senderDomain.verified ? `Sender domain ${senderDomain.domain || "unknown"} is ${senderDomain.status.replace(/_/g, " ")}.` : `Missing: ${config.missing.join(", ")}.`;
    await markEscalationFailed(delivery.id, detail, retry);
    return { status: "failed" as const, error: detail };
  }
  try {
    const rendered = renderEscalation(delivery);
    const result = await new Resend(config.apiKey).emails.send({ from: config.from, to: [delivery.recipientEmail], replyTo: config.replyTo, subject: rendered.subject, html: rendered.html, text: rendered.text, tags: [{ name: "certificate_approval_escalation", value: String(delivery.cohortStudentId) }] }, { idempotencyKey: delivery.idempotencyKey.slice(0, 256) });
    if (result.error || !result.data?.id) {
      const detail = result.error?.message || "Resend did not accept the approval escalation.";
      await markEscalationFailed(delivery.id, detail, retry);
      return { status: "failed" as const, error: detail };
    }
    await markEscalationAccepted(delivery.id, result.data.id);
    return { status: "accepted" as const, error: null };
  } catch (error) {
    const detail = error instanceof Error ? error.message : "The approval escalation request did not complete.";
    await markEscalationFailed(delivery.id, detail, retry);
    return { status: "failed" as const, error: detail };
  }
}

export async function runCertificateApprovalEscalationSweep() {
  const db = await requireDb();
  const now = new Date();
  const rows = await db.select({
    cohortStudentId: cohortStudents.id,
    certificationId: certifications.id,
    recipientUserId: users.id,
    recipientName: users.name,
    recipientEmail: users.email,
    studentName: cohortStudents.name,
    credentialTitle: certifications.title,
    cohortTitle: cohorts.title,
    firstApprovedByUserId: cohortStudents.completionFirstApprovedByUserId,
    startedAt: sql<Date>`COALESCE(${cohortStudents.completionFirstApprovedAt}, ${cohortStudents.completionApprovalRequestedAt}, ${cohortStudents.updatedAt})`,
    delayMinutes: certificateProgramProfiles.approvalEscalationDelayMinutes,
    templateSubject: certificateProgramProfiles.approvalEscalationEmailSubject,
    templateBody: certificateProgramProfiles.approvalEscalationEmailBody,
    existingId: certificateApprovalEscalations.id,
  }).from(cohortStudents)
    .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
    .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
    .innerJoin(certificateProgramProfiles, eq(certifications.id, certificateProgramProfiles.certificationId))
    .innerJoin(users, eq(certificateProgramProfiles.approvalEscalationRecipientUserId, users.id))
    .leftJoin(certificateApprovalEscalations, and(eq(certificateApprovalEscalations.cohortStudentId, cohortStudents.id), eq(certificateApprovalEscalations.recipientUserId, users.id)))
    .where(and(eq(cohorts.status, "completed"), eq(cohortStudents.status, "completed"), eq(cohortStudents.completionApprovalStatus, "pending"), eq(certificateProgramProfiles.approvalEscalationEnabled, true), eq(users.role, "admin"), isNull(certificateApprovalEscalations.id)))
    .limit(50);
  let accepted = 0; let failed = 0; let duplicates = 0;
  for (const row of rows) {
    if (!row.recipientEmail || !row.recipientName || row.recipientUserId === row.firstApprovedByUserId || now.getTime() - new Date(row.startedAt).getTime() < row.delayMinutes * 60 * 1000) continue;
    const rendered = renderEscalation({ recipientName: row.recipientName, studentName: row.studentName, credentialTitle: row.credentialTitle, cohortTitle: row.cohortTitle, templateSubject: row.templateSubject, templateBody: row.templateBody });
    const existing = (await db.select().from(certificateApprovalEscalations).where(and(eq(certificateApprovalEscalations.cohortStudentId, row.cohortStudentId), eq(certificateApprovalEscalations.recipientUserId, row.recipientUserId))).limit(1))[0];
    if (existing) { duplicates += 1; continue; }
    const inserted = await db.insert(certificateApprovalEscalations).values({ cohortStudentId: row.cohortStudentId, certificationId: row.certificationId, recipientUserId: row.recipientUserId, recipientName: row.recipientName, recipientEmail: row.recipientEmail, subject: rendered.subject, idempotencyKey: `certificate-approval-escalation/${row.cohortStudentId}/${row.recipientUserId}` });
    const delivery = await getCertificateApprovalEscalationDelivery(Number(inserted[0].insertId));
    if (!delivery) continue;
    await db.insert(administrationAuditEvents).values({ actorUserId: null, action: "certificate.approval.escalated", entityType: "cohort_student", entityId: String(row.cohortStudentId), eventMetadata: { certificationId: row.certificationId, recipientUserId: row.recipientUserId, delayMinutes: row.delayMinutes } });
    const first = await deliverEscalation(delivery, false);
    const result = first.status === "accepted" ? first : await deliverEscalation(delivery, true);
    if (result.status === "accepted") accepted += 1; else failed += 1;
  }
  return { due: rows.length, accepted, failed, duplicates };
}

export async function resendCertificateApprovalEscalation(id: number, actorUserId: number) {
  const db = await requireDb();
  const delivery = await getCertificateApprovalEscalationDelivery(id);
  if (!delivery) throw new Error("CERTIFICATE_NOT_FOUND");
  await db.transaction(async tx => {
    await tx.update(certificateApprovalEscalations).set({ status: "queued", retryCount: delivery.retryCount + 1, errorCode: null, errorMessage: null }).where(eq(certificateApprovalEscalations.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.approval.escalation_resent", entityType: "certificate_approval_escalation", entityId: String(id), eventMetadata: { cohortStudentId: delivery.cohortStudentId } });
  });
  const result = await deliverEscalation({ ...delivery, retryCount: delivery.retryCount + 1 }, false);
  return { delivery: await getCertificateApprovalEscalationDelivery(id), result };
}

export async function reassignCertificateApprovalEscalation(id: number, recipientUserId: number, actorUserId: number) {
  const db = await requireDb();
  const current = (await db.select({ id: certificateApprovalEscalations.id, cohortStudentId: certificateApprovalEscalations.cohortStudentId, recipientUserId: certificateApprovalEscalations.recipientUserId, firstApprovedByUserId: cohortStudents.completionFirstApprovedByUserId }).from(certificateApprovalEscalations).innerJoin(cohortStudents, eq(certificateApprovalEscalations.cohortStudentId, cohortStudents.id)).where(eq(certificateApprovalEscalations.id, id)).limit(1))[0];
  if (!current) throw new Error("CERTIFICATE_NOT_FOUND");
  if (current.recipientUserId === recipientUserId || current.firstApprovedByUserId === recipientUserId) throw new Error("INVALID_ESCALATION_RECIPIENT");
  const recipient = (await db.select({ id: users.id, name: users.name, email: users.email }).from(users).where(and(eq(users.id, recipientUserId), eq(users.role, "admin"))).limit(1))[0];
  if (!recipient?.name || !recipient.email) throw new Error("INVALID_ESCALATION_RECIPIENT");
  const recipientName = recipient.name;
  const recipientEmail = recipient.email;
  const duplicate = (await db.select({ id: certificateApprovalEscalations.id }).from(certificateApprovalEscalations).where(and(eq(certificateApprovalEscalations.cohortStudentId, current.cohortStudentId), eq(certificateApprovalEscalations.recipientUserId, recipientUserId))).limit(1))[0];
  if (duplicate) throw new Error("ESCALATION_ALREADY_ASSIGNED");
  await db.transaction(async tx => {
    await tx.update(certificateApprovalEscalations).set({ recipientUserId, recipientName, recipientEmail, status: "queued", retryCount: 0, errorCode: null, errorMessage: null, providerMessageId: null, sentAt: null, idempotencyKey: `certificate-approval-escalation/${current.cohortStudentId}/${recipientUserId}/reassigned/${Date.now()}` }).where(eq(certificateApprovalEscalations.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.approval.escalation_reassigned", entityType: "certificate_approval_escalation", entityId: String(id), targetUserId: recipientUserId, eventMetadata: { cohortStudentId: current.cohortStudentId } });
  });
  const delivery = await getCertificateApprovalEscalationDelivery(id);
  if (!delivery) throw new Error("CERTIFICATE_NOT_FOUND");
  const result = await deliverEscalation(delivery, false);
  return { delivery: await getCertificateApprovalEscalationDelivery(id), result };
}

export async function listCertificateGovernanceNotificationStatus() {
  const db = await requireDb();
  const [preview, escalations] = await Promise.all([
    db.select({ id: certificatePreviewReminderNotifications.id, type: sql<string>`'preview_reminder'`, recipientUserId: certificatePreviewReminderNotifications.recipientUserId, status: certificatePreviewReminderNotifications.status, retryCount: certificatePreviewReminderNotifications.retryCount, errorMessage: certificatePreviewReminderNotifications.errorMessage, createdAt: certificatePreviewReminderNotifications.createdAt, sentAt: certificatePreviewReminderNotifications.sentAt, recipientName: certificatePreviewReminderNotifications.recipientName, credentialTitle: certifications.title, cohortTitle: cohorts.title }).from(certificatePreviewReminderNotifications).innerJoin(certificatePreviewAcknowledgements, eq(certificatePreviewReminderNotifications.acknowledgementId, certificatePreviewAcknowledgements.id)).innerJoin(cohortStudents, eq(certificatePreviewAcknowledgements.cohortStudentId, cohortStudents.id)).innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id)).innerJoin(certifications, eq(certificatePreviewAcknowledgements.certificationId, certifications.id)).orderBy(desc(certificatePreviewReminderNotifications.createdAt)).limit(50),
    db.select({ id: certificateApprovalEscalations.id, type: sql<string>`'approval_escalation'`, cohortStudentId: certificateApprovalEscalations.cohortStudentId, recipientUserId: certificateApprovalEscalations.recipientUserId, status: certificateApprovalEscalations.status, retryCount: certificateApprovalEscalations.retryCount, errorMessage: certificateApprovalEscalations.errorMessage, createdAt: certificateApprovalEscalations.createdAt, sentAt: certificateApprovalEscalations.sentAt, recipientName: certificateApprovalEscalations.recipientName, credentialTitle: certifications.title, cohortTitle: cohorts.title }).from(certificateApprovalEscalations).innerJoin(cohortStudents, eq(certificateApprovalEscalations.cohortStudentId, cohortStudents.id)).innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id)).innerJoin(certifications, eq(certificateApprovalEscalations.certificationId, certifications.id)).orderBy(desc(certificateApprovalEscalations.createdAt)).limit(50),
  ]);
  return [...preview, ...escalations].sort((left, right) => new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime());
}

export async function listCertificateAdministratorOptions() {
  const db = await requireDb();
  return db.select({ id: users.id, name: users.name, email: users.email }).from(users).where(eq(users.role, "admin")).orderBy(desc(users.id));
}

export async function getCertificateGovernanceDashboard(administratorUserId: number, input?: { fromDate?: string; toDate?: string }) {
  const db = await requireDb();
  const fromDate = input?.fromDate ?? new Date(Date.now() - 29 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
  const toDate = input?.toDate ?? new Date().toISOString().slice(0, 10);
  const [delayedRows, escalationRows, availableReviews, assignedEscalations, trendRows] = await Promise.all([
    db.select({
      certificationId: certifications.id,
      certificationTitle: certifications.title,
      pendingCount: sql<number>`COUNT(${cohortStudents.id})`,
      oldestRequestedAt: sql<Date | null>`MIN(COALESCE(${cohortStudents.completionFirstApprovedAt}, ${cohortStudents.completionApprovalRequestedAt}, ${cohortStudents.updatedAt}))`,
      approvalSlaTargetMinutes: certificateProgramProfiles.approvalSlaTargetMinutes,
    }).from(certifications)
      .innerJoin(cohorts, eq(cohorts.certificationId, certifications.id))
      .innerJoin(cohortStudents, eq(cohortStudents.cohortId, cohorts.id))
      .innerJoin(certificateProgramProfiles, eq(certificateProgramProfiles.certificationId, certifications.id))
      .where(and(eq(cohorts.status, "completed"), eq(cohortStudents.status, "completed"), eq(cohortStudents.completionApprovalStatus, "pending"), sql`(${certificateProgramProfiles.approvalEscalationEnabled} = true OR ${certificateProgramProfiles.approvalSlaTargetMinutes} IS NOT NULL)`))
      .groupBy(certifications.id, certifications.title, certificateProgramProfiles.approvalSlaTargetMinutes),
    db.select({ certificationId: certificateApprovalEscalations.certificationId, count: sql<number>`COUNT(${certificateApprovalEscalations.id})`, accepted: sql<number>`SUM(CASE WHEN ${certificateApprovalEscalations.status} = 'accepted' THEN 1 ELSE 0 END)` })
      .from(certificateApprovalEscalations)
      .groupBy(certificateApprovalEscalations.certificationId),
    db.select({ id: cohortStudents.id, highStakes: certificateProgramProfiles.isHighStakes, firstApprovedByUserId: cohortStudents.completionFirstApprovedByUserId })
      .from(cohortStudents)
      .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
      .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
      .leftJoin(certificateProgramProfiles, eq(certificateProgramProfiles.certificationId, certifications.id))
      .where(and(eq(cohorts.status, "completed"), eq(cohortStudents.status, "completed"), eq(cohortStudents.completionApprovalStatus, "pending"))),
    db.select({ id: certificateApprovalEscalations.id, status: certificateApprovalEscalations.status })
      .from(certificateApprovalEscalations)
      .where(eq(certificateApprovalEscalations.recipientUserId, administratorUserId)),
    db.select({ date: sql<string>`DATE(${certificateApprovalEscalations.createdAt})`, total: sql<number>`COUNT(${certificateApprovalEscalations.id})`, delivered: sql<number>`SUM(CASE WHEN ${certificateApprovalEscalations.status} = 'accepted' THEN 1 ELSE 0 END)` })
      .from(certificateApprovalEscalations)
      .where(sql`DATE(${certificateApprovalEscalations.createdAt}) BETWEEN ${fromDate} AND ${toDate}`)
      .groupBy(sql`DATE(${certificateApprovalEscalations.createdAt})`)
      .orderBy(sql`DATE(${certificateApprovalEscalations.createdAt})`),
  ]);
  const escalationMap = new Map(escalationRows.map(row => [row.certificationId, row]));
  const dashboardNow = Date.now();
  const byCertification = delayedRows.map(row => {
    const escalation = escalationMap.get(row.certificationId);
    const elapsedMinutes = row.oldestRequestedAt ? Math.max(0, Math.floor((dashboardNow - new Date(row.oldestRequestedAt).getTime()) / 60000)) : 0;
    const slaTargetMinutes = row.approvalSlaTargetMinutes ?? null;
    return { certificationId: row.certificationId, certificationTitle: row.certificationTitle, delayedApprovals: Number(row.pendingCount), escalationRecords: Number(escalation?.count ?? 0), deliveredEscalations: Number(escalation?.accepted ?? 0), oldestRequestedAt: row.oldestRequestedAt, elapsedMinutes, slaTargetMinutes, slaBreached: Boolean(slaTargetMinutes && elapsedMinutes > slaTargetMinutes) };
  }).sort((left, right) => right.delayedApprovals - left.delayedApprovals || left.certificationTitle.localeCompare(right.certificationTitle));
  const pendingSecondApprovals = availableReviews.filter(row => Boolean(row.highStakes) && row.firstApprovedByUserId !== null && row.firstApprovedByUserId !== administratorUserId).length;
  const availableReviewTasks = availableReviews.filter(row => !row.highStakes || row.firstApprovedByUserId === null || row.firstApprovedByUserId !== administratorUserId).length;
  const activeAssignedEscalations = assignedEscalations.filter(row => row.status !== "accepted").length;
  return { byCertification, trends: trendRows.map(row => ({ date: row.date, total: Number(row.total), delivered: Number(row.delivered) })), range: { fromDate, toDate }, generatedAt: new Date().toISOString(), workload: { availableReviewTasks, pendingSecondApprovals, assignedEscalations: activeAssignedEscalations } };
}
