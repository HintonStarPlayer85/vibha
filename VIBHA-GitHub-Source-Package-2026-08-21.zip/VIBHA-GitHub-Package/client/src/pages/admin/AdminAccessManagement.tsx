import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Check, Clipboard, Loader2, ShieldAlert, ShieldCheck, UserMinus, UserPlus } from "lucide-react";
import { FormEvent, useState } from "react";
import { toast } from "sonner";

function AccessContent() {
  const { user } = useAuth();
  const [email, setEmail] = useState("");
  const [expiresInDays, setExpiresInDays] = useState(7);
  const [invitationUrl, setInvitationUrl] = useState("");
  const utils = trpc.useUtils();
  const access = trpc.adminAccess.list.useQuery(undefined, { enabled: user?.role === "owner" });
  const invite = trpc.adminAccess.createInvitation.useMutation({
    onSuccess: async result => {
      setInvitationUrl(result.invitationUrl);
      setEmail("");
      await utils.adminAccess.list.invalidate();
      toast.success("Administrator invitation created.");
    },
  });
  const revokeInvite = trpc.adminAccess.revokeInvitation.useMutation({ onSuccess: () => utils.adminAccess.list.invalidate() });
  const setRole = trpc.adminAccess.setRole.useMutation({ onSuccess: () => utils.adminAccess.list.invalidate() });

  if (user?.role !== "owner") {
    return <div className="mx-auto max-w-2xl rounded-2xl border border-amber-200 bg-amber-50 p-8 text-amber-950"><ShieldAlert className="h-8 w-8" /><h1 className="mt-4 text-3xl font-bold">Owner access required</h1><p className="mt-3 leading-7">Administrator invitations and role changes are restricted to the VIBHA project owner.</p></div>;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    await invite.mutateAsync({ email, expiresInDays, origin: window.location.origin });
  }

  async function copyInvitation() {
    await navigator.clipboard.writeText(invitationUrl);
    toast.success("Invitation link copied.");
  }

  return (
    <div className="mx-auto max-w-7xl">
      <p className="text-sm font-bold uppercase tracking-[0.16em] text-[#b94700]">Owner Controls</p>
      <h1 className="mt-2 text-4xl font-bold text-[#071f49]">Administrator access</h1>
      <p className="mt-3 max-w-3xl leading-7 text-slate-600">Issue invitation-only access, review authorized administrators, revoke permissions, and audit access events.</p>

      <div className="mt-8 grid gap-6 xl:grid-cols-[420px_1fr]">
        <section className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <UserPlus className="h-7 w-7 text-[#b94700]" />
          <h2 className="mt-4 text-2xl font-bold text-[#071f49]">Invite an administrator</h2>
          <form onSubmit={submit} className="mt-5 space-y-4">
            <div><Label htmlFor="administrator-email">Administrator email</Label><Input id="administrator-email" type="email" autoComplete="email" className="mt-2" value={email} onChange={event => setEmail(event.target.value)} required /></div>
            <div><Label htmlFor="invitation-expiration">Invitation expires in</Label><select id="invitation-expiration" className="mt-2 w-full rounded-md border border-input bg-white px-3" value={expiresInDays} onChange={event => setExpiresInDays(Number(event.target.value))}><option value={1}>1 day</option><option value={3}>3 days</option><option value={7}>7 days</option><option value={14}>14 days</option><option value={30}>30 days</option></select></div>
            {invite.error ? <p role="alert" className="text-sm font-semibold text-red-700">{invite.error.message}</p> : null}
            <Button type="submit" disabled={invite.isPending} className="w-full bg-[#071f49] text-white hover:bg-[#173b70]">{invite.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}Create secure invitation</Button>
          </form>
          {invitationUrl ? <div role="status" aria-live="polite" className="mt-5 rounded-xl border border-emerald-200 bg-emerald-50 p-4"><p className="font-bold text-emerald-950">Invitation ready</p><p className="mt-2 break-all text-xs text-emerald-900">{invitationUrl}</p><Button type="button" variant="outline" className="mt-3 border-emerald-300 bg-white" onClick={copyInvitation}><Clipboard className="mr-2 h-4 w-4" />Copy link</Button></div> : null}
        </section>

        <section className="rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-200 p-6"><h2 className="text-2xl font-bold text-[#071f49]">Authorized accounts</h2></div>
          {access.isLoading ? <p role="status" className="p-6 text-slate-600">Loading access records…</p> : null}
          {access.error ? <p role="alert" className="p-6 text-red-700">{access.error.message}</p> : null}
          <div className="divide-y divide-slate-200">
            {access.data?.administrators.map(administrator => <div key={administrator.id} className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex items-center gap-2"><p className="font-bold text-[#071f49]">{administrator.name || "Unnamed account"}</p><Badge className={administrator.role === "owner" ? "bg-[#071f49] text-white" : "bg-emerald-100 text-emerald-900"}>{administrator.role}</Badge></div><p className="mt-1 text-sm text-slate-600">{administrator.email || "Email unavailable"}</p></div>{administrator.role !== "owner" ? <Button variant="outline" disabled={setRole.isPending} onClick={() => setRole.mutate({ userId: administrator.id, role: "user" })} className="border-rose-200 bg-white text-rose-800"><UserMinus className="mr-2 h-4 w-4" />Revoke access</Button> : <span className="inline-flex items-center gap-2 text-sm font-semibold text-slate-600"><ShieldCheck className="h-4 w-4" />Protected owner</span>}</div>)}
          </div>
        </section>
      </div>

      <div className="mt-8 grid gap-6 xl:grid-cols-2">
        <section className="rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-200 p-6"><h2 className="text-2xl font-bold text-[#071f49]">Invitations</h2></div><div className="divide-y divide-slate-200">{access.data?.invitations.map(invitation => <div key={invitation.id} className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold text-[#071f49]">{invitation.email}</p><p className="mt-1 text-xs text-slate-500">{invitation.status} · expires {new Date(invitation.expiresAt).toLocaleString()}</p></div>{invitation.status === "pending" ? <Button variant="outline" onClick={() => revokeInvite.mutate({ invitationId: invitation.id })} disabled={revokeInvite.isPending} className="border-slate-300 bg-white">Revoke invitation</Button> : <span className="inline-flex items-center gap-2 text-sm text-slate-600"><Check className="h-4 w-4" />{invitation.status}</span>}</div>)}</div></section>
        <section className="rounded-2xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-200 p-6"><h2 className="text-2xl font-bold text-[#071f49]">Recent access activity</h2></div><div className="divide-y divide-slate-200">{access.data?.auditEvents.map(event => <div key={event.id} className="p-5"><p className="font-semibold text-[#071f49]">{event.action.replaceAll(".", " ")}</p><p className="mt-1 text-xs text-slate-500">{new Date(event.createdAt).toLocaleString()}</p></div>)}</div></section>
      </div>
    </div>
  );
}

export default function AdminAccessManagement() {
  return <DashboardLayout><AccessContent /></DashboardLayout>;
}
