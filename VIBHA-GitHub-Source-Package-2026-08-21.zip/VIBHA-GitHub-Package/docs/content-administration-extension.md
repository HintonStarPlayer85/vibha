# VIBHA Content Administration Extension

## Operating Objective

The Content Administration extension will convert the current certification editor into a controlled institutional operations environment. It will manage certification content, instructor records, cohort configuration, student rosters, protected cohort resources, administrator access, and auditable communication delivery without creating an open registration path or exposing student data on public routes.

## Access and Role Model

Public administrator self-registration is prohibited. The platform will support three roles: **user**, **admin**, and **owner**. A user may authenticate but cannot enter Content Administration. An admin may manage certifications, instructors, cohorts, rosters, resources, and approved cohort communications. The owner has all admin permissions and exclusive authority to create, revoke, and review administrator invitations.

| Control | Required Behavior |
|---|---|
| Invitation creation | Owner-only; captures invitee email, expiration, creator, and status |
| Token handling | Cryptographically random token; only the SHA-256 digest is stored |
| Invitation use | Single use, time limited, revocable, and bound to the invited email address |
| Identity binding | Invitee signs in through the existing OAuth flow; acceptance promotes only the matching authenticated account |
| Session authorization | Every Content Administration API remains protected server-side; hiding navigation is not treated as security |
| Revocation | Owner may return an admin to the standard user role; revocation is recorded |
| Audit trail | Invitation, acceptance, role change, instructor, cohort, roster, resource, and communication actions record the authenticated actor and timestamp |

The public access page will explain that Content Administration is invitation-only. An invitation acceptance page will inspect the token, preserve the invitation across OAuth, identify invalid or expired invitations, and prevent authenticated but non-permissioned accounts from entering protected modules.

## Content Administration Information Architecture

| Module | Primary Responsibilities |
|---|---|
| Certifications | Existing certification catalog content, status, enrollment URLs, SEO, and instructor assignments |
| Instructors | Instructor identity, email, title, credentials, biography, expertise, active status, and certification assignments |
| Cohorts | Program selection, instructor, dates, time zone, Zoom information, roster, resources, and communication history |
| Administrator Access | Owner-only invitations, pending access, active administrators, revocation, and access audit history |

## Instructor Domain

Instructor records are normalized and reusable. A certification may have multiple instructors, and an instructor may be assigned to multiple certifications. Deactivation preserves historical assignments while removing the instructor from new-assignment options. Cohort assignment references the same instructor record rather than copying instructor content.

## Cohort Domain

Each cohort belongs to one certification or program and has one primary instructor. The cohort records a title, operational status, start and end date, time zone, schedule summary, Zoom join URL, meeting ID, optional passcode, and internal notes. Student roster entries record only the minimum operational data requested: student name, email, active status, and timestamps. A unique cohort-and-email constraint prevents duplicate roster entries.

> Cohort records are educational operations data, not clinical records. Administrators will be instructed not to upload protected health information, clinical documentation, or unnecessary sensitive personal data.

## Resource Domain

Syllabi, class schedules, and other files will be stored in the platform’s managed S3 storage; the database will store only the object key, secure application URL, filename, MIME type, size, resource classification, active state, and audit metadata. External resource links are supported through the same resource model. Removing a resource makes the database reference inactive because the current storage service does not expose destructive object deletion.

## Resend Communication Architecture

Resend is the approved transactional provider. Cohort notices will be sent as individual recipient messages or privacy-safe provider batch entries so one student never receives another student’s email address. Resend supports transactional APIs, attachments, batch sending, delivery monitoring, and provider idempotency keys, which align with the required duplicate-send controls.[1] Resend requires a verified sending domain before a VIBHA-domain sender can be used.[2]

| Stage | System Control |
|---|---|
| Draft | Administrator selects the cohort, subject, message, Zoom details, and resources |
| Preview | System shows the exact active recipient list, count, included links, and message content |
| Confirmation | Administrator must explicitly confirm; the interface disables repeat submission while processing |
| Persistence | Communication and recipient records are created before external delivery begins |
| Delivery | Server sends one privacy-safe message per active student with a deterministic idempotency key |
| Reconciliation | Provider message identifiers are stored per recipient |
| Event tracking | Verified webhook events update sent, delivered, bounced, complained, or failed states |
| Retry | Only unsent or explicitly failed recipients may be retried; already accepted provider messages are excluded |

Live sending remains disabled until `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, and `RESEND_WEBHOOK_SECRET` are present and the sender domain is verified. The CMS will display configuration status and permit draft/preview testing without implying that an email was sent.

## Public-Site Corrections

Program Areas footer links will route to database-generated program-area pages instead of relying on fragile filter-only links. Every route transition will restore the document to the top and move programmatic focus to the destination’s primary content region. The footer and institutional standing content will display **Accreditation Pending** with the explanatory statement: “VIBHA is pursuing institutional accreditation. Accreditation has not yet been awarded.”

The footer will include the exact credit, **“This site was designed by Designing Virtuosity,”** linked to `https://www.designingvirtuosty.com` with external-link security attributes and an accessible new-window label.

## Acceptance Gates

The extension is not release-ready until unauthorized users are rejected by direct API calls, invitation tokens cannot be reused, roster duplicates are prevented, files are stored outside the application filesystem, email recipients remain private, confirmed sends are idempotent, provider failures are visible and retry-safe, all new routes pass keyboard and responsive validation, and the full production build completes without TypeScript, test, browser-console, or network errors.

## References

[1]: https://resend.com/docs/dashboard/emails/introduction "Resend: Sending Emails"
[2]: https://resend.com/docs/dashboard/emails/introduction "Resend: Domain Verification Requirement"
