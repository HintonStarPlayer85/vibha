CREATE TABLE `certificate_approval_escalations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cohortStudentId` int NOT NULL,
	`certificationId` int NOT NULL,
	`recipientUserId` int NOT NULL,
	`recipientName` varchar(180) NOT NULL,
	`recipientEmail` varchar(320) NOT NULL,
	`subject` varchar(240) NOT NULL,
	`idempotencyKey` varchar(128) NOT NULL,
	`providerMessageId` varchar(180),
	`status` enum('queued','accepted','failed') NOT NULL DEFAULT 'queued',
	`retryCount` int NOT NULL DEFAULT 0,
	`errorCode` varchar(120),
	`errorMessage` text,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certificate_approval_escalations_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificate_escalation_student_recipient_unique` UNIQUE(`cohortStudentId`,`recipientUserId`)
);
--> statement-breakpoint
CREATE TABLE `certificate_approval_history_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`certificateId` int NOT NULL,
	`exportedByUserId` int NOT NULL,
	`exportedByName` varchar(180) NOT NULL,
	`eventFilters` json,
	`reportSha256` varchar(64) NOT NULL,
	`attestation` varchar(128) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `certificate_approval_history_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `approvalEscalationEnabled` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `approvalEscalationDelayMinutes` int DEFAULT 1440 NOT NULL;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `approvalEscalationRecipientUserId` int;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD `completionApprovalRequestedAt` timestamp;--> statement-breakpoint
ALTER TABLE `certificate_approval_escalations` ADD CONSTRAINT `cert_escalation_student_fk` FOREIGN KEY (`cohortStudentId`) REFERENCES `cohort_students`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_approval_escalations` ADD CONSTRAINT `cert_escalation_cert_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_approval_escalations` ADD CONSTRAINT `cert_escalation_recipient_fk` FOREIGN KEY (`recipientUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_approval_history_reports` ADD CONSTRAINT `cert_history_report_cert_fk` FOREIGN KEY (`certificateId`) REFERENCES `issued_certificates`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_approval_history_reports` ADD CONSTRAINT `cert_history_report_exporter_fk` FOREIGN KEY (`exportedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_escalation_recipient_status_idx` ON `certificate_approval_escalations` (`recipientUserId`,`status`);--> statement-breakpoint
CREATE INDEX `certificate_history_report_created_idx` ON `certificate_approval_history_reports` (`certificateId`,`createdAt`);--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD CONSTRAINT `cert_profile_escalation_recipient_fk` FOREIGN KEY (`approvalEscalationRecipientUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_program_profile_escalation_recipient_idx` ON `certificate_program_profiles` (`approvalEscalationRecipientUserId`);--> statement-breakpoint
CREATE INDEX `cohort_student_completion_escalation_idx` ON `cohort_students` (`status`,`completionApprovalStatus`,`completionApprovalRequestedAt`);
