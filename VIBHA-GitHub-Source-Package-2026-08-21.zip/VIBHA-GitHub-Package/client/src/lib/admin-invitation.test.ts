import { describe, expect, it } from "vitest";
import { invitationStatusGuidance } from "./admin-invitation";

describe("administrator invitation registration states", () => {
  it("keeps a pending invitation available for registration", () => {
    expect(invitationStatusGuidance("pending")).toBeNull();
  });

  it.each([
    ["expired", "expired", "new administrator invitation"],
    ["revoked", "revoked", "VIBHA owner"],
    ["accepted", "already been used", "Administrator Access"],
  ] as const)("provides a recovery path for %s invitations", (status, title, message) => {
    const guidance = invitationStatusGuidance(status);
    expect(guidance?.title).toContain(title);
    expect(guidance?.message).toContain(message);
  });
});
