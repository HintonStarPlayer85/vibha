import { useEffect } from "react";

const baseTitle = "VIBHA";

export function usePageMeta(title: string, description: string) {
  useEffect(() => {
    const resolvedTitle = title.includes("VIBHA") ? title : `${title} | ${baseTitle}`;
    document.title = resolvedTitle;
    let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!meta) {
      meta = document.createElement("meta");
      meta.name = "description";
      document.head.appendChild(meta);
    }
    meta.content = description;

    let canonical = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.rel = "canonical";
      document.head.appendChild(canonical);
    }
    canonical.href = `${window.location.origin}${window.location.pathname}`;

    const socialMeta = [
      ["property", "og:title", resolvedTitle],
      ["property", "og:description", description],
      ["property", "og:type", "website"],
      ["property", "og:url", canonical.href],
      ["name", "twitter:card", "summary_large_image"],
      ["name", "twitter:title", resolvedTitle],
      ["name", "twitter:description", description],
    ] as const;
    socialMeta.forEach(([attribute, key, content]) => {
      let element = document.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute(attribute, key);
        document.head.appendChild(element);
      }
      element.content = content;
    });
  }, [description, title]);
}

export function useStructuredData(id: string, data: Record<string, unknown> | null) {
  useEffect(() => {
    const existing = document.getElementById(id);
    existing?.remove();
    if (!data) return;
    const script = document.createElement("script");
    script.id = id;
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(data).replace(/</g, "\\u003c");
    document.head.appendChild(script);
    return () => script.remove();
  }, [data, id]);
}
