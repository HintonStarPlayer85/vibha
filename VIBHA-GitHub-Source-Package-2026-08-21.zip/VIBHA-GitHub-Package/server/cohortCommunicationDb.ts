import { and, asc, desc, eq, inArray } from "drizzle-orm";
import {
  administrationAuditEvents,
  certifications,
  cohortCommunicationEvents,
  cohortCommunicationRecipients,
  cohortCommunications,
  cohortResources,
  cohorts,
  cohortStudents,
  instructors,
} from "../drizzle/schema";
import type { CohortCommunicationDraft } from "../shared/administration";
import { getDb } from "./db";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is unavailable.");
  return db;
}

export function summarizeCommunicationContent(message: string) {
  const compact = message.replace(/\s+/g, " ").trim();
  if (compact.length <= 480) return compact;
  const boundary = compact.slice(0, 480).lastIndexOf(" ");
  return `${compact.slice(0, boundary > 360 ? boundary : 480).trim()}…`;
}

export async function getCohortMessageContext(input: CohortCommunicationDraft) {
  const db = await requireDb();
  const cohort = (
    await db
      .select({
        id: cohorts.id,
        title: cohorts.title,
        status: cohorts.status,
        certificationTitle: certifications.title,
        instructorName: instructors.name,
        startAt: cohorts.startAt,
        endAt: cohorts.endAt,
        timeZone: cohorts.timeZone,
        scheduleSummary: cohorts.scheduleSummary,
        zoomUrl: cohorts.zoomUrl,
        zoomMeetingId: cohorts.zoomMeetingId,
        zoomPasscode: cohorts.zoomPasscode,
      })
      .from(cohorts)
      .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
      .leftJoin(instructors, eq(cohorts.instructorId, instructors.id))
      .where(eq(cohorts.id, input.cohortId))
      .limit(1)
  )[0];
  if (!cohort) throw new Error("Cohort not found.");

  const recipients = await db
    .select({ id: cohortStudents.id, name: cohortStudents.name, email: cohortStudents.email })
    .from(cohortStudents)
    .where(and(eq(cohortStudents.cohortId, input.cohortId), eq(cohortStudents.status, "active")))
    .orderBy(asc(cohortStudents.name), asc(cohortStudents.email));

  const resources = input.resourceIds.length
    ? await db
        .select({
          id: cohortResources.id,
          title: cohortResources.title,
          description: cohortResources.description,
          resourceType: cohortResources.resourceType,
          audience: cohortResources.audience,
          url: cohortResources.url,
          displayOrder: cohortResources.displayOrder,
        })
        .from(cohortResources)
        .where(
          and(
            eq(cohortResources.cohortId, input.cohortId),
            eq(cohortResources.isActive, true),
            inArray(cohortResources.id, input.resourceIds),
            inArray(cohortResources.audience, ["students", "all"]),
          ),
        )
        .orderBy(asc(cohortResources.displayOrder), asc(cohortResources.title))
    : [];

  if (resources.length !== input.resourceIds.length) {
    throw new Error("One or more selected resources are unavailable to students.");
  }
  return { cohort, recipients, resources };
}

export async function findCommunicationByIdempotencyKey(idempotencyKey: string) {
  const db = await requireDb();
  return (
    await db.select().from(cohortCommunications).where(eq(cohortCommunications.idempotencyKey, idempotencyKey)).limit(1)
  )[0];
}

export async function createCommunicationSnapshot(args: {
  draft: CohortCommunicationDraft;
  previewHash: string;
  idempotencyKey: string;
  actorUserId: number;
  recipients: Array<{ id: number; name: string; email: string }>;
}) {
  const db = await requireDb();
  const existing = await findCommunicationByIdempotencyKey(args.idempotencyKey);
  if (existing) return { communication: existing, recipientRows: await getCommunicationRecipients(existing.id), existing: true as const };

  return db.transaction(async tx => {
    const result = await tx.insert(cohortCommunications).values({
      cohortId: args.draft.cohortId,
      senderUserId: args.actorUserId,
      communicationType: args.draft.communicationType,
      subject: args.draft.subject,
      contentSummary: summarizeCommunicationContent(args.draft.message),
      message: args.draft.message,
      includeZoom: args.draft.includeZoom,
      resourceIds: args.draft.resourceIds,
      previewHash: args.previewHash,
      idempotencyKey: args.idempotencyKey,
      provider: "resend",
      status: "processing",
      recipientCount: args.recipients.length,
    });
    const communicationId = Number(result[0].insertId);
    await tx.insert(cohortCommunicationRecipients).values(
      args.recipients.map(recipient => ({
        communicationId,
        studentId: recipient.id,
        studentName: recipient.name,
        email: recipient.email,
        status: "queued" as const,
      })),
    );
    await tx.insert(administrationAuditEvents).values({
      actorUserId: args.actorUserId,
      action: "cohort.communication.confirmed",
      entityType: "cohort_communication",
      entityId: String(communicationId),
      eventMetadata: { cohortId: args.draft.cohortId, recipientCount: args.recipients.length },
    });
    const communication = (
      await tx.select().from(cohortCommunications).where(eq(cohortCommunications.id, communicationId)).limit(1)
    )[0]!;
    const recipientRows = await tx
      .select()
      .from(cohortCommunicationRecipients)
      .where(eq(cohortCommunicationRecipients.communicationId, communicationId))
      .orderBy(asc(cohortCommunicationRecipients.id));
    return { communication, recipientRows, existing: false as const };
  });
}

export async function getCommunicationRecipients(communicationId: number) {
  const db = await requireDb();
  return db
    .select()
    .from(cohortCommunicationRecipients)
    .where(eq(cohortCommunicationRecipients.communicationId, communicationId))
    .orderBy(asc(cohortCommunicationRecipients.id));
}

export async function markRecipientsAccepted(
  items: Array<{ id: number; providerMessageId: string }>,
) {
  const db = await requireDb();
  const sentAt = new Date();
  for (const item of items) {
    await db
      .update(cohortCommunicationRecipients)
      .set({ providerMessageId: item.providerMessageId, status: "accepted", sentAt, lastEventAt: sentAt, errorCode: null, errorMessage: null })
      .where(eq(cohortCommunicationRecipients.id, item.id));
  }
}

export async function markRecipientsFailed(ids: number[], errorCode: string, errorMessage: string) {
  if (!ids.length) return;
  const db = await requireDb();
  await db
    .update(cohortCommunicationRecipients)
    .set({ status: "failed", errorCode: errorCode.slice(0, 120), errorMessage: errorMessage.slice(0, 5000), lastEventAt: new Date() })
    .where(inArray(cohortCommunicationRecipients.id, ids));
}

export async function incrementRecipientRetries(ids: number[]) {
  if (!ids.length) return;
  const db = await requireDb();
  for (const id of ids) {
    const recipient = (
      await db.select({ retryCount: cohortCommunicationRecipients.retryCount }).from(cohortCommunicationRecipients).where(eq(cohortCommunicationRecipients.id, id)).limit(1)
    )[0];
    if (recipient) {
      await db.update(cohortCommunicationRecipients).set({ retryCount: recipient.retryCount + 1, status: "queued", errorCode: null, errorMessage: null }).where(eq(cohortCommunicationRecipients.id, id));
    }
  }
}

export async function recomputeCommunicationStatus(communicationId: number) {
  const db = await requireDb();
  const recipients = await getCommunicationRecipients(communicationId);
  const counts = {
    accepted: recipients.filter(item => item.status === "accepted" || item.status === "delivered").length,
    delivered: recipients.filter(item => item.status === "delivered").length,
    failed: recipients.filter(item => item.status === "failed").length,
    bounced: recipients.filter(item => item.status === "bounced").length,
    complained: recipients.filter(item => item.status === "complained").length,
  };
  const adverse = counts.failed + counts.bounced + counts.complained;
  const status = adverse === recipients.length
    ? "failed"
    : adverse > 0
      ? "partial"
      : recipients.some(item => item.status === "queued")
        ? "processing"
        : "sent";
  await db.update(cohortCommunications).set({
    status,
    acceptedCount: counts.accepted,
    deliveredCount: counts.delivered,
    failedCount: counts.failed,
    bouncedCount: counts.bounced,
    complainedCount: counts.complained,
    sentAt: counts.accepted > 0 ? new Date() : undefined,
  }).where(eq(cohortCommunications.id, communicationId));
  return { status, ...counts, recipientCount: recipients.length };
}

export async function getCommunicationHistory(cohortId: number) {
  const db = await requireDb();
  const communications = await db.select().from(cohortCommunications).where(eq(cohortCommunications.cohortId, cohortId)).orderBy(desc(cohortCommunications.createdAt));
  if (!communications.length) return [];
  const recipients = await db.select().from(cohortCommunicationRecipients).where(inArray(cohortCommunicationRecipients.communicationId, communications.map(item => item.id))).orderBy(asc(cohortCommunicationRecipients.id));
  return communications.map(communication => ({
    ...communication,
    recipients: recipients.filter(recipient => recipient.communicationId === communication.id),
  }));
}

export async function getRetryContext(communicationId: number, recipientIds: number[]) {
  const db = await requireDb();
  const communication = (
    await db.select().from(cohortCommunications).where(eq(cohortCommunications.id, communicationId)).limit(1)
  )[0];
  if (!communication) throw new Error("Communication not found.");
  const recipients = await db
    .select()
    .from(cohortCommunicationRecipients)
    .where(and(eq(cohortCommunicationRecipients.communicationId, communicationId), inArray(cohortCommunicationRecipients.id, recipientIds), eq(cohortCommunicationRecipients.status, "failed")))
    .orderBy(asc(cohortCommunicationRecipients.id));
  if (recipients.length !== recipientIds.length) throw new Error("Only recipients with a failed delivery attempt can be retried.");
  return { communication, recipients };
}

const statusPriority: Record<string, number> = { queued: 0, accepted: 1, delivered: 2, failed: 3, bounced: 3, complained: 4 };

export async function applyResendWebhookEvent(input: {
  providerEventId: string;
  providerMessageId: string;
  eventType: string;
  occurredAt: Date;
  eventMetadata: Record<string, string | number | boolean | null>;
}) {
  const db = await requireDb();
  const recipient = (
    await db.select().from(cohortCommunicationRecipients).where(eq(cohortCommunicationRecipients.providerMessageId, input.providerMessageId)).limit(1)
  )[0];
  if (!recipient) return { processed: false as const, reason: "recipient_not_found" as const };
  const existingEvent = (
    await db.select({ id: cohortCommunicationEvents.id }).from(cohortCommunicationEvents).where(eq(cohortCommunicationEvents.providerEventId, input.providerEventId)).limit(1)
  )[0];
  if (existingEvent) return { processed: false as const, reason: "duplicate" as const };

  const mappedStatus = input.eventType === "email.sent" ? "accepted"
    : input.eventType === "email.delivered" ? "delivered"
      : input.eventType === "email.bounced" ? "bounced"
        : input.eventType === "email.complained" ? "complained"
          : input.eventType === "email.failed" ? "failed"
            : null;

  await db.transaction(async tx => {
    await tx.insert(cohortCommunicationEvents).values({
      recipientId: recipient.id,
      providerEventId: input.providerEventId,
      eventType: input.eventType,
      occurredAt: input.occurredAt,
      eventMetadata: input.eventMetadata,
    });
    if (mappedStatus && statusPriority[mappedStatus] >= statusPriority[recipient.status]) {
      await tx.update(cohortCommunicationRecipients).set({
        status: mappedStatus,
        deliveredAt: mappedStatus === "delivered" ? input.occurredAt : recipient.deliveredAt,
        lastEventAt: input.occurredAt,
        errorCode: mappedStatus === "failed" || mappedStatus === "bounced" ? input.eventType : recipient.errorCode,
      }).where(eq(cohortCommunicationRecipients.id, recipient.id));
    }
  });
  await recomputeCommunicationStatus(recipient.communicationId);
  return { processed: true as const, communicationId: recipient.communicationId, recipientId: recipient.id };
}

export async function recordRetryAudit(communicationId: number, recipientCount: number, actorUserId: number) {
  const db = await requireDb();
  await db.insert(administrationAuditEvents).values({
    actorUserId,
    action: "cohort.communication.retry.confirmed",
    entityType: "cohort_communication",
    entityId: String(communicationId),
    eventMetadata: { recipientCount },
  });
}
