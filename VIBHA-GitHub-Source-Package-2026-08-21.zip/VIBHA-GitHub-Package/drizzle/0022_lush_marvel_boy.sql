CREATE TABLE `certificate_template_test_deliveries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`certificationId` int NOT NULL,
	`templateType` enum('preview_reminder','approval_escalation') NOT NULL,
	`recipientUserId` int NOT NULL,
	`recipientName` varchar(180) NOT NULL,
	`recipientEmail` varchar(320) NOT NULL,
	`subject` varchar(240) NOT NULL,
	`providerMessageId` varchar(180),
	`status` enum('queued','accepted','failed') NOT NULL DEFAULT 'queued',
	`errorMessage` text,
	`createdByUserId` int NOT NULL,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certificate_template_test_deliveries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `certificate_template_test_deliveries` ADD CONSTRAINT `cert_test_cert_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_template_test_deliveries` ADD CONSTRAINT `cert_test_recipient_fk` FOREIGN KEY (`recipientUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_template_test_deliveries` ADD CONSTRAINT `cert_test_created_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_template_test_cert_created_idx` ON `certificate_template_test_deliveries` (`certificationId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `certificate_template_test_recipient_status_idx` ON `certificate_template_test_deliveries` (`recipientUserId`,`status`);
