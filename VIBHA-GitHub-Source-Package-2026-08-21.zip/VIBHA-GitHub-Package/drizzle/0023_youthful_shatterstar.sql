ALTER TABLE `certificate_program_profiles` ADD `approvalSlaTargetMinutes` int;
