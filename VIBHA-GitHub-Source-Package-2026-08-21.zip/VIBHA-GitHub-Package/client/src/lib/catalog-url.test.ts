import { describe, expect, it } from "vitest";
import { parseCatalogSearch, serializeCatalogSearch } from "./catalog-url";

describe("catalog URL state", () => {
  it("parses all supported shareable filters", () => {
    expect(
      parseCatalogSearch(
        "?q=documentation&category=compliance-documentation-operations&format=virtual-live&ceu=not-listed&cost=1000-1499&page=3",
      ),
    ).toEqual({
      q: "documentation",
      category: "compliance-documentation-operations",
      format: "virtual-live",
      ceu: "not-listed",
      cost: "1000-1499",
      page: 3,
    });
  });

  it("drops unsupported filter values and normalizes invalid pages", () => {
    expect(parseCatalogSearch("?format=telepathy&ceu=all&cost=free&page=-5")).toEqual({ page: 1 });
  });

  it("serializes a compact reload-safe query string", () => {
    expect(
      serializeCatalogSearch({
        q: "crisis response",
        category: "act-crisis-community-stabilization",
        format: "hybrid",
        page: 1,
      }),
    ).toBe("?q=crisis+response&category=act-crisis-community-stabilization&format=hybrid");
  });

  it("round-trips a filtered state without changing meaning", () => {
    const state = {
      category: "workforce-entry-foundations",
      ceu: "0.1-2" as const,
      cost: "under-1000" as const,
      page: 2,
    };
    expect(parseCatalogSearch(serializeCatalogSearch(state))).toEqual(state);
  });
});
