import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  adminCatalogQuerySchema,
  certificationInputSchema,
  certificationStatusSchema,
} from "../../shared/catalog";
import {
  createCertification,
  getAdminCatalog,
  getAdminCertificationById,
  getCertificationCategories,
  getInstructors,
  setCertificationStatus,
  updateCertification,
} from "../db";
import { adminProcedure, router } from "../_core/trpc";

function translateWriteError(error: unknown): never {
  if (error instanceof Error && error.message === "SLUG_CONFLICT") {
    throw new TRPCError({ code: "CONFLICT", message: "That certification slug is already in use." });
  }
  throw error;
}

export const adminCertificationsRouter = router({
  list: adminProcedure
    .input(adminCatalogQuerySchema.optional())
    .query(({ input }) => getAdminCatalog(input ?? {})),
  getById: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
    const certification = await getAdminCertificationById(input.id);
    if (!certification) throw new TRPCError({ code: "NOT_FOUND", message: "Certification not found." });
    return certification;
  }),
  options: adminProcedure.query(async () => ({
    categories: await getCertificationCategories(true),
    instructors: await getInstructors(),
  })),
  create: adminProcedure.input(certificationInputSchema).mutation(async ({ input }) => {
    try {
      return await createCertification(input);
    } catch (error) {
      return translateWriteError(error);
    }
  }),
  update: adminProcedure
    .input(z.object({ id: z.number().int().positive(), data: certificationInputSchema }))
    .mutation(async ({ input }) => {
      try {
        const updated = await updateCertification(input.id, input.data);
        if (!updated) throw new TRPCError({ code: "NOT_FOUND", message: "Certification not found." });
        return updated;
      } catch (error) {
        return translateWriteError(error);
      }
    }),
  setStatus: adminProcedure
    .input(z.object({ id: z.number().int().positive(), status: certificationStatusSchema }))
    .mutation(async ({ input }) => {
      const updated = await setCertificationStatus(input.id, input.status);
      if (!updated) throw new TRPCError({ code: "NOT_FOUND", message: "Certification not found." });
      return updated;
    }),
});

