import type { TrpcContext } from "./_core/context";
import { beforeEach, describe, expect, it, vi } from "vitest";

const resendMocks = vi.hoisted(() => ({ batchSend: vi.fn(), verify: vi.fn(), domainList: vi.fn() }));
const dbMocks = vi.hoisted(() => ({
  getCohortMessageContext: vi.fn(),
  createCommunicationSnapshot: vi.fn(),
  getCommunicationHistory: vi.fn(),
  getRetryContext: vi.fn(),
  incrementRecipientRetries: vi.fn(),
  markRecipientsAccepted: vi.fn(),
  markRecipientsFailed: vi.fn(),
  recomputeCommunicationStatus: vi.fn(),
  recordRetryAudit: vi.fn(),
  applyResendWebhookEvent: vi.fn(),
}));

vi.mock("resend", () => ({
  Resend: class {
    batch = { send: resendMocks.batchSend };
    webhooks = { verify: resendMocks.verify };
    domains = { list: resendMocks.domainList };
  },
}));

vi.mock("./cohortCommunicationDb", async () => {
  const actual = await vi.importActual<typeof import("./cohortCommunicationDb")>("./cohortCommunicationDb");
  return { ...actual, ...dbMocks };
});

import { appRouter } from "./routers";
import { previewCohortCommunication, sendConfirmedCohortCommunication } from "./resendCohort";

type User = NonNullable<TrpcContext["user"]>;

function context(role: User["role"]): TrpcContext {
  const user: User = {
    id: 31,
    openId: `${role}-communication-test`,
    email: `${role}@example.com`,
    name: "Communication Test",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const draft = {
  cohortId: 9,
  communicationType: "zoom_details" as const,
  subject: "Virtual classroom information",
  message: "Please use the information below for our next class session.",
  includeZoom: true,
  resourceIds: [4],
};

function messageContext(count = 2) {
  return {
    cohort: {
      id: 9,
      title: "Fall Documentation Cohort",
      status: "active" as const,
      certificationTitle: "Documentation Excellence Certification",
      instructorName: "Alex Instructor",
      startAt: new Date("2026-09-01T22:00:00.000Z"),
      endAt: new Date("2026-10-01T22:00:00.000Z"),
      timeZone: "America/New_York",
      scheduleSummary: "Tuesdays at 6 PM",
      zoomUrl: "https://zoom.us/j/123456789",
      zoomMeetingId: "123 456 789",
      zoomPasscode: "VIBHA",
    },
    recipients: Array.from({ length: count }, (_, index) => ({ id: index + 1, name: `Student ${index + 1}`, email: `student${index + 1}@example.com` })),
    resources: [{ id: 4, title: "Course syllabus", description: null, resourceType: "syllabus" as const, audience: "students" as const, url: "https://files.example.com/syllabus.pdf", displayOrder: 1 }],
  };
}

describe("Cohort communication controls", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.RESEND_API_KEY = "re_test_valid_format";
    process.env.RESEND_FROM_EMAIL = "VIBHA Education <programs@mail.vibha.example>";
    process.env.RESEND_REPLY_TO_EMAIL = "programs@vibha.example";
    process.env.RESEND_WEBHOOK_SECRET = "whsec_test";
    dbMocks.getCohortMessageContext.mockResolvedValue(messageContext());
    resendMocks.domainList.mockResolvedValue({ data: { data: [{ name: "mail.vibha.example", status: "verified" }] }, error: null, headers: null });
    dbMocks.recomputeCommunicationStatus.mockResolvedValue({ status: "sent", accepted: 2, delivered: 0, failed: 0, bounced: 0, complained: 0, recipientCount: 2 });
  });

  it("denies communication configuration to standard users", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.adminCohortCommunications.configuration()).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("builds a deterministic preview from the current roster, Zoom data, and student-facing resources", async () => {
    const first = await previewCohortCommunication(draft);
    const second = await previewCohortCommunication(draft);
    expect(first.previewHash).toBe(second.previewHash);
    expect(first.recipientCount).toBe(2);
    expect(first.recipients.map(item => item.email)).toEqual(["student1@example.com", "student2@example.com"]);
    expect(first.zoom?.url).toBe("https://zoom.us/j/123456789");
  });

  it("sends separate messages per recipient and applies a provider idempotency key", async () => {
    const preview = await previewCohortCommunication(draft);
    dbMocks.createCommunicationSnapshot.mockResolvedValue({
      communication: { id: 44 },
      recipientRows: preview.recipients.map((recipient, index) => ({ id: 100 + index, studentName: recipient.name, email: recipient.email, status: "queued" })),
      existing: false,
    });
    resendMocks.batchSend.mockResolvedValue({ data: { data: [{ id: "email_1" }, { id: "email_2" }] }, error: null, headers: null });

    await sendConfirmedCohortCommunication({ ...draft, previewHash: preview.previewHash, idempotencyKey: "a2abfe27-3435-41a5-8cab-65be422de682", confirmedRecipientCount: 2, confirmation: true }, 31);

    const [payload, options] = resendMocks.batchSend.mock.calls[0];
    expect(payload).toHaveLength(2);
    expect(payload.every((email: { to: string[]; cc?: string[]; bcc?: string[] }) => email.to.length === 1 && !email.cc && !email.bcc)).toBe(true);
    expect(payload.map((email: { to: string[] }) => email.to[0])).toEqual(["student1@example.com", "student2@example.com"]);
    expect(options.idempotencyKey).toContain("vibha/a2abfe27-3435-41a5-8cab-65be422de682/0");
    expect(dbMocks.markRecipientsAccepted).toHaveBeenCalledWith([{ id: 100, providerMessageId: "email_1" }, { id: 101, providerMessageId: "email_2" }]);
  });

  it("does not call Resend again when the same communication has no queued recipients", async () => {
    const preview = await previewCohortCommunication(draft);
    dbMocks.createCommunicationSnapshot.mockResolvedValue({
      communication: { id: 44 },
      recipientRows: [{ id: 100, studentName: "Student 1", email: "student1@example.com", status: "accepted" }],
      existing: true,
    });
    await sendConfirmedCohortCommunication({ ...draft, previewHash: preview.previewHash, idempotencyKey: "a2abfe27-3435-41a5-8cab-65be422de682", confirmedRecipientCount: 2, confirmation: true }, 31);
    expect(resendMocks.batchSend).not.toHaveBeenCalled();
  });

  it("isolates a failed provider chunk instead of exposing recipients or duplicating accepted chunks", async () => {
    dbMocks.getCohortMessageContext.mockResolvedValue(messageContext(101));
    const preview = await previewCohortCommunication(draft);
    dbMocks.createCommunicationSnapshot.mockResolvedValue({
      communication: { id: 45 },
      recipientRows: preview.recipients.map((recipient, index) => ({ id: 200 + index, studentName: recipient.name, email: recipient.email, status: "queued" })),
      existing: false,
    });
    resendMocks.batchSend
      .mockResolvedValueOnce({ data: { data: Array.from({ length: 100 }, (_, index) => ({ id: `accepted_${index}` })) }, error: null, headers: null })
      .mockResolvedValueOnce({ data: null, error: { name: "rate_limit_exceeded", message: "Try again", statusCode: 429 }, headers: null });

    await sendConfirmedCohortCommunication({ ...draft, previewHash: preview.previewHash, idempotencyKey: "c476c0d6-4573-46df-b44e-0e8191f6320f", confirmedRecipientCount: 101, confirmation: true }, 31);

    expect(resendMocks.batchSend).toHaveBeenCalledTimes(2);
    expect(dbMocks.markRecipientsAccepted.mock.calls[0][0]).toHaveLength(100);
    expect(dbMocks.markRecipientsFailed).toHaveBeenCalledWith([300], "rate_limit_exceeded", "Try again");
  });
});
