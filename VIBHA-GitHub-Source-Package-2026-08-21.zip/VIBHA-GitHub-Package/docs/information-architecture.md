# VIBHA Information Architecture

## Public Navigation

The primary navigation labels are fixed exactly as required: **Home, Certifications, Programs, About, Contact**. The global shell includes a skip link, utility context, sticky navigation, mobile drawer, responsive program access, and a structured institutional footer. The public site does not display a learner account, LMS, payment, faculty, or portal control.

| Route | Page Responsibility | Primary Action |
|---|---|---|
| `/` | Institutional positioning, featured certifications, pathways, agency training, delivery formats | Browse Certifications |
| `/certifications` | Searchable and filterable certification catalog | Request Program Information |
| `/certifications/:slug` | Database-generated certification detail and related programs | Request Program Information |
| `/programs` | Category pathways, agency packages, and delivery models | Explore Certifications |
| `/about` | Mission, vision, institutional standing, leadership, and workforce role | Contact VIBHA |
| `/contact` | Individual, agency, and general inquiry routing | Submit Inquiry |
| `/privacy` | Privacy notice for inquiry data | Return to Contact |
| `/accessibility` | Accessibility commitment and feedback path | Contact VIBHA |
| `/admin/certifications` | Authenticated, admin-only certification index | Create Certification |
| `/admin/certifications/new` | Authenticated certification editor | Save Certification |
| `/admin/certifications/:id/edit` | Authenticated certification editor | Save Changes |

## Certification Discovery Model

The catalog is a single scalable route backed by typed API queries. Search covers title, summary, description, category, audience, and learning outcomes. Filters combine through URL query parameters and remain shareable and reload-safe.

| Query Parameter | Meaning | Example |
|---|---|---|
| `q` | Keyword search | `?q=documentation` |
| `category` | Topic-area slug | `?category=compliance-documentation-operations` |
| `format` | Primary delivery format | `?format=virtual-live` |
| `ceu` | CEU range bucket | `?ceu=1-2` |
| `cost` | Tuition range bucket | `?cost=1000-1999` |
| `page` | Pagination-ready result page | `?page=2` |

Card components always surface **category, level, CEUs, format, and cost**. Detail routes resolve by stable slug and include a breadcrumb, overview, ideal audience, objectives, curriculum topics, eligibility, schedule, delivery, CEUs, instructor information, career relevance, related programs, and a program-preselected inquiry action.

## CMS Boundary

The admin CMS is infrastructure for managing public certification records; it is not a learner portal. Authentication uses the existing secure OAuth flow, and authorization is enforced in both the interface and tRPC procedures through the existing admin role. Editors can create, edit, publish, deactivate, and reactivate records without modifying source files. Deactivation is preferred to deletion to preserve links, audit history, and future restoration.

## Scale and Future Compatibility

The platform uses route templates, shared components, normalized categories and instructors, typed API procedures, and database-driven records. Growing from the initial catalog to hundreds of certifications requires adding database records rather than adding routes or duplicating page components. Future learner, faculty, payment, LMS, CRM, and credential modules can be added behind separate route groups and database domains without restructuring the public information architecture.

