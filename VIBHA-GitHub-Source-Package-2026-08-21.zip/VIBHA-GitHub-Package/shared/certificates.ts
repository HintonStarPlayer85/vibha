import { z } from "zod";

export const certificateStatusSchema = z.enum(["issued", "revoked", "superseded"]);

export const certificateRepositoryQuerySchema = z.object({
  q: z.string().trim().max(160).optional(),
  status: certificateStatusSchema.optional(),
});

export const certificateIssueSchema = z.object({
  cohortStudentId: z.number().int().positive(),
  previewAcknowledgementToken: z.string().uuid("Generate and acknowledge a current certificate preview before issuing."),
});

export const certificatePreviewRequestSchema = z.object({
  cohortStudentId: z.number().int().positive(),
});

export const certificatePreviewSchema = certificatePreviewRequestSchema;

export const certificatePreviewAcknowledgementSchema = z.object({
  acknowledgementToken: z.string().uuid(),
  notes: z.string().trim().max(1000).optional().default(""),
});

export const certificateHistorySchema = z.object({
  certificateId: z.number().int().positive(),
  eventTypes: z.array(z.enum([
    "certificate.completion.resubmitted",
    "certificate.completion.returned",
    "certificate.completion.first_approved",
    "certificate.completion.approved",
    "certificate.preview.acknowledged",
    "certificate.issued",
    "certificate.reissued",
    "certificate.revoked",
    "certificate.history.exported",
    "certificate.approval.escalated",
    "certificate.approval.escalation_resent",
  ])).max(11).optional(),
});

export const signatureCropSchema = z.object({
  x: z.number().min(0).max(1),
  y: z.number().min(0).max(1),
  size: z.number().positive().max(1),
  zoom: z.number().min(1).max(3),
});

export const certificateReissueSchema = z.object({
  certificateId: z.number().int().positive(),
});

export const certificateRevokeSchema = z.object({
  certificateId: z.number().int().positive(),
  reason: z.string().trim().min(5, "Enter a revocation reason.").max(500),
});

export const certificateDownloadSchema = z.object({
  certificateId: z.number().int().positive(),
});

export const certificateCompletionReviewSchema = z.object({
  cohortStudentId: z.number().int().positive(),
  decision: z.enum(["approve", "return"]),
  notes: z.string().trim().max(1000).optional().default(""),
});

export const certificateCompletionResubmitSchema = z.object({
  cohortStudentId: z.number().int().positive(),
});

export const completionNotificationResendSchema = z.object({
  notificationId: z.number().int().positive(),
});

export const certificateApprovalEscalationResendSchema = z.object({
  escalationId: z.number().int().positive(),
});

export const certificateApprovalEscalationReassignSchema = z.object({
  escalationId: z.number().int().positive(),
  recipientUserId: z.number().int().positive(),
});

export const certificateGovernanceDashboardSchema = z.object({
  fromDate: z.string().date().optional(),
  toDate: z.string().date().optional(),
}).superRefine((value, context) => {
  if (value.fromDate && value.toDate && value.fromDate > value.toDate) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["toDate"], message: "The end date must be on or after the start date." });
  }
});

export const certificateGovernanceDashboardExportSchema = certificateGovernanceDashboardSchema.safeExtend({
  format: z.enum(["csv", "pdf"]),
});

export const certificateTemplateTestHistorySchema = z.object({
  certificationId: z.number().int().positive().optional(),
});

export const certificateTemplateTestSendSchema = z.object({
  certificationId: z.number().int().positive(),
  templateType: z.enum(["preview_reminder", "approval_escalation"]),
});

export const certificateProgramProfileSchema = z.object({
  certificationId: z.number().int().positive(),
  completionNarrative: z.string().trim().max(3000).optional().default(""),
  instructionalHours: z.string().trim().max(160).optional().default(""),
  supervisedPracticalTraining: z.string().trim().max(180).optional().default(""),
  complianceStatement: z.string().trim().max(3000).optional().default(""),
  accreditingBodyName: z.string().trim().max(240).optional().default(""),
  licenseNumber: z.string().trim().max(160).optional().default(""),
  executiveName: z.string().trim().max(220).optional().default("Jacquese Hinton"),
  executiveTitle: z.string().trim().max(220).optional().default("Founder & Director of Institutional Strategy"),
  courseInstructorSignatoryName: z.string().trim().max(220).optional().default(""),
  courseInstructorSignatoryTitle: z.string().trim().max(220).optional().default(""),
  isHighStakes: z.boolean().optional().default(false),
  previewAcknowledgementExpirationMinutes: z.number().int().min(5).max(1440).optional().default(30),
  previewReminderEnabled: z.boolean().optional().default(true),
  previewReminderLeadMinutes: z.number().int().min(1).max(1439).optional().default(10),
  previewReminderEmailSubject: z.string().trim().max(240).optional().default(""),
  previewReminderEmailBody: z.string().trim().max(5000).optional().default(""),
  approvalEscalationEnabled: z.boolean().optional().default(false),
  approvalEscalationDelayMinutes: z.number().int().min(30).max(10080).optional().default(1440),
  approvalEscalationRecipientUserId: z.number().int().positive().nullable().optional().default(null),
  approvalEscalationEmailSubject: z.string().trim().max(240).optional().default(""),
  approvalEscalationEmailBody: z.string().trim().max(5000).optional().default(""),
  approvalSlaTargetMinutes: z.number().int().min(30).max(43200).nullable().optional().default(null),
}).superRefine((value, context) => {
  if (value.previewReminderEnabled && value.previewReminderLeadMinutes >= value.previewAcknowledgementExpirationMinutes) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["previewReminderLeadMinutes"], message: "Reminder lead time must be shorter than the preview acknowledgement expiration." });
  }
  if (value.approvalEscalationEnabled && !value.approvalEscalationRecipientUserId) {
    context.addIssue({ code: z.ZodIssueCode.custom, path: ["approvalEscalationRecipientUserId"], message: "Select the second administrator who should receive delayed-approval escalation notices." });
  }
  const allowedMergeFields = new Set(["administratorName", "credentialTitle", "cohortTitle", "expiresAt", "studentName"]);
  for (const [key, template] of [["previewReminderEmailSubject", value.previewReminderEmailSubject], ["previewReminderEmailBody", value.previewReminderEmailBody], ["approvalEscalationEmailSubject", value.approvalEscalationEmailSubject], ["approvalEscalationEmailBody", value.approvalEscalationEmailBody]] as const) {
    const mergeFields = template.match(/\{\{\s*([^{}]+?)\s*\}\}/g) ?? [];
    for (const field of mergeFields) {
      const name = field.replace(/^\{\{\s*|\s*\}\}$/g, "");
      if (!allowedMergeFields.has(name)) context.addIssue({ code: z.ZodIssueCode.custom, path: [key], message: `Unsupported merge field ${field}. Use administratorName, credentialTitle, cohortTitle, expiresAt, or studentName.` });
    }
  }
});

export const certificateVerifySchema = z.object({
  reference: z.string().trim().toUpperCase().regex(/^VIBHA-[0-9]{4}-[A-F0-9]{8,32}$/, "Enter the certificate number printed on the document."),
  token: z.string().trim().regex(/^[a-f0-9]{32,128}$/i).optional(),
});

export type CertificateRepositoryQuery = z.infer<typeof certificateRepositoryQuerySchema>;
export type CertificateVerifyInput = z.infer<typeof certificateVerifySchema>;
export type CertificateProgramProfileInput = z.infer<typeof certificateProgramProfileSchema>;
