CREATE TABLE `online_completion_transcripts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`enrollmentId` int NOT NULL,
	`recipientName` varchar(220) NOT NULL,
	`courseTitle` varchar(300) NOT NULL,
	`courseSlug` varchar(240) NOT NULL,
	`ceus` decimal(6,2) NOT NULL,
	`completedAtSnapshot` timestamp NOT NULL,
	`moduleCount` int NOT NULL,
	`lessonCount` int NOT NULL,
	`storageKey` varchar(800) NOT NULL,
	`url` varchar(1000) NOT NULL,
	`checksum` varchar(128) NOT NULL,
	`generatedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `online_completion_transcripts_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_transcript_enrollment_unique` UNIQUE(`enrollmentId`)
);
--> statement-breakpoint
CREATE TABLE `online_course_invitations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`recipientName` varchar(180) NOT NULL,
	`recipientEmail` varchar(320) NOT NULL,
	`tokenHash` varchar(128) NOT NULL,
	`status` enum('pending','accepted','expired','canceled','failed') NOT NULL DEFAULT 'pending',
	`deliveryStatus` enum('queued','sent','failed') NOT NULL DEFAULT 'queued',
	`providerMessageId` varchar(255),
	`deliveryError` varchar(1000),
	`invitedByUserId` int NOT NULL,
	`acceptedByUserId` int,
	`sentAt` timestamp,
	`acceptedAt` timestamp,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_course_invitations_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_invitation_token_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `online_learner_module_notes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`courseId` int NOT NULL,
	`moduleId` int NOT NULL,
	`content` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_learner_module_notes_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_note_user_module_unique` UNIQUE(`userId`,`moduleId`)
);
--> statement-breakpoint
ALTER TABLE `online_completion_transcripts` ADD CONSTRAINT `online_transcript_enrollment_fk` FOREIGN KEY (`enrollmentId`) REFERENCES `online_course_enrollments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_invitations` ADD CONSTRAINT `online_invitation_course_fk` FOREIGN KEY (`courseId`) REFERENCES `online_courses`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_invitations` ADD CONSTRAINT `online_invitation_sender_fk` FOREIGN KEY (`invitedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_invitations` ADD CONSTRAINT `online_invitation_acceptor_fk` FOREIGN KEY (`acceptedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_learner_module_notes` ADD CONSTRAINT `online_note_user_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_learner_module_notes` ADD CONSTRAINT `online_note_course_fk` FOREIGN KEY (`courseId`) REFERENCES `online_courses`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_learner_module_notes` ADD CONSTRAINT `online_note_module_fk` FOREIGN KEY (`moduleId`) REFERENCES `online_course_modules`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `online_transcript_course_generated_idx` ON `online_completion_transcripts` (`courseSlug`,`generatedAt`);--> statement-breakpoint
CREATE INDEX `online_invitation_course_recipient_idx` ON `online_course_invitations` (`courseId`,`recipientEmail`,`status`);--> statement-breakpoint
CREATE INDEX `online_invitation_expiry_idx` ON `online_course_invitations` (`status`,`expiresAt`);--> statement-breakpoint
CREATE INDEX `online_note_user_course_updated_idx` ON `online_learner_module_notes` (`userId`,`courseId`,`updatedAt`);
