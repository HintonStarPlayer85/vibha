export const siteContentDefaults = {
  "home.hero.eyebrow": "Virginia’s behavioral health workforce institute",
  "home.hero.title": "Developing the workforce behind",
  "home.hero.highlight": "behavioral health excellence.",
  "home.hero.description": "VIBHA equips professionals and organizations with practical education, credible workforce preparation, and operationally relevant certification pathways.",
  "home.programDirectory.title": "Find the credential aligned with your next responsibility.",
  "home.programDirectory.description": "Explore structured pathways for workforce entry, direct service, crisis response, documentation, operations, leadership, and specialized behavioral health roles.",
  "home.programAreas.title": "Six connected pathways. One workforce mission.",
  "home.programAreas.description": "Move directly into the topic area that reflects your role, service environment, or organizational priority.",
  "home.pathways.title": "Education that advances with the work.",
  "home.pathways.description": "VIBHA organizes learning as a progression from foundational readiness to specialized practice and systems leadership.",
  "home.agencyTraining.title": "Agency training built around organizational capability.",
  "home.agencyTraining.description": "VIBHA connects education to onboarding, documentation quality, compliance, leadership, retention, program readiness, and operating discipline.",
  "home.flexibleAccess.title": "Designed for working professionals and active organizations.",
  "home.flexibleAccess.description": "Choose from delivery models that expand access without reducing educational rigor.",
  "programs.hero.title": "A workforce education system built for role readiness and organizational strength.",
  "programs.hero.description": "VIBHA connects certification pathways, agency training, and flexible delivery models into one scalable behavioral health workforce platform.",
  "programs.pathways.title": "Move from foundational preparation to advanced systems leadership.",
  "programs.pathways.description": "Each program family organizes related certifications around the realities of behavioral health service delivery, operations, compliance, and workforce development.",
  "programs.training.title": "Capability-building packages for organizations under real operating pressure.",
  "programs.training.description": "Agency training is structured as an organizational solution, not bulk course purchasing. Packages can be adapted to workforce size, service model, risk profile, and implementation priorities.",
  "programs.delivery.title": "Access designed around workforce realities.",
  "programs.delivery.description": "Cohort timing and delivery format vary by program. VIBHA confirms current availability during the inquiry and enrollment process.",
  "about.hero.title": "Workforce advancement grounded in competence, ethics, and community impact.",
  "about.hero.description": "The Virginia Institute for Behavioral Health & Advancement develops professionals and organizations prepared to meet the operating realities of behavioral health service delivery.",
  "about.mission.title": "Develop and advance a competent, diverse, and sustainable behavioral health workforce.",
  "about.mission.description": "VIBHA advances this mission through education, certification, and collaboration that improves lives and strengthens communities.",
  "about.vision.title": "A Virginia where every community has access to high-quality behavioral health services.",
  "about.vision.description": "That future requires services delivered by a strong, prepared, and supported workforce.",
  "about.philosophy.title": "People, standards, impact, and community operate as one system.",
  "about.philosophy.description": "VIBHA approaches workforce education as infrastructure. Stronger professionals support stronger organizations, and stronger organizations are better positioned to serve communities.",
  "about.leadership.title": "Leadership connected to institutional execution.",
  "about.leadership.description": "Meet the leaders guiding VIBHA’s institutional strategy, educational operations, clinical education, workforce programs, and business development.",
  "about.standing.title": "Institutional standing and credential transparency",
  "contact.hero.title": "Start with the right conversation.",
  "contact.hero.description": "Route your inquiry to certification information, agency workforce training, partnership development, or general institutional support.",
  "contact.inquiry.title": "Tell us what you need to move forward.",
  "contact.inquiry.description": "Use the routing field to connect your question to the appropriate program or organizational pathway. Do not use this form for emergencies or clinical services.",
  "contact.professionals.description": "Ask about program fit, eligibility, schedule, delivery, and enrollment steps.",
  "contact.organizations.description": "Discuss workforce size, operating priorities, training scope, and timeline.",
  "leadership.hero.title": "The people guiding VIBHA’s institutional mission.",
  "leadership.hero.description": "Meet the leaders responsible for institutional strategy, educational operations, clinical education, workforce programs, and partnership development.",
  "leadership.directory.title": "Institutional leadership connected to execution.",
  "leadership.directory.description": "Select a leader to move directly to the complete biography provided for publication.",
  "leadership.cta.title": "Start the right institutional conversation.",
  "leadership.cta.description": "Route a leadership, partnership, workforce education, or program inquiry through VIBHA’s inquiry center.",
} as const;

export const leadershipProfileOverrideKeys = [
  "leadership.profile.jacquese-hinton.name",
  "leadership.profile.jacquese-hinton.title",
  "leadership.profile.jacquese-hinton.biography",
  "leadership.profile.candice-womack.name",
  "leadership.profile.candice-womack.title",
  "leadership.profile.candice-womack.biography",
  "leadership.profile.beverly-cobbs.name",
  "leadership.profile.beverly-cobbs.title",
  "leadership.profile.beverly-cobbs.biography",
  "leadership.profile.welton-loftin.name",
  "leadership.profile.welton-loftin.title",
  "leadership.profile.welton-loftin.biography",
] as const;

export type SiteContentDefaultKey = keyof typeof siteContentDefaults;
export type LeadershipProfileOverrideKey = (typeof leadershipProfileOverrideKeys)[number];
export type SiteContentKey = SiteContentDefaultKey | LeadershipProfileOverrideKey;

export const siteContentKeys = [
  ...(Object.keys(siteContentDefaults) as SiteContentDefaultKey[]),
  ...leadershipProfileOverrideKeys,
] as unknown as [SiteContentKey, ...SiteContentKey[]];

export type SiteContentGroup = "Home" | "Programs" | "About" | "Contact" | "Leadership";

export type SiteContentDefinition = {
  key: SiteContentDefaultKey;
  group: SiteContentGroup;
  label: string;
  helper: string;
  maxLength: number;
};

const definitions: SiteContentDefinition[] = [
  ["home.hero.eyebrow", "Home", "Hero eyebrow", "Small context line above the homepage headline.", 140],
  ["home.hero.title", "Home", "Hero headline", "First line of the main homepage headline.", 120],
  ["home.hero.highlight", "Home", "Hero headline highlight", "Orange-highlighted completion of the homepage headline.", 120],
  ["home.hero.description", "Home", "Hero introduction", "Short institutional introduction beneath the homepage headline.", 500],
  ["home.programDirectory.title", "Home", "Program directory heading", "Heading above featured certifications.", 180],
  ["home.programDirectory.description", "Home", "Program directory introduction", "Description above featured certifications.", 600],
  ["home.programAreas.title", "Home", "Program areas heading", "Heading above the program-area tiles.", 180],
  ["home.programAreas.description", "Home", "Program areas introduction", "Description above the program-area tiles.", 600],
  ["home.pathways.title", "Home", "Career pathway heading", "Heading for the career-pathway section.", 180],
  ["home.pathways.description", "Home", "Career pathway introduction", "Description for the career-pathway section.", 600],
  ["home.agencyTraining.title", "Home", "Agency training heading", "Heading for the agency-training feature.", 180],
  ["home.agencyTraining.description", "Home", "Agency training introduction", "Description for the agency-training feature.", 600],
  ["home.flexibleAccess.title", "Home", "Flexible access heading", "Heading for delivery-format access information.", 180],
  ["home.flexibleAccess.description", "Home", "Flexible access introduction", "Description for delivery-format access information.", 600],
  ["programs.hero.title", "Programs", "Hero headline", "Main Programs page heading.", 180],
  ["programs.hero.description", "Programs", "Hero introduction", "Main Programs page introduction.", 600],
  ["programs.pathways.title", "Programs", "Certification pathways heading", "Heading above the program-area tiles.", 180],
  ["programs.pathways.description", "Programs", "Certification pathways introduction", "Description above the program-area tiles.", 600],
  ["programs.training.title", "Programs", "Agency training heading", "Heading above the agency-training packages.", 180],
  ["programs.training.description", "Programs", "Agency training introduction", "Description above the agency-training packages.", 700],
  ["programs.delivery.title", "Programs", "Delivery formats heading", "Heading for delivery-format information.", 180],
  ["programs.delivery.description", "Programs", "Delivery formats introduction", "Description for delivery-format information.", 600],
  ["about.hero.title", "About", "Hero headline", "Main About page heading.", 180],
  ["about.hero.description", "About", "Hero introduction", "Main About page introduction.", 600],
  ["about.mission.title", "About", "Mission statement", "Primary mission statement.", 260],
  ["about.mission.description", "About", "Mission explanation", "Supporting mission explanation.", 600],
  ["about.vision.title", "About", "Vision statement", "Primary vision statement.", 260],
  ["about.vision.description", "About", "Vision explanation", "Supporting vision explanation.", 600],
  ["about.philosophy.title", "About", "Institutional philosophy heading", "Heading above VIBHA’s philosophy pillars.", 220],
  ["about.philosophy.description", "About", "Institutional philosophy introduction", "Description above VIBHA’s philosophy pillars.", 700],
  ["about.leadership.title", "About", "Leadership preview heading", "Heading above the leadership-team preview.", 180],
  ["about.leadership.description", "About", "Leadership preview introduction", "Description above the leadership-team preview.", 700],
  ["about.standing.title", "About", "Institutional standing heading", "Heading above the accreditation and credential-transparency disclosure.", 200],
  ["contact.hero.title", "Contact", "Hero headline", "Main Contact page heading.", 180],
  ["contact.hero.description", "Contact", "Hero introduction", "Main Contact page introduction.", 600],
  ["contact.inquiry.title", "Contact", "Inquiry center heading", "Heading beside the inquiry form.", 180],
  ["contact.inquiry.description", "Contact", "Inquiry center guidance", "Routing and safety guidance beside the inquiry form.", 600],
  ["contact.professionals.description", "Contact", "Individual professionals guidance", "Text in the individual-professionals contact card.", 420],
  ["contact.organizations.description", "Contact", "Organizations guidance", "Text in the organizations contact card.", 420],
  ["leadership.hero.title", "Leadership", "Hero headline", "Main Leadership page heading.", 180],
  ["leadership.hero.description", "Leadership", "Hero introduction", "Main Leadership page introduction.", 600],
  ["leadership.directory.title", "Leadership", "Directory heading", "Heading above the leadership profile directory.", 180],
  ["leadership.directory.description", "Leadership", "Directory introduction", "Description above the leadership profile directory.", 600],
  ["leadership.cta.title", "Leadership", "Inquiry call to action heading", "Heading for the Leadership page contact call to action.", 180],
  ["leadership.cta.description", "Leadership", "Inquiry call to action description", "Description for the Leadership page contact call to action.", 600],
].map(([key, group, label, helper, maxLength]) => ({
  key: key as SiteContentDefaultKey,
  group: group as SiteContentGroup,
  label: label as string,
  helper: helper as string,
  maxLength: maxLength as number,
}));

export const siteContentDefinitions = definitions;

export function mergeSiteContent(overrides?: Record<string, string> | null) {
  const publicOverrides = Object.fromEntries(
    Object.entries(overrides ?? {}).filter(([key]) => key in siteContentDefaults),
  );
  return { ...siteContentDefaults, ...publicOverrides } as Record<SiteContentDefaultKey, string>;
}
