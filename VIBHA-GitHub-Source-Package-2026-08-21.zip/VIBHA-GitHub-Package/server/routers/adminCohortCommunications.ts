import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  cohortCommunicationConfirmSchema,
  cohortCommunicationDraftSchema,
  cohortCommunicationRetrySchema,
} from "../../shared/administration";
import { getCommunicationHistory } from "../cohortCommunicationDb";
import {
  getResendConfiguration,
  previewCohortCommunication,
  retryFailedCohortRecipients,
  sendConfirmedCohortCommunication,
  verifyResendSenderDomain,
} from "../resendCohort";
import { adminProcedure, router } from "../_core/trpc";

function communicationError(error: unknown): never {
  const message = error instanceof Error ? error.message : "The cohort communication could not be processed.";
  if (/not found|changed after preview|roster|resource|Zoom|configured|failed delivery|active student/i.test(message)) {
    throw new TRPCError({ code: "BAD_REQUEST", message });
  }
  throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "The cohort communication could not be processed." });
}

export const adminCohortCommunicationsRouter = router({
  configuration: adminProcedure.query(async () => {
    const config = getResendConfiguration();
    const senderDomain = await verifyResendSenderDomain();
    return {
      readyToSend: config.readyToSend && senderDomain.verified,
      webhookReady: config.webhookReady,
      missing: config.missing,
      from: config.from,
      replyTo: config.replyTo,
      senderDomain,
    };
  }),
  preview: adminProcedure.input(cohortCommunicationDraftSchema).mutation(async ({ input }) => {
    try { return await previewCohortCommunication(input); } catch (error) { communicationError(error); }
  }),
  send: adminProcedure.input(cohortCommunicationConfirmSchema).mutation(async ({ input, ctx }) => {
    try { return await sendConfirmedCohortCommunication(input, ctx.user.id); } catch (error) { communicationError(error); }
  }),
  history: adminProcedure.input(z.object({ cohortId: z.number().int().positive() })).query(async ({ input }) => {
    try { return await getCommunicationHistory(input.cohortId); } catch (error) { communicationError(error); }
  }),
  retry: adminProcedure.input(cohortCommunicationRetrySchema).mutation(async ({ input, ctx }) => {
    try {
      return await retryFailedCohortRecipients(
        { communicationId: input.communicationId, recipientIds: input.recipientIds },
        ctx.user.id,
      );
    } catch (error) { communicationError(error); }
  }),
});
