import { TRPCError } from "@trpc/server";
import { createHash, randomBytes } from "node:crypto";
import { z } from "zod";
import {
  administratorInvitationInputSchema,
  administratorStatusSchema,
  invitationAcceptSchema,
  invitationTokenSchema,
} from "../../shared/administration";
import {
  acceptAdministratorInvitation,
  administrationErrors,
  createAdministratorInvitation,
  getAdministratorInvitationPreview,
  listAdministratorAccess,
  revokeAdministratorInvitation,
  setAdministratorRole,
} from "../administrationDb";
import { ownerProcedure, protectedProcedure, publicProcedure, router } from "../_core/trpc";

export function hashInvitationToken(token: string) {
  return createHash("sha256").update(token).digest("hex");
}

function translateAccessError(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === administrationErrors.invitationExists) {
    throw new TRPCError({ code: "CONFLICT", message: "An active invitation already exists for this email address." });
  }
  if (message === administrationErrors.invitationExpired) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "This administrator invitation has expired." });
  }
  if (message === administrationErrors.invitationEmailMismatch) {
    throw new TRPCError({ code: "FORBIDDEN", message: "The signed-in account does not match the invited email address." });
  }
  if (message === administrationErrors.invitationInvalid) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "This administrator invitation is invalid or has already been used." });
  }
  if (message === administrationErrors.ownerProtected) {
    throw new TRPCError({ code: "FORBIDDEN", message: "The project owner role cannot be revoked." });
  }
  if (message === administrationErrors.userNotFound) {
    throw new TRPCError({ code: "NOT_FOUND", message: "The selected administrator account was not found." });
  }
  throw error;
}

export const adminAccessRouter = router({
  invitationPreview: publicProcedure.input(invitationTokenSchema).query(async ({ input }) => {
    const preview = await getAdministratorInvitationPreview(hashInvitationToken(input.token));
    if (!preview) throw new TRPCError({ code: "NOT_FOUND", message: "Administrator invitation not found." });
    return preview;
  }),
  acceptInvitation: protectedProcedure.input(invitationAcceptSchema).mutation(async ({ input, ctx }) => {
    try {
      return await acceptAdministratorInvitation({
        tokenHash: hashInvitationToken(input.token),
        confirmEmail: input.confirmEmail,
        userId: ctx.user.id,
        userEmail: ctx.user.email,
      });
    } catch (error) {
      translateAccessError(error);
    }
  }),
  list: ownerProcedure.query(() => listAdministratorAccess()),
  createInvitation: ownerProcedure
    .input(administratorInvitationInputSchema)
    .mutation(async ({ input, ctx }) => {
      const token = randomBytes(32).toString("base64url");
      const expiresAt = new Date(Date.now() + input.expiresInDays * 24 * 60 * 60 * 1000);
      try {
        const invitation = await createAdministratorInvitation({
          email: input.email,
          tokenHash: hashInvitationToken(token),
          expiresAt,
          actorUserId: ctx.user.id,
        });
        return {
          ...invitation,
          invitationUrl: `${input.origin.replace(/\/$/, "")}/admin/register?token=${encodeURIComponent(token)}`,
        };
      } catch (error) {
        translateAccessError(error);
      }
    }),
  revokeInvitation: ownerProcedure
    .input(z.object({ invitationId: z.number().int().positive() }))
    .mutation(async ({ input, ctx }) => {
      try {
        return await revokeAdministratorInvitation({
          invitationId: input.invitationId,
          actorUserId: ctx.user.id,
        });
      } catch (error) {
        translateAccessError(error);
      }
    }),
  setRole: ownerProcedure.input(administratorStatusSchema).mutation(async ({ input, ctx }) => {
    try {
      return await setAdministratorRole({ ...input, actorUserId: ctx.user.id });
    } catch (error) {
      translateAccessError(error);
    }
  }),
});
