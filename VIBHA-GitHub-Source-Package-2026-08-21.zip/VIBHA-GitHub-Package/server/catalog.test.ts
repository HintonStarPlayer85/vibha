import { beforeEach, describe, expect, it, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

const dbMocks = vi.hoisted(() => ({
  getCatalog: vi.fn(),
  getCertificationCategories: vi.fn(),
  getFeaturedCertifications: vi.fn(),
  getCertificationBySlug: vi.fn(),
  getFilterOptions: vi.fn(),
  createInquiry: vi.fn(),
  getAdminCatalog: vi.fn(),
  getAdminCertificationById: vi.fn(),
  getInstructors: vi.fn(),
  createCertification: vi.fn(),
  updateCertification: vi.fn(),
  setCertificationStatus: vi.fn(),
}));

vi.mock("./db", () => dbMocks);

import { appRouter } from "./routers";
import { catalogQuerySchema, certificationInputSchema } from "../shared/catalog";

function context(role: "admin" | "user" | null = null): TrpcContext {
  return {
    user:
      role === null
        ? null
        : {
            id: 1,
            openId: `${role}-user`,
            email: `${role}@example.com`,
            name: role === "admin" ? "Admin User" : "Standard User",
            loginMethod: "manus",
            role,
            createdAt: new Date(),
            updatedAt: new Date(),
            lastSignedIn: new Date(),
          },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

const validCertification = {
  title: "Clinical Documentation Certification",
  shortTitle: "Documentation Certification",
  slug: "clinical-documentation-certification",
  categoryId: 1,
  description:
    "A structured certification focused on defensible behavioral health documentation, service alignment, and operational quality.",
  summary: "Build practical documentation capability for behavioral health service environments.",
  valueStatement: "Documentation is an operating control, not an administrative afterthought.",
  objectives: ["Apply documentation standards to realistic service scenarios."],
  curriculumTopics: ["Medical necessity and service alignment"],
  idealAudience: ["Behavioral health professionals"],
  eligibilityRequirements: ["Professional or paraprofessional behavioral health role"],
  prerequisites: "No prior VIBHA certification required.",
  format: "Virtual live",
  deliveryLocation: "Online",
  deliveryMethods: ["Virtual Live Instruction"],
  schedule: "Cohort-based scheduling. Contact VIBHA for current availability.",
  duration: "4 weeks",
  ceus: 1.5,
  costCents: 89500,
  costDisplay: "$895",
  level: "Foundational",
  careerRelevance: "Supports documentation quality and role readiness.",
  enrollmentUrl: "https://example.com/enroll",
  inquiryType: "program-information",
  status: "published" as const,
  isFeatured: false,
  displayOrder: 10,
  seoTitle: "Clinical Documentation Certification | VIBHA",
  seoDescription: "Behavioral health documentation certification from VIBHA.",
  instructorIds: [1],
};

describe("catalog schemas", () => {
  it("applies bounded pagination defaults to URL-derived catalog input", () => {
    expect(catalogQuerySchema.parse({ q: "documentation" })).toMatchObject({
      q: "documentation",
      page: 1,
      pageSize: 12,
    });
  });

  it("rejects non-readable slugs before persistence", () => {
    const result = certificationInputSchema.safeParse({
      ...validCertification,
      slug: "Example Certification",
    });
    expect(result.success).toBe(false);
    if (!result.success) {
      expect(result.error.issues.some(issue => issue.path[0] === "slug")).toBe(true);
    }
  });

  it("accepts a complete certification payload used by the no-code editor", () => {
    expect(certificationInputSchema.parse(validCertification)).toMatchObject({
      slug: "clinical-documentation-certification",
      deliveryLocation: "Online",
      status: "published",
      ceus: 1.5,
    });
  });
});

describe("certification and inquiry procedures", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    dbMocks.getCatalog.mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 12, totalPages: 1 });
    dbMocks.getCertificationBySlug.mockResolvedValue(null);
    dbMocks.getCertificationCategories.mockResolvedValue([]);
    dbMocks.getFeaturedCertifications.mockResolvedValue([]);
    dbMocks.getFilterOptions.mockResolvedValue({ categories: [], levels: [], formats: [], ceuRanges: [], costRanges: [] });
    dbMocks.createInquiry.mockResolvedValue({ success: true, route: "general" });
  });

  it("passes normalized defaults into the public catalog query", async () => {
    const caller = appRouter.createCaller(context());
    await caller.certifications.list({ q: "leadership" });
    expect(dbMocks.getCatalog).toHaveBeenCalledWith({ q: "leadership", page: 1, pageSize: 12 });
  });

  it("does not expose missing or non-public certification detail records", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.certifications.bySlug({ slug: "not-public" })).rejects.toMatchObject({
      code: "NOT_FOUND",
    });
  });

  it("returns a published certification detail record from the public procedure", async () => {
    dbMocks.getCertificationBySlug.mockResolvedValueOnce({
      id: 12,
      title: "Clinical Documentation Certification",
      slug: "clinical-documentation-certification",
      status: "published",
    });
    const caller = appRouter.createCaller(context());
    await expect(
      caller.certifications.bySlug({ slug: "clinical-documentation-certification" }),
    ).resolves.toMatchObject({ id: 12, status: "published" });
  });

  it("requires explicit privacy consent before accepting an inquiry", async () => {
    const caller = appRouter.createCaller(context());
    await expect(
      caller.inquiries.submit({
        inquiryType: "general",
        name: "Inquiry User",
        email: "inquiry@example.com",
        message: "I would like information about VIBHA programs.",
        consent: false as true,
      }),
    ).rejects.toBeDefined();
    expect(dbMocks.createInquiry).not.toHaveBeenCalled();
  });

  it("filters honeypot submissions without writing an inquiry record", async () => {
    const caller = appRouter.createCaller(context());
    const result = await caller.inquiries.submit({
      inquiryType: "general",
      name: "Inquiry User",
      email: "inquiry@example.com",
      message: "I would like information about VIBHA programs.",
      consent: true,
      website: "automated-spam.example",
    });
    expect(result).toEqual({ success: true, route: "filtered" });
    expect(dbMocks.createInquiry).not.toHaveBeenCalled();
  });

  it("passes a consented program inquiry into persistence with routing metadata", async () => {
    dbMocks.createInquiry.mockResolvedValueOnce({ success: true, route: "program-information" });
    const caller = appRouter.createCaller(context());
    const input = {
      inquiryType: "program" as const,
      certificationId: 12,
      programRoute: "Clinical Documentation Certification",
      name: "Inquiry User",
      email: "inquiry@example.com",
      organization: "Example Agency",
      message: "Please provide the next available cohort and enrollment steps.",
      consent: true as const,
      sourcePath: "/certifications/clinical-documentation-certification",
    };
    await expect(caller.inquiries.submit(input)).resolves.toEqual({
      success: true,
      route: "program-information",
    });
    expect(dbMocks.createInquiry).toHaveBeenCalledWith(input);
  });

  it("blocks unauthenticated users before CMS database access", async () => {
    const caller = appRouter.createCaller(context());
    await expect(caller.adminCertifications.list({})).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    expect(dbMocks.getAdminCatalog).not.toHaveBeenCalled();
  });

  it("blocks non-admin users before CMS database access", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.adminCertifications.list({})).rejects.toMatchObject({ code: "FORBIDDEN" });
    expect(dbMocks.getAdminCatalog).not.toHaveBeenCalled();
  });
});
