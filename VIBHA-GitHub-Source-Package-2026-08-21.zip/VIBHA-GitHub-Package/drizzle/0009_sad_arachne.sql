CREATE TABLE `online_course_enrollments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`userId` int NOT NULL,
	`status` enum('enrolled','completed','withdrawn') NOT NULL DEFAULT 'enrolled',
	`enrolledAt` timestamp NOT NULL DEFAULT (now()),
	`lastAccessedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_course_enrollments_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_enrollment_course_user_unique` UNIQUE(`courseId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `online_lesson_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`enrollmentId` int NOT NULL,
	`lessonId` int NOT NULL,
	`completed` boolean NOT NULL DEFAULT false,
	`firstCompletedAt` timestamp,
	`lastOpenedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_lesson_progress_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_progress_enrollment_lesson_unique` UNIQUE(`enrollmentId`,`lessonId`)
);
--> statement-breakpoint
CREATE TABLE `online_module_quiz_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`enrollmentId` int NOT NULL,
	`quizId` int NOT NULL,
	`score` int NOT NULL,
	`passed` boolean NOT NULL,
	`answers` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `online_module_quiz_attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `online_module_quiz_questions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`quizId` int NOT NULL,
	`position` int NOT NULL,
	`prompt` text NOT NULL,
	`options` json NOT NULL,
	`correctOptionIndex` int NOT NULL,
	`explanation` text NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_module_quiz_questions_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_quiz_question_position_unique` UNIQUE(`quizId`,`position`)
);
--> statement-breakpoint
CREATE TABLE `online_module_quizzes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`moduleId` int NOT NULL,
	`title` varchar(220) NOT NULL,
	`passingScore` int NOT NULL DEFAULT 70,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_module_quizzes_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_quiz_module_unique` UNIQUE(`moduleId`)
);
--> statement-breakpoint
ALTER TABLE `online_course_enrollments` ADD CONSTRAINT `online_enrollment_course_fk` FOREIGN KEY (`courseId`) REFERENCES `online_courses`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_enrollments` ADD CONSTRAINT `online_enrollment_user_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_lesson_progress` ADD CONSTRAINT `online_progress_enrollment_fk` FOREIGN KEY (`enrollmentId`) REFERENCES `online_course_enrollments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_lesson_progress` ADD CONSTRAINT `online_progress_lesson_fk` FOREIGN KEY (`lessonId`) REFERENCES `online_course_lessons`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_module_quiz_attempts` ADD CONSTRAINT `online_quiz_attempt_enrollment_fk` FOREIGN KEY (`enrollmentId`) REFERENCES `online_course_enrollments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_module_quiz_attempts` ADD CONSTRAINT `online_quiz_attempt_quiz_fk` FOREIGN KEY (`quizId`) REFERENCES `online_module_quizzes`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_module_quiz_questions` ADD CONSTRAINT `online_quiz_question_quiz_fk` FOREIGN KEY (`quizId`) REFERENCES `online_module_quizzes`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_module_quizzes` ADD CONSTRAINT `online_quiz_module_fk` FOREIGN KEY (`moduleId`) REFERENCES `online_course_modules`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `online_enrollment_user_access_idx` ON `online_course_enrollments` (`userId`,`lastAccessedAt`);--> statement-breakpoint
CREATE INDEX `online_enrollment_course_status_idx` ON `online_course_enrollments` (`courseId`,`status`);--> statement-breakpoint
CREATE INDEX `online_progress_enrollment_updated_idx` ON `online_lesson_progress` (`enrollmentId`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `online_quiz_attempt_enrollment_created_idx` ON `online_module_quiz_attempts` (`enrollmentId`,`quizId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `online_quiz_attempt_quiz_passed_idx` ON `online_module_quiz_attempts` (`quizId`,`passed`);--> statement-breakpoint
CREATE INDEX `online_quiz_question_published_idx` ON `online_module_quiz_questions` (`quizId`,`isPublished`,`position`);--> statement-breakpoint
CREATE INDEX `online_quiz_module_published_idx` ON `online_module_quizzes` (`moduleId`,`isPublished`);
