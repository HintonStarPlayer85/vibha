import type { TrpcContext } from "./_core/context";
import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { cohortInputSchema, cohortRosterInputSchema } from "../shared/administration";

const cohortMocks = vi.hoisted(() => ({
  listCohorts: vi.fn(),
  getCohortById: vi.fn(),
  getCohortOptions: vi.fn(),
  createCohort: vi.fn(),
  updateCohort: vi.fn(),
  addCohortStudent: vi.fn(),
  updateCohortStudent: vi.fn(),
  removeCohortStudent: vi.fn(),
  createCohortResource: vi.fn(),
  createCohortResourceLink: vi.fn(),
  updateCohortResourceSettings: vi.fn(),
  setCohortResourceStatus: vi.fn(),
}));

const storageMocks = vi.hoisted(() => ({ storagePut: vi.fn() }));

vi.mock("./cohortDb", async () => {
  const actual = await vi.importActual<typeof import("./cohortDb")>("./cohortDb");
  return { ...actual, ...cohortMocks };
});

vi.mock("./storage", () => storageMocks);

import { appRouter } from "./routers";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function context(role: AuthenticatedUser["role"]): TrpcContext {
  const user: AuthenticatedUser = {
    id: 15,
    openId: `${role}-cohort-test`,
    email: `${role}@example.com`,
    name: "Cohort Test",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const validCohort = {
  title: "Fall Documentation Cohort",
  slug: "fall-documentation-cohort",
  certificationId: 4,
  instructorId: 2,
  certificateSignatoryInstructorId: null,
  status: "planned" as const,
  startAt: new Date("2026-09-01T22:00:00.000Z"),
  endAt: new Date("2026-10-15T23:00:00.000Z"),
  timeZone: "America/New_York",
  scheduleSummary: "Tuesdays at 6:00 PM Eastern",
  zoomUrl: "https://zoom.us/j/123456789",
  zoomMeetingId: "123 456 789",
  zoomPasscode: "VIBHA",
  administratorNotes: null,
};

describe("Cohort CMS", () => {
  beforeEach(() => vi.clearAllMocks());

  it("rejects a cohort ending before it begins", () => {
    expect(() => cohortInputSchema.parse({
      ...validCohort,
      endAt: new Date("2026-08-01T22:00:00.000Z"),
    })).toThrow(/End date must be after/);
  });

  it("normalizes roster email addresses and blocks duplicates within a cohort", () => {
    const result = cohortRosterInputSchema.safeParse({
      cohortId: 3,
      students: [
        { name: "Avery Cole", email: "STUDENT@EXAMPLE.COM", status: "active" },
        { name: "Avery Duplicate", email: "student@example.com", status: "active" },
      ],
    });
    expect(result.success).toBe(false);
    if (!result.success) expect(result.error.issues[0]?.message).toContain("only once");
  });

  it("passes the authenticated administrator into cohort creation", async () => {
    cohortMocks.createCohort.mockResolvedValue({ id: 21, ...validCohort });
    const caller = appRouter.createCaller(context("admin"));
    await caller.adminCohorts.create(validCohort);
    expect(cohortMocks.createCohort).toHaveBeenCalledWith(validCohort, 15);
  });

  it("allows the project owner to manage cohorts", async () => {
    cohortMocks.listCohorts.mockResolvedValue([]);
    const caller = appRouter.createCaller(context("owner"));
    await expect(caller.adminCohorts.list({})).resolves.toEqual([]);
  });

  it("denies Cohort CMS access to a standard authenticated user", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.adminCohorts.list({})).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
  });

  it("adds a normalized student roster entry through the protected cohort procedure", async () => {
    cohortMocks.addCohortStudent.mockResolvedValue({ id: 8, cohortId: 21, name: "Avery Cole", email: "student@example.com", status: "active" });
    const caller = appRouter.createCaller(context("admin"));
    await caller.adminCohorts.addStudent({
      cohortId: 21,
      data: { name: "Avery Cole", email: "STUDENT@EXAMPLE.COM", status: "active" },
    });
    expect(cohortMocks.addCohortStudent).toHaveBeenCalledWith(
      21,
      expect.objectContaining({ email: "student@example.com" }),
      15,
    );
  });

  it("uploads file bytes to managed storage and persists only storage metadata", async () => {
    storageMocks.storagePut.mockResolvedValue({ key: "cohorts/21/resource.pdf", url: "/manus-storage/cohorts/21/resource.pdf" });
    cohortMocks.createCohortResource.mockResolvedValue({ id: 14, cohortId: 21, title: "Course syllabus" });
    const caller = appRouter.createCaller(context("admin"));
    await caller.adminCohorts.uploadResource({
      cohortId: 21,
      title: "Course syllabus",
      description: null,
      resourceType: "syllabus",
      fileName: "syllabus.pdf",
      mimeType: "application/pdf",
      dataBase64: Buffer.from("test pdf bytes").toString("base64"),
      displayOrder: 0,
    });
    expect(storageMocks.storagePut).toHaveBeenCalledWith(
      expect.stringMatching(/^cohorts\/21\//),
      expect.any(Buffer),
      "application/pdf",
    );
    expect(cohortMocks.createCohortResource).toHaveBeenCalledWith(
      expect.objectContaining({
        cohortId: 21,
        storageKey: "cohorts/21/resource.pdf",
        url: "/manus-storage/cohorts/21/resource.pdf",
        actorUserId: 15,
      }),
    );
  });

  it("denies cohort resource uploads before storage access for a standard user", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.adminCohorts.uploadResource({
      cohortId: 21,
      title: "Course syllabus",
      description: null,
      resourceType: "syllabus",
      audience: "students",
      fileName: "syllabus.pdf",
      mimeType: "application/pdf",
      dataBase64: Buffer.from("test pdf bytes").toString("base64"),
      displayOrder: 0,
    })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    expect(storageMocks.storagePut).not.toHaveBeenCalled();
  });

  it("persists administrator-selected resource audience and display order", async () => {
    cohortMocks.updateCohortResourceSettings.mockResolvedValue({ id: 14, audience: "instructors", displayOrder: 5 });
    const caller = appRouter.createCaller(context("admin"));
    await caller.adminCohorts.updateResourceSettings({ id: 14, audience: "instructors", displayOrder: 5 });
    expect(cohortMocks.updateCohortResourceSettings).toHaveBeenCalledWith(14, "instructors", 5, 15);
  });
});
