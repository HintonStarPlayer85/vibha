import { CategoryTiles } from "@/components/programs/CategoryTiles";
import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { SectionHeading } from "@/components/public/SectionHeading";
import { Button } from "@/components/ui/button";
import { usePageMeta } from "@/hooks/usePageMeta";
import { useSiteContent } from "@/hooks/useSiteContent";
import { ArrowRight, Building2, CalendarDays, Laptop2, MoonStar, Presentation, UsersRound } from "lucide-react";
import { Link } from "wouter";

const agencyPackages = [
  ["Workforce Onboarding Package", "Prepare newly hired staff for documentation, ethics, compliance, communication, and role-specific service delivery."],
  ["Compliance Remediation Package", "Address audit findings, documentation deficiencies, operational vulnerabilities, and corrective workforce needs."],
  ["ACT Team Intensive Package", "Strengthen fidelity, acuity management, service scheduling, crisis coordination, multidisciplinary alignment, and documentation."],
  ["Behavioral Health Operations Package", "Stabilize workflows, staffing structures, scheduling systems, productivity oversight, and operational communication."],
  ["Executive Leadership & Governance Package", "Develop governance, workforce strategy, compliance oversight, accountability, and organizational sustainability."],
  ["Documentation Recovery & Audit Defense", "Improve documentation quality, reduce audit exposure, and strengthen defensibility across service systems."],
] as const;

export default function Programs() {
  const { content } = useSiteContent();
  usePageMeta("Programs | VIBHA", "Explore VIBHA certification pathways, agency workforce packages, and flexible educational delivery models.");
  return (
    <PublicLayout>
      <PageHero eyebrow="Programs" title={content["programs.hero.title"]} description={content["programs.hero.description"]} breadcrumbs={[{ label: "Programs" }]} actions={<><Button asChild className="bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><Link href="/certifications">Explore certifications <ArrowRight className="ml-2 h-4 w-4" /></Link></Button><Button asChild variant="outline" className="border-white/40 bg-transparent text-white hover:bg-white/10 hover:text-white"><Link href="/contact?type=agency">Agency consultation</Link></Button></>} />
      <section className="py-20 sm:py-24"><div className="container"><SectionHeading eyebrow="Certification pathways" title={content["programs.pathways.title"]} description={content["programs.pathways.description"]} /><div className="mt-12"><CategoryTiles /></div></div></section>
      <section className="bg-[#f6f8fb] py-20 sm:py-24"><div className="container"><SectionHeading eyebrow="Institutional & agency training" title={content["programs.training.title"]} description={content["programs.training.description"]} /><div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">{agencyPackages.map(([title, copy], index) => <article key={title} className="rounded-xl border border-slate-200 bg-white p-6"><span className="text-sm font-extrabold tracking-[0.14em] text-[#b94700]">{String(index + 1).padStart(2, "0")}</span><h3 className="mt-3 text-2xl font-bold text-[#071f49]">{title}</h3><p className="mt-3 text-sm leading-6 text-slate-600">{copy}</p><Link href={`/contact?type=agency&priority=${encodeURIComponent(title)}`} className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-[#173b70] hover:underline">Discuss this package <ArrowRight className="h-4 w-4" /></Link></article>)}</div></div></section>
      <section className="py-20 sm:py-24"><div className="container grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:items-start"><SectionHeading eyebrow="Delivery formats" title={content["programs.delivery.title"]} description={content["programs.delivery.description"]} /><div className="grid gap-4 sm:grid-cols-2">{[{ icon: Laptop2, title: "Virtual live instruction", copy: "Real-time, facilitated learning with structured interaction." }, { icon: Presentation, title: "Hybrid learning", copy: "Coordinated virtual and applied instructional components." }, { icon: MoonStar, title: "Evening cohorts", copy: "Scheduling designed to support working professionals." }, { icon: CalendarDays, title: "Weekend cohorts", copy: "Concentrated learning windows for greater access." }, { icon: UsersRound, title: "Workforce bootcamps", copy: "Focused preparation around defined role and operating needs." }, { icon: Building2, title: "Agency contract training", copy: "Virtual, hybrid, or onsite delivery for organizations." }].map(item => <article key={item.title} className="rounded-xl border border-slate-200 p-5"><item.icon className="h-6 w-6 text-[#b94700]" /><h3 className="mt-4 text-xl font-bold text-[#071f49]">{item.title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{item.copy}</p></article>)}</div></div></section>
    </PublicLayout>
  );
}
