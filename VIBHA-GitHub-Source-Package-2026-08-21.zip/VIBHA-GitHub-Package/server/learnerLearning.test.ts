import { beforeEach, describe, expect, it, vi } from "vitest";

const learnerDbMocks = vi.hoisted(() => ({
  enrollLearnerInCourse: vi.fn(),
  getLearnerCourseBySlug: vi.fn(),
  listLearnerDashboard: vi.fn(),
  submitLearnerModuleQuiz: vi.fn(),
  updateLearnerLessonProgress: vi.fn(),
  upsertModuleQuiz: vi.fn(),
  createModuleQuizQuestion: vi.fn(),
  updateModuleQuizQuestion: vi.fn(),
}));
const serviceMocks = vi.hoisted(() => ({ answerOnlineInstructor: vi.fn() }));

vi.mock("./learnerLearningDb", async () => {
  const actual = await vi.importActual<typeof import("./learnerLearningDb")>("./learnerLearningDb");
  return { ...actual, ...learnerDbMocks };
});
vi.mock("./onlineLearningService", () => serviceMocks);

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;
function context(role?: AuthenticatedUser["role"]): TrpcContext {
  const user = role ? { id: 61, openId: `${role}-learner`, email: `${role}@example.com`, name: "Learner Test", loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() } : null;
  return { user, req: { protocol: "https", headers: {}, get: () => "thevibha.org" } as unknown as TrpcContext["req"], res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"] };
}

describe("Learner delivery router", () => {
  beforeEach(() => vi.clearAllMocks());

  it("requires an authenticated account before exposing dashboard records", async () => {
    await expect(appRouter.createCaller(context()).learnerLearning.dashboard()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });

  it("enrolls only the signed-in learner in a published self-paced course", async () => {
    learnerDbMocks.enrollLearnerInCourse.mockResolvedValue({ certificationSlug: "workforce-foundations", enrollment: { userId: 61 } });
    await expect(appRouter.createCaller(context("user")).learnerLearning.enroll({ courseSlug: "workforce-foundations" })).resolves.toMatchObject({ certificationSlug: "workforce-foundations" });
    expect(learnerDbMocks.enrollLearnerInCourse).toHaveBeenCalledWith("workforce-foundations", 61);
  });

  it("persists progress only through the learner’s own enrollment context", async () => {
    learnerDbMocks.updateLearnerLessonProgress.mockResolvedValue({ completedLessonCount: 1, resumeLesson: { id: 501 } });
    await appRouter.createCaller(context("user")).learnerLearning.updateLessonProgress({ courseSlug: "workforce-foundations", lessonId: 501, completed: true });
    expect(learnerDbMocks.updateLearnerLessonProgress).toHaveBeenCalledWith("workforce-foundations", 501, true, 61);
  });

  it("records a quiz attempt and returns score-level immediate feedback", async () => {
    learnerDbMocks.submitLearnerModuleQuiz.mockResolvedValue({ score: 100, passed: true, passingScore: 70, feedback: [{ questionId: 3, correct: true, explanation: "Grounded in the approved lesson." }] });
    const response = await appRouter.createCaller(context("user")).learnerLearning.submitModuleQuiz({ courseSlug: "workforce-foundations", moduleId: 7, answers: [{ questionId: 3, selectedOptionIndex: 1 }] });
    expect(response).toMatchObject({ score: 100, passed: true, feedback: [{ questionId: 3, correct: true }] });
    expect(learnerDbMocks.submitLearnerModuleQuiz).toHaveBeenCalledWith({ courseSlug: "workforce-foundations", moduleId: 7, answers: [{ questionId: 3, selectedOptionIndex: 1 }] }, 61);
  });

  it("keeps the course-grounded AI instructor behind active learner access", async () => {
    learnerDbMocks.getLearnerCourseBySlug.mockResolvedValue({ id: 8, enrollment: { userId: 61 } });
    serviceMocks.answerOnlineInstructor.mockResolvedValue({ answer: "This is grounded in the approved course material." });
    await expect(appRouter.createCaller(context("user")).learnerLearning.askInstructor({ courseSlug: "workforce-foundations", question: "What is the core workflow?" })).resolves.toMatchObject({ answer: expect.any(String) });
    expect(learnerDbMocks.getLearnerCourseBySlug).toHaveBeenCalledWith("workforce-foundations", 61);
  });

  it("denies standard learners the ability to author graded module quizzes", async () => {
    await expect(appRouter.createCaller(context("user")).adminModuleQuizzes.upsert({ moduleId: 7, title: "Module assessment", passingScore: 70, isPublished: true })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("rejects a correct-answer index that does not belong to the submitted quiz options", async () => {
    await expect(appRouter.createCaller(context("admin")).adminModuleQuizzes.createQuestion({ quizId: 4, position: 1, prompt: "Which option is correct?", options: ["One", "Two"], correctOptionIndex: 3, explanation: "Review the module materials.", isPublished: true })).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});
