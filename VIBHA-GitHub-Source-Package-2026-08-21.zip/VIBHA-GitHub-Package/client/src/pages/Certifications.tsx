import { CertificationCard } from "@/components/certifications/CertificationCard";
import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { usePageMeta } from "@/hooks/usePageMeta";
import {
  CatalogUrlState,
  catalogReturnPath,
  parseCatalogSearch,
  serializeCatalogSearch,
} from "@/lib/catalog-url";
import { trpc } from "@/lib/trpc";
import { ChevronLeft, ChevronRight, Filter, Search, SlidersHorizontal, X } from "lucide-react";
import { FormEvent, useCallback, useEffect, useMemo, useState } from "react";

const selectClass = "mt-2 h-11 w-full rounded-md border border-input bg-white px-3 text-sm text-slate-900";

export default function Certifications() {
  usePageMeta("Certifications | VIBHA", "Search and filter VIBHA behavioral health workforce certifications by topic area, format, CEU range, and cost.");
  const [search, setSearch] = useState(() => window.location.search);
  const filters = useMemo(() => parseCatalogSearch(search), [search]);
  const [queryText, setQueryText] = useState(filters.q ?? "");
  const [mobileFilters, setMobileFilters] = useState(false);
  const queryInput = useMemo(() => ({ ...filters, pageSize: 12 }), [filters]);
  const { data: options } = trpc.certifications.filterOptions.useQuery();
  const { data, isLoading, isFetching, error } = trpc.certifications.list.useQuery(queryInput, {
    placeholderData: previous => previous,
  });

  useEffect(() => {
    const sync = () => setSearch(window.location.search);
    window.addEventListener("popstate", sync);
    return () => window.removeEventListener("popstate", sync);
  }, []);

  useEffect(() => setQueryText(filters.q ?? ""), [filters.q]);

  useEffect(() => {
    if (window.location.hash !== "#catalog-top") return;
    const destination = document.getElementById("catalog-top");
    if (!destination) return;
    requestAnimationFrame(() => {
      destination.scrollIntoView({ block: "start" });
      destination.focus({ preventScroll: true });
    });
  }, [search]);

  const updateFilters = useCallback((patch: Partial<CatalogUrlState>) => {
    const next = { ...parseCatalogSearch(window.location.search), ...patch };
    if (!("page" in patch)) next.page = 1;
    const nextSearch = serializeCatalogSearch(next);
    window.history.pushState({}, "", `/certifications${nextSearch}`);
    setSearch(nextSearch);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  function submitSearch(event: FormEvent) {
    event.preventDefault();
    updateFilters({ q: queryText.trim() || undefined });
  }

  const active = [
    filters.q ? { key: "q" as const, label: `Search: ${filters.q}` } : null,
    filters.category ? { key: "category" as const, label: options?.categories.find(item => item.slug === filters.category)?.name ?? filters.category } : null,
    filters.format ? { key: "format" as const, label: options?.formats.find(item => item.value === filters.format)?.label ?? filters.format } : null,
    filters.ceu ? { key: "ceu" as const, label: options?.ceuRanges.find(item => item.value === filters.ceu)?.label ?? filters.ceu } : null,
    filters.cost ? { key: "cost" as const, label: options?.costRanges.find(item => item.value === filters.cost)?.label ?? filters.cost } : null,
  ].filter(Boolean) as { key: keyof CatalogUrlState; label: string }[];

  const filtersForm = (
    <div className="space-y-5">
      <div>
        <Label htmlFor="category-filter">Topic area</Label>
        <select id="category-filter" value={filters.category ?? "all"} onChange={event => updateFilters({ category: event.target.value === "all" ? undefined : event.target.value })} className={selectClass}>
          <option value="all">All topic areas</option>
          {options?.categories.map(category => <option key={category.id} value={category.slug}>{category.name}</option>)}
        </select>
      </div>
      <div>
        <Label htmlFor="format-filter">Format</Label>
        <select id="format-filter" value={filters.format ?? "all"} onChange={event => updateFilters({ format: event.target.value === "all" ? undefined : event.target.value as CatalogUrlState["format"] })} className={selectClass}>
          <option value="all">All formats</option>
          {options?.formats.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
      </div>
      <div>
        <Label htmlFor="ceu-filter">CEU range</Label>
        <select id="ceu-filter" value={filters.ceu ?? "all"} onChange={event => updateFilters({ ceu: event.target.value === "all" ? undefined : event.target.value as CatalogUrlState["ceu"] })} className={selectClass}>
          <option value="all">All CEU levels</option>
          {options?.ceuRanges.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
      </div>
      <div>
        <Label htmlFor="cost-filter">Cost</Label>
        <select id="cost-filter" value={filters.cost ?? "all"} onChange={event => updateFilters({ cost: event.target.value === "all" ? undefined : event.target.value as CatalogUrlState["cost"] })} className={selectClass}>
          <option value="all">All cost ranges</option>
          {options?.costRanges.map(option => <option key={option.value} value={option.value}>{option.label}</option>)}
        </select>
      </div>
      {active.length ? <Button type="button" variant="outline" className="w-full border-slate-300 bg-white" onClick={() => { setQueryText(""); updateFilters({ q: undefined, category: undefined, format: undefined, ceu: undefined, cost: undefined, page: 1 }); }}>Clear all filters</Button> : null}
    </div>
  );

  return (
    <PublicLayout>
      <div id="catalog-top" tabIndex={-1} className="scroll-mt-28 outline-none"><PageHero eyebrow="Certification directory" title="Find the credential aligned with your role, responsibility, and next move." description="Search VIBHA’s database-backed certification portfolio and refine results by topic area, delivery format, CEU level, and cost." breadcrumbs={[{ label: "Certifications" }]} /></div>
      <section className="bg-[#f6f8fb] py-12 sm:py-16">
        <div className="container">
          <form data-reveal="scale" onSubmit={submitSearch} role="search" className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-[0_10px_35px_rgba(4,22,52,0.07)] sm:flex-row sm:p-5">
            <div className="relative flex-1"><Label htmlFor="catalog-search" className="sr-only">Search certifications</Label><Search className="pointer-events-none absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-500" /><Input id="catalog-search" value={queryText} onChange={event => setQueryText(event.target.value)} className="h-12 pl-11 text-base" placeholder="Search by certification, role, category, or subject" /></div>
            <Button type="submit" className="h-12 bg-[#071f49] px-6 text-white hover:bg-[#173b70]">Search directory</Button>
            <Button type="button" variant="outline" className="h-12 border-slate-300 bg-white lg:hidden" onClick={() => setMobileFilters(value => !value)} aria-expanded={mobileFilters} aria-controls="mobile-catalog-filters"><Filter className="mr-2 h-4 w-4" />Filters {active.length ? `(${active.length})` : ""}</Button>
          </form>
          {mobileFilters ? <div id="mobile-catalog-filters" className="mt-4 rounded-xl border border-slate-200 bg-white p-5 lg:hidden">{filtersForm}</div> : null}
        </div>
      </section>
      <section className="py-12 sm:py-16">
        <div className="container grid gap-8 lg:grid-cols-[270px_1fr] lg:items-start">
          <aside data-reveal="left" aria-label="Certification filters" className="sticky top-32 hidden rounded-xl border border-slate-200 bg-[#f6f8fb] p-5 lg:block">
            <div className="mb-5 flex items-center gap-2 border-b border-slate-200 pb-4"><SlidersHorizontal className="h-5 w-5 text-[#b94700]" /><h2 className="font-sans text-base font-bold text-[#071f49]">Filter certifications</h2></div>
            {filtersForm}
          </aside>
          <div>
            <div className="flex flex-col gap-4 border-b border-slate-200 pb-6 sm:flex-row sm:items-center sm:justify-between">
              <div aria-live="polite"><h2 className="font-sans text-xl font-bold text-[#071f49]">{isLoading ? "Loading certifications" : `${data?.total ?? 0} certification${data?.total === 1 ? "" : "s"}`}</h2><p className="mt-1 text-sm text-slate-600">{isFetching && !isLoading ? "Updating results…" : "Results are generated from the active VIBHA catalog."}</p></div>
              {active.length ? <div className="flex flex-wrap gap-2">{active.map(item => <button key={item.key} type="button" onClick={() => { if (item.key === "q") setQueryText(""); updateFilters({ [item.key]: undefined }); }} className="inline-flex items-center gap-1 rounded-full border border-[#173b70]/20 bg-[#eef3f9] px-3 py-1.5 text-xs font-semibold text-[#173b70] hover:bg-[#dce6f2]">{item.label}<X className="h-3 w-3" /><span className="sr-only">Remove {item.label} filter</span></button>)}</div> : null}
            </div>
            {error ? <div role="alert" className="mt-8 rounded-xl border border-red-200 bg-red-50 p-6 text-red-800"><h2 className="font-sans text-lg font-bold">The catalog could not be loaded.</h2><p className="mt-2 text-sm">Refresh the page or try again in a few moments.</p></div> : null}
            {isLoading ? <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">{Array.from({ length: 6 }).map((_, index) => <div key={index} className="h-[430px] animate-pulse rounded-xl bg-slate-100" />)}</div> : null}
            {!isLoading && data && data.items.length ? <div data-stagger className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">{data.items.map(certification => <CertificationCard key={certification.id} certification={certification} returnTo={catalogReturnPath()} />)}</div> : null}
            {!isLoading && data && data.items.length === 0 ? <div className="mt-8 rounded-2xl border border-slate-200 bg-[#f6f8fb] p-10 text-center"><Search className="mx-auto h-10 w-10 text-[#b94700]" /><h2 className="mt-4 text-3xl font-bold text-[#071f49]">No certifications match these filters.</h2><p className="mx-auto mt-3 max-w-xl leading-7 text-slate-600">Remove one or more filters, broaden your search language, or contact VIBHA for guidance on the best program pathway.</p><Button type="button" className="mt-6 bg-[#071f49] text-white hover:bg-[#173b70]" onClick={() => { setQueryText(""); updateFilters({ q: undefined, category: undefined, format: undefined, ceu: undefined, cost: undefined, page: 1 }); }}>Reset the directory</Button></div> : null}
            {data && data.totalPages > 1 ? <nav aria-label="Certification results pages" className="mt-10 flex items-center justify-between border-t border-slate-200 pt-6"><Button type="button" variant="outline" disabled={data.page <= 1} onClick={() => updateFilters({ page: data.page - 1 })} className="border-slate-300 bg-white"><ChevronLeft className="mr-1 h-4 w-4" />Previous</Button><p className="text-sm font-semibold text-slate-700">Page {data.page} of {data.totalPages}</p><Button type="button" variant="outline" disabled={data.page >= data.totalPages} onClick={() => updateFilters({ page: data.page + 1 })} className="border-slate-300 bg-white">Next<ChevronRight className="ml-1 h-4 w-4" /></Button></nav> : null}
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
