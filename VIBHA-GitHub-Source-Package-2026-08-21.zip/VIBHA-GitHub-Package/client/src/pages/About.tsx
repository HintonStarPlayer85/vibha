import { AccreditationPendingBadge } from "@/components/public/AccreditationPendingBadge";
import { LeadershipCard } from "@/components/leadership/LeadershipCard";
import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { SectionHeading } from "@/components/public/SectionHeading";
import { Button } from "@/components/ui/button";
import { getLeadershipTeam } from "@/data/leadership";
import { usePageMeta } from "@/hooks/usePageMeta";
import { useSiteContent } from "@/hooks/useSiteContent";
import { ArrowRight, Compass, HeartHandshake, Scale, ShieldCheck, UsersRound } from "lucide-react";
import { Link } from "wouter";
import { useMemo } from "react";

const pillars = [
  { icon: UsersRound, title: "Our people", copy: "We invest in professionals who strengthen communities and change lives." },
  { icon: ShieldCheck, title: "Our standards", copy: "We center ethical practice, evidence-informed education, operational quality, and accountability." },
  { icon: Compass, title: "Our impact", copy: "We prepare a workforce positioned to strengthen service delivery and behavioral health systems." },
  { icon: HeartHandshake, title: "Our community", copy: "We partner with organizations across Virginia to build stronger systems and healthier futures." },
];

export default function About() {
  const { content, overrides } = useSiteContent();
  const team = useMemo(() => getLeadershipTeam(overrides), [overrides]);
  usePageMeta("About VIBHA", "Learn about VIBHA’s mission, vision, institutional philosophy, leadership, and commitment to behavioral health workforce advancement.");
  return (
    <PublicLayout>
      <PageHero eyebrow="About VIBHA" title={content["about.hero.title"]} description={content["about.hero.description"]} breadcrumbs={[{ label: "About" }]} actions={<Button asChild className="bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><Link href="/contact">Connect with VIBHA <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>} />
      <section className="py-20 sm:py-24"><div className="container grid gap-6 lg:grid-cols-2"><article className="rounded-2xl bg-[#071f49] p-8 text-white sm:p-10"><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#ff9a52]">Mission</p><h2 className="mt-4 text-3xl font-bold">{content["about.mission.title"]}</h2><p className="mt-5 text-lg leading-8 text-slate-300">{content["about.mission.description"]}</p></article><article className="rounded-2xl border border-slate-200 bg-[#f6f8fb] p-8 sm:p-10"><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Vision</p><h2 className="mt-4 text-3xl font-bold text-[#071f49]">{content["about.vision.title"]}</h2><p className="mt-5 text-lg leading-8 text-slate-600">{content["about.vision.description"]}</p></article></div></section>
      <section className="bg-[#f6f8fb] py-20 sm:py-24"><div className="container"><SectionHeading align="center" eyebrow="Institutional philosophy" title={content["about.philosophy.title"]} description={content["about.philosophy.description"]} /><div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{pillars.map(item => <article key={item.title} className="rounded-xl border border-slate-200 bg-white p-6"><div className="flex h-11 w-11 items-center justify-center rounded-lg bg-[#071f49] text-white"><item.icon className="h-5 w-5" /></div><h3 className="mt-5 text-2xl font-bold text-[#071f49]">{item.title}</h3><p className="mt-3 text-sm leading-6 text-slate-600">{item.copy}</p></article>)}</div></div></section>
      <section id="leadership-preview" className="py-20 sm:py-24">
        <div className="container">
          <SectionHeading align="center" eyebrow="Institutional leadership" title={content["about.leadership.title"]} description={content["about.leadership.description"]} />
          <div className="mt-12 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
            {team.map(profile => <LeadershipCard key={profile.id} profile={profile} />)}
          </div>
          <div className="mt-10 flex justify-center">
            <Button asChild size="lg" className="bg-[#071f49] font-bold text-white hover:bg-[#173b70]">
              <Link href="/about/leadership">Meet VIBHA’s leadership team <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </section>
      <section className="border-y border-slate-200 bg-white py-20 sm:py-24"><div className="container grid gap-10 lg:grid-cols-[0.8fr_1.2fr]"><div><Scale className="h-10 w-10 text-[#b94700]" /><h2 className="mt-5 text-4xl font-bold text-[#071f49]">{content["about.standing.title"]}</h2><AccreditationPendingBadge className="mt-6" /></div><div className="space-y-5 text-lg leading-8 text-slate-600"><p>VIBHA provides workforce education and institutional certification programs. Program completion does not, by itself, constitute a Virginia professional license, state-issued credential, university degree, or governmental endorsement.</p><p>Eligibility, employer recognition, continuing education acceptance, and role-specific requirements may vary by employer, payer, licensing board, credentialing body, and service setting. Prospective participants should verify how a program applies to their professional objective before enrollment.</p><p className="font-semibold text-[#071f49]">VIBHA’s accreditation review is pending. VIBHA will publish final accreditation or formal approval claims only when the underlying documentation has been verified and approved for public use.</p></div></div></section>
    </PublicLayout>
  );
}
