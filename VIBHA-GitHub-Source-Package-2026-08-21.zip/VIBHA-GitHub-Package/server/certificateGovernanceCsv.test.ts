import { describe, expect, it } from "vitest";
import { serializeCertificateApprovalHistoryCsv } from "./certificateDb";

describe("signed certificate approval history CSV", () => {
  it("includes an administrator-attributed export attestation and neutralizes formula-like event details", () => {
    const csv = serializeCertificateApprovalHistoryCsv({
      certificateNumber: "VIBHA-2026-ABCD1234",
      exportedAt: new Date("2026-08-21T20:00:00.000Z"),
      exporterName: "Jacquese Hinton",
      exporterOpenId: "owner-open-id",
      eventTypes: ["certificate.issued"],
      history: [{ action: "certificate.issued", actorName: "Jacquese Hinton", createdAt: new Date("2026-08-21T19:59:00.000Z"), details: "=HYPERLINK(\"unsafe\")" }],
    });
    expect(csv).toContain('"Export Timestamp (UTC)","2026-08-21T20:00:00.000Z"');
    expect(csv).toContain('"Exported By","Jacquese Hinton"');
    expect(csv).toContain('"Export Attestation (HMAC-SHA256)"');
    expect(csv).toContain("'=HYPERLINK");
  });
});
