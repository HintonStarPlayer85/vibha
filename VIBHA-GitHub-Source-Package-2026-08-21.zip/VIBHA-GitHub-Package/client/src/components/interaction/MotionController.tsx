import { useEffect } from "react";

const REVEAL_SELECTOR = "[data-reveal]";
const AUTO_REVEAL_SELECTOR = "main > section:not(:first-child):not([data-reveal]), main article:not([data-reveal]), main form:not([data-reveal])";

export function MotionController() {
  useEffect(() => {
    const root = document.documentElement;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

    const revealAll = () => {
      document.querySelectorAll<HTMLElement>(REVEAL_SELECTOR).forEach(element => {
        element.classList.add("is-visible");
      });
    };

    if (reducedMotion.matches || !("IntersectionObserver" in window)) {
      root.classList.add("motion-reduced");
      revealAll();
      return () => root.classList.remove("motion-reduced");
    }

    root.classList.add("motion-ready");
    const observer = new IntersectionObserver(
      entries => {
        entries.forEach(entry => {
          if (!entry.isIntersecting) return;
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        });
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.12 },
    );

    const registerRevealTargets = () => {
      document.querySelectorAll<HTMLElement>(AUTO_REVEAL_SELECTOR).forEach(element => {
        element.dataset.reveal = element.tagName === "SECTION" ? "up" : "scale";
        if (element.tagName === "ARTICLE") element.classList.add("vibha-card-interactive");
      });
      document.querySelectorAll<HTMLElement>(REVEAL_SELECTOR).forEach(element => {
        if (element.dataset.revealObserved === "true") return;
        element.dataset.revealObserved = "true";
        observer.observe(element);
      });
    };

    registerRevealTargets();
    const mutationObserver = new MutationObserver(registerRevealTargets);
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    const handleMotionPreference = (event: MediaQueryListEvent) => {
      root.classList.toggle("motion-reduced", event.matches);
      root.classList.toggle("motion-ready", !event.matches);
      if (event.matches) revealAll();
    };

    reducedMotion.addEventListener("change", handleMotionPreference);
    return () => {
      observer.disconnect();
      mutationObserver.disconnect();
      reducedMotion.removeEventListener("change", handleMotionPreference);
      root.classList.remove("motion-ready", "motion-reduced");
    };
  }, []);

  return null;
}
