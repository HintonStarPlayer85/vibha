import { cn } from "@/lib/utils";
import { Link } from "wouter";

export function VibhaBrand({
  inverse = false,
  compact = false,
  className,
}: {
  inverse?: boolean;
  compact?: boolean;
  className?: string;
}) {
  return (
    <Link
      href="/"
      aria-label="VIBHA home"
      className={cn("group inline-flex items-center gap-3 rounded-md", className)}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 64 64"
        className="h-11 w-11 shrink-0"
      >
        <circle cx="32" cy="19" r="14" fill="none" stroke="#F47A20" strokeWidth="8" />
        <circle
          cx="20"
          cy="41"
          r="14"
          fill="none"
          stroke={inverse ? "#FFFFFF" : "#071F49"}
          strokeWidth="8"
        />
        <circle
          cx="44"
          cy="41"
          r="14"
          fill="none"
          stroke={inverse ? "#DCE3EC" : "#173B70"}
          strokeWidth="8"
        />
      </svg>
      <span className="min-w-0">
        <span
          className={cn(
            "block text-[1.65rem] font-extrabold leading-none tracking-[0.08em]",
            inverse ? "text-white" : "text-[#071f49]",
          )}
        >
          VIBHA
        </span>
        {!compact ? (
          <span
            className={cn(
              "mt-1 hidden max-w-[300px] text-[0.61rem] font-semibold uppercase leading-[1.25] tracking-[0.12em] sm:block",
              inverse ? "text-slate-200" : "text-slate-600",
            )}
          >
            The Virginia Institute for Behavioral Health &amp; Advancement
          </span>
        ) : null}
      </span>
    </Link>
  );
}

