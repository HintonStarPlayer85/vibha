import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { ENV } from "./_core/env";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { upsertUser } from "./db";
import { adminCertificationsRouter } from "./routers/adminCertifications";
import { adminAccessRouter } from "./routers/adminAccess";
import { adminInstructorsRouter } from "./routers/adminInstructors";
import { adminCohortsRouter } from "./routers/adminCohorts";
import { adminCohortCommunicationsRouter } from "./routers/adminCohortCommunications";
import { certificationsRouter } from "./routers/certifications";
import { inquiriesRouter } from "./routers/inquiries";
import { adminSiteContentRouter, siteContentRouter } from "./routers/siteContent";
import { adminCertificateRepositoryRouter, certificateVerificationRouter } from "./routers/certificateRepository";
import { adminOnlineLearningRouter, onlineLearningRouter } from "./routers/onlineLearning";
import { adminModuleQuizzesRouter, learnerLearningRouter } from "./routers/learnerLearning";
import { adminLearnerEngagementRouter, learnerEngagementRouter } from "./routers/learnerEngagement";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async opts => {
      const user = opts.ctx.user;
      if (user?.openId === ENV.ownerOpenId && user.role !== "owner") {
        await upsertUser({ openId: user.openId });
        return { ...user, role: "owner" as const };
      }
      return user;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  certifications: certificationsRouter,
  inquiries: inquiriesRouter,
  adminCertifications: adminCertificationsRouter,
  adminAccess: adminAccessRouter,
  adminInstructors: adminInstructorsRouter,
  adminCohorts: adminCohortsRouter,
  adminCohortCommunications: adminCohortCommunicationsRouter,
  siteContent: siteContentRouter,
  adminSiteContent: adminSiteContentRouter,
  certificateVerification: certificateVerificationRouter,
  adminCertificates: adminCertificateRepositoryRouter,
  onlineLearning: onlineLearningRouter,
  adminOnlineLearning: adminOnlineLearningRouter,
  learnerLearning: learnerLearningRouter,
  adminModuleQuizzes: adminModuleQuizzesRouter,
  learnerEngagement: learnerEngagementRouter,
  adminLearnerEngagement: adminLearnerEngagementRouter,
});

export type AppRouter = typeof appRouter;
