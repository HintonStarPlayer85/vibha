CREATE TABLE `administration_audit_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int,
	`action` varchar(120) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` varchar(120),
	`targetUserId` int,
	`eventMetadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `administration_audit_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `administrator_invitations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`email` varchar(320) NOT NULL,
	`tokenHash` varchar(64) NOT NULL,
	`invitedRole` enum('admin') NOT NULL DEFAULT 'admin',
	`status` enum('pending','accepted','revoked','expired') NOT NULL DEFAULT 'pending',
	`invitedByUserId` int NOT NULL,
	`acceptedByUserId` int,
	`revokedByUserId` int,
	`expiresAt` timestamp NOT NULL,
	`acceptedAt` timestamp,
	`revokedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `administrator_invitations_id` PRIMARY KEY(`id`),
	CONSTRAINT `administrator_invitation_token_unique` UNIQUE(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `cohort_communication_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipientId` int NOT NULL,
	`providerEventId` varchar(180) NOT NULL,
	`eventType` varchar(80) NOT NULL,
	`occurredAt` timestamp NOT NULL,
	`eventMetadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cohort_communication_events_id` PRIMARY KEY(`id`),
	CONSTRAINT `cohort_event_provider_unique` UNIQUE(`providerEventId`)
);
--> statement-breakpoint
CREATE TABLE `cohort_communication_recipients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`communicationId` int NOT NULL,
	`studentId` int,
	`studentName` varchar(180) NOT NULL,
	`email` varchar(320) NOT NULL,
	`providerMessageId` varchar(180),
	`status` enum('queued','accepted','delivered','bounced','complained','failed') NOT NULL DEFAULT 'queued',
	`retryCount` int NOT NULL DEFAULT 0,
	`errorCode` varchar(120),
	`errorMessage` text,
	`sentAt` timestamp,
	`deliveredAt` timestamp,
	`lastEventAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cohort_communication_recipients_id` PRIMARY KEY(`id`),
	CONSTRAINT `cohort_recipient_email_unique` UNIQUE(`communicationId`,`email`),
	CONSTRAINT `cohort_recipient_provider_message_unique` UNIQUE(`providerMessageId`)
);
--> statement-breakpoint
CREATE TABLE `cohort_communications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cohortId` int NOT NULL,
	`senderUserId` int NOT NULL,
	`communicationType` enum('zoom_details','resource_update','schedule_update','general') NOT NULL DEFAULT 'general',
	`subject` varchar(240) NOT NULL,
	`message` text NOT NULL,
	`includeZoom` boolean NOT NULL DEFAULT false,
	`resourceIds` json NOT NULL,
	`previewHash` varchar(64) NOT NULL,
	`idempotencyKey` varchar(64) NOT NULL,
	`provider` varchar(32) NOT NULL DEFAULT 'resend',
	`status` enum('draft','processing','partial','sent','failed','cancelled') NOT NULL DEFAULT 'draft',
	`recipientCount` int NOT NULL DEFAULT 0,
	`acceptedCount` int NOT NULL DEFAULT 0,
	`deliveredCount` int NOT NULL DEFAULT 0,
	`failedCount` int NOT NULL DEFAULT 0,
	`bouncedCount` int NOT NULL DEFAULT 0,
	`complainedCount` int NOT NULL DEFAULT 0,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cohort_communications_id` PRIMARY KEY(`id`),
	CONSTRAINT `cohort_communication_idempotency_unique` UNIQUE(`idempotencyKey`)
);
--> statement-breakpoint
CREATE TABLE `cohort_resources` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cohortId` int NOT NULL,
	`title` varchar(220) NOT NULL,
	`description` text,
	`resourceType` enum('syllabus','schedule','document','link','other') NOT NULL DEFAULT 'document',
	`sourceType` enum('file','link') NOT NULL,
	`url` varchar(1000) NOT NULL,
	`storageKey` varchar(800),
	`fileName` varchar(320),
	`mimeType` varchar(160),
	`fileSize` int,
	`displayOrder` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdByUserId` int NOT NULL,
	`updatedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cohort_resources_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cohort_students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cohortId` int NOT NULL,
	`name` varchar(180) NOT NULL,
	`email` varchar(320) NOT NULL,
	`status` enum('active','inactive','completed','withdrawn') NOT NULL DEFAULT 'active',
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cohort_students_id` PRIMARY KEY(`id`),
	CONSTRAINT `cohort_student_email_unique` UNIQUE(`cohortId`,`email`)
);
--> statement-breakpoint
CREATE TABLE `cohorts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(220) NOT NULL,
	`slug` varchar(240) NOT NULL,
	`certificationId` int NOT NULL,
	`instructorId` int,
	`status` enum('draft','planned','active','completed','cancelled','archived') NOT NULL DEFAULT 'draft',
	`startAt` timestamp,
	`endAt` timestamp,
	`timeZone` varchar(80) NOT NULL DEFAULT 'America/New_York',
	`scheduleSummary` text,
	`zoomUrl` varchar(1000),
	`zoomMeetingId` varchar(120),
	`zoomPasscode` varchar(120),
	`administratorNotes` text,
	`createdByUserId` int NOT NULL,
	`updatedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cohorts_id` PRIMARY KEY(`id`),
	CONSTRAINT `cohort_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','owner') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `instructors` ADD `email` varchar(320);--> statement-breakpoint
ALTER TABLE `instructors` ADD `expertise` json;--> statement-breakpoint
ALTER TABLE `instructors` ADD CONSTRAINT `instructor_email_unique` UNIQUE(`email`);--> statement-breakpoint
ALTER TABLE `administration_audit_events` ADD CONSTRAINT `administration_audit_events_actorUserId_users_id_fk` FOREIGN KEY (`actorUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `administration_audit_events` ADD CONSTRAINT `administration_audit_events_targetUserId_users_id_fk` FOREIGN KEY (`targetUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `administrator_invitations` ADD CONSTRAINT `administrator_invitations_invitedByUserId_users_id_fk` FOREIGN KEY (`invitedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `administrator_invitations` ADD CONSTRAINT `administrator_invitations_acceptedByUserId_users_id_fk` FOREIGN KEY (`acceptedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `administrator_invitations` ADD CONSTRAINT `administrator_invitations_revokedByUserId_users_id_fk` FOREIGN KEY (`revokedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_communication_events` ADD CONSTRAINT `cohort_event_recipient_fk` FOREIGN KEY (`recipientId`) REFERENCES `cohort_communication_recipients`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_communication_recipients` ADD CONSTRAINT `cohort_recipient_communication_fk` FOREIGN KEY (`communicationId`) REFERENCES `cohort_communications`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_communication_recipients` ADD CONSTRAINT `cohort_recipient_student_fk` FOREIGN KEY (`studentId`) REFERENCES `cohort_students`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_communications` ADD CONSTRAINT `cohort_communication_cohort_fk` FOREIGN KEY (`cohortId`) REFERENCES `cohorts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_communications` ADD CONSTRAINT `cohort_communication_sender_fk` FOREIGN KEY (`senderUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_resources` ADD CONSTRAINT `cohort_resource_cohort_fk` FOREIGN KEY (`cohortId`) REFERENCES `cohorts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_resources` ADD CONSTRAINT `cohort_resource_creator_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_resources` ADD CONSTRAINT `cohort_resource_updater_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD CONSTRAINT `cohort_student_cohort_fk` FOREIGN KEY (`cohortId`) REFERENCES `cohorts`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD CONSTRAINT `cohort_student_creator_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohorts` ADD CONSTRAINT `cohort_certification_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohorts` ADD CONSTRAINT `cohort_instructor_fk` FOREIGN KEY (`instructorId`) REFERENCES `instructors`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohorts` ADD CONSTRAINT `cohort_creator_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `cohorts` ADD CONSTRAINT `cohort_updater_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `administration_audit_actor_created_idx` ON `administration_audit_events` (`actorUserId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `administration_audit_entity_idx` ON `administration_audit_events` (`entityType`,`entityId`);--> statement-breakpoint
CREATE INDEX `administrator_invitation_email_status_idx` ON `administrator_invitations` (`email`,`status`);--> statement-breakpoint
CREATE INDEX `administrator_invitation_expiry_idx` ON `administrator_invitations` (`status`,`expiresAt`);--> statement-breakpoint
CREATE INDEX `cohort_event_recipient_occurred_idx` ON `cohort_communication_events` (`recipientId`,`occurredAt`);--> statement-breakpoint
CREATE INDEX `cohort_recipient_status_idx` ON `cohort_communication_recipients` (`communicationId`,`status`);--> statement-breakpoint
CREATE INDEX `cohort_communication_created_idx` ON `cohort_communications` (`cohortId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `cohort_communication_status_idx` ON `cohort_communications` (`status`);--> statement-breakpoint
CREATE INDEX `cohort_resource_active_order_idx` ON `cohort_resources` (`cohortId`,`isActive`,`displayOrder`);--> statement-breakpoint
CREATE INDEX `cohort_student_status_idx` ON `cohort_students` (`cohortId`,`status`);--> statement-breakpoint
CREATE INDEX `cohort_status_start_idx` ON `cohorts` (`status`,`startAt`);--> statement-breakpoint
CREATE INDEX `cohort_certification_idx` ON `cohorts` (`certificationId`);--> statement-breakpoint
CREATE INDEX `cohort_instructor_idx` ON `cohorts` (`instructorId`);
