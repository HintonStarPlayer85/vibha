import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { ExternalLink, FilePenLine, Loader2, Plus, Search, ShieldCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

const statusLabels: Record<string, string> = {
  draft: "Draft",
  published: "Published",
  coming_soon: "Coming soon",
  inactive: "Inactive",
  archived: "Archived",
};

const statusStyles: Record<string, string> = {
  draft: "bg-slate-100 text-slate-700",
  published: "bg-emerald-100 text-emerald-800",
  coming_soon: "bg-amber-100 text-amber-800",
  inactive: "bg-rose-100 text-rose-800",
  archived: "bg-slate-200 text-slate-700",
};

function AdminCertificationIndex() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [statusMessage, setStatusMessage] = useState("");
  const input = useMemo(() => ({ q: query.trim() || undefined, status: status === "all" ? undefined : status as "draft" | "published" | "coming_soon" | "inactive" | "archived" }), [query, status]);
  const { data, isLoading, error } = trpc.adminCertifications.list.useQuery(input);
  const utils = trpc.useUtils();
  const statusMutation = trpc.adminCertifications.setStatus.useMutation({
    onSuccess: async item => {
      await utils.adminCertifications.list.invalidate();
      const message = `${item?.title ?? "Certification"} status updated.`;
      setStatusMessage(message);
      toast.success(message);
    },
    onError: mutationError => {
      setStatusMessage(`Status update failed: ${mutationError.message}`);
      toast.error(mutationError.message);
    },
  });

  return (
    <div className="mx-auto max-w-7xl">
      <p role="status" aria-live="polite" className="sr-only">{statusMutation.isPending ? "Updating certification status." : statusMessage}</p>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="text-sm font-bold uppercase tracking-[0.16em] text-[#b94700]">Certification CMS</p><h1 className="mt-2 text-4xl font-bold text-[#071f49]">Certification listings</h1><p className="mt-3 max-w-2xl leading-7 text-slate-600">Create, revise, publish, deactivate, and restore public certification content without changing application code.</p></div>
        <Button asChild className="h-11 shrink-0 bg-[#071f49] font-bold text-white hover:bg-[#173b70]"><Link href="/admin/certifications/new"><Plus className="mr-2 h-4 w-4" />Create certification</Link></Button>
      </div>
      <div className="mt-8 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-[1fr_220px]">
        <div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input aria-label="Search certification administration records" value={query} onChange={event => setQuery(event.target.value)} placeholder="Search by title or slug" className="pl-10" /></div>
        <select aria-label="Filter records by status" value={status} onChange={event => setStatus(event.target.value)} className="h-11 rounded-md border border-input bg-white px-3 text-sm"><option value="all">All statuses</option>{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>
      </div>
      {isLoading ? <div className="mt-8 flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-8 text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Loading certification records…</div> : null}
      {error ? <div role="alert" className="mt-8 rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{error.message}</div> : null}
      {data ? (
        <div className="mt-8 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          <div className="border-b border-slate-200 px-5 py-4 text-sm text-slate-600"><strong className="text-[#071f49]">{data.length}</strong> managed record{data.length === 1 ? "" : "s"}</div>
          <div className="divide-y divide-slate-200">
            {data.map(item => (
              <article key={item.id} className="grid gap-5 p-5 lg:grid-cols-[1fr_180px_190px_220px] lg:items-center">
                <div><div className="flex flex-wrap items-center gap-2"><h2 className="font-sans text-lg font-bold text-[#071f49]">{item.title}</h2>{item.isFeatured ? <Badge className="bg-[#fff0e6] text-[#9a4300]">Featured</Badge> : null}</div><p className="mt-1 text-xs text-slate-500">/{item.slug}</p><p className="mt-2 line-clamp-2 text-sm leading-6 text-slate-600">{item.summary}</p></div>
                <div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Category</p><p className="mt-1 text-sm font-semibold text-slate-700">{item.categoryName}</p></div>
                <div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Status</p><Badge className={`mt-2 border-0 ${statusStyles[item.status]}`}>{statusLabels[item.status]}</Badge><p className="mt-2 text-xs text-slate-500">Updated {new Date(item.updatedAt).toLocaleDateString()}</p></div>
                <div className="flex flex-wrap gap-2 lg:justify-end"><Button asChild size="sm" variant="outline" className="border-slate-300 bg-white"><Link href={`/admin/certifications/${item.id}/edit`}><FilePenLine className="mr-1.5 h-4 w-4" />Edit</Link></Button>{item.status === "published" ? <Button asChild size="sm" variant="outline" className="border-slate-300 bg-white"><Link href={`/certifications/${item.slug}`}><ExternalLink className="mr-1.5 h-4 w-4" />View</Link></Button> : null}<Button size="sm" variant="outline" disabled={statusMutation.isPending} onClick={() => statusMutation.mutate({ id: item.id, status: item.status === "inactive" ? "published" : "inactive" })} className="border-slate-300 bg-white">{item.status === "inactive" ? "Reactivate" : "Deactivate"}</Button></div>
              </article>
            ))}
          </div>
          {data.length === 0 ? <div className="p-10 text-center"><ShieldCheck className="mx-auto h-9 w-9 text-[#b94700]" /><h2 className="mt-3 text-2xl font-bold text-[#071f49]">No managed records match this view.</h2><p className="mt-2 text-sm text-slate-600">Change the search or status filter, or create a new certification.</p></div> : null}
        </div>
      ) : null}
    </div>
  );
}

export default function AdminCertifications() {
  return <DashboardLayout><AdminCertificationIndex /></DashboardLayout>;
}
