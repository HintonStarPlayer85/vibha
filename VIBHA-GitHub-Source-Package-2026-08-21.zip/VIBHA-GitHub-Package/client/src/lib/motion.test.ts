import { describe, expect, it } from "vitest";
import { backToTopThreshold, preferredScrollBehavior, shouldShowBackToTop } from "./motion";

describe("motion utilities", () => {
  it("uses a meaningful minimum scroll threshold", () => {
    expect(backToTopThreshold(400)).toBe(480);
    expect(backToTopThreshold(1000)).toBe(750);
  });

  it("shows the back-to-top control only after the threshold", () => {
    expect(shouldShowBackToTop(480, 400)).toBe(false);
    expect(shouldShowBackToTop(481, 400)).toBe(true);
  });

  it("disables smooth scrolling when reduced motion is preferred", () => {
    expect(preferredScrollBehavior(true)).toBe("auto");
    expect(preferredScrollBehavior(false)).toBe("smooth");
  });
});
