import { and, asc, count, desc, eq, like, or, sql } from "drizzle-orm";
import {
  administrationAuditEvents,
  certificationInstructors,
  certifications,
  instructors,
} from "../drizzle/schema";
import type { InstructorInput, InstructorListQuery } from "../shared/administration";
import { getDb } from "./db";

export const instructorErrors = {
  slugConflict: "INSTRUCTOR_SLUG_CONFLICT",
  emailConflict: "INSTRUCTOR_EMAIL_CONFLICT",
  notFound: "INSTRUCTOR_NOT_FOUND",
  signatureMissing: "INSTRUCTOR_SIGNATURE_MISSING",
} as const;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

function instructorValues(input: InstructorInput) {
  return {
    name: input.name,
    slug: input.slug,
    email: input.email || null,
    credentials: input.credentials || null,
    title: input.title || null,
    biography: input.biography || null,
    expertise: input.expertise,
    photoUrl: input.photoUrl || null,
    isActive: input.isActive,
  };
}

async function assertUnique(input: InstructorInput, ignoreId?: number) {
  const db = await requireDb();
  const conditions = [eq(instructors.slug, input.slug)];
  if (input.email) conditions.push(eq(instructors.email, input.email));
  const matches = await db
    .select({ id: instructors.id, slug: instructors.slug, email: instructors.email })
    .from(instructors)
    .where(or(...conditions));
  for (const match of matches) {
    if (match.id === ignoreId) continue;
    if (match.slug === input.slug) throw new Error(instructorErrors.slugConflict);
    if (input.email && match.email?.toLowerCase() === input.email.toLowerCase()) {
      throw new Error(instructorErrors.emailConflict);
    }
  }
}

async function assignCertifications(
  tx: Parameters<Parameters<Awaited<ReturnType<typeof requireDb>>["transaction"]>[0]>[0],
  instructorId: number,
  certificationIds: number[],
) {
  await tx.delete(certificationInstructors).where(eq(certificationInstructors.instructorId, instructorId));
  const uniqueIds = Array.from(new Set(certificationIds));
  if (uniqueIds.length) {
    await tx.insert(certificationInstructors).values(
      uniqueIds.map((certificationId, displayOrder) => ({
        certificationId,
        instructorId,
        displayOrder,
      })),
    );
  }
}

export async function listInstructors(query: InstructorListQuery) {
  const db = await requireDb();
  const conditions = [];
  if (query.q) {
    const term = `%${query.q}%`;
    conditions.push(
      or(
        like(instructors.name, term),
        like(instructors.email, term),
        like(instructors.credentials, term),
        like(instructors.title, term),
      ),
    );
  }
  if (query.status) conditions.push(eq(instructors.isActive, query.status === "active"));
  return db
    .select({
      id: instructors.id,
      name: instructors.name,
      slug: instructors.slug,
      email: instructors.email,
      credentials: instructors.credentials,
      title: instructors.title,
      expertise: instructors.expertise,
      isActive: instructors.isActive,
      updatedAt: instructors.updatedAt,
      certificationCount: count(certificationInstructors.certificationId),
    })
    .from(instructors)
    .leftJoin(certificationInstructors, eq(certificationInstructors.instructorId, instructors.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .groupBy(instructors.id)
    .orderBy(desc(instructors.isActive), asc(instructors.name));
}

export async function getInstructorById(id: number) {
  const db = await requireDb();
  const instructor = (
    await db.select().from(instructors).where(eq(instructors.id, id)).limit(1)
  )[0];
  if (!instructor) return null;
  const assignments = await db
    .select({ certificationId: certificationInstructors.certificationId })
    .from(certificationInstructors)
    .where(eq(certificationInstructors.instructorId, id))
    .orderBy(asc(certificationInstructors.displayOrder));
  return { ...instructor, certificationIds: assignments.map(item => item.certificationId) };
}

export async function getInstructorOptions() {
  const db = await requireDb();
  return db
    .select({ id: certifications.id, title: certifications.title, status: certifications.status })
    .from(certifications)
    .orderBy(asc(certifications.title));
}

export async function createInstructor(input: InstructorInput, actorUserId: number) {
  const db = await requireDb();
  await assertUnique(input);
  const id = await db.transaction(async tx => {
    const result = await tx.insert(instructors).values(instructorValues(input));
    const instructorId = Number(result[0].insertId);
    await assignCertifications(tx, instructorId, input.certificationIds);
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "instructor.created",
      entityType: "instructor",
      entityId: String(instructorId),
      eventMetadata: { name: input.name, certificationCount: input.certificationIds.length },
    });
    return instructorId;
  });
  return getInstructorById(id);
}

export async function updateInstructor(id: number, input: InstructorInput, actorUserId: number) {
  const db = await requireDb();
  if (!(await getInstructorById(id))) throw new Error(instructorErrors.notFound);
  await assertUnique(input, id);
  await db.transaction(async tx => {
    await tx.update(instructors).set(instructorValues(input)).where(eq(instructors.id, id));
    await assignCertifications(tx, id, input.certificationIds);
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "instructor.updated",
      entityType: "instructor",
      entityId: String(id),
      eventMetadata: { name: input.name, certificationCount: input.certificationIds.length },
    });
  });
  return getInstructorById(id);
}

export async function setInstructorStatus(id: number, isActive: boolean, actorUserId: number) {
  const db = await requireDb();
  const result = await db.update(instructors).set({ isActive }).where(eq(instructors.id, id));
  if (Number(result[0].affectedRows) !== 1) throw new Error(instructorErrors.notFound);
  await db.insert(administrationAuditEvents).values({
    actorUserId,
    action: isActive ? "instructor.activated" : "instructor.deactivated",
    entityType: "instructor",
    entityId: String(id),
  });
  return getInstructorById(id);
}

export async function setInstructorSignature(input: { instructorId: number; storageKey: string; url: string; fileName: string; mimeType: "image/png" | "image/jpeg"; crop: { x: number; y: number; size: number; zoom: number } | null; actorUserId: number }) {
  const db = await requireDb();
  if (!(await getInstructorById(input.instructorId))) throw new Error(instructorErrors.notFound);
  await db.update(instructors).set({ signatureStorageKey: input.storageKey, signatureUrl: input.url, signatureFileName: input.fileName, signatureMimeType: input.mimeType, signatureCrop: input.crop, signatureUploadedAt: new Date(), signatureUpdatedByUserId: input.actorUserId }).where(eq(instructors.id, input.instructorId));
  await db.insert(administrationAuditEvents).values({ actorUserId: input.actorUserId, action: "instructor.signature.uploaded", entityType: "instructor", entityId: String(input.instructorId), eventMetadata: { fileName: input.fileName, mimeType: input.mimeType, cropped: Boolean(input.crop) } });
  return getInstructorById(input.instructorId);
}

export async function clearInstructorSignature(instructorId: number, actorUserId: number) {
  const db = await requireDb();
  const instructor = await getInstructorById(instructorId);
  if (!instructor) throw new Error(instructorErrors.notFound);
  if (!instructor.signatureStorageKey) throw new Error(instructorErrors.signatureMissing);
  await db.update(instructors).set({ signatureStorageKey: null, signatureUrl: null, signatureFileName: null, signatureMimeType: null, signatureCrop: null, signatureUploadedAt: null, signatureUpdatedByUserId: actorUserId }).where(eq(instructors.id, instructorId));
  await db.insert(administrationAuditEvents).values({ actorUserId, action: "instructor.signature.removed", entityType: "instructor", entityId: String(instructorId) });
  return getInstructorById(instructorId);
}
