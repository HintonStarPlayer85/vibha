import { ShieldAlert } from "lucide-react";

export function AccreditationPendingBadge({ inverse = false, className = "" }: { inverse?: boolean; className?: string }) {
  return (
    <div
      role="note"
      aria-label="Accreditation status: pending"
      className={`inline-flex max-w-xl items-start gap-3 rounded-lg border px-4 py-3 ${inverse ? "border-[#f47a20]/50 bg-white/5 text-slate-200" : "border-[#f47a20]/35 bg-[#fff8f0] text-slate-700"} ${className}`}
    >
      <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-[#f47a20]" aria-hidden="true" />
      <span className="text-sm leading-6"><strong className={inverse ? "text-white" : "text-[#071f49]"}>Accreditation Pending</strong><span className="block">Accreditation review is pending. This status does not represent current accreditation, professional licensure, or governmental endorsement.</span></span>
    </div>
  );
}
