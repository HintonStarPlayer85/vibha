import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { usePageMeta } from "@/hooks/usePageMeta";
import { Link } from "wouter";

export default function Accessibility() {
  usePageMeta("Accessibility | VIBHA", "VIBHA’s commitment to an accessible institutional website experience.");
  return <PublicLayout><PageHero eyebrow="Accessibility" title="Accessibility commitment" description="VIBHA is committed to providing a clear and usable digital experience for professionals, organizations, and community partners." breadcrumbs={[{ label: "Accessibility" }]} /><article className="container max-w-4xl py-16 prose prose-slate lg:prose-lg"><h2>Our target</h2><p>This website is designed toward WCAG Level AA expectations, including keyboard access, visible focus, semantic structure, sufficient contrast, descriptive labels, responsive layouts, and reduced-motion support.</p><h2>Feedback and assistance</h2><p>If you encounter a barrier or need information in another format, <Link href="/contact">contact VIBHA</Link>. Include the page address, the task you were attempting, and the assistive technology or browser involved when possible.</p><h2>Ongoing improvement</h2><p>Accessibility is treated as an operational requirement. VIBHA will continue reviewing content, navigation, forms, and interactive controls as the platform expands.</p></article></PublicLayout>;
}

