import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const dbMocks = vi.hoisted(() => ({
  activateOnlineCourse: vi.fn(),
  createOnlineCourseMaterial: vi.fn(),
  getOnlineCourseAdminById: vi.fn(),
  getPublicOnlineCourseBySlug: vi.fn(),
  listOnlineCourses: vi.fn(),
  listPublishedCertificationOptions: vi.fn(),
  updateOnlineCourseStatus: vi.fn(),
  updateOnlineLesson: vi.fn(),
  updateOnlineModule: vi.fn(),
}));
const serviceMocks = vi.hoisted(() => ({ analyzeCourseMaterials: vi.fn(), answerOnlineInstructor: vi.fn(), generateCourseFromMaterials: vi.fn(), generateOnlineModuleVisual: vi.fn() }));
const storageMocks = vi.hoisted(() => ({ storagePut: vi.fn() }));

vi.mock("./onlineLearningDb", async () => {
  const actual = await vi.importActual<typeof import("./onlineLearningDb")>("./onlineLearningDb");
  return { ...actual, ...dbMocks };
});
vi.mock("./onlineLearningService", () => serviceMocks);
vi.mock("./storage", () => storageMocks);

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;
function context(role?: AuthenticatedUser["role"]): TrpcContext {
  const user = role ? { id: 44, openId: `${role}-online-learning`, email: `${role}@example.com`, name: "Online Learning Test", loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() } : null;
  return { user, req: { protocol: "https", headers: {}, get: () => "thevibha.org" } as unknown as TrpcContext["req"], res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"] };
}

describe("Online Learning router", () => {
  beforeEach(() => vi.clearAllMocks());
  it("allows public learners to retrieve only a published course route", async () => {
    dbMocks.getPublicOnlineCourseBySlug.mockResolvedValue({ id: 8, certificationTitle: "Workforce Foundations", modules: [] });
    await expect(appRouter.createCaller(context()).onlineLearning.getBySlug({ slug: "workforce-foundations" })).resolves.toMatchObject({ certificationTitle: "Workforce Foundations" });
  });
  it("denies non-administrators Online Learning controls", async () => {
    await expect(appRouter.createCaller(context("user")).adminOnlineLearning.list()).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
  });
  it("activates a published certification through an administrator identity", async () => {
    dbMocks.activateOnlineCourse.mockResolvedValue({ id: 9, certificationId: 21 });
    await expect(appRouter.createCaller(context("admin")).adminOnlineLearning.activate({ certificationId: 21 })).resolves.toEqual({ id: 9, certificationId: 21 });
    expect(dbMocks.activateOnlineCourse).toHaveBeenCalledWith(21, 44);
  });
  it("stores course materials server-side with validated PDF bytes", async () => {
    storageMocks.storagePut.mockResolvedValue({ key: "online-learning/9/materials/guide.pdf", url: "/manus-storage/guide.pdf" });
    dbMocks.createOnlineCourseMaterial.mockResolvedValue({ id: 6, analysisStatus: "pending" });
    await appRouter.createCaller(context("owner")).adminOnlineLearning.uploadMaterial({ courseId: 9, title: "Course guide", fileName: "guide.pdf", mimeType: "application/pdf", dataBase64: Buffer.from("PDF material").toString("base64") });
    expect(storageMocks.storagePut).toHaveBeenCalledWith(expect.stringMatching(/^online-learning\/9\/materials\//), Buffer.from("PDF material"), "application/pdf");
    expect(dbMocks.createOnlineCourseMaterial).toHaveBeenCalledWith(expect.objectContaining({ courseId: 9, title: "Course guide", actorUserId: 44 }));
  });
});
