import { beforeEach, describe, expect, it, vi } from "vitest";

const certificateDbMocks = vi.hoisted(() => ({
  getCertificatePreviewReminderSchedule: vi.fn(),
  listDueCertificatePreviewReminders: vi.fn(),
  markCertificatePreviewReminderAccepted: vi.fn(),
  markCertificatePreviewReminderFailed: vi.fn(),
  recordCertificatePreviewReminderScheduleRun: vi.fn(),
  reserveCertificatePreviewReminder: vi.fn(),
}));
const resendMocks = vi.hoisted(() => ({ send: vi.fn(), getResendConfiguration: vi.fn(), verifyResendSenderDomain: vi.fn() }));

vi.mock("./certificateDb", () => certificateDbMocks);
vi.mock("./resendCohort", () => ({ getResendConfiguration: resendMocks.getResendConfiguration, verifyResendSenderDomain: resendMocks.verifyResendSenderDomain }));
vi.mock("resend", () => ({ Resend: class { emails = { send: resendMocks.send }; } }));

import { runCertificatePreviewReminderSweep } from "./certificatePreviewReminderService";

describe("certificate preview reminder sweep", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    certificateDbMocks.getCertificatePreviewReminderSchedule.mockResolvedValue({ enabled: true });
    certificateDbMocks.recordCertificatePreviewReminderScheduleRun.mockResolvedValue(undefined);
    resendMocks.getResendConfiguration.mockReturnValue({ readyToSend: true, apiKey: "re_test", from: "VIBHA <certificates@example.org>", replyTo: "support@example.org", missing: [] });
    resendMocks.verifyResendSenderDomain.mockResolvedValue({ verified: true, status: "verified", domain: "example.org" });
    resendMocks.send.mockResolvedValue({ data: { id: "provider-message" } });
  });

  it("sends one tracked reminder for a due confirmed preview", async () => {
    certificateDbMocks.listDueCertificatePreviewReminders.mockResolvedValue([{ acknowledgementId: 44, recipientUserId: 9, recipientName: "Certificate Admin", recipientEmail: "admin@example.org", credentialTitle: "Clinical Documentation", cohortTitle: "Fall 2026", expiresAt: new Date("2026-08-22T12:00:00Z") }]);
    certificateDbMocks.reserveCertificatePreviewReminder.mockResolvedValue({ created: true, reminder: { id: 7, acknowledgementId: 44, recipientName: "Certificate Admin", recipientEmail: "admin@example.org", idempotencyKey: "certificate-preview-reminder/44" } });

    await expect(runCertificatePreviewReminderSweep("task-1")).resolves.toMatchObject({ ok: true, due: 1, accepted: 1, failed: 0, duplicates: 0 });
    expect(resendMocks.send).toHaveBeenCalledOnce();
    expect(certificateDbMocks.markCertificatePreviewReminderAccepted).toHaveBeenCalledWith(7, "provider-message");
  });

  it("does not send another message when a reminder reservation already exists", async () => {
    certificateDbMocks.listDueCertificatePreviewReminders.mockResolvedValue([{ acknowledgementId: 44, recipientUserId: 9, recipientName: "Certificate Admin", recipientEmail: "admin@example.org", credentialTitle: "Clinical Documentation", cohortTitle: "Fall 2026", expiresAt: new Date("2026-08-22T12:00:00Z") }]);
    certificateDbMocks.reserveCertificatePreviewReminder.mockResolvedValue({ created: false, reminder: { id: 7 } });

    await expect(runCertificatePreviewReminderSweep("task-1")).resolves.toMatchObject({ ok: true, due: 1, duplicates: 1, accepted: 0 });
    expect(resendMocks.send).not.toHaveBeenCalled();
  });
});
