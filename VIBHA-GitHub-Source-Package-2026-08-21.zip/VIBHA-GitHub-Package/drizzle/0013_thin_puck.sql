CREATE TABLE `completion_decision_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cohortStudentId` int NOT NULL,
	`decision` enum('approved','returned') NOT NULL,
	`recipientName` varchar(180) NOT NULL,
	`recipientEmail` varchar(320) NOT NULL,
	`subject` varchar(240) NOT NULL,
	`idempotencyKey` varchar(96) NOT NULL,
	`providerMessageId` varchar(180),
	`status` enum('queued','accepted','failed') NOT NULL DEFAULT 'queued',
	`retryCount` int NOT NULL DEFAULT 0,
	`errorCode` varchar(120),
	`errorMessage` text,
	`createdByUserId` int NOT NULL,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `completion_decision_notifications_id` PRIMARY KEY(`id`),
	CONSTRAINT `completion_notification_idempotency_unique` UNIQUE(`idempotencyKey`)
);
--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `isHighStakes` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD `completionFirstApprovedByUserId` int;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD `completionFirstApprovedAt` timestamp;--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureCrop` json;--> statement-breakpoint
ALTER TABLE `completion_decision_notifications` ADD CONSTRAINT `completion_notification_student_fk` FOREIGN KEY (`cohortStudentId`) REFERENCES `cohort_students`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `completion_decision_notifications` ADD CONSTRAINT `completion_notification_creator_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `completion_notification_student_created_idx` ON `completion_decision_notifications` (`cohortStudentId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `completion_notification_status_idx` ON `completion_decision_notifications` (`status`,`createdAt`);--> statement-breakpoint
ALTER TABLE `cohort_students` ADD CONSTRAINT `cohort_first_approval_user_fk` FOREIGN KEY (`completionFirstApprovedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `cohort_student_first_approval_idx` ON `cohort_students` (`completionFirstApprovedByUserId`,`completionFirstApprovedAt`);
