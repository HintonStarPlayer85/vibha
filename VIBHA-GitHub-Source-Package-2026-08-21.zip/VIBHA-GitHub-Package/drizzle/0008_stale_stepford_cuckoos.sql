CREATE TABLE `online_course_generation_runs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`status` enum('processing','ready','failed') NOT NULL DEFAULT 'processing',
	`model` varchar(120) NOT NULL,
	`materialIds` json NOT NULL,
	`outputSnapshot` json,
	`errorMessage` varchar(1000),
	`createdByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	CONSTRAINT `online_course_generation_runs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `online_course_lessons` (
	`id` int AUTO_INCREMENT NOT NULL,
	`moduleId` int NOT NULL,
	`position` int NOT NULL,
	`title` varchar(220) NOT NULL,
	`estimatedMinutes` int NOT NULL,
	`content` text NOT NULL,
	`knowledgeCheckQuestion` text NOT NULL,
	`knowledgeCheckAnswer` text NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_course_lessons_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_lesson_module_position_unique` UNIQUE(`moduleId`,`position`)
);
--> statement-breakpoint
CREATE TABLE `online_course_materials` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`title` varchar(220) NOT NULL,
	`fileName` varchar(320) NOT NULL,
	`mimeType` varchar(160) NOT NULL,
	`storageKey` varchar(800) NOT NULL,
	`url` varchar(1000) NOT NULL,
	`fileSize` int NOT NULL,
	`analysisStatus` enum('pending','analyzed','failed') NOT NULL DEFAULT 'pending',
	`analysisSummary` text,
	`sourceExcerpt` text,
	`analysisError` varchar(1000),
	`uploadedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_course_materials_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `online_course_modules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`courseId` int NOT NULL,
	`generationRunId` int,
	`position` int NOT NULL,
	`title` varchar(220) NOT NULL,
	`learningObjective` text NOT NULL,
	`sourceGrounding` text NOT NULL,
	`visualPrompt` text NOT NULL,
	`visualImageUrl` varchar(1000),
	`videoBrief` text NOT NULL,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_course_modules_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_module_course_position_unique` UNIQUE(`courseId`,`position`)
);
--> statement-breakpoint
CREATE TABLE `online_courses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`certificationId` int NOT NULL,
	`status` enum('draft','review','published','archived') NOT NULL DEFAULT 'draft',
	`courseOverview` text,
	`sourceGroundingNotice` text,
	`aiInstructorName` varchar(100) NOT NULL DEFAULT 'VIBHA Learning Guide',
	`aiInstructorWelcome` text,
	`aiInstructorScope` text,
	`lastGeneratedAt` timestamp,
	`createdByUserId` int NOT NULL,
	`updatedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `online_courses_id` PRIMARY KEY(`id`),
	CONSTRAINT `online_course_certification_unique` UNIQUE(`certificationId`)
);
--> statement-breakpoint
ALTER TABLE `online_course_generation_runs` ADD CONSTRAINT `online_course_generation_runs_courseId_online_courses_id_fk` FOREIGN KEY (`courseId`) REFERENCES `online_courses`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_generation_runs` ADD CONSTRAINT `online_course_generation_runs_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_lessons` ADD CONSTRAINT `online_course_lessons_moduleId_online_course_modules_id_fk` FOREIGN KEY (`moduleId`) REFERENCES `online_course_modules`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_materials` ADD CONSTRAINT `online_course_materials_courseId_online_courses_id_fk` FOREIGN KEY (`courseId`) REFERENCES `online_courses`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_materials` ADD CONSTRAINT `online_course_materials_uploadedByUserId_users_id_fk` FOREIGN KEY (`uploadedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_modules` ADD CONSTRAINT `online_course_modules_courseId_online_courses_id_fk` FOREIGN KEY (`courseId`) REFERENCES `online_courses`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_course_modules` ADD CONSTRAINT `online_modules_generation_run_fk` FOREIGN KEY (`generationRunId`) REFERENCES `online_course_generation_runs`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_courses` ADD CONSTRAINT `online_courses_certificationId_certifications_id_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_courses` ADD CONSTRAINT `online_courses_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `online_courses` ADD CONSTRAINT `online_courses_updatedByUserId_users_id_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `online_generation_course_created_idx` ON `online_course_generation_runs` (`courseId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `online_generation_status_idx` ON `online_course_generation_runs` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `online_lesson_module_published_idx` ON `online_course_lessons` (`moduleId`,`isPublished`,`position`);--> statement-breakpoint
CREATE INDEX `online_material_course_created_idx` ON `online_course_materials` (`courseId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `online_material_analysis_idx` ON `online_course_materials` (`courseId`,`analysisStatus`);--> statement-breakpoint
CREATE INDEX `online_module_course_published_idx` ON `online_course_modules` (`courseId`,`isPublished`,`position`);--> statement-breakpoint
CREATE INDEX `online_course_status_updated_idx` ON `online_courses` (`status`,`updatedAt`);
