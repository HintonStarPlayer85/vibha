import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { startLogin } from "@/const";
import { invitationStatusGuidance } from "@/lib/admin-invitation";
import { trpc } from "@/lib/trpc";
import { AlertTriangle, ArrowRight, CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { Link } from "wouter";

export default function AdminRegistration() {
  const token = useMemo(() => new URLSearchParams(window.location.search).get("token") ?? "", []);
  const { user, loading, refresh } = useAuth();
  const [confirmEmail, setConfirmEmail] = useState("");
  const preview = trpc.adminAccess.invitationPreview.useQuery({ token }, { enabled: token.length >= 32, retry: false });
  const accept = trpc.adminAccess.acceptInvitation.useMutation();

  async function submit(event: FormEvent) {
    event.preventDefault();
    await accept.mutateAsync({ token, confirmEmail });
    await refresh();
  }

  const alreadyAuthorized = user?.role === "admin" || user?.role === "owner";
  const invitationUsable = preview.data?.status === "pending";
  const statusGuidance = preview.data ? invitationStatusGuidance(preview.data.status) : null;

  return (
    <main id="main-content" className="flex min-h-screen items-center justify-center bg-[#f6f8fb] p-5 py-12">
      <div className="w-full max-w-xl rounded-3xl border border-slate-200 bg-white p-7 shadow-institutional sm:p-10">
        <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-[#071f49] text-white"><ShieldCheck className="h-7 w-7" /></div>
        <p className="mt-7 text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Administrator Registration</p>
        <h1 className="mt-3 text-4xl font-bold text-[#071f49]">Bind your approved account.</h1>

        {!alreadyAuthorized && !token ? <div role="alert" className="mt-6 rounded-xl border border-red-200 bg-red-50 p-5 text-red-900"><AlertTriangle className="h-5 w-5" /><p className="mt-2 font-bold">Invitation token missing.</p><p className="mt-1 text-sm">Open the complete invitation link issued by the VIBHA owner.</p></div> : null}
        {!alreadyAuthorized && preview.isLoading ? <p role="status" className="mt-6 flex items-center gap-2 text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Validating invitation…</p> : null}
        {!alreadyAuthorized && preview.error ? <div role="alert" className="mt-6 rounded-xl border border-red-200 bg-red-50 p-5 text-red-900"><p className="font-bold">This invitation is not available.</p><p className="mt-1 text-sm">It may be invalid, expired, revoked, or already used.</p></div> : null}
        {!alreadyAuthorized && preview.data ? (
          <div className="mt-6 rounded-xl border border-slate-200 bg-[#f6f8fb] p-5">
            <p className="text-sm font-bold text-[#071f49]">Invitation account</p>
            <p className="mt-1 text-slate-700">{preview.data.maskedEmail}</p>
            <p className="mt-3 text-xs uppercase tracking-wide text-slate-500">Status: {preview.data.status.replace("_", " ")}</p>
          </div>
        ) : null}
        {!alreadyAuthorized && statusGuidance ? (
          <div role="alert" className="mt-5 rounded-xl border border-amber-200 bg-amber-50 p-5 text-amber-950">
            <p className="font-bold">{statusGuidance.title}</p>
            <p className="mt-2 text-sm leading-6">{statusGuidance.message}</p>
            <Button asChild variant="outline" className="mt-4 border-amber-300 bg-white"><Link href="/admin/access">Return to Administrator Access</Link></Button>
          </div>
        ) : null}

        {!loading && invitationUsable && !user ? (
          <div className="mt-6">
            <p className="leading-7 text-slate-600">Sign in with the exact email address that received this invitation. You will return here to complete registration.</p>
            <Button className="mt-5 w-full bg-[#071f49] text-white hover:bg-[#173b70]" onClick={() => startLogin(`${window.location.pathname}${window.location.search}`)}>Sign in and continue <ArrowRight className="ml-2 h-4 w-4" /></Button>
          </div>
        ) : null}

        {!loading && invitationUsable && user && !alreadyAuthorized && !accept.isSuccess ? (
          <form onSubmit={submit} className="mt-6">
            <p className="leading-7 text-slate-600">Signed in as <strong>{user.email ?? "an account without an email"}</strong>. Confirm the invited email to complete registration.</p>
            <Label htmlFor="confirm-admin-email" className="mt-5 block">Invited email address</Label>
            <Input id="confirm-admin-email" type="email" autoComplete="email" className="mt-2" value={confirmEmail} onChange={event => setConfirmEmail(event.target.value)} required />
            {accept.error ? <p role="alert" className="mt-3 text-sm font-semibold text-red-700">{accept.error.message}</p> : null}
            <Button type="submit" disabled={accept.isPending} className="mt-5 w-full bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">{accept.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}Complete administrator registration</Button>
          </form>
        ) : null}

        {(accept.isSuccess || alreadyAuthorized) ? (
          <div role="status" aria-live="polite" className="mt-6 rounded-xl border border-emerald-200 bg-emerald-50 p-5 text-emerald-950">
            <CheckCircle2 className="h-6 w-6" />
            <p className="mt-2 font-bold">Administrator access is active.</p>
            <Button asChild className="mt-4 bg-[#071f49] text-white hover:bg-[#173b70]"><Link href="/admin/certifications">Enter Content Administration</Link></Button>
          </div>
        ) : null}

        <p className="mt-7 text-sm text-slate-500"><Link href="/admin/access" className="font-bold text-[#173b70] hover:underline">Return to administrator access</Link></p>
      </div>
    </main>
  );
}
