import { and, asc, desc, eq, gt, inArray, isNull, like, or, sql } from "drizzle-orm";
import { createHmac } from "node:crypto";
import {
  administrationAuditEvents,
  certificateProgramProfiles,
  certificatePreviewReminderNotifications,
  certificatePreviewReminderSchedules,
  certificateTemplateTestDeliveries,
  certifications,
  completionDecisionNotifications,
  cohorts,
  cohortStudents,
  instructors,
  issuedCertificates,
  certificatePreviewAcknowledgements,
  users,
} from "../drizzle/schema";
import type { CertificateProgramProfileInput, CertificateRepositoryQuery, CertificateVerifyInput } from "../shared/certificates";
import { getDb } from "./db";
import { ENV } from "./_core/env";

export const certificateErrors = {
  notFound: "CERTIFICATE_NOT_FOUND",
  candidateNotFound: "CERTIFICATE_CANDIDATE_NOT_FOUND",
  notEligible: "CERTIFICATE_NOT_ELIGIBLE",
  alreadyIssued: "CERTIFICATE_ALREADY_ISSUED",
  notIssued: "CERTIFICATE_NOT_ISSUED",
  completionNotApproved: "CERTIFICATE_COMPLETION_NOT_APPROVED",
  secondApprovalRequired: "CERTIFICATE_SECOND_APPROVAL_REQUIRED",
  duplicateHighStakesReviewer: "CERTIFICATE_DUPLICATE_HIGH_STAKES_REVIEWER",
  previewAcknowledgementRequired: "CERTIFICATE_PREVIEW_ACKNOWLEDGEMENT_REQUIRED",
} as const;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

export type CertificateCandidate = {
  cohortId: number;
  cohortStudentId: number | null;
  certificationId: number;
  recipientName: string;
  recipientEmail: string;
  cohortTitle: string;
  credentialTitle: string;
  ceuValue: string | null;
  instructorName: string | null;
  instructorTitle: string | null;
  cohortSignatoryInstructorId: number | null;
  courseInstructorSignatoryName: string | null;
  courseInstructorSignatoryTitle: string | null;
  instructorSignatureStorageKey: string | null;
  instructorSignatureUrl: string | null;
  instructorSignatureMimeType: "image/png" | "image/jpeg" | null;
  executiveSignatureStorageKey: string | null;
  executiveSignatureUrl: string | null;
  executiveSignatureMimeType: "image/png" | "image/jpeg" | null;
  deliveryMode: string | null;
  completionNarrative: string | null;
  instructionalHours: string | null;
  supervisedPracticalTraining: string | null;
  complianceStatement: string | null;
  accreditingBodyName: string | null;
  licenseNumber: string | null;
  executiveName: string | null;
  executiveTitle: string | null;
  previewAcknowledgementExpirationMinutes: number | null;
};

export async function listCertificateRepository(query: CertificateRepositoryQuery) {
  const db = await requireDb();
  const conditions = [];
  if (query.q) {
    const value = `%${query.q}%`;
    conditions.push(or(
      like(issuedCertificates.certificateNumber, value),
      like(issuedCertificates.recipientName, value),
      like(issuedCertificates.credentialTitle, value),
      like(issuedCertificates.cohortTitle, value),
    ));
  }
  if (query.status) conditions.push(eq(issuedCertificates.status, query.status));
  return db
    .select({
      id: issuedCertificates.id,
      certificateNumber: issuedCertificates.certificateNumber,
      cohortId: issuedCertificates.cohortId,
      cohortStudentId: issuedCertificates.cohortStudentId,
      recipientName: issuedCertificates.recipientName,
      recipientEmail: issuedCertificates.recipientEmail,
      credentialTitle: issuedCertificates.credentialTitle,
      cohortTitle: issuedCertificates.cohortTitle,
      ceuValue: issuedCertificates.ceuValue,
      status: issuedCertificates.status,
      issuedAt: issuedCertificates.issuedAt,
      revokedAt: issuedCertificates.revokedAt,
      revocationReason: issuedCertificates.revocationReason,
      documentUrl: issuedCertificates.documentUrl,
      reissueOfCertificateId: issuedCertificates.reissueOfCertificateId,
      updatedAt: issuedCertificates.updatedAt,
    })
    .from(issuedCertificates)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(issuedCertificates.issuedAt), asc(issuedCertificates.recipientName));
}

export async function listEligibleCertificateRecipients() {
  const db = await requireDb();
  const rows = await db
    .select({
      cohortId: cohorts.id,
      cohortStudentId: cohortStudents.id,
      certificationId: certifications.id,
      recipientName: cohortStudents.name,
      recipientEmail: cohortStudents.email,
      cohortTitle: cohorts.title,
      credentialTitle: certifications.title,
      ceuValue: certifications.ceus,
      existingIssuedCertificateId: issuedCertificates.id,
    })
    .from(cohortStudents)
    .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
    .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
    .leftJoin(issuedCertificates, and(eq(issuedCertificates.cohortStudentId, cohortStudents.id), eq(issuedCertificates.status, "issued")))
    .where(and(eq(cohorts.status, "completed"), eq(cohortStudents.status, "completed"), eq(cohortStudents.completionApprovalStatus, "approved")))
    .orderBy(desc(cohorts.endAt), asc(cohortStudents.name));
  return rows.filter(row => !row.existingIssuedCertificateId).map(({ existingIssuedCertificateId: _existing, ...row }) => ({ ...row, ceuValue: row.ceuValue ? String(row.ceuValue) : null }));
}

export async function recordCertificatePreviewAcknowledgement(input: { cohortStudentId: number; certificationId: number; acknowledgementToken: string; previewFingerprint: string; actorUserId: number; expiresAt: Date }) {
  const db = await requireDb();
  const result = await db.insert(certificatePreviewAcknowledgements).values({ cohortStudentId: input.cohortStudentId, certificationId: input.certificationId, acknowledgementToken: input.acknowledgementToken, previewFingerprint: input.previewFingerprint, previewedByUserId: input.actorUserId, expiresAt: input.expiresAt });
  const id = Number(result[0].insertId);
  await db.insert(administrationAuditEvents).values({ actorUserId: input.actorUserId, action: "certificate.preview.generated", entityType: "certificate_preview_acknowledgement", entityId: String(id), eventMetadata: { cohortStudentId: input.cohortStudentId, certificationId: input.certificationId } });
  return { id, acknowledgementToken: input.acknowledgementToken, expiresAt: input.expiresAt };
}

export async function confirmCertificatePreviewAcknowledgement(acknowledgementToken: string, notes: string, actorUserId: number) {
  const db = await requireDb();
  const acknowledgement = (await db.select().from(certificatePreviewAcknowledgements).where(and(eq(certificatePreviewAcknowledgements.acknowledgementToken, acknowledgementToken), eq(certificatePreviewAcknowledgements.previewedByUserId, actorUserId), isNull(certificatePreviewAcknowledgements.usedAt), gt(certificatePreviewAcknowledgements.expiresAt, new Date()))).limit(1))[0];
  if (!acknowledgement) throw new Error(certificateErrors.previewAcknowledgementRequired);
  const confirmedAt = new Date();
  await db.transaction(async tx => {
    await tx.update(certificatePreviewAcknowledgements).set({ confirmedAt, acknowledgementNotes: notes || null }).where(eq(certificatePreviewAcknowledgements.id, acknowledgement.id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.preview.acknowledged", entityType: "certificate_preview_acknowledgement", entityId: String(acknowledgement.id), eventMetadata: { cohortStudentId: acknowledgement.cohortStudentId, certificationId: acknowledgement.certificationId, hasNotes: Boolean(notes) } });
  });
  return { acknowledgementToken, confirmedAt, expiresAt: acknowledgement.expiresAt };
}

export async function validateCertificatePreviewAcknowledgement(input: { acknowledgementToken: string; cohortStudentId: number; actorUserId: number; previewFingerprint: string }) {
  const db = await requireDb();
  const acknowledgement = (await db.select().from(certificatePreviewAcknowledgements).where(and(eq(certificatePreviewAcknowledgements.acknowledgementToken, input.acknowledgementToken), eq(certificatePreviewAcknowledgements.cohortStudentId, input.cohortStudentId), eq(certificatePreviewAcknowledgements.previewedByUserId, input.actorUserId), eq(certificatePreviewAcknowledgements.previewFingerprint, input.previewFingerprint), isNull(certificatePreviewAcknowledgements.usedAt), gt(certificatePreviewAcknowledgements.expiresAt, new Date()))).limit(1))[0];
  if (!acknowledgement?.confirmedAt) throw new Error(certificateErrors.previewAcknowledgementRequired);
  return acknowledgement;
}

export async function markCertificatePreviewAcknowledgementUsed(acknowledgementId: number, issuedCertificateId: number, actorUserId: number) {
  const db = await requireDb();
  await db.transaction(async tx => {
    await tx.update(certificatePreviewAcknowledgements).set({ usedAt: new Date(), usedForCertificateId: issuedCertificateId }).where(and(eq(certificatePreviewAcknowledgements.id, acknowledgementId), isNull(certificatePreviewAcknowledgements.usedAt)));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.preview_acknowledgement.used", entityType: "certificate_preview_acknowledgement", entityId: String(acknowledgementId), eventMetadata: { issuedCertificateId } });
  });
}

export async function listCertificateApprovalHistory(certificateId: number, eventTypes?: string[]) {
  const db = await requireDb();
  const certificate = await getCertificateById(certificateId);
  if (!certificate) throw new Error(certificateErrors.notFound);
  const studentCondition = certificate.cohortStudentId ? and(eq(administrationAuditEvents.entityType, "cohort_student"), eq(administrationAuditEvents.entityId, String(certificate.cohortStudentId)), inArray(administrationAuditEvents.action, ["certificate.completion.resubmitted", "certificate.completion.returned", "certificate.completion.first_approved", "certificate.completion.approved"])) : undefined;
  const certificateCondition = and(eq(administrationAuditEvents.entityType, "issued_certificate"), eq(administrationAuditEvents.entityId, String(certificateId)), inArray(administrationAuditEvents.action, ["certificate.issued", "certificate.reissued", "certificate.revoked"]));
  const [auditEvents, previewEvents] = await Promise.all([
    db.select({ id: administrationAuditEvents.id, action: administrationAuditEvents.action, createdAt: administrationAuditEvents.createdAt, eventMetadata: administrationAuditEvents.eventMetadata, actorName: users.name, details: sql<string | null>`NULL` }).from(administrationAuditEvents).leftJoin(users, eq(administrationAuditEvents.actorUserId, users.id)).where(studentCondition ? or(studentCondition, certificateCondition) : certificateCondition),
    db.select({ id: certificatePreviewAcknowledgements.id, action: sql<string>`'certificate.preview.acknowledged'`, createdAt: certificatePreviewAcknowledgements.confirmedAt, eventMetadata: sql<Record<string, string | number | boolean | null> | null>`NULL`, actorName: users.name, details: certificatePreviewAcknowledgements.acknowledgementNotes }).from(certificatePreviewAcknowledgements).leftJoin(users, eq(certificatePreviewAcknowledgements.previewedByUserId, users.id)).where(eq(certificatePreviewAcknowledgements.usedForCertificateId, certificateId)),
  ]);
  const history = [...auditEvents, ...previewEvents].filter(event => event.createdAt).sort((left, right) => new Date(left.createdAt!).getTime() - new Date(right.createdAt!).getTime());
  return eventTypes?.length ? history.filter(event => eventTypes.includes(event.action)) : history;
}

function csvCell(value: string | number | Date | null | undefined) {
  const text = value == null ? "" : value instanceof Date ? value.toISOString() : String(value);
  const safe = /^[=+\-@]/.test(text) ? `'${text}` : text;
  return `"${safe.replaceAll('"', '""')}"`;
}

type CertificateApprovalHistoryRow = { action: string; actorName: string | null; createdAt: Date | null; details: string | null };
type CertificateApprovalHistoryExportArgs = {
  certificateNumber: string;
  history: CertificateApprovalHistoryRow[];
  exportedAt?: Date;
  exporterName?: string;
  exporterOpenId?: string;
  eventTypes?: string[];
};

export function serializeCertificateApprovalHistoryCsv(args: CertificateApprovalHistoryExportArgs): string;
export function serializeCertificateApprovalHistoryCsv(certificateNumber: string, history: CertificateApprovalHistoryRow[]): string;
export function serializeCertificateApprovalHistoryCsv(argsOrCertificateNumber: CertificateApprovalHistoryExportArgs | string, positionalHistory?: CertificateApprovalHistoryRow[]) {
  const args: CertificateApprovalHistoryExportArgs = typeof argsOrCertificateNumber === "string"
    ? { certificateNumber: argsOrCertificateNumber, history: positionalHistory ?? [] }
    : argsOrCertificateNumber;
  const exportedAt = args.exportedAt ?? new Date();
  const exporterName = args.exporterName ?? "VIBHA administrator";
  const exporterOpenId = args.exporterOpenId ?? "unattributed-export";
  const attestationPayload = JSON.stringify({
    certificateNumber: args.certificateNumber,
    exportedAt: exportedAt.toISOString(),
    exporterOpenId,
    eventTypes: args.eventTypes ?? [],
    rows: args.history.map(event => [event.action, event.actorName, event.createdAt?.toISOString() ?? null, event.details]),
  });
  const attestation = createHmac("sha256", ENV.cookieSecret || "certificate-export-fallback").update(attestationPayload).digest("hex");
  const header = ["Certificate Number", "Event", "Administrator", "Timestamp (UTC)", "Notes or Details"];
  const metadata = [
    ["Report", "VIBHA Certificate Approval History"],
    ["Certificate Number", args.certificateNumber],
    ["Export Timestamp (UTC)", exportedAt.toISOString()],
    ["Exported By", exporterName],
    ["Exporting Administrator Identity", exporterOpenId],
    ["Applied Event Filters", args.eventTypes?.length ? args.eventTypes.join(" | ") : "All certificate history events"],
    ["Export Attestation (HMAC-SHA256)", attestation],
    [],
  ];
  const rows = args.history.map(event => [args.certificateNumber, event.action, event.actorName ?? "Former administrator", event.createdAt, event.details ?? ""]);
  return [...metadata, header, ...rows].map(row => row.map(value => csvCell(value as string | number | Date | null | undefined)).join(",")).join("\r\n");
}

export async function exportCertificateApprovalHistoryCsv(input: { certificateId: number; eventTypes?: string[]; exporter: { id: number; name: string; openId: string } }) {
  const certificate = await getCertificateById(input.certificateId);
  if (!certificate) throw new Error(certificateErrors.notFound);
  const history = await listCertificateApprovalHistory(input.certificateId, input.eventTypes);
  const exportedAt = new Date();
  const csv = serializeCertificateApprovalHistoryCsv({ certificateNumber: certificate.certificateNumber, history, exportedAt, exporterName: input.exporter.name, exporterOpenId: input.exporter.openId, eventTypes: input.eventTypes });
  const db = await requireDb();
  await db.insert(administrationAuditEvents).values({ actorUserId: input.exporter.id, action: "certificate.history.exported", entityType: "issued_certificate", entityId: String(input.certificateId), eventMetadata: { eventTypes: input.eventTypes?.join("|") ?? "all", exportedAt: exportedAt.toISOString() } });
  return { fileName: `${certificate.certificateNumber}-approval-history.csv`, dataBase64: Buffer.from(csv, "utf8").toString("base64"), exportedAt: exportedAt.toISOString(), exporterName: input.exporter.name };
}

export async function listDueCertificatePreviewReminders(now = new Date()) {
  const db = await requireDb();
  const rows = await db.select({
    acknowledgementId: certificatePreviewAcknowledgements.id,
    expiresAt: certificatePreviewAcknowledgements.expiresAt,
    recipientUserId: users.id,
    recipientName: users.name,
    recipientEmail: users.email,
    credentialTitle: certifications.title,
    cohortTitle: cohorts.title,
    reminderEnabled: certificateProgramProfiles.previewReminderEnabled,
    reminderLeadMinutes: certificateProgramProfiles.previewReminderLeadMinutes,
    reminderEmailSubject: certificateProgramProfiles.previewReminderEmailSubject,
    reminderEmailBody: certificateProgramProfiles.previewReminderEmailBody,
  }).from(certificatePreviewAcknowledgements)
    .innerJoin(users, eq(certificatePreviewAcknowledgements.previewedByUserId, users.id))
    .innerJoin(cohortStudents, eq(certificatePreviewAcknowledgements.cohortStudentId, cohortStudents.id))
    .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
    .innerJoin(certifications, eq(certificatePreviewAcknowledgements.certificationId, certifications.id))
    .leftJoin(certificateProgramProfiles, eq(certifications.id, certificateProgramProfiles.certificationId))
    .leftJoin(certificatePreviewReminderNotifications, eq(certificatePreviewReminderNotifications.acknowledgementId, certificatePreviewAcknowledgements.id))
    .where(and(sql`${certificatePreviewAcknowledgements.confirmedAt} IS NOT NULL`, isNull(certificatePreviewAcknowledgements.usedAt), gt(certificatePreviewAcknowledgements.expiresAt, now), isNull(certificatePreviewReminderNotifications.id)))
    .limit(50);
  return rows.filter(row => Boolean(row.recipientEmail) && (row.reminderEnabled ?? true) && row.expiresAt.getTime() - now.getTime() <= (row.reminderLeadMinutes ?? 10) * 60 * 1000);
}

export async function reserveCertificatePreviewReminder(input: { acknowledgementId: number; recipientUserId: number; recipientName: string; recipientEmail: string; subject: string }) {
  const db = await requireDb();
  const existing = (await db.select().from(certificatePreviewReminderNotifications).where(eq(certificatePreviewReminderNotifications.acknowledgementId, input.acknowledgementId)).limit(1))[0];
  if (existing) return { reminder: existing, created: false };
  const result = await db.insert(certificatePreviewReminderNotifications).values({ ...input, idempotencyKey: `certificate-preview-reminder/${input.acknowledgementId}` });
  const reminder = (await db.select().from(certificatePreviewReminderNotifications).where(eq(certificatePreviewReminderNotifications.id, Number(result[0].insertId))).limit(1))[0]!;
  return { reminder, created: true };
}

export async function getCertificatePreviewReminderDelivery(id: number) {
  const db = await requireDb();
  return (await db.select({
    id: certificatePreviewReminderNotifications.id,
    acknowledgementId: certificatePreviewReminderNotifications.acknowledgementId,
    recipientName: certificatePreviewReminderNotifications.recipientName,
    recipientEmail: certificatePreviewReminderNotifications.recipientEmail,
    subject: certificatePreviewReminderNotifications.subject,
    idempotencyKey: certificatePreviewReminderNotifications.idempotencyKey,
    retryCount: certificatePreviewReminderNotifications.retryCount,
    credentialTitle: certifications.title,
    cohortTitle: cohorts.title,
    expiresAt: certificatePreviewAcknowledgements.expiresAt,
  }).from(certificatePreviewReminderNotifications)
    .innerJoin(certificatePreviewAcknowledgements, eq(certificatePreviewReminderNotifications.acknowledgementId, certificatePreviewAcknowledgements.id))
    .innerJoin(cohortStudents, eq(certificatePreviewAcknowledgements.cohortStudentId, cohortStudents.id))
    .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
    .innerJoin(certifications, eq(certificatePreviewAcknowledgements.certificationId, certifications.id))
    .where(eq(certificatePreviewReminderNotifications.id, id)).limit(1))[0] ?? null;
}

export async function prepareCertificatePreviewReminderRetry(id: number, actorUserId: number) {
  const db = await requireDb();
  const reminder = await getCertificatePreviewReminderDelivery(id);
  if (!reminder) throw new Error(certificateErrors.notFound);
  await db.transaction(async tx => {
    await tx.update(certificatePreviewReminderNotifications).set({ status: "queued", retryCount: reminder.retryCount + 1, errorCode: null, errorMessage: null }).where(eq(certificatePreviewReminderNotifications.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.preview_reminder.resent", entityType: "certificate_preview_reminder_notification", entityId: String(id), eventMetadata: { acknowledgementId: reminder.acknowledgementId } });
  });
  return getCertificatePreviewReminderDelivery(id);
}

export async function markCertificatePreviewReminderAccepted(id: number, providerMessageId: string) {
  const db = await requireDb();
  await db.update(certificatePreviewReminderNotifications).set({ status: "accepted", providerMessageId, errorCode: null, errorMessage: null, sentAt: new Date() }).where(eq(certificatePreviewReminderNotifications.id, id));
}

export async function markCertificatePreviewReminderFailed(id: number, errorCode: string, errorMessage: string, incrementRetry = false) {
  const db = await requireDb();
  const reminder = (await db.select({ retryCount: certificatePreviewReminderNotifications.retryCount }).from(certificatePreviewReminderNotifications).where(eq(certificatePreviewReminderNotifications.id, id)).limit(1))[0];
  if (!reminder) return;
  await db.update(certificatePreviewReminderNotifications).set({ status: "failed", retryCount: incrementRetry ? reminder.retryCount + 1 : reminder.retryCount, errorCode, errorMessage }).where(eq(certificatePreviewReminderNotifications.id, id));
}

export async function getCertificatePreviewReminderSchedule(taskUid: string) {
  const db = await requireDb();
  return (await db.select().from(certificatePreviewReminderSchedules).where(eq(certificatePreviewReminderSchedules.scheduleCronTaskUid, taskUid)).limit(1))[0] ?? null;
}

export async function recordCertificatePreviewReminderScheduleRun(taskUid: string, summary: Record<string, unknown>) {
  const db = await requireDb();
  await db.update(certificatePreviewReminderSchedules).set({ lastRunAt: new Date(), lastRunSummary: JSON.stringify(summary) }).where(eq(certificatePreviewReminderSchedules.scheduleCronTaskUid, taskUid));
}

export async function listCertificateCompletionReviews() {
  const db = await requireDb();
  return db.select({ cohortStudentId: cohortStudents.id, recipientName: cohortStudents.name, recipientEmail: cohortStudents.email, completionApprovalStatus: cohortStudents.completionApprovalStatus, completionReviewNotes: cohortStudents.completionReviewNotes, completionReviewedAt: cohortStudents.completionReviewedAt, completionFirstApprovedByUserId: cohortStudents.completionFirstApprovedByUserId, completionFirstApprovedAt: cohortStudents.completionFirstApprovedAt, cohortId: cohorts.id, cohortTitle: cohorts.title, credentialTitle: certifications.title, isHighStakes: certificateProgramProfiles.isHighStakes, instructorName: instructors.name })
    .from(cohortStudents).innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id)).innerJoin(certifications, eq(cohorts.certificationId, certifications.id)).leftJoin(instructors, eq(cohorts.instructorId, instructors.id))
    .leftJoin(certificateProgramProfiles, eq(certifications.id, certificateProgramProfiles.certificationId))
    .where(and(eq(cohorts.status, "completed"), eq(cohortStudents.status, "completed"), inArray(cohortStudents.completionApprovalStatus, ["not_requested", "pending", "returned"])))
    .orderBy(asc(cohortStudents.completionApprovalStatus), asc(cohorts.title), asc(cohortStudents.name));
}

export async function reviewCertificateCompletion(cohortStudentId: number, decision: "approve" | "return", notes: string, actorUserId: number) {
  const db = await requireDb();
  const student = (await db.select({ id: cohortStudents.id, cohortId: cohortStudents.cohortId, status: cohortStudents.status, name: cohortStudents.name, email: cohortStudents.email, cohortTitle: cohorts.title, credentialTitle: certifications.title, isHighStakes: certificateProgramProfiles.isHighStakes, firstApprovedByUserId: cohortStudents.completionFirstApprovedByUserId }).from(cohortStudents).innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id)).innerJoin(certifications, eq(cohorts.certificationId, certifications.id)).leftJoin(certificateProgramProfiles, eq(certifications.id, certificateProgramProfiles.certificationId)).where(eq(cohortStudents.id, cohortStudentId)).limit(1))[0];
  if (!student) throw new Error(certificateErrors.candidateNotFound);
  if (student.status !== "completed") throw new Error(certificateErrors.notEligible);
  const highStakes = Boolean(student.isHighStakes);
  if (decision === "approve" && highStakes && student.firstApprovedByUserId === actorUserId) throw new Error(certificateErrors.duplicateHighStakesReviewer);
  const firstApproval = decision === "approve" && highStakes && !student.firstApprovedByUserId;
  const completionApprovalStatus = decision === "return" ? "returned" as const : firstApproval ? "pending" as const : "approved" as const;
  const notificationDecision = decision === "return" ? "returned" as const : completionApprovalStatus === "approved" ? "approved" as const : null;
  let notificationId: number | null = null;
  await db.transaction(async tx => {
    await tx.update(cohortStudents).set({ completionApprovalStatus, completionReviewedByUserId: firstApproval || decision === "return" ? null : actorUserId, completionReviewedAt: firstApproval || decision === "return" ? null : new Date(), completionReviewNotes: notes || null, completionFirstApprovedByUserId: firstApproval ? actorUserId : decision === "return" ? null : student.firstApprovedByUserId, completionFirstApprovedAt: firstApproval ? new Date() : decision === "return" ? null : undefined }).where(eq(cohortStudents.id, cohortStudentId));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: decision === "return" ? "certificate.completion.returned" : firstApproval ? "certificate.completion.first_approved" : "certificate.completion.approved", entityType: "cohort_student", entityId: String(cohortStudentId), eventMetadata: { cohortId: student.cohortId, highStakes, hasNotes: Boolean(notes) } });
    if (notificationDecision) {
      const now = new Date();
      const subject = notificationDecision === "approved" ? `Your VIBHA course completion has been approved` : `Your VIBHA course completion requires updates`;
      const inserted = await tx.insert(completionDecisionNotifications).values({ cohortStudentId, decision: notificationDecision, recipientName: student.name, recipientEmail: student.email, subject, idempotencyKey: `completion/${cohortStudentId}/${notificationDecision}/${now.getTime()}/${actorUserId}`, createdByUserId: actorUserId });
      notificationId = Number(inserted[0].insertId);
    }
  });
  const reviewed = (await db.select().from(cohortStudents).where(eq(cohortStudents.id, cohortStudentId)).limit(1))[0]!;
  return { student: reviewed, notification: notificationDecision && notificationId ? { id: notificationId, decision: notificationDecision } : null, awaitingSecondApproval: firstApproval };
}

export async function getCompletionNotificationDelivery(id: number) {
  const db = await requireDb();
  return (await db.select({ id: completionDecisionNotifications.id, decision: completionDecisionNotifications.decision, recipientName: completionDecisionNotifications.recipientName, recipientEmail: completionDecisionNotifications.recipientEmail, subject: completionDecisionNotifications.subject, idempotencyKey: completionDecisionNotifications.idempotencyKey, retryCount: completionDecisionNotifications.retryCount, status: completionDecisionNotifications.status, reviewNotes: cohortStudents.completionReviewNotes, cohortTitle: cohorts.title, credentialTitle: certifications.title }).from(completionDecisionNotifications).innerJoin(cohortStudents, eq(completionDecisionNotifications.cohortStudentId, cohortStudents.id)).innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id)).innerJoin(certifications, eq(cohorts.certificationId, certifications.id)).where(eq(completionDecisionNotifications.id, id)).limit(1))[0] ?? null;
}

export async function markCompletionNotificationAccepted(id: number, providerMessageId: string) {
  const db = await requireDb();
  await db.update(completionDecisionNotifications).set({ status: "accepted", providerMessageId, errorCode: null, errorMessage: null, sentAt: new Date() }).where(eq(completionDecisionNotifications.id, id));
}

export async function markCompletionNotificationFailed(id: number, errorCode: string, errorMessage: string, incrementRetry = false) {
  const db = await requireDb();
  const notification = (await db.select({ retryCount: completionDecisionNotifications.retryCount }).from(completionDecisionNotifications).where(eq(completionDecisionNotifications.id, id)).limit(1))[0];
  if (!notification) return;
  await db.update(completionDecisionNotifications).set({ status: "failed", retryCount: incrementRetry ? notification.retryCount + 1 : notification.retryCount, errorCode, errorMessage }).where(eq(completionDecisionNotifications.id, id));
}

export async function prepareCompletionNotificationRetry(id: number, actorUserId: number) {
  const db = await requireDb();
  const notification = await getCompletionNotificationDelivery(id);
  if (!notification) throw new Error(certificateErrors.notFound);
  await db.transaction(async tx => {
    await tx.update(completionDecisionNotifications).set({ status: "queued", retryCount: notification.retryCount + 1, errorCode: null, errorMessage: null }).where(eq(completionDecisionNotifications.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.completion_notification.resent", entityType: "completion_decision_notification", entityId: String(id), eventMetadata: { decision: notification.decision } });
  });
  return getCompletionNotificationDelivery(id);
}

export async function listCompletionNotificationHistory() {
  const db = await requireDb();
  return db.select({ id: completionDecisionNotifications.id, decision: completionDecisionNotifications.decision, subject: completionDecisionNotifications.subject, status: completionDecisionNotifications.status, retryCount: completionDecisionNotifications.retryCount, errorCode: completionDecisionNotifications.errorCode, createdAt: completionDecisionNotifications.createdAt, sentAt: completionDecisionNotifications.sentAt, cohortStudentId: completionDecisionNotifications.cohortStudentId, recipientName: completionDecisionNotifications.recipientName, cohortTitle: cohorts.title, credentialTitle: certifications.title }).from(completionDecisionNotifications).innerJoin(cohortStudents, eq(completionDecisionNotifications.cohortStudentId, cohortStudents.id)).innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id)).innerJoin(certifications, eq(cohorts.certificationId, certifications.id)).orderBy(desc(completionDecisionNotifications.createdAt)).limit(50);
}

export async function resubmitCertificateCompletion(cohortStudentId: number, actorUserId: number) {
  const db = await requireDb();
  const student = (await db.select({ id: cohortStudents.id, cohortId: cohortStudents.cohortId, status: cohortStudents.status, completionApprovalStatus: cohortStudents.completionApprovalStatus }).from(cohortStudents).where(eq(cohortStudents.id, cohortStudentId)).limit(1))[0];
  if (!student) throw new Error(certificateErrors.candidateNotFound);
  if (student.status !== "completed") throw new Error(certificateErrors.notEligible);
  await db.update(cohortStudents).set({ completionApprovalStatus: "pending", completionReviewedByUserId: null, completionReviewedAt: null, completionReviewNotes: null, completionFirstApprovedByUserId: null, completionFirstApprovedAt: null, completionApprovalRequestedAt: new Date() }).where(eq(cohortStudents.id, cohortStudentId));
  await db.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.completion.resubmitted", entityType: "cohort_student", entityId: String(cohortStudentId), eventMetadata: { cohortId: student.cohortId, previousStatus: student.completionApprovalStatus } });
  return (await db.select().from(cohortStudents).where(eq(cohortStudents.id, cohortStudentId)).limit(1))[0]!;
}

export async function getCertificateCandidate(cohortStudentId: number): Promise<CertificateCandidate> {
  const db = await requireDb();
  const row = (await db
    .select({
      cohortId: cohorts.id,
      cohortStatus: cohorts.status,
      cohortStudentId: cohortStudents.id,
      studentStatus: cohortStudents.status,
      completionApprovalStatus: cohortStudents.completionApprovalStatus,
      certificationId: certifications.id,
      recipientName: cohortStudents.name,
      recipientEmail: cohortStudents.email,
      cohortTitle: cohorts.title,
      cohortSignatoryInstructorId: cohorts.certificateSignatoryInstructorId,
      credentialTitle: certifications.title,
      ceuValue: certifications.ceus,
      instructorName: instructors.name,
      instructorCredentials: instructors.credentials,
      instructorTitle: instructors.title,
      instructorSignatureStorageKey: instructors.signatureStorageKey,
      instructorSignatureUrl: instructors.signatureUrl,
      instructorSignatureMimeType: instructors.signatureMimeType,
      deliveryMode: certifications.format,
      completionNarrative: certificateProgramProfiles.completionNarrative,
      instructionalHours: certificateProgramProfiles.instructionalHours,
      supervisedPracticalTraining: certificateProgramProfiles.supervisedPracticalTraining,
      complianceStatement: certificateProgramProfiles.complianceStatement,
      accreditingBodyName: certificateProgramProfiles.accreditingBodyName,
      licenseNumber: certificateProgramProfiles.licenseNumber,
      executiveName: certificateProgramProfiles.executiveName,
      executiveTitle: certificateProgramProfiles.executiveTitle,
      executiveSignatureStorageKey: certificateProgramProfiles.executiveSignatureStorageKey,
      executiveSignatureUrl: certificateProgramProfiles.executiveSignatureUrl,
      executiveSignatureMimeType: certificateProgramProfiles.executiveSignatureMimeType,
      courseInstructorSignatoryName: certificateProgramProfiles.courseInstructorSignatoryName,
      courseInstructorSignatoryTitle: certificateProgramProfiles.courseInstructorSignatoryTitle,
      previewAcknowledgementExpirationMinutes: certificateProgramProfiles.previewAcknowledgementExpirationMinutes,
      existingIssuedCertificateId: issuedCertificates.id,
    })
    .from(cohortStudents)
    .innerJoin(cohorts, eq(cohortStudents.cohortId, cohorts.id))
    .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
    .leftJoin(instructors, eq(cohorts.instructorId, instructors.id))
    .leftJoin(certificateProgramProfiles, eq(certifications.id, certificateProgramProfiles.certificationId))
    .leftJoin(issuedCertificates, and(eq(issuedCertificates.cohortStudentId, cohortStudents.id), eq(issuedCertificates.status, "issued")))
    .where(eq(cohortStudents.id, cohortStudentId))
    .limit(1))[0];
  if (!row) throw new Error(certificateErrors.candidateNotFound);
  if (row.cohortStatus !== "completed" || row.studentStatus !== "completed") throw new Error(certificateErrors.notEligible);
  if (row.completionApprovalStatus !== "approved") throw new Error(certificateErrors.completionNotApproved);
  if (row.existingIssuedCertificateId) throw new Error(certificateErrors.alreadyIssued);
  const { cohortStatus: _cohortStatus, studentStatus: _studentStatus, completionApprovalStatus: _approval, existingIssuedCertificateId: _existing, ...candidate } = row;
  const override = candidate.cohortSignatoryInstructorId ? (await db.select({ name: instructors.name, credentials: instructors.credentials, title: instructors.title, signatureStorageKey: instructors.signatureStorageKey, signatureUrl: instructors.signatureUrl, signatureMimeType: instructors.signatureMimeType }).from(instructors).where(eq(instructors.id, candidate.cohortSignatoryInstructorId)).limit(1))[0] : null;
  const resolvedInstructor = override ?? { name: candidate.instructorName, credentials: candidate.instructorCredentials, title: candidate.instructorTitle, signatureStorageKey: candidate.instructorSignatureStorageKey, signatureUrl: candidate.instructorSignatureUrl, signatureMimeType: candidate.instructorSignatureMimeType };
  return { ...candidate, instructorName: [resolvedInstructor.name, resolvedInstructor.credentials].filter(Boolean).join(", ") || null, instructorTitle: resolvedInstructor.title || null, instructorSignatureStorageKey: resolvedInstructor.signatureStorageKey || null, instructorSignatureUrl: resolvedInstructor.signatureUrl || null, instructorSignatureMimeType: resolvedInstructor.signatureMimeType === "image/png" || resolvedInstructor.signatureMimeType === "image/jpeg" ? resolvedInstructor.signatureMimeType : null, executiveSignatureMimeType: candidate.executiveSignatureMimeType === "image/png" || candidate.executiveSignatureMimeType === "image/jpeg" ? candidate.executiveSignatureMimeType : null, ceuValue: candidate.ceuValue ? String(candidate.ceuValue) : null };
}

export async function listCertificateProgramOptions() {
  const db = await requireDb();
  return db.select({ id: certifications.id, title: certifications.title, status: certifications.status }).from(certifications).where(inArray(certifications.status, ["draft", "published", "inactive"])).orderBy(asc(certifications.title));
}

export async function getCertificateProgramProfile(certificationId: number) {
  const db = await requireDb();
  const profile = (await db.select().from(certificateProgramProfiles).where(eq(certificateProgramProfiles.certificationId, certificationId)).limit(1))[0];
  return profile ?? { certificationId, completionNarrative: null, instructionalHours: null, supervisedPracticalTraining: null, complianceStatement: null, accreditingBodyName: null, licenseNumber: null, executiveName: "Jacquese Hinton", executiveTitle: "Founder & Director of Institutional Strategy", executiveSignatureStorageKey: null, executiveSignatureUrl: null, executiveSignatureMimeType: null, executiveSignatureCrop: null, courseInstructorSignatoryName: null, courseInstructorSignatoryTitle: null, isHighStakes: false, previewAcknowledgementExpirationMinutes: 30, previewReminderEnabled: true, previewReminderLeadMinutes: 10, previewReminderEmailSubject: null, previewReminderEmailBody: null, approvalEscalationEnabled: false, approvalEscalationDelayMinutes: 1440, approvalEscalationRecipientUserId: null, approvalEscalationEmailSubject: null, approvalEscalationEmailBody: null, approvalSlaTargetMinutes: null };
}

export async function upsertCertificateProgramProfile(input: CertificateProgramProfileInput, actorUserId: number) {
  const db = await requireDb();
  const existing = (await db.select({ id: certificateProgramProfiles.id }).from(certificateProgramProfiles).where(eq(certificateProgramProfiles.certificationId, input.certificationId)).limit(1))[0];
  const values = { completionNarrative: input.completionNarrative || null, instructionalHours: input.instructionalHours || null, supervisedPracticalTraining: input.supervisedPracticalTraining || null, complianceStatement: input.complianceStatement || null, accreditingBodyName: input.accreditingBodyName || null, licenseNumber: input.licenseNumber || null, executiveName: input.executiveName || "Jacquese Hinton", executiveTitle: input.executiveTitle || "Founder & Director of Institutional Strategy", courseInstructorSignatoryName: input.courseInstructorSignatoryName || null, courseInstructorSignatoryTitle: input.courseInstructorSignatoryTitle || null, isHighStakes: input.isHighStakes, previewAcknowledgementExpirationMinutes: input.previewAcknowledgementExpirationMinutes, previewReminderEnabled: input.previewReminderEnabled, previewReminderLeadMinutes: input.previewReminderLeadMinutes, previewReminderEmailSubject: input.previewReminderEmailSubject || null, previewReminderEmailBody: input.previewReminderEmailBody || null, approvalEscalationEnabled: input.approvalEscalationEnabled, approvalEscalationDelayMinutes: input.approvalEscalationDelayMinutes, approvalEscalationRecipientUserId: input.approvalEscalationRecipientUserId, approvalEscalationEmailSubject: input.approvalEscalationEmailSubject || null, approvalEscalationEmailBody: input.approvalEscalationEmailBody || null, approvalSlaTargetMinutes: input.approvalSlaTargetMinutes, updatedByUserId: actorUserId };
  if (existing) await db.update(certificateProgramProfiles).set(values).where(eq(certificateProgramProfiles.id, existing.id)); else await db.insert(certificateProgramProfiles).values({ certificationId: input.certificationId, ...values });
  await db.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.program_profile.updated", entityType: "certificate_program_profile", entityId: String(input.certificationId), eventMetadata: { certificationId: input.certificationId, highStakes: input.isHighStakes, previewExpirationMinutes: input.previewAcknowledgementExpirationMinutes, previewReminderEnabled: input.previewReminderEnabled, previewReminderLeadMinutes: input.previewReminderLeadMinutes, hasPreviewReminderTemplate: Boolean(input.previewReminderEmailSubject || input.previewReminderEmailBody), approvalEscalationEnabled: input.approvalEscalationEnabled, approvalEscalationDelayMinutes: input.approvalEscalationDelayMinutes, approvalSlaTargetMinutes: input.approvalSlaTargetMinutes ?? null, hasEscalationTemplate: Boolean(input.approvalEscalationEmailSubject || input.approvalEscalationEmailBody), hasAccreditingBody: Boolean(input.accreditingBodyName), hasLicenseNumber: Boolean(input.licenseNumber) } });
  return getCertificateProgramProfile(input.certificationId);
}

export async function listCertificateTemplateTestDeliveryHistory(certificationId?: number) {
  const db = await requireDb();
  return db.select({
    id: certificateTemplateTestDeliveries.id,
    certificationId: certificateTemplateTestDeliveries.certificationId,
    credentialTitle: certifications.title,
    templateType: certificateTemplateTestDeliveries.templateType,
    subject: certificateTemplateTestDeliveries.subject,
    status: certificateTemplateTestDeliveries.status,
    providerMessageId: certificateTemplateTestDeliveries.providerMessageId,
    errorMessage: certificateTemplateTestDeliveries.errorMessage,
    createdAt: certificateTemplateTestDeliveries.createdAt,
    sentAt: certificateTemplateTestDeliveries.sentAt,
    createdByName: users.name,
  }).from(certificateTemplateTestDeliveries)
    .innerJoin(certifications, eq(certificateTemplateTestDeliveries.certificationId, certifications.id))
    .leftJoin(users, eq(certificateTemplateTestDeliveries.createdByUserId, users.id))
    .where(certificationId ? eq(certificateTemplateTestDeliveries.certificationId, certificationId) : undefined)
    .orderBy(desc(certificateTemplateTestDeliveries.createdAt))
    .limit(50);
}

export async function setExecutiveSignature(input: { certificationId: number; storageKey: string; url: string; fileName: string; mimeType: "image/png" | "image/jpeg"; crop: { x: number; y: number; size: number; zoom: number } | null; actorUserId: number }) {
  const db = await requireDb();
  const existing = (await db.select({ id: certificateProgramProfiles.id }).from(certificateProgramProfiles).where(eq(certificateProgramProfiles.certificationId, input.certificationId)).limit(1))[0];
  const values = { executiveSignatureStorageKey: input.storageKey, executiveSignatureUrl: input.url, executiveSignatureMimeType: input.mimeType, executiveSignatureCrop: input.crop, updatedByUserId: input.actorUserId };
  if (existing) await db.update(certificateProgramProfiles).set(values).where(eq(certificateProgramProfiles.id, existing.id));
  else await db.insert(certificateProgramProfiles).values({ certificationId: input.certificationId, ...values });
  await db.insert(administrationAuditEvents).values({ actorUserId: input.actorUserId, action: "certificate.executive_signature.updated", entityType: "certificate_program_profile", entityId: String(input.certificationId), eventMetadata: { fileName: input.fileName, mimeType: input.mimeType, cropped: Boolean(input.crop) } });
  return getCertificateProgramProfile(input.certificationId);
}

export async function clearExecutiveSignature(certificationId: number, actorUserId: number) {
  const db = await requireDb();
  const existing = (await db.select({ id: certificateProgramProfiles.id, executiveSignatureStorageKey: certificateProgramProfiles.executiveSignatureStorageKey }).from(certificateProgramProfiles).where(eq(certificateProgramProfiles.certificationId, certificationId)).limit(1))[0];
  if (!existing?.executiveSignatureStorageKey) throw new Error(certificateErrors.notFound);
  await db.update(certificateProgramProfiles).set({ executiveSignatureStorageKey: null, executiveSignatureUrl: null, executiveSignatureMimeType: null, executiveSignatureCrop: null, updatedByUserId: actorUserId }).where(eq(certificateProgramProfiles.id, existing.id));
  await db.insert(administrationAuditEvents).values({ actorUserId, action: "certificate.executive_signature.removed", entityType: "certificate_program_profile", entityId: String(certificationId), eventMetadata: {} });
  return getCertificateProgramProfile(certificationId);
}

export async function getCertificateById(id: number) {
  const db = await requireDb();
  return (await db.select().from(issuedCertificates).where(eq(issuedCertificates.id, id)).limit(1))[0] ?? null;
}

type CertificateRecordInput = CertificateCandidate & {
  certificateNumber: string;
  verificationToken: string;
  activeIssuanceKey: string | null;
  issuedAt: Date;
  documentStorageKey: string;
  documentUrl: string;
  documentSha256: string;
  documentSnapshot: Record<string, string | null>;
  actorUserId: number;
  reissueOfCertificateId?: number;
};

export async function createIssuedCertificate(input: CertificateRecordInput) {
  const db = await requireDb();
  return db.transaction(async tx => {
    if (input.reissueOfCertificateId) {
      const previous = (await tx.select().from(issuedCertificates).where(eq(issuedCertificates.id, input.reissueOfCertificateId)).limit(1))[0];
      if (!previous) throw new Error(certificateErrors.notFound);
      if (previous.status !== "issued") throw new Error(certificateErrors.notIssued);
      await tx.update(issuedCertificates).set({ status: "superseded", activeIssuanceKey: null }).where(eq(issuedCertificates.id, previous.id));
    }
    const result = await tx.insert(issuedCertificates).values({
      certificateNumber: input.certificateNumber,
      verificationToken: input.verificationToken,
      activeIssuanceKey: input.activeIssuanceKey,
      cohortId: input.cohortId,
      cohortStudentId: input.cohortStudentId,
      certificationId: input.certificationId,
      recipientName: input.recipientName,
      recipientEmail: input.recipientEmail,
      cohortTitle: input.cohortTitle,
      credentialTitle: input.credentialTitle,
      ceuValue: input.ceuValue,
      issuedAt: input.issuedAt,
      reissueOfCertificateId: input.reissueOfCertificateId ?? null,
      documentStorageKey: input.documentStorageKey,
      documentUrl: input.documentUrl,
      documentSha256: input.documentSha256,
      documentSnapshot: input.documentSnapshot,
      issuedByUserId: input.actorUserId,
    });
    const id = Number(result[0].insertId);
    await tx.insert(administrationAuditEvents).values({
      actorUserId: input.actorUserId,
      action: input.reissueOfCertificateId ? "certificate.reissued" : "certificate.issued",
      entityType: "issued_certificate",
      entityId: String(id),
      eventMetadata: { certificateNumber: input.certificateNumber, cohortId: input.cohortId, certificationId: input.certificationId },
    });
    return (await tx.select().from(issuedCertificates).where(eq(issuedCertificates.id, id)).limit(1))[0]!;
  });
}

export async function revokeIssuedCertificate(certificateId: number, reason: string, actorUserId: number) {
  const db = await requireDb();
  const certificate = await getCertificateById(certificateId);
  if (!certificate) throw new Error(certificateErrors.notFound);
  if (certificate.status !== "issued") throw new Error(certificateErrors.notIssued);
  await db.transaction(async tx => {
    await tx.update(issuedCertificates).set({ status: "revoked", activeIssuanceKey: null, revokedAt: new Date(), revocationReason: reason }).where(eq(issuedCertificates.id, certificateId));
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "certificate.revoked",
      entityType: "issued_certificate",
      entityId: String(certificateId),
      eventMetadata: { certificateNumber: certificate.certificateNumber },
    });
  });
  return getCertificateById(certificateId);
}

export async function getPublicCertificateVerification(input: CertificateVerifyInput) {
  const db = await requireDb();
  const conditions = [eq(issuedCertificates.certificateNumber, input.reference)];
  if (input.token) conditions.push(eq(issuedCertificates.verificationToken, input.token));
  const certificate = (await db
    .select({
      certificateNumber: issuedCertificates.certificateNumber,
      status: issuedCertificates.status,
      recipientName: issuedCertificates.recipientName,
      credentialTitle: issuedCertificates.credentialTitle,
      cohortTitle: issuedCertificates.cohortTitle,
      ceuValue: issuedCertificates.ceuValue,
      issuedAt: issuedCertificates.issuedAt,
    })
    .from(issuedCertificates)
    .where(and(...conditions))
    .limit(1))[0];
  if (!certificate) return null;
  if (certificate.status !== "issued") return { certificateNumber: certificate.certificateNumber, status: certificate.status };
  return { ...certificate, ceuValue: certificate.ceuValue ? String(certificate.ceuValue) : null };
}
