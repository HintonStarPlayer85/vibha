import { degrees, PDFDocument, PDFFont, PDFPage, StandardFonts, rgb } from "pdf-lib";
import QRCode from "qrcode";

export type CertificateDocumentInput = {
  certificateNumber: string;
  isPreview?: boolean;
  recipientName: string;
  credentialTitle: string;
  cohortTitle: string;
  issuedAt: Date;
  verificationUrl: string;
  instructorName?: string | null;
  instructorTitle?: string | null;
  deliveryMode?: string | null;
  completionNarrative?: string | null;
  instructionalHours?: string | null;
  supervisedPracticalTraining?: string | null;
  complianceStatement?: string | null;
  accreditingBodyName?: string | null;
  licenseNumber?: string | null;
  executiveName?: string | null;
  executiveTitle?: string | null;
  instructorSignature?: { bytes: Uint8Array; mimeType: "image/png" | "image/jpeg" } | null;
  executiveSignature?: { bytes: Uint8Array; mimeType: "image/png" | "image/jpeg" } | null;
};

function drawCentered(page: PDFPage, text: string, font: PDFFont, size: number, y: number, color: ReturnType<typeof rgb>) {
  const { width } = page.getSize(); const textWidth = font.widthOfTextAtSize(text, size);
  page.drawText(text, { x: Math.max(42, (width - textWidth) / 2), y, size, font, color });
}
function drawCenteredInRegion(page: PDFPage, text: string, font: PDFFont, size: number, y: number, color: ReturnType<typeof rgb>, x: number, width: number) {
  const textWidth = font.widthOfTextAtSize(text, size);
  page.drawText(text, { x: Math.max(x, x + (width - textWidth) / 2), y, size, font, color });
}
function wrappedLines(font: PDFFont, value: string, size: number, maxWidth: number) {
  const lines: string[] = []; let line = "";
  value.split(/\s+/).filter(Boolean).forEach(word => { const next = line ? `${line} ${word}` : word; if (line && font.widthOfTextAtSize(next, size) > maxWidth) { lines.push(line); line = word; } else line = next; });
  if (line) lines.push(line); return lines;
}
function drawWrappedCentered(page: PDFPage, value: string, font: PDFFont, size: number, y: number, color: ReturnType<typeof rgb>, maxWidth: number, lineGap = 5) {
  const lines = wrappedLines(font, value, size, maxWidth); lines.forEach((line, index) => drawCentered(page, line, font, size, y - index * (size + lineGap), color)); return lines.length;
}
function present(value: string | null | undefined) { return Boolean(value?.trim()); }

export async function generateCertificatePdf(input: CertificateDocumentInput) {
  const document = await PDFDocument.create(); const page = document.addPage([792, 612]);
  const navy = rgb(7 / 255, 31 / 255, 73 / 255); const blue = rgb(61 / 255, 136 / 255, 194 / 255); const orange = rgb(244 / 255, 122 / 255, 32 / 255); const ink = rgb(38 / 255, 38 / 255, 42 / 255); const muted = rgb(79 / 255, 84 / 255, 91 / 255); const pale = rgb(250 / 255, 249 / 255, 247 / 255);
  const titleFont = await document.embedFont(StandardFonts.TimesRomanBold); const serif = await document.embedFont(StandardFonts.TimesRoman); const italic = await document.embedFont(StandardFonts.TimesRomanItalic); const sans = await document.embedFont(StandardFonts.Helvetica); const sansBold = await document.embedFont(StandardFonts.HelveticaBold);
  page.drawRectangle({ x: 0, y: 0, width: 792, height: 612, color: rgb(1, 1, 1) });
  page.drawRectangle({ x: 18, y: 18, width: 756, height: 576, borderColor: blue, borderWidth: 2.2 });
  page.drawRectangle({ x: 27, y: 27, width: 738, height: 558, borderColor: orange, borderWidth: 0.8 });
  page.drawRectangle({ x: 38, y: 463, width: 716, height: 3, color: orange });
  drawCentered(page, "Certificate of Completion", titleFont, 42, 522, blue);
  drawCentered(page, "VIBHA", sansBold, 20, 490, navy);
  drawCentered(page, "THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH & ADVANCEMENT", sansBold, 7.2, 476, muted);
  drawCentered(page, "THIS IS TO CERTIFY THAT", serif, 12, 438, ink);
  const recipientLines = drawWrappedCentered(page, input.recipientName, titleFont, 30, 394, blue, 650, 4);
  const credentialTop = 346 - Math.max(0, recipientLines - 1) * 34;
  drawCentered(page, "HAS SUCCESSFULLY COMPLETED THE", serif, 11, credentialTop, muted);
  const credentialLines = drawWrappedCentered(page, input.credentialTitle.toUpperCase(), titleFont, 19, credentialTop - 28, ink, 690, 4);
  let detailY = credentialTop - 52 - Math.max(0, credentialLines - 1) * 23;
  const narrative = input.completionNarrative?.trim() || "This VIBHA training program was completed in accordance with its approved instructional requirements.";
  detailY -= drawWrappedCentered(page, narrative, serif, 10, detailY, muted, 650, 3) * 13;
  const facts = [
    `Awarded on: ${new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" }).format(input.issuedAt)}`,
    `Program modality: ${input.deliveryMode?.trim() || "VIBHA Instruction"}`,
    `Cohort: ${input.cohortTitle}`,
    input.instructionalHours?.trim() ? `Total instructional hours: ${input.instructionalHours.trim()}` : null,
    input.supervisedPracticalTraining?.trim() ? `Supervised practical training: ${input.supervisedPracticalTraining.trim()}` : null,
  ].filter((value): value is string => Boolean(value));
  facts.forEach((fact, index) => drawCentered(page, fact, sansBold, 9.2, detailY - 16 - index * 14, ink));
  detailY -= 22 + facts.length * 14;
  if (present(input.complianceStatement)) { const count = drawWrappedCentered(page, input.complianceStatement!.trim(), italic, 8.3, detailY, muted, 650, 2); detailY -= count * 10 + 7; }
  if (present(input.accreditingBodyName) || present(input.licenseNumber)) {
    const disclosures = [input.accreditingBodyName?.trim() ? `Accrediting / licensing organization: ${input.accreditingBodyName.trim()}` : null, input.licenseNumber?.trim() ? `License / approval number: ${input.licenseNumber.trim()}` : null].filter((value): value is string => Boolean(value));
    const disclosureLines = disclosures.flatMap(value => wrappedLines(sansBold, value, 7.7, 560)); const blockHeight = Math.max(27, disclosureLines.length * 10 + 12);
    page.drawRectangle({ x: 100, y: detailY - blockHeight + 4, width: 592, height: blockHeight, color: pale, borderColor: orange, borderWidth: 0.5 }); disclosureLines.forEach((line, index) => drawCentered(page, line, sansBold, 7.7, detailY - 7 - index * 10, navy)); detailY -= blockHeight + 10;
  }
  const signatureY = Math.max(78, detailY - 15);
  page.drawLine({ start: { x: 82, y: signatureY }, end: { x: 324, y: signatureY }, thickness: 0.8, color: rgb(175 / 255, 143 / 255, 65 / 255) });
  page.drawLine({ start: { x: 468, y: signatureY }, end: { x: 710, y: signatureY }, thickness: 0.8, color: rgb(175 / 255, 143 / 255, 65 / 255) });
  if (input.instructorSignature) {
    try {
      const signature = input.instructorSignature.mimeType === "image/png" ? await document.embedPng(input.instructorSignature.bytes) : await document.embedJpg(input.instructorSignature.bytes);
      const scale = Math.min(150 / signature.width, 36 / signature.height, 1);
      const width = signature.width * scale; const height = signature.height * scale;
      page.drawImage(signature, { x: 203 - width / 2, y: signatureY + 4, width, height });
    } catch { /* A malformed optional signature must not prevent a valid certificate from being generated. */ }
  }
  if (input.executiveSignature) {
    try {
      const signature = input.executiveSignature.mimeType === "image/png" ? await document.embedPng(input.executiveSignature.bytes) : await document.embedJpg(input.executiveSignature.bytes);
      const scale = Math.min(150 / signature.width, 36 / signature.height, 1);
      const width = signature.width * scale; const height = signature.height * scale;
      page.drawImage(signature, { x: 589 - width / 2, y: signatureY + 4, width, height });
    } catch { /* A malformed optional executive signature must not prevent a valid certificate from being generated. */ }
  }
  drawCenteredInRegion(page, input.instructorName?.trim() || "VIBHA Instructor", titleFont, 10.2, signatureY - 15, ink, 82, 242); drawCenteredInRegion(page, input.instructorTitle?.trim() || "Course Instructor", serif, 9.5, signatureY - 29, muted, 82, 242);
  drawCenteredInRegion(page, input.executiveName?.trim() || "Jacquese Hinton", titleFont, 10.2, signatureY - 15, ink, 468, 242); const executiveTitle = input.executiveTitle?.trim() || "Founder & Director of Institutional Strategy"; drawCenteredInRegion(page, executiveTitle, serif, 8.5, signatureY - 29, muted, 468, 242);
  if (input.isPreview) {
    page.drawText("PREVIEW ONLY — NOT ISSUED", { x: 50, y: 43, font: sansBold, size: 8.5, color: orange });
    page.drawText("Certificate number and verification code are assigned only at issuance.", { x: 50, y: 31, font: sans, size: 7.2, color: muted });
    page.drawText("PREVIEW", { x: 356, y: 280, font: sansBold, size: 38, color: rgb(0.93, 0.93, 0.93), rotate: degrees(24), opacity: 0.55 });
  } else {
    page.drawText(`Verification no. ${input.certificateNumber}`, { x: 50, y: 43, font: sansBold, size: 7.5, color: navy }); page.drawText("Verify at thevibha.org/verify-certificate", { x: 50, y: 31, font: sans, size: 7.2, color: muted });
    const qrDataUrl = await QRCode.toDataURL(input.verificationUrl, { width: 104, margin: 1, errorCorrectionLevel: "M" }); const qr = await document.embedPng(Buffer.from(qrDataUrl.split(",")[1] ?? "", "base64")); page.drawImage(qr, { x: 690, y: 32, width: 52, height: 52 }); page.drawText("Scan to verify", { x: 683, y: 22, font: sans, size: 6.6, color: muted });
  }
  document.setTitle(`VIBHA Certificate ${input.certificateNumber}`); document.setAuthor("VIBHA | The Virginia Institute for Behavioral Health & Advancement"); document.setSubject("Certificate of Completion"); return document.save();
}
