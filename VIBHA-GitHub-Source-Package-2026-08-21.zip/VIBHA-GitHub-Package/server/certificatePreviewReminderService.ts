import { Resend } from "resend";
import {
  getCertificatePreviewReminderSchedule,
  getCertificatePreviewReminderDelivery,
  listDueCertificatePreviewReminders,
  markCertificatePreviewReminderAccepted,
  markCertificatePreviewReminderFailed,
  recordCertificatePreviewReminderScheduleRun,
  reserveCertificatePreviewReminder,
  prepareCertificatePreviewReminderRetry,
} from "./certificateDb";
import { getResendConfiguration, verifyResendSenderDomain } from "./resendCohort";

type Reminder = {
  id: number;
  acknowledgementId: number;
  recipientName: string;
  recipientEmail: string;
  idempotencyKey: string;
  credentialTitle?: string;
  cohortTitle?: string;
  expiresAt?: Date;
  templateSubject?: string | null;
  templateBody?: string | null;
};

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]!);
}

function renderReminder(input: { recipientName: string; credentialTitle: string; cohortTitle: string; expiresAt: Date; templateSubject?: string | null; templateBody?: string | null }) {
  const expiresAt = new Intl.DateTimeFormat("en-US", { dateStyle: "long", timeStyle: "short" }).format(input.expiresAt);
  const merge = (template: string) => template.replace(/\{\{\s*(administratorName|credentialTitle|cohortTitle|expiresAt|studentName)\s*\}\}/g, (_match, key: string) => ({ administratorName: input.recipientName, credentialTitle: input.credentialTitle, cohortTitle: input.cohortTitle, expiresAt, studentName: "" })[key] ?? "");
  const subject = input.templateSubject ? merge(input.templateSubject) : `Action needed: VIBHA certificate preview expires soon`;
  const message = `Your acknowledged preview for ${input.credentialTitle} in ${input.cohortTitle} will expire on ${expiresAt}. Review the Certificate Repository and issue the certificate, or generate a fresh preview if the certificate details have changed.`;
  const body = input.templateBody ? merge(input.templateBody) : message;
  const html = `<!doctype html><html><body style="margin:0;background:#f6f8fb;font-family:Arial,sans-serif"><div style="max-width:680px;margin:0 auto;padding:28px 16px"><div style="background:#071f49;padding:20px 24px;color:#fff"><strong style="font-size:22px">VIBHA</strong><div style="margin-top:4px;font-size:12px;letter-spacing:.08em">THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH &amp; ADVANCEMENT</div></div><div style="background:#fff;padding:28px 24px;border:1px solid #dce3ec"><h1 style="margin:0 0 18px;font-size:22px;color:#071f49">Certificate preview reminder</h1><p style="margin:0;color:#34435a;line-height:1.65">Hello ${escapeHtml(input.recipientName)},</p><p style="margin:16px 0 0;color:#34435a;line-height:1.65">${escapeHtml(body)}</p><p style="margin:28px 0 0;padding-top:18px;border-top:1px solid #dce3ec;color:#667085;font-size:13px;line-height:1.6">This is an automated VIBHA certificate-governance reminder. Reply to this email if you need assistance.</p></div></div></body></html>`;
  return { subject, html, text: `Hello ${input.recipientName},\n\n${body}` };
}

async function attemptReminderDelivery(reminder: Reminder, retry: boolean) {
  const config = getResendConfiguration();
  const senderDomain = await verifyResendSenderDomain(true);
  if (!config.readyToSend || !config.apiKey || !config.from || !config.replyTo || !senderDomain.verified) {
    const detail = !senderDomain.verified ? `Sender domain ${senderDomain.domain || "unknown"} is ${senderDomain.status.replace(/_/g, " ")}.` : `Missing: ${config.missing.join(", ")}.`;
    await markCertificatePreviewReminderFailed(reminder.id, "resend_not_ready", detail, retry);
    return { status: "failed" as const, error: detail };
  }
  try {
    const { subject, html, text } = renderReminder({ recipientName: reminder.recipientName, credentialTitle: reminder.credentialTitle ?? "your VIBHA course", cohortTitle: reminder.cohortTitle ?? "your cohort", expiresAt: reminder.expiresAt ?? new Date(), templateSubject: reminder.templateSubject, templateBody: reminder.templateBody });
    const result = await new Resend(config.apiKey).emails.send({
      from: config.from,
      to: [reminder.recipientEmail],
      replyTo: config.replyTo,
      subject,
      html,
      text,
      tags: [{ name: "certificate_preview_reminder", value: String(reminder.acknowledgementId) }],
    }, { idempotencyKey: reminder.idempotencyKey.slice(0, 256) });
    if (result.error || !result.data?.id) {
      const error = result.error?.message || "Resend did not accept the certificate preview reminder.";
      await markCertificatePreviewReminderFailed(reminder.id, result.error?.name || "resend_error", error, retry);
      return { status: "failed" as const, error };
    }
    await markCertificatePreviewReminderAccepted(reminder.id, result.data.id);
    return { status: "accepted" as const, error: null };
  } catch (error) {
    const detail = error instanceof Error ? error.message : "The reminder request did not complete.";
    await markCertificatePreviewReminderFailed(reminder.id, "resend_network_error", detail, retry);
    return { status: "failed" as const, error: detail };
  }
}

export async function runCertificatePreviewReminderSweep(taskUid: string) {
  const schedule = await getCertificatePreviewReminderSchedule(taskUid);
  if (!schedule) return { ok: true, skipped: "orphan" as const };
  if (!schedule.enabled) return { ok: true, skipped: "disabled" as const };
  const due = await listDueCertificatePreviewReminders();
  let accepted = 0;
  let failed = 0;
  let duplicates = 0;
  for (const candidate of due) {
    if (!candidate.recipientEmail || !candidate.recipientName) { continue; }
    const rendered = renderReminder({ recipientName: candidate.recipientName, credentialTitle: candidate.credentialTitle, cohortTitle: candidate.cohortTitle, expiresAt: candidate.expiresAt, templateSubject: candidate.reminderEmailSubject, templateBody: candidate.reminderEmailBody });
    const reserved = await reserveCertificatePreviewReminder({ acknowledgementId: candidate.acknowledgementId, recipientUserId: candidate.recipientUserId, recipientName: candidate.recipientName, recipientEmail: candidate.recipientEmail, subject: rendered.subject });
    if (!reserved.created) { duplicates += 1; continue; }
    const enriched = Object.assign(reserved.reminder, { credentialTitle: candidate.credentialTitle, cohortTitle: candidate.cohortTitle, expiresAt: candidate.expiresAt, templateSubject: candidate.reminderEmailSubject, templateBody: candidate.reminderEmailBody });
    const first = await attemptReminderDelivery(enriched, false);
    const result = first.status === "accepted" ? first : await attemptReminderDelivery(enriched, true);
    if (result.status === "accepted") accepted += 1; else failed += 1;
  }
  const summary = { due: due.length, accepted, failed, duplicates };
  await recordCertificatePreviewReminderScheduleRun(taskUid, summary);
  return { ok: true, ...summary };
}

export async function resendCertificatePreviewReminder(id: number, actorUserId: number) {
  const prepared = await prepareCertificatePreviewReminderRetry(id, actorUserId);
  if (!prepared) throw new Error("CERTIFICATE_NOT_FOUND");
  const result = await attemptReminderDelivery(prepared, false);
  return { reminder: await getCertificatePreviewReminderDelivery(id), result };
}
