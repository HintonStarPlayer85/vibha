export type LeadershipProfile = {
  id: string;
  name: string;
  title: string;
  biography: readonly string[];
  image: {
    small: string;
    large: string;
    width: number;
    height: number;
    alt: string;
  };
};

export type LeadershipContentOverrides = Record<string, string | undefined>;

export const leadershipTeam = [
  {
    id: "jacquese-hinton",
    name: "Jacquese J. Hinton, MS, QMHP",
    title: "Founder & Director of Institutional Strategy",
    biography: [
      "Jacquese Hinton brings more than 20 years of executive operations and behavioral health leadership experience to the Virginia Institute for Behavioral Health & Advancement, where she leads institutional strategy, service-line growth, and the systems that connect clinical care, compliance, and organizational performance.",
      "Jacquese holds a Master of Science in Human Resource Management and a Master of Science in Clinical Mental Health Counseling, and is registered with the Commonwealth of Virginia as a Qualified Mental Health Professional (QMHP). She is also a Certified Executive Behavioral Health Leader (CEBHL). Her expertise spans clinical operations, program launch and scaling, credentialing and payer readiness, compliance, and care coordination — skills built through hands-on leadership across outpatient, residential, and emergency psychiatric care settings.",
      "Jacquese currently serves as VP of Operations & Care Integration and Chief Compliance Officer at Ervin's Village Family Support LLC, where she co-owns and leads operations, compliance, and care integration for the practice's outpatient therapy and medication-management services. She previously served as Executive Director of Operations & Care Coordination at Divine Minds LLC, where she helped scale the organization to nearly $1M in revenue while launching new service lines and standardizing clinical and administrative workflows, and as an Emergency Psychiatry Assessment Clinician at Carilion Clinic, providing crisis assessment and disposition coordination in a high-acuity emergency and inpatient setting.",
      "As Founder and Principal Consultant of Hinton Consulting LLC, Jacquese has advised more than 50 organizations — including behavioral health providers, nonprofits, and government entities — on business formation, strategic planning, and operational design, and has supported more than $10M in grant and program funding across her consulting engagements.",
      "The Virginia Institute for Behavioral Health & Advancement is Jacquese's passion project: an effort to change the way behavioral health services are delivered by building a stronger, better-trained workforce from the ground up. Having spent two decades inside the systems she now works to improve, she founded VIBHA to train the next generation of behavioral health workers — equipping them not just with skills, but with the judgment, ethics, and resilience the field demands.",
    ],
    image: {
      small: "/manus-storage/jacquese-hinton-480_27eeaec8.webp",
      large: "/manus-storage/jacquese-hinton-960_bd8540dd.webp",
      width: 960,
      height: 1576,
      alt: "Portrait of Jacquese J. Hinton",
    },
  },
  {
    id: "candice-womack",
    name: "Candice Womack",
    title: "Chancellor",
    biography: [
      "Candice Womack brings nearly two decades of hands-on leadership experience to her role as Chancellor of the Virginia Institute for Behavioral Health & Advancement, shaped by two very different but equally demanding environments: faith-based education and high-volume corporate customer service.",
      "For seven years, Candice served as Assistant Administrator at Victory International College, a theology school, where she gained firsthand experience in the realities of running an educational institution — administration, operations, student support, and community-building. That experience gave her an intimate, ground-level understanding of what it actually takes to build and sustain a school.",
      "Candice spent 10 years as a Customer Service Call Center Supervisor for Spectrum, specializing in managing high-escalation calls — the kind of high-pressure interactions that demand composure, quick judgment, and genuine empathy. In that role, she led and coached teams, built processes and workflows from scratch to improve consistency and outcomes, and earned a reputation for being deeply relatable — able to connect with people from all walks of life and de-escalate even the most difficult situations.",
      "That combination — real operational know-how paired with a natural ability to lead, organize, and build structure where none exists — is exactly what Candice brings to her role as Chancellor. She is known for creating clear, workable processes, developing strong teams, and leading with a steady, relatable presence that puts students, staff, and partners at ease, even in challenging moments.",
    ],
    image: {
      small: "/manus-storage/candice-womack-480_1f43a43b.webp",
      large: "/manus-storage/candice-womack-960_57ec1c13.webp",
      width: 960,
      height: 1200,
      alt: "Portrait of Candice Womack",
    },
  },
  {
    id: "beverly-cobbs",
    name: "Beverly L. Cobbs, MSW, LCSW-S",
    title: "Director of Clinical Education, De-Escalation & Forensic Interviewing",
    biography: [
      "Beverly Cobbs brings more than two decades of clinical leadership to the Virginia Institute for Behavioral Health & Advancement, where she serves as a Behavioral Health Instructor delivering training in clinical foundations, ethics, crisis response, documentation standards, and workforce readiness. She is a Licensed Clinical Social Worker (Supervisee) in Virginia, a Certified Mental Health Instructor, and certified in both De-Escalation Techniques and Forensic Interviewing — the latter developed during her years as a Child Protective Investigator and Foster Care Case Management Supervisor, and sharpened over 12 years of conducting clinical assessments.",
      "Beverly previously served as Clinical Director at Divine Minds LLC and Chief Therapist at Divine Minds Behavioral Health LLC, where she provided executive clinical leadership across outpatient and community-based behavioral health services, oversees clinical operations and staff supervision, and ensures compliance with ethical, regulatory, and Medicaid standards. Her clinical leadership background also includes serving as Clinical Director at Crossroads Treatment Centers and at L&G Support Services, and as a Senior Foster Care Case Manager at HumanKind. Earlier in her career, she held progressive roles in social work supervision, program leadership, child welfare, and family services with organizations including Alliance Human Services, Jones County Department of Social Services, Seamen's Society, SCO Family Services, The Children's Village, and Duke University.",
      "Beverly holds a Master of Social Work from the University of New England, a Master of Theology from Victory International College, and a Bachelor of Science from the University of North Carolina. She is also a Church Elder and Ordained Minister, a role she has held since 1997, bringing a steady, values-driven presence to her clinical and educational work.",
      "Beverly is a member of Delta Sigma Theta Sorority, Inc., serves as CEO of Ervin's Village Family Support, LLC, and is a provider with Psychology Today and the Open Path Psychotherapy Network.",
    ],
    image: {
      small: "/manus-storage/beverly-cobbs-480_d7f9687f.webp",
      large: "/manus-storage/beverly-cobbs-960_1e6f960c.webp",
      width: 960,
      height: 1302,
      alt: "Portrait of Beverly L. Cobbs",
    },
  },
  {
    id: "welton-loftin",
    name: "WL Loftin, M.Ed",
    title: "Director of Workforce Education & Business Development",
    biography: [
      "WL Loftin leads all Mental Health Agency and Corporate workshops and Mental Health Non-Clinical Cohorts at the Virginia Institute for Behavioral Health & Advancement, while also guiding the Institute's strategic growth, business development, and community partnerships.",
      "Welton currently serves as an Adjunct Professor teaching Mental Health at both the UNC-G and the UNC-W, ECU, Guilford College and leads Mental Health Forums across North Carolina, Virginia, and Tennessee. He holds a Master of Education in Adult Education with a focus in training and seminar development, and a Bachelor of Arts in Political Science with a minor in Psychology, and is currently pursuing a Doctorate in Education concentrating in Organizational Management. That academic foundation, paired with his work as a life coach and mental health advisor, gives him a practical, adult-learner-centered approach to workforce training. His areas of expertise include cognitive-behavioral approaches, psychological assessment, clinical supervision, conflict resolution, and research methodology and statistical analysis — skills he brings directly into the classroom and into the strategic planning process alike.",
      "Over a career spanning corporate training, adult education, and real estate development, Welton built and delivered training curricula for organizations including UPS and JLT Real Estate Group, where he also served as Owner/Broker, developing sales teams and strategic growth plans that consistently outperformed targets.",
      "Welton is active in his community, serving on the boards of local community orginatizations, and holding memberships with the National Association of Adult Educators, the National Association of Investors, the Charlotte and Piedmont Boards of Realtors, and Kappa Alpha Psi Fraternity.",
    ],
    image: {
      small: "/manus-storage/welton-loftin-480_bbbd001f.webp",
      large: "/manus-storage/welton-loftin-960_06f4d1c6.webp",
      width: 960,
      height: 1303,
      alt: "Portrait of WL Loftin",
    },
  },
] as const satisfies readonly LeadershipProfile[];

function profileContentKey(profileId: string, field: "name" | "title" | "biography") {
  return `leadership.profile.${profileId}.${field}`;
}

function splitBiography(value: string) {
  return value
    .split(/\n\s*\n/)
    .map(paragraph => paragraph.trim())
    .filter(Boolean);
}

export function getLeadershipTeam(overrides: LeadershipContentOverrides = {}) {
  return leadershipTeam.map(profile => {
    const name = overrides[profileContentKey(profile.id, "name")]?.trim() || profile.name;
    const title = overrides[profileContentKey(profile.id, "title")]?.trim() || profile.title;
    const biography = overrides[profileContentKey(profile.id, "biography")]?.trim();
    return {
      ...profile,
      name,
      title,
      biography: biography ? splitBiography(biography) : profile.biography,
      image: { ...profile.image, alt: `Portrait of ${name}` },
    };
  });
}
