import { createHash, randomBytes } from "node:crypto";
import {
  certificateErrors,
  createIssuedCertificate,
  getCertificateById,
  getCertificateCandidate,
  markCertificatePreviewAcknowledgementUsed,
  revokeIssuedCertificate,
  validateCertificatePreviewAcknowledgement,
  type CertificateCandidate,
} from "./certificateDb";
import { generateCertificatePdf } from "./certificatePdf";
import { storageGetSignedUrl, storagePut } from "./storage";

export function generateCertificateNumber() {
  return `VIBHA-${new Date().getUTCFullYear()}-${randomBytes(6).toString("hex").toUpperCase()}`;
}

function verificationToken() {
  return randomBytes(24).toString("hex");
}

function previewFingerprint(candidate: CertificateCandidate) {
  return createHash("sha256").update(JSON.stringify({
    cohortStudentId: candidate.cohortStudentId,
    certificationId: candidate.certificationId,
    recipientName: candidate.recipientName,
    credentialTitle: candidate.credentialTitle,
    cohortTitle: candidate.cohortTitle,
    instructorName: candidate.instructorName,
    instructorTitle: candidate.instructorTitle,
    deliveryMode: candidate.deliveryMode,
    completionNarrative: candidate.completionNarrative,
    instructionalHours: candidate.instructionalHours,
    supervisedPracticalTraining: candidate.supervisedPracticalTraining,
    complianceStatement: candidate.complianceStatement,
    accreditingBodyName: candidate.accreditingBodyName,
    licenseNumber: candidate.licenseNumber,
    executiveName: candidate.executiveName,
    executiveTitle: candidate.executiveTitle,
    instructorSignatureStorageKey: candidate.instructorSignatureStorageKey,
    executiveSignatureStorageKey: candidate.executiveSignatureStorageKey,
  })).digest("hex");
}

function safePathSegment(value: string) {
  return value.replace(/[^A-Za-z0-9-]/g, "").slice(0, 64);
}

async function loadSignature(storageKey: string | null, mimeType: "image/png" | "image/jpeg" | null) {
  if (!storageKey || !mimeType) return null;
  try {
    const signedUrl = await storageGetSignedUrl(storageKey);
    const response = await fetch(signedUrl);
    if (!response.ok) return null;
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (!bytes.length || bytes.length > 2 * 1024 * 1024) return null;
    return { bytes, mimeType };
  } catch { return null; }
}

async function createCertificateArtifact(candidate: CertificateCandidate, actorUserId: number, origin: string, reissueOfCertificateId?: number) {
  const number = generateCertificateNumber();
  const token = verificationToken();
  const issuedAt = new Date();
  const verifyUrl = `${origin.replace(/\/$/, "")}/verify-certificate?reference=${encodeURIComponent(number)}&token=${encodeURIComponent(token)}`;
  const instructorName = candidate.cohortSignatoryInstructorId ? candidate.instructorName : candidate.courseInstructorSignatoryName || candidate.instructorName;
  const instructorTitle = candidate.cohortSignatoryInstructorId ? candidate.instructorTitle || "Course Instructor" : candidate.courseInstructorSignatoryTitle || candidate.instructorTitle || "Course Instructor";
  const documentSnapshot = {
    recipientName: candidate.recipientName,
    credentialTitle: candidate.credentialTitle,
    cohortTitle: candidate.cohortTitle,
    instructorName,
    instructorTitle,
    courseInstructorSignatoryName: candidate.courseInstructorSignatoryName,
    courseInstructorSignatoryTitle: candidate.courseInstructorSignatoryTitle,
    deliveryMode: candidate.deliveryMode,
    completionNarrative: candidate.completionNarrative,
    instructionalHours: candidate.instructionalHours,
    supervisedPracticalTraining: candidate.supervisedPracticalTraining,
    complianceStatement: candidate.complianceStatement,
    accreditingBodyName: candidate.accreditingBodyName,
    licenseNumber: candidate.licenseNumber,
    executiveName: candidate.executiveName,
    executiveTitle: candidate.executiveTitle,
    executiveSignatureStorageKey: candidate.executiveSignatureStorageKey,
    executiveSignatureUrl: candidate.executiveSignatureUrl,
    executiveSignatureMimeType: candidate.executiveSignatureMimeType,
    instructorSignatureStorageKey: candidate.instructorSignatureStorageKey,
    instructorSignatureUrl: candidate.instructorSignatureUrl,
    instructorSignatureMimeType: candidate.instructorSignatureMimeType,
  };
  const instructorSignature = await loadSignature(candidate.instructorSignatureStorageKey, candidate.instructorSignatureMimeType);
  const executiveSignature = await loadSignature(candidate.executiveSignatureStorageKey, candidate.executiveSignatureMimeType);
  const pdf = await generateCertificatePdf({
    certificateNumber: number,
    issuedAt,
    verificationUrl: verifyUrl,
    ...documentSnapshot,
    instructorSignature,
    executiveSignature,
  });
  const bytes = Buffer.from(pdf);
  const stored = await storagePut(`certificates/${issuedAt.getUTCFullYear()}/${safePathSegment(number)}.pdf`, bytes, "application/pdf");
  return createIssuedCertificate({
    ...candidate,
    certificateNumber: number,
    verificationToken: token,
    activeIssuanceKey: candidate.cohortStudentId ? `${candidate.cohortId}:${candidate.cohortStudentId}` : null,
    issuedAt,
    documentStorageKey: stored.key,
    documentUrl: stored.url,
    documentSha256: createHash("sha256").update(bytes).digest("hex"),
    documentSnapshot,
    actorUserId,
    reissueOfCertificateId,
  });
}

export async function issueCertificate(cohortStudentId: number, acknowledgementToken: string, actorUserId: number, origin: string) {
  const candidate = await getCertificateCandidate(cohortStudentId);
  const acknowledgement = await validateCertificatePreviewAcknowledgement({ acknowledgementToken, cohortStudentId, actorUserId, previewFingerprint: previewFingerprint(candidate) });
  const certificate = await createCertificateArtifact(candidate, actorUserId, origin);
  await markCertificatePreviewAcknowledgementUsed(acknowledgement.id, certificate.id, actorUserId);
  return certificate;
}

export async function previewCertificate(cohortStudentId: number, origin: string) {
  const candidate = await getCertificateCandidate(cohortStudentId);
  const issuedAt = new Date();
  const instructorName = candidate.cohortSignatoryInstructorId ? candidate.instructorName : candidate.courseInstructorSignatoryName || candidate.instructorName;
  const instructorTitle = candidate.cohortSignatoryInstructorId ? candidate.instructorTitle || "Course Instructor" : candidate.courseInstructorSignatoryTitle || candidate.instructorTitle || "Course Instructor";
  const [instructorSignature, executiveSignature] = await Promise.all([
    loadSignature(candidate.instructorSignatureStorageKey, candidate.instructorSignatureMimeType),
    loadSignature(candidate.executiveSignatureStorageKey, candidate.executiveSignatureMimeType),
  ]);
  const pdf = await generateCertificatePdf({
    certificateNumber: "PREVIEW-NOT-ISSUED",
    isPreview: true,
    issuedAt,
    verificationUrl: `${origin.replace(/\/$/, "")}/verify-certificate`,
    recipientName: candidate.recipientName,
    credentialTitle: candidate.credentialTitle,
    cohortTitle: candidate.cohortTitle,
    instructorName,
    instructorTitle,
    deliveryMode: candidate.deliveryMode,
    completionNarrative: candidate.completionNarrative,
    instructionalHours: candidate.instructionalHours,
    supervisedPracticalTraining: candidate.supervisedPracticalTraining,
    complianceStatement: candidate.complianceStatement,
    accreditingBodyName: candidate.accreditingBodyName,
    licenseNumber: candidate.licenseNumber,
    executiveName: candidate.executiveName,
    executiveTitle: candidate.executiveTitle,
    instructorSignature,
    executiveSignature,
  });
  return { fileName: `VIBHA-certificate-preview-${safePathSegment(candidate.recipientName) || "student"}.pdf`, dataBase64: Buffer.from(pdf).toString("base64"), previewFingerprint: previewFingerprint(candidate), certificationId: candidate.certificationId, expirationMinutes: candidate.previewAcknowledgementExpirationMinutes ?? 30 };
}

export async function reissueCertificate(certificateId: number, actorUserId: number, origin: string) {
  const certificate = await getCertificateById(certificateId);
  if (!certificate) throw new Error(certificateErrors.notFound);
  if (certificate.status !== "issued") throw new Error(certificateErrors.notIssued);
  return createCertificateArtifact({
    cohortId: certificate.cohortId,
    cohortStudentId: certificate.cohortStudentId,
    certificationId: certificate.certificationId,
    recipientName: certificate.recipientName,
    recipientEmail: certificate.recipientEmail,
    cohortTitle: certificate.cohortTitle,
    credentialTitle: certificate.credentialTitle,
    ceuValue: certificate.ceuValue,
    instructorName: certificate.documentSnapshot?.instructorName ?? null,
    instructorTitle: certificate.documentSnapshot?.instructorTitle ?? null,
    cohortSignatoryInstructorId: null,
    courseInstructorSignatoryName: certificate.documentSnapshot?.courseInstructorSignatoryName ?? null,
    courseInstructorSignatoryTitle: certificate.documentSnapshot?.courseInstructorSignatoryTitle ?? null,
    deliveryMode: certificate.documentSnapshot?.deliveryMode ?? null,
    completionNarrative: certificate.documentSnapshot?.completionNarrative ?? null,
    instructionalHours: certificate.documentSnapshot?.instructionalHours ?? null,
    supervisedPracticalTraining: certificate.documentSnapshot?.supervisedPracticalTraining ?? null,
    complianceStatement: certificate.documentSnapshot?.complianceStatement ?? null,
    accreditingBodyName: certificate.documentSnapshot?.accreditingBodyName ?? null,
    licenseNumber: certificate.documentSnapshot?.licenseNumber ?? null,
    executiveName: certificate.documentSnapshot?.executiveName ?? null,
    executiveTitle: certificate.documentSnapshot?.executiveTitle ?? null,
    previewAcknowledgementExpirationMinutes: 30,
    executiveSignatureStorageKey: certificate.documentSnapshot?.executiveSignatureStorageKey ?? null,
    executiveSignatureUrl: certificate.documentSnapshot?.executiveSignatureUrl ?? null,
    executiveSignatureMimeType: certificate.documentSnapshot?.executiveSignatureMimeType === "image/png" || certificate.documentSnapshot?.executiveSignatureMimeType === "image/jpeg" ? certificate.documentSnapshot.executiveSignatureMimeType : null,
    instructorSignatureStorageKey: certificate.documentSnapshot?.instructorSignatureStorageKey ?? null,
    instructorSignatureUrl: certificate.documentSnapshot?.instructorSignatureUrl ?? null,
    instructorSignatureMimeType: certificate.documentSnapshot?.instructorSignatureMimeType === "image/png" || certificate.documentSnapshot?.instructorSignatureMimeType === "image/jpeg" ? certificate.documentSnapshot.instructorSignatureMimeType : null,
  }, actorUserId, origin, certificate.id);
}

export { revokeIssuedCertificate };
