CREATE TABLE `certificate_preview_reminder_notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`acknowledgementId` int NOT NULL,
	`recipientUserId` int NOT NULL,
	`recipientName` varchar(180) NOT NULL,
	`recipientEmail` varchar(320) NOT NULL,
	`subject` varchar(240) NOT NULL,
	`idempotencyKey` varchar(128) NOT NULL,
	`providerMessageId` varchar(180),
	`status` enum('queued','accepted','failed') NOT NULL DEFAULT 'queued',
	`retryCount` int NOT NULL DEFAULT 0,
	`errorCode` varchar(120),
	`errorMessage` text,
	`sentAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certificate_preview_reminder_notifications_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificate_preview_reminder_ack_unique` UNIQUE(`acknowledgementId`)
);
--> statement-breakpoint
CREATE TABLE `certificate_preview_reminder_schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`scheduleCronTaskUid` varchar(65) NOT NULL,
	`cronExpression` varchar(64) NOT NULL,
	`enabled` boolean NOT NULL DEFAULT true,
	`lastRunAt` timestamp,
	`lastRunSummary` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certificate_preview_reminder_schedules_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificate_preview_reminder_task_unique` UNIQUE(`scheduleCronTaskUid`)
);
--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `previewReminderEnabled` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `previewReminderLeadMinutes` int DEFAULT 10 NOT NULL;--> statement-breakpoint
ALTER TABLE `certificate_preview_reminder_notifications` ADD CONSTRAINT `cert_prev_reminder_ack_fk` FOREIGN KEY (`acknowledgementId`) REFERENCES `certificate_preview_acknowledgements`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_preview_reminder_notifications` ADD CONSTRAINT `cert_prev_reminder_user_fk` FOREIGN KEY (`recipientUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_preview_reminder_recipient_status_idx` ON `certificate_preview_reminder_notifications` (`recipientUserId`,`status`);
