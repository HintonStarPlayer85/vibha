import { describe, expect, it } from "vitest";
import { serializeCertificateApprovalHistoryCsv } from "./certificateDb";

describe("certificate approval history CSV", () => {
  it("escapes quoted notes and neutralizes spreadsheet formulas without exporting learner contact data", () => {
    const csv = serializeCertificateApprovalHistoryCsv("VIBHA-2026-A1B2C3D4", [{
      action: "certificate.preview.acknowledged",
      actorName: "Certificate Test",
      createdAt: new Date("2026-08-21T19:00:00Z"),
      details: '=HYPERLINK("https://untrusted.example","click")',
    }]);
    expect(csv).toContain('"\'=HYPERLINK(""https://untrusted.example"",""click"")"');
    expect(csv).not.toContain("recipientEmail");
    expect(csv).toContain("VIBHA-2026-A1B2C3D4");
  });
});
