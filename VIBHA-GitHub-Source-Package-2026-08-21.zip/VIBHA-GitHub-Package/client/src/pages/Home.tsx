import { FeaturedCertifications } from "@/components/certifications/FeaturedCertifications";
import { CategoryTiles } from "@/components/programs/CategoryTiles";
import { PublicLayout } from "@/components/public/PublicLayout";
import { SectionHeading } from "@/components/public/SectionHeading";
import { TitleSectionBackground } from "@/components/public/TitleSectionBackground";
import { Button } from "@/components/ui/button";
import { usePageMeta, useStructuredData } from "@/hooks/usePageMeta";
import { useSiteContent } from "@/hooks/useSiteContent";
import {
  ArrowRight,
  Award,
  BriefcaseBusiness,
  Building2,
  CalendarClock,
  CheckCircle2,
  MonitorPlay,
  ShieldCheck,
  UsersRound,
} from "lucide-react";
import { Link } from "wouter";

const proof = [
  { icon: Award, value: "40", label: "Published workforce certifications" },
  { icon: CalendarClock, value: "7", label: "Flexible delivery models" },
  { icon: UsersRound, value: "6", label: "Structured program families" },
];

const pathways = [
  { level: "01", title: "Enter the field", copy: "Build foundational knowledge, documentation discipline, and workforce readiness." },
  { level: "02", title: "Strengthen practice", copy: "Develop role-specific competence for community, crisis, compliance, and specialty services." },
  { level: "03", title: "Lead systems", copy: "Advance supervision, operations, governance, and executive decision-making capability." },
];

export default function Home() {
  const { content } = useSiteContent();
  usePageMeta(
    "VIBHA | Behavioral Health Certifications & Workforce Education",
    "VIBHA develops Virginia’s behavioral health workforce through practical certification, leadership education, and agency training.",
  );
  useStructuredData("vibha-organization-schema", {
    "@context": "https://schema.org",
    "@type": "EducationalOrganization",
    name: "VIBHA",
    alternateName: "The Virginia Institute for Behavioral Health & Advancement",
    url: window.location.origin,
    telephone: "+1-804-293-3341",
    areaServed: "Virginia",
    description:
      "Behavioral health workforce education, institutional certification, leadership development, and agency training.",
    address: {
      "@type": "PostalAddress",
      addressLocality: "Richmond",
      addressRegion: "VA",
      addressCountry: "US",
    },
  });

  return (
    <PublicLayout>
      <section className="vibha-grid relative min-h-[960px] overflow-hidden bg-[#071f49] text-white sm:min-h-[720px] xl:aspect-video xl:min-h-0">
        <TitleSectionBackground />
        <div className="container relative pb-10 pt-44 sm:pb-12 sm:pt-[26rem] xl:py-14">
          <div data-reveal="left" data-mobile-title-load className="w-[62%] sm:w-full sm:max-w-[50%] lg:max-w-[38%]">
            <p className="inline-flex rounded-full border border-[#f47a20]/40 bg-[#f47a20]/10 px-4 py-2 text-xs font-bold uppercase tracking-[0.18em] text-[#ffab70]">
              {content["home.hero.eyebrow"]}
            </p>
            <h1 className="mt-4 text-balance text-3xl font-bold leading-[1.05] lg:text-[2.75rem]">
              {content["home.hero.title"]} <span className="text-[#ff8c3b]">{content["home.hero.highlight"]}</span>
            </h1>
            <p className="mt-4 text-pretty text-sm leading-6 text-slate-200 lg:text-lg lg:leading-8">
              {content["home.hero.description"]}
            </p>
            <div className="mt-5 flex flex-col gap-3 lg:flex-row">
              <Button asChild size="lg" className="vibha-pulse vibha-icon-shift h-12 bg-[#f47a20] px-6 font-bold text-[#041634] hover:bg-[#ff9648]">
                <Link href="/certifications">Browse Certifications <ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="h-12 border-white/35 bg-transparent px-6 font-bold text-white hover:bg-white/10 hover:text-white">
                <Link href="/contact?type=agency">Agency Training</Link>
              </Button>
            </div>
            <p className="sr-only"><ShieldCheck aria-hidden="true" /> Workforce-focused education. Clear requirements. Practical application.</p>
          </div>
        </div>
      </section>

      <section aria-label="Institutional proof" className="relative z-10 -mt-1 border-b border-slate-200 bg-white">
        <div data-stagger className="container grid sm:grid-cols-3">
          {proof.map((item, index) => (
            <div key={item.label} data-reveal="scale" className={`vibha-card-interactive flex items-center gap-4 py-7 sm:px-6 ${index > 0 ? "border-t border-slate-200 sm:border-l sm:border-t-0" : ""}`}>
              <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#fff0e6] text-[#b94700]"><item.icon className="h-5 w-5" /></div>
              <div><strong className="block text-2xl text-[#071f49]">{item.value}</strong><span className="text-sm text-slate-600">{item.label}</span></div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-[#f6f8fb] py-20 sm:py-24">
        <div className="container">
          <div data-reveal="left" className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
            <SectionHeading eyebrow="Program directory" title={content["home.programDirectory.title"]} description={content["home.programDirectory.description"]} />
            <Button asChild variant="outline" className="w-fit border-[#173b70] bg-white text-[#173b70] hover:bg-[#eef3f9]"><Link href="/certifications">View all certifications <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
          </div>
          <div className="mt-10"><FeaturedCertifications /></div>
        </div>
      </section>

      <section className="py-20 sm:py-24">
        <div className="container">
          <SectionHeading align="center" eyebrow="Program areas" title={content["home.programAreas.title"]} description={content["home.programAreas.description"]} />
          <div className="mt-12"><CategoryTiles /></div>
        </div>
      </section>

      <section className="overflow-hidden bg-[#071f49] py-20 text-white sm:py-24">
        <div className="container grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:items-center">
          <div data-reveal="left">
            <SectionHeading inverse eyebrow="Career pathway" title={content["home.pathways.title"]} description={content["home.pathways.description"]} />
            <Button asChild className="mt-7 bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><Link href="/programs">Explore program pathways <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
          </div>
          <div data-stagger className="space-y-4">
            {pathways.map(pathway => (
              <article key={pathway.level} data-reveal="right" className="vibha-card-interactive grid gap-4 rounded-xl border border-white/15 bg-white/[0.055] p-6 sm:grid-cols-[72px_1fr] hover:border-[#f47a20]/50 hover:bg-white/[0.085]">
                <span className="font-serif text-4xl font-bold text-[#ff9a52]">{pathway.level}</span>
                <div><h3 className="text-2xl font-bold text-white">{pathway.title}</h3><p className="mt-2 leading-7 text-slate-300">{pathway.copy}</p></div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-24">
        <div className="container grid gap-10 lg:grid-cols-2 lg:items-center">
          <div data-reveal="left" className="vibha-card-interactive rounded-2xl bg-[#f6f8fb] p-8 sm:p-10">
            <Building2 className="h-10 w-10 text-[#b94700]" />
            <h2 className="mt-6 text-4xl font-bold text-[#071f49]">{content["home.agencyTraining.title"]}</h2>
            <p className="mt-5 text-lg leading-8 text-slate-600">{content["home.agencyTraining.description"]}</p>
            <ul className="mt-6 grid gap-3 sm:grid-cols-2">
              {["Customized curriculum", "Virtual or onsite delivery", "Leadership consultation", "Implementation guidance"].map(item => <li key={item} className="flex gap-2 text-sm font-semibold text-slate-700"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-700" />{item}</li>)}
            </ul>
            <Button asChild className="mt-8 bg-[#071f49] text-white hover:bg-[#173b70]"><Link href="/contact?type=agency">Schedule an agency consultation <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
          </div>
          <div data-reveal="right">
            <SectionHeading eyebrow="Flexible access" title={content["home.flexibleAccess.title"]} description={content["home.flexibleAccess.description"]} />
            <div data-stagger className="mt-8 grid gap-4 sm:grid-cols-2">
              {[{ icon: MonitorPlay, title: "Virtual live", copy: "Facilitated instruction with real-time interaction." }, { icon: BriefcaseBusiness, title: "Agency contract", copy: "Customized delivery aligned to organizational priorities." }, { icon: CalendarClock, title: "Evening and weekend", copy: "Cohort schedules structured around working professionals." }, { icon: Building2, title: "Hybrid and onsite", copy: "Flexible implementation for teams and institutions." }].map(item => <article key={item.title} data-reveal="scale" className="vibha-card-interactive group rounded-xl border border-slate-200 p-5 hover:border-[#173b70]/35"><item.icon className="h-6 w-6 text-[#b94700] transition-transform duration-200 group-hover:scale-110" /><h3 className="mt-4 text-xl font-bold text-[#071f49]">{item.title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{item.copy}</p></article>)}
            </div>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
