import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { usePageMeta } from "@/hooks/usePageMeta";

export default function Privacy() {
  usePageMeta("Privacy | VIBHA", "How VIBHA handles information submitted through its institutional website.");
  return <PublicLayout><PageHero eyebrow="Privacy" title="Privacy notice" description="How information submitted through the VIBHA website is collected and used." breadcrumbs={[{ label: "Privacy" }]} /><article className="container max-w-4xl py-16 prose prose-slate lg:prose-lg"><h2>Information submitted through inquiry forms</h2><p>VIBHA collects the information you voluntarily provide, including your name, email address, organization, program interest, and message, to review and respond to your inquiry.</p><h2>Use and retention</h2><p>Inquiry information is used for program communication, agency consultation routing, institutional follow-up, and related administrative purposes. Do not submit protected health information, client records, or other sensitive clinical information.</p><h2>Access and questions</h2><p>To ask a privacy question or request correction of information submitted through this website, use the Contact page and select General Information.</p></article></PublicLayout>;
}

