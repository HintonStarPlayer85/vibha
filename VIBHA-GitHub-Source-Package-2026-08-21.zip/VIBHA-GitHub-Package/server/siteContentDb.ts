import { asc, eq, inArray } from "drizzle-orm";
import { administrationAuditEvents, siteContentOverrides } from "../drizzle/schema";
import type { SiteContentBatchUpdate } from "../shared/administration";
import { getDb } from "./db";

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

export async function listSiteContentOverrides() {
  const db = await requireDb();
  return db
    .select({
      key: siteContentOverrides.contentKey,
      value: siteContentOverrides.value,
      updatedAt: siteContentOverrides.updatedAt,
      updatedByUserId: siteContentOverrides.updatedByUserId,
    })
    .from(siteContentOverrides)
    .orderBy(asc(siteContentOverrides.contentKey));
}

export async function updateSiteContent(values: SiteContentBatchUpdate["values"], actorUserId: number) {
  const db = await requireDb();
  await db.transaction(async tx => {
    for (const value of values) {
      await tx
        .insert(siteContentOverrides)
        .values({ contentKey: value.key, value: value.value, updatedByUserId: actorUserId })
        .onDuplicateKeyUpdate({
          set: { value: value.value, updatedByUserId: actorUserId, updatedAt: new Date() },
        });
    }
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "site_content.updated",
      entityType: "site_content",
      entityId: "batch",
      eventMetadata: { fieldCount: values.length },
    });
  });
  const keys = values.map(value => value.key);
  const rows = await db
    .select({ key: siteContentOverrides.contentKey, value: siteContentOverrides.value, updatedAt: siteContentOverrides.updatedAt })
    .from(siteContentOverrides)
    .where(inArray(siteContentOverrides.contentKey, keys));
  return rows;
}

export async function resetSiteContent(key: string, actorUserId: number) {
  const db = await requireDb();
  await db.transaction(async tx => {
    await tx.delete(siteContentOverrides).where(eq(siteContentOverrides.contentKey, key));
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "site_content.reset",
      entityType: "site_content",
      entityId: key,
    });
  });
  return { key };
}
