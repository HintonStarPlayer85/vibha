import { createHash, randomBytes } from "crypto";
import { Resend } from "resend";
import { recordAdministrationAudit } from "./administrationDb";
import { createCourseInvitationRecord, createTranscriptArtifact, findTranscript, getTranscriptForDownload, getTranscriptSource, markCourseInvitationDelivery } from "./learnerEngagementDb";
import { generateCompletionTranscriptPdf } from "./learnerEngagementPdf";
import { getResendConfiguration, verifyResendSenderDomain } from "./resendCohort";
import { storageGetSignedUrl, storagePut } from "./storage";

function escapeHtml(value: string) { return value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]!); }
function hashToken(value: string) { return createHash("sha256").update(value).digest("hex"); }

export async function generateLearnerTranscript(courseSlug: string, userId: number) {
  const existing = await findTranscript(courseSlug, userId);
  if (existing) return { transcriptId: existing.id, url: await storageGetSignedUrl(existing.storageKey), generatedAt: existing.generatedAt };
  const source = await getTranscriptSource(courseSlug, userId);
  const bytes = await generateCompletionTranscriptPdf({ recipientName: source.recipientName, courseTitle: source.certification.title, ceus: Number(source.certification.ceus), completedAt: source.enrollment.completedAt!, moduleCount: source.moduleCount, lessonCount: source.lessonCount });
  const stored = await storagePut(`online-learning/transcripts/${source.enrollment.id}-${Date.now()}.pdf`, bytes, "application/pdf");
  const transcript = await createTranscriptArtifact({ enrollmentId: source.enrollment.id, recipientName: source.recipientName, courseTitle: source.certification.title, courseSlug, ceus: Number(source.certification.ceus), completedAt: source.enrollment.completedAt!, moduleCount: source.moduleCount, lessonCount: source.lessonCount, storageKey: stored.key, url: stored.url, checksum: createHash("sha256").update(bytes).digest("hex") });
  await recordAdministrationAudit({ actorUserId: userId, action: "learner.transcript.generated", entityType: "online_completion_transcript", entityId: transcript.id, targetUserId: userId, eventMetadata: { courseSlug } });
  return { transcriptId: transcript.id, url: await storageGetSignedUrl(transcript.storageKey), generatedAt: transcript.generatedAt };
}

export async function downloadLearnerTranscript(courseSlug: string, userId: number) {
  const transcript = await getTranscriptForDownload(courseSlug, userId);
  return { transcriptId: transcript.id, url: await storageGetSignedUrl(transcript.storageKey), generatedAt: transcript.generatedAt };
}

export async function sendCourseInvitation(input: { courseId: number; recipientName: string; recipientEmail: string; origin: string; actorUserId: number }) {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
  const record = await createCourseInvitationRecord({ ...input, tokenHash: hashToken(token), expiresAt });
  const config = getResendConfiguration(); const sender = await verifyResendSenderDomain(true);
  if (!config.readyToSend || !config.apiKey || !config.from || !config.replyTo || !sender.verified) {
    const error = !sender.verified ? `Sender domain ${sender.domain || "unknown"} is ${sender.status.replace(/_/g, " ")}.` : `Resend is not configured. Missing: ${config.missing.join(", ")}.`;
    await markCourseInvitationDelivery({ invitationId: record.invitationId, error });
    throw new Error(error);
  }
  const inviteUrl = `${input.origin.replace(/\/$/, "")}/learn/invite/${encodeURIComponent(token)}`;
  const subject = `You are invited to learn: ${record.course.title}`;
  const html = `<!doctype html><html><body style="margin:0;background:#f6f8fb;font-family:Arial,sans-serif"><div style="max-width:680px;margin:0 auto;padding:28px 16px"><div style="background:#071f49;padding:20px 24px;color:#fff"><strong style="font-size:22px">VIBHA</strong><div style="margin-top:4px;font-size:12px;letter-spacing:.08em">THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH &amp; ADVANCEMENT</div></div><div style="background:#fff;padding:28px 24px;border:1px solid #dce3ec"><p style="margin:0 0 18px;color:#34435a">Hello ${escapeHtml(input.recipientName)},</p><p style="line-height:1.65;color:#34435a">You have been invited to enroll in the VIBHA self-paced course <strong>${escapeHtml(record.course.title)}</strong>.</p><p style="margin:26px 0"><a href="${escapeHtml(inviteUrl)}" style="display:inline-block;background:#b94700;color:#fff;padding:13px 18px;text-decoration:none;font-weight:700">Accept course invitation</a></p><p style="line-height:1.65;color:#667085;font-size:13px">Sign in with this invitation’s email address to accept. This link expires on ${escapeHtml(expiresAt.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }))}.</p></div></div></body></html>`;
  try {
    const result = await new Resend(config.apiKey).emails.send({ from: config.from, to: [input.recipientEmail], replyTo: config.replyTo, subject, html, text: `Hello ${input.recipientName},\n\nYou have been invited to enroll in ${record.course.title}.\n\nAccept your invitation: ${inviteUrl}\n\nSign in with this invitation's email address. This link expires ${expiresAt.toLocaleDateString("en-US")}.`, tags: [{ name: "online_course_id", value: String(input.courseId) }, { name: "online_invitation_id", value: String(record.invitationId) }] });
    if (result.error || !result.data) throw new Error(result.error?.message || "Resend did not accept the course invitation.");
    await markCourseInvitationDelivery({ invitationId: record.invitationId, providerMessageId: result.data.id });
  } catch (error) { const message = error instanceof Error ? error.message : "Course invitation delivery did not complete."; await markCourseInvitationDelivery({ invitationId: record.invitationId, error: message }); throw error; }
  await recordAdministrationAudit({ actorUserId: input.actorUserId, action: "online_course.invitation.sent", entityType: "online_course_invitation", entityId: record.invitationId, eventMetadata: { courseId: input.courseId, recipientEmail: input.recipientEmail.toLowerCase(), expiresAt: expiresAt.toISOString() } });
  return { invitationId: record.invitationId, expiresAt, recipientEmail: input.recipientEmail.toLowerCase() };
}
