import express from "express";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ verify: vi.fn(), apply: vi.fn() }));

vi.mock("resend", () => ({
  Resend: class {
    webhooks = { verify: mocks.verify };
  },
}));

vi.mock("./cohortCommunicationDb", async () => {
  const actual = await vi.importActual<typeof import("./cohortCommunicationDb")>("./cohortCommunicationDb");
  return { ...actual, applyResendWebhookEvent: mocks.apply };
});

import { registerResendWebhook } from "./resendWebhook";

const servers: Array<ReturnType<ReturnType<typeof express>["listen"]>> = [];

async function withServer(run: (origin: string) => Promise<void>) {
  const app = express();
  registerResendWebhook(app);
  const server = app.listen(0);
  servers.push(server);
  await new Promise<void>(resolve => server.once("listening", () => resolve()));
  const address = server.address();
  if (!address || typeof address === "string") throw new Error("Test server did not expose a port.");
  await run(`http://127.0.0.1:${address.port}`);
}

describe("Resend webhook", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    process.env.RESEND_API_KEY = "re_test";
    process.env.RESEND_WEBHOOK_SECRET = "whsec_test";
  });

  afterEach(async () => {
    await Promise.all(servers.splice(0).map(server => new Promise<void>(resolve => server.close(() => resolve()))));
  });

  it("rejects requests without the required signature headers", async () => {
    await withServer(async origin => {
      const response = await fetch(`${origin}/api/webhooks/resend`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ type: "email.delivered" }),
      });
      expect(response.status).toBe(400);
      expect(mocks.verify).not.toHaveBeenCalled();
    });
  });

  it("verifies the raw payload and applies a minimal delivery event", async () => {
    mocks.verify.mockReturnValue({
      type: "email.bounced",
      created_at: "2026-08-07T01:00:00.000Z",
      data: {
        email_id: "email_123",
        to: ["student@example.com"],
        subject: "Sensitive subject is not persisted",
        bounce: { type: "Permanent", subType: "Suppressed" },
      },
    });
    mocks.apply.mockResolvedValue({ processed: true, communicationId: 4, recipientId: 7 });

    await withServer(async origin => {
      const payload = JSON.stringify({ sample: true });
      const response = await fetch(`${origin}/api/webhooks/resend`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "svix-id": "evt_123",
          "svix-timestamp": "1786064400",
          "svix-signature": "v1,test",
        },
        body: payload,
      });
      expect(response.status).toBe(200);
      expect(mocks.verify).toHaveBeenCalledWith(expect.objectContaining({ payload, webhookSecret: "whsec_test" }));
      expect(mocks.apply).toHaveBeenCalledWith({
        providerEventId: "evt_123",
        providerMessageId: "email_123",
        eventType: "email.bounced",
        occurredAt: new Date("2026-08-07T01:00:00.000Z"),
        eventMetadata: { bounceType: "Permanent", bounceSubType: "Suppressed" },
      });
    });
  });

  it("acknowledges replayed provider events without applying them twice", async () => {
    mocks.verify.mockReturnValue({
      type: "email.delivered",
      created_at: "2026-08-07T01:00:00.000Z",
      data: { email_id: "email_123" },
    });
    mocks.apply.mockResolvedValue({ processed: false, reason: "duplicate" });
    await withServer(async origin => {
      const response = await fetch(`${origin}/api/webhooks/resend`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "svix-id": "evt_replay",
          "svix-timestamp": "1786064400",
          "svix-signature": "v1,test",
        },
        body: "{}",
      });
      expect(response.status).toBe(200);
      await expect(response.json()).resolves.toEqual({ received: true, processed: false });
    });
  });
});
