import { z } from "zod";

export const onlineCourseStatuses = ["draft", "review", "published", "archived"] as const;
export const onlineCourseStatusSchema = z.enum(onlineCourseStatuses);
export const onlineMaterialAnalysisStatuses = ["pending", "analyzed", "failed"] as const;
export const onlineMaterialAnalysisStatusSchema = z.enum(onlineMaterialAnalysisStatuses);

export const onlineCourseActivationSchema = z.object({
  certificationId: z.number().int().positive(),
});

export const onlineCourseMaterialUploadSchema = z.object({
  courseId: z.number().int().positive(),
  title: z.string().trim().min(2).max(220),
  fileName: z.string().trim().min(1).max(320),
  mimeType: z.enum(["application/pdf", "text/plain"]),
  dataBase64: z.string().min(1),
});

export const onlineCourseGenerationSchema = z.object({
  courseId: z.number().int().positive(),
});

export const onlineCourseStatusUpdateSchema = z.object({
  courseId: z.number().int().positive(),
  status: onlineCourseStatusSchema,
});

export const onlineModuleVisualSchema = z.object({
  moduleId: z.number().int().positive(),
});

export const onlineCourseModuleUpdateSchema = z.object({
  moduleId: z.number().int().positive(),
  title: z.string().trim().min(3).max(220),
  learningObjective: z.string().trim().min(10).max(1200),
  visualPrompt: z.string().trim().min(10).max(2000),
  videoBrief: z.string().trim().min(10).max(6000),
  sourceGrounding: z.string().trim().min(10).max(2500),
  isPublished: z.boolean(),
});

export const onlineCourseLessonUpdateSchema = z.object({
  lessonId: z.number().int().positive(),
  title: z.string().trim().min(3).max(220),
  estimatedMinutes: z.number().int().min(1).max(240),
  content: z.string().trim().min(80).max(30000),
  knowledgeCheckQuestion: z.string().trim().min(10).max(2000),
  knowledgeCheckAnswer: z.string().trim().min(10).max(4000),
  isPublished: z.boolean(),
});

export const onlineInstructorQuestionSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
  question: z.string().trim().min(3).max(1500),
});

export const onlineCoursePublicQuerySchema = z.object({
  slug: z.string().trim().min(3).max(240),
});

export const onlineCourseEnrollmentSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
});

export const onlineLessonProgressSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
  lessonId: z.number().int().positive(),
  completed: z.boolean(),
});

export const onlineModuleQuizSchema = z.object({
  moduleId: z.number().int().positive(),
  title: z.string().trim().min(3).max(220),
  passingScore: z.number().int().min(0).max(100),
  isPublished: z.boolean(),
});

export const onlineModuleQuizQuestionSchema = z.object({
  quizId: z.number().int().positive(),
  position: z.number().int().min(1).max(50),
  prompt: z.string().trim().min(8).max(2500),
  options: z.array(z.string().trim().min(1).max(1000)).min(2).max(6),
  correctOptionIndex: z.number().int().min(0).max(5),
  explanation: z.string().trim().min(10).max(4000),
  isPublished: z.boolean(),
}).superRefine((value, ctx) => {
  if (value.correctOptionIndex >= value.options.length) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["correctOptionIndex"], message: "Choose one of the provided answer options." });
});

export const onlineModuleQuizQuestionUpdateSchema = onlineModuleQuizQuestionSchema.safeExtend({ id: z.number().int().positive() });

export const onlineModuleQuizSubmissionSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
  moduleId: z.number().int().positive(),
  answers: z.array(z.object({ questionId: z.number().int().positive(), selectedOptionIndex: z.number().int().min(0).max(5) })).min(1).max(50),
});

export const onlineCourseInvitationSchema = z.object({
  courseId: z.number().int().positive(),
  recipientName: z.string().trim().min(1).max(180),
  recipientEmail: z.string().trim().email().max(320),
  origin: z.string().url(),
});

export const onlineCourseInvitationAcceptSchema = z.object({
  token: z.string().trim().min(32).max(256),
});

export const onlineTranscriptRequestSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
});

export const onlineModuleNoteSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
  moduleId: z.number().int().positive(),
  content: z.string().trim().min(1).max(10000),
});

export const onlineModuleNoteDeleteSchema = z.object({
  courseSlug: z.string().trim().min(3).max(240),
  moduleId: z.number().int().positive(),
});

export const generatedLessonSchema = z.object({
  position: z.number().int().min(1).max(20),
  title: z.string().trim().min(3).max(220),
  estimatedMinutes: z.number().int().min(1).max(240),
  content: z.string().trim().min(80).max(30000),
  knowledgeCheckQuestion: z.string().trim().min(10).max(2000),
  knowledgeCheckAnswer: z.string().trim().min(10).max(4000),
});

export const generatedModuleSchema = z.object({
  position: z.number().int().min(1).max(12),
  title: z.string().trim().min(3).max(220),
  learningObjective: z.string().trim().min(10).max(1200),
  sourceGrounding: z.string().trim().min(10).max(2500),
  visualPrompt: z.string().trim().min(10).max(2000),
  videoBrief: z.string().trim().min(10).max(6000),
  lessons: z.array(generatedLessonSchema).min(1).max(12),
});

export const generatedCourseSchema = z.object({
  courseOverview: z.string().trim().min(80).max(6000),
  sourceGroundingNotice: z.string().trim().min(30).max(2000),
  aiInstructorName: z.string().trim().min(3).max(100),
  aiInstructorWelcome: z.string().trim().min(30).max(2000),
  aiInstructorScope: z.string().trim().min(30).max(2500),
  modules: z.array(generatedModuleSchema).min(1).max(12),
});

export type GeneratedCourse = z.infer<typeof generatedCourseSchema>;
export type OnlineCourseStatus = z.infer<typeof onlineCourseStatusSchema>;
