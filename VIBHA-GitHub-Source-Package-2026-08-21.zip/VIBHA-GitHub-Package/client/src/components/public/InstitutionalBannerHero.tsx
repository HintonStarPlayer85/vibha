const bannerSources = {
  small: "/manus-storage/vibha-banner-800_ccd927a7.webp",
  medium: "/manus-storage/vibha-banner-1280_46b36c6a.webp",
  large: "/manus-storage/vibha-banner-1600_61a81915.webp",
};

export function InstitutionalBannerHero() {
  return (
    <section
      aria-label="VIBHA institutional banner"
      className="relative overflow-hidden bg-[#041634]"
    >
      <picture>
        <source
          type="image/webp"
          srcSet={`${bannerSources.small} 800w, ${bannerSources.medium} 1280w, ${bannerSources.large} 1600w`}
          sizes="100vw"
        />
        <img
          src={bannerSources.medium}
          srcSet={`${bannerSources.small} 800w, ${bannerSources.medium} 1280w, ${bannerSources.large} 1600w`}
          sizes="100vw"
          alt="VIBHA develops the workforce behind behavioral health excellence through research, education, academic programs, certification, and workforce development in Virginia."
          width="1600"
          height="640"
          fetchPriority="high"
          decoding="async"
          className="block h-auto w-full"
        />
      </picture>
    </section>
  );
}
