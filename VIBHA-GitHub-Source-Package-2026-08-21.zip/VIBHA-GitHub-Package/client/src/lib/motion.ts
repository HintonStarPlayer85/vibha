export function backToTopThreshold(viewportHeight: number) {
  return Math.max(480, Math.round(viewportHeight * 0.75));
}

export function shouldShowBackToTop(scrollY: number, viewportHeight: number) {
  return scrollY > backToTopThreshold(viewportHeight);
}

export function preferredScrollBehavior(reducedMotion: boolean): ScrollBehavior {
  return reducedMotion ? "auto" : "smooth";
}
