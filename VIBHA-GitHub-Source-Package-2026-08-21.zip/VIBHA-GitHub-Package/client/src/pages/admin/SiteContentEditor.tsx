import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { leadershipTeam } from "@/data/leadership";
import { trpc } from "@/lib/trpc";
import {
  siteContentDefinitions,
  siteContentDefaults,
  type SiteContentGroup,
  type SiteContentKey,
} from "@shared/siteContent";
import { ExternalLink, FilePenLine, Loader2, RotateCcw, Save } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

type EditorField = {
  key: SiteContentKey;
  group: SiteContentGroup;
  label: string;
  helper: string;
  maxLength: number;
  defaultValue: string;
  multiline?: boolean;
};

const previewPaths: Record<SiteContentGroup, string> = {
  Home: "/",
  Programs: "/programs",
  About: "/about",
  Contact: "/contact",
  Leadership: "/about/leadership",
};

const groups: SiteContentGroup[] = ["Home", "Programs", "About", "Contact", "Leadership"];

function createFields(): EditorField[] {
  const pageFields = siteContentDefinitions.map(definition => ({
    ...definition,
    defaultValue: siteContentDefaults[definition.key],
    multiline: definition.maxLength > 260,
  }));
  const profileFields = leadershipTeam.flatMap(profile => [
    {
      key: `leadership.profile.${profile.id}.name` as SiteContentKey,
      group: "Leadership" as const,
      label: `${profile.name}: display name`,
      helper: "Name shown on the About preview, Leadership page, portrait alternative text, and Person metadata.",
      maxLength: 220,
      defaultValue: profile.name,
    },
    {
      key: `leadership.profile.${profile.id}.title` as SiteContentKey,
      group: "Leadership" as const,
      label: `${profile.name}: institutional title`,
      helper: "Role and credential line displayed with this profile.",
      maxLength: 260,
      defaultValue: profile.title,
    },
    {
      key: `leadership.profile.${profile.id}.biography` as SiteContentKey,
      group: "Leadership" as const,
      label: `${profile.name}: complete biography`,
      helper: "Use a blank line between paragraphs. The same biography publishes to the Leadership page and Person metadata.",
      maxLength: 10000,
      defaultValue: profile.biography.join("\n\n"),
      multiline: true,
    },
  ]);
  return [...pageFields, ...profileFields];
}

const fields = createFields();

function Editor() {
  const overridesQuery = trpc.adminSiteContent.list.useQuery();
  const updateMutation = trpc.adminSiteContent.update.useMutation();
  const resetMutation = trpc.adminSiteContent.reset.useMutation();
  const utils = trpc.useUtils();
  const [values, setValues] = useState<Record<string, string>>({});
  const [persistedValues, setPersistedValues] = useState<Record<string, string>>({});
  const [overrideKeys, setOverrideKeys] = useState<Set<string>>(new Set());
  const [statusMessage, setStatusMessage] = useState("");
  const [activeGroup, setActiveGroup] = useState<SiteContentGroup>("Home");

  useEffect(() => {
    if (!overridesQuery.data) return;
    const overrides = Object.fromEntries(overridesQuery.data.map(item => [item.key, item.value]));
    const next = Object.fromEntries(fields.map(field => [field.key, overrides[field.key] ?? field.defaultValue]));
    setValues(next);
    setPersistedValues(next);
    setOverrideKeys(new Set(Object.keys(overrides)));
  }, [overridesQuery.data]);

  const changedFields = useMemo(
    () => fields.filter(field => values[field.key] !== persistedValues[field.key]),
    [values, persistedValues],
  );
  const hasOverride = (field: EditorField) => overrideKeys.has(field.key);
  const isSaving = updateMutation.isPending || resetMutation.isPending;

  function setValue(key: SiteContentKey, value: string) {
    setValues(current => ({ ...current, [key]: value }));
  }

  async function saveChanges() {
    const invalid = changedFields.find(field => !values[field.key]?.trim());
    if (invalid) {
      const message = `${invalid.label} cannot be empty. Use Restore default to remove an override.`;
      setStatusMessage(message);
      toast.error(message);
      document.getElementById(`content-${invalid.key}`)?.focus();
      return;
    }
    if (!changedFields.length) {
      setStatusMessage("There are no unsaved changes.");
      return;
    }
    try {
      await updateMutation.mutateAsync({
        values: changedFields.map(field => ({ key: field.key, value: values[field.key]!.trim() })),
      });
      await Promise.all([utils.adminSiteContent.invalidate(), utils.siteContent.invalidate()]);
      setPersistedValues(values);
      setOverrideKeys(current => new Set([...Array.from(current), ...changedFields.map(field => field.key)]));
      const message = `${changedFields.length} text ${changedFields.length === 1 ? "field was" : "fields were"} published.`;
      setStatusMessage(message);
      toast.success(message);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The text changes could not be saved.";
      setStatusMessage(`Save failed: ${message}`);
      toast.error(message);
    }
  }

  async function restoreDefault(field: EditorField) {
    if (!hasOverride(field)) return;
    if (!window.confirm(`Restore the original VIBHA text for “${field.label}”?`)) return;
    try {
      await resetMutation.mutateAsync({ key: field.key });
      const nextValues = { ...values, [field.key]: field.defaultValue };
      setValues(nextValues);
      setPersistedValues(current => ({ ...current, [field.key]: field.defaultValue }));
      setOverrideKeys(current => {
        const next = new Set(current);
        next.delete(field.key);
        return next;
      });
      await Promise.all([utils.adminSiteContent.invalidate(), utils.siteContent.invalidate()]);
      const message = `Original text restored for ${field.label}.`;
      setStatusMessage(message);
      toast.success(message);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The original text could not be restored.";
      setStatusMessage(`Restore failed: ${message}`);
      toast.error(message);
    }
  }

  if (overridesQuery.isLoading) {
    return <div role="status" className="mx-auto flex max-w-6xl items-center gap-3 rounded-xl border border-slate-200 bg-white p-8"><Loader2 className="h-5 w-5 animate-spin" />Loading the Content Editor…</div>;
  }

  if (overridesQuery.error) {
    return <div role="alert" className="mx-auto max-w-6xl rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{overridesQuery.error.message}</div>;
  }

  return (
    <main className="mx-auto max-w-6xl pb-12">
      <p role="status" aria-live="polite" className="sr-only">{isSaving ? "Publishing text changes." : statusMessage}</p>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Content Administration</p>
          <h1 className="mt-3 text-4xl font-bold text-[#071f49]">Content Editor</h1>
          <p className="mt-3 max-w-3xl text-slate-600">Update approved public text without changing code. Changes publish immediately after saving. Use one blank line to create a new leadership biography paragraph.</p>
        </div>
        <Button onClick={saveChanges} disabled={isSaving || !changedFields.length} className="min-h-12 bg-[#071f49] font-bold text-white hover:bg-[#173b70]">
          {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Publish {changedFields.length ? `${changedFields.length} change${changedFields.length === 1 ? "" : "s"}` : "changes"}
        </Button>
      </div>

      <section className="mt-8 rounded-xl border border-[#f47a20]/35 bg-[#fff7f2] p-5 text-sm leading-6 text-[#5a2a07]">
        <strong className="block text-[#8f3d00]">Guardrails</strong>
        This editor manages the approved page copy and leadership profiles. It does not alter navigation, certification records, accreditation disclosures, contact details, branding, layouts, or site permissions.
      </section>

      <nav aria-label="Content editor sections" className="mt-6 flex flex-wrap gap-2">
        {groups.map(group => <Button key={group} type="button" variant="outline" onClick={() => setActiveGroup(group)} aria-pressed={activeGroup === group} className={`min-h-11 rounded-full px-4 font-bold ${activeGroup === group ? "border-[#071f49] bg-[#071f49] text-white hover:bg-[#173b70] hover:text-white" : "border-slate-300 bg-white text-[#173b70] hover:border-[#173b70] hover:bg-[#eef3f9]"}`}>{group}</Button>)}
      </nav>

      <div className="mt-8 space-y-8">
        {[activeGroup].map(group => {
          const groupFields = fields.filter(field => field.group === group);
          return (
            <section key={group} id={`content-${group.toLowerCase()}`} className="scroll-mt-24 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
              <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-[#071f49]">{group}</h2>
                  <p className="mt-1 text-sm text-slate-600">Edit only the text that belongs to this public page area.</p>
                </div>
                <a href={previewPaths[group]} target="_blank" rel="noreferrer" className="inline-flex min-h-11 items-center gap-2 text-sm font-bold text-[#173b70] hover:underline">Preview {group} page <ExternalLink className="h-4 w-4" /></a>
              </div>
              <div className="mt-6 grid gap-6">
                {groupFields.map(field => {
                  const value = values[field.key] ?? field.defaultValue;
                  const overridden = hasOverride(field);
                  return (
                    <div key={field.key} className="rounded-xl border border-slate-200 p-4 sm:p-5">
                      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                        <div>
                          <Label htmlFor={`content-${field.key}`} className="text-base font-bold text-[#071f49]">{field.label}</Label>
                          <p className="mt-1 max-w-3xl text-sm leading-6 text-slate-600">{field.helper}</p>
                        </div>
                        <span className={`w-fit rounded-full px-3 py-1 text-xs font-bold ${overridden ? "bg-[#fff0e6] text-[#9a3b00]" : "bg-slate-100 text-slate-600"}`}>{overridden ? "Custom text" : "Original text"}</span>
                      </div>
                      <Textarea id={`content-${field.key}`} value={value} onChange={event => setValue(field.key, event.target.value)} maxLength={field.maxLength} rows={field.multiline ? 7 : 3} className="mt-4 resize-y" aria-describedby={`help-${field.key}`} />
                      <div id={`help-${field.key}`} className="mt-2 flex flex-col gap-2 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
                        <span>{value.length}/{field.maxLength} characters</span>
                        {overridden ? <Button type="button" variant="ghost" size="sm" onClick={() => restoreDefault(field)} disabled={isSaving} className="min-h-9 w-fit text-[#9a3b00] hover:bg-[#fff0e6] hover:text-[#7d2f00]"><RotateCcw className="mr-1.5 h-3.5 w-3.5" />Restore original text</Button> : null}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      <div className="mt-8 flex justify-end rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <Button onClick={saveChanges} disabled={isSaving || !changedFields.length} className="min-h-12 w-full bg-[#071f49] font-bold text-white hover:bg-[#173b70] sm:w-auto"><FilePenLine className="mr-2 h-4 w-4" />Publish changes</Button>
      </div>
    </main>
  );
}

export default function SiteContentEditor() {
  return <DashboardLayout><Editor /></DashboardLayout>;
}
