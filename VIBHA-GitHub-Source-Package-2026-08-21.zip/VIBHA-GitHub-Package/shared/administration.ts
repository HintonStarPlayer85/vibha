import { z } from "zod";
import { siteContentKeys } from "./siteContent";

export const normalizedEmailSchema = z
  .string()
  .trim()
  .email("Enter a valid email address.")
  .max(320)
  .transform(value => value.toLowerCase());

export const administratorInvitationInputSchema = z.object({
  email: normalizedEmailSchema,
  expiresInDays: z.number().int().min(1).max(30).default(7),
  origin: z.string().url().refine(value => {
    const protocol = new URL(value).protocol;
    return protocol === "https:" || protocol === "http:";
  }, "A valid website origin is required."),
});

export const invitationTokenSchema = z.object({
  token: z.string().trim().min(32).max(256),
});

export const invitationAcceptSchema = invitationTokenSchema.extend({
  confirmEmail: normalizedEmailSchema,
});

export const administratorStatusSchema = z.object({
  userId: z.number().int().positive(),
  role: z.enum(["user", "admin"]),
});

export const instructorInputSchema = z.object({
  name: z.string().trim().min(2).max(180),
  slug: z.string().trim().min(2).max(200).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers, and hyphens."),
  email: z.union([normalizedEmailSchema, z.literal("")]).default(""),
  credentials: z.string().trim().max(220).nullable().default(null),
  title: z.string().trim().max(220).nullable().default(null),
  biography: z.string().trim().max(10000).nullable().default(null),
  expertise: z.array(z.string().trim().min(1).max(120)).max(30).default([]),
  photoUrl: z.union([z.string().url().max(600), z.literal("")]).default(""),
  isActive: z.boolean().default(true),
  certificationIds: z.array(z.number().int().positive()).max(500).default([]),
});

export const instructorListQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  status: z.enum(["active", "inactive"]).optional(),
});

export const cohortStatusSchema = z.enum(["draft", "planned", "active", "completed", "cancelled", "archived"]);

export const cohortInputSchema = z
  .object({
    title: z.string().trim().min(3).max(220),
    slug: z.string().trim().min(3).max(240).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers, and hyphens."),
    certificationId: z.number().int().positive(),
    instructorId: z.number().int().positive().nullable().default(null),
    certificateSignatoryInstructorId: z.number().int().positive().nullable().default(null),
    status: cohortStatusSchema.default("draft"),
    startAt: z.date().nullable().default(null),
    endAt: z.date().nullable().default(null),
    timeZone: z.string().trim().min(1).max(80).default("America/New_York"),
    scheduleSummary: z.string().trim().max(10000).nullable().default(null),
    zoomUrl: z.union([z.string().url().max(1000), z.literal("")]).default(""),
    zoomMeetingId: z.string().trim().max(120).nullable().default(null),
    zoomPasscode: z.string().trim().max(120).nullable().default(null),
    administratorNotes: z.string().trim().max(20000).nullable().default(null),
  })
  .superRefine((value, context) => {
    if (value.startAt && value.endAt && value.endAt < value.startAt) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["endAt"],
        message: "End date must be after the start date.",
      });
    }
  });

export const cohortListQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  status: cohortStatusSchema.optional(),
});

export const cohortStudentInputSchema = z.object({
  name: z.string().trim().min(2).max(180),
  email: normalizedEmailSchema,
  status: z.enum(["active", "inactive", "completed", "withdrawn"]).default("active"),
});

export const cohortStudentUpdateSchema = cohortStudentInputSchema.extend({
  id: z.number().int().positive(),
});

export const cohortRosterInputSchema = z
  .object({
    cohortId: z.number().int().positive(),
    students: z.array(cohortStudentInputSchema).max(1000),
  })
  .superRefine((value, context) => {
    const emails = new Set<string>();
    value.students.forEach((student, index) => {
      if (emails.has(student.email)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["students", index, "email"],
          message: "Each student email may appear only once in a cohort.",
        });
      }
      emails.add(student.email);
    });
  });

export const cohortResourceLinkInputSchema = z.object({
  cohortId: z.number().int().positive(),
  title: z.string().trim().min(2).max(220),
  description: z.string().trim().max(5000).nullable().default(null),
  resourceType: z.enum(["syllabus", "schedule", "document", "link", "other"]),
  audience: z.enum(["all", "students", "instructors", "administrators"]).default("students"),
  url: z.string().url().max(1000),
  displayOrder: z.number().int().min(0).max(10000).default(0),
  isActive: z.boolean().default(true),
});

export const cohortResourceStatusSchema = z.object({
  id: z.number().int().positive(),
  isActive: z.boolean(),
});

export const cohortResourceSettingsSchema = z.object({
  id: z.number().int().positive(),
  audience: z.enum(["all", "students", "instructors", "administrators"]),
  displayOrder: z.number().int().min(0).max(10000),
});

export const cohortResourceUploadInputSchema = z.object({
  cohortId: z.number().int().positive(),
  title: z.string().trim().min(2).max(220),
  description: z.string().trim().max(5000).nullable().default(null),
  resourceType: z.enum(["syllabus", "schedule", "document", "other"]),
  audience: z.enum(["all", "students", "instructors", "administrators"]).default("students"),
  fileName: z.string().trim().min(1).max(320),
  mimeType: z.enum([
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "text/csv",
    "text/plain",
  ]),
  dataBase64: z.string().min(4).max(14_000_000),
  displayOrder: z.number().int().min(0).max(10000).default(0),
});

export const cohortCommunicationDraftSchema = z.object({
  cohortId: z.number().int().positive(),
  communicationType: z.enum(["zoom_details", "resource_update", "schedule_update", "general"]),
  subject: z.string().trim().min(3).max(240),
  message: z.string().trim().min(10).max(50000),
  includeZoom: z.boolean().default(false),
  resourceIds: z.array(z.number().int().positive()).max(50).default([]),
});

export const cohortCommunicationConfirmSchema = cohortCommunicationDraftSchema.extend({
  previewHash: z.string().length(64),
  idempotencyKey: z.string().uuid(),
  confirmedRecipientCount: z.number().int().positive().max(1000),
  confirmation: z.literal(true),
});

export const cohortCommunicationRetrySchema = z.object({
  communicationId: z.number().int().positive(),
  recipientIds: z.array(z.number().int().positive()).min(1).max(1000),
  confirmation: z.literal(true),
});

export type AdministratorInvitationInput = z.infer<typeof administratorInvitationInputSchema>;
export type InstructorInput = z.infer<typeof instructorInputSchema>;
export type InstructorListQuery = z.infer<typeof instructorListQuerySchema>;
export type CohortInput = z.infer<typeof cohortInputSchema>;
export type CohortListQuery = z.infer<typeof cohortListQuerySchema>;
export type CohortStudentInput = z.infer<typeof cohortStudentInputSchema>;
export type CohortRosterInput = z.infer<typeof cohortRosterInputSchema>;
export type CohortResourceLinkInput = z.infer<typeof cohortResourceLinkInputSchema>;
export type CohortCommunicationDraft = z.infer<typeof cohortCommunicationDraftSchema>;
export type CohortCommunicationConfirm = z.infer<typeof cohortCommunicationConfirmSchema>;

export const siteContentKeySchema = z.enum(siteContentKeys);

export const siteContentUpdateSchema = z.object({
  key: siteContentKeySchema,
  value: z.string().trim().min(1, "Text cannot be empty.").max(10000),
});

export const siteContentBatchUpdateSchema = z
  .object({
    values: z.array(siteContentUpdateSchema).min(1).max(siteContentKeys.length),
  })
  .superRefine((input, context) => {
    const keys = new Set<string>();
    input.values.forEach((value, index) => {
      if (keys.has(value.key)) {
        context.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["values", index, "key"],
          message: "Each text field can be saved only once per request.",
        });
      }
      keys.add(value.key);
    });
  });

export const siteContentResetSchema = z.object({ key: siteContentKeySchema });

export type SiteContentUpdate = z.infer<typeof siteContentUpdateSchema>;
export type SiteContentBatchUpdate = z.infer<typeof siteContentBatchUpdateSchema>;
