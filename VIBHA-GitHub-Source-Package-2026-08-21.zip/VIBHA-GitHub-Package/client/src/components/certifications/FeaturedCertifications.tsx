import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, ArrowRight } from "lucide-react";
import { useRef } from "react";
import { CertificationCard } from "./CertificationCard";

export function FeaturedCertifications() {
  const { data, isLoading, error } = trpc.certifications.featured.useQuery({ limit: 8 });
  const rail = useRef<HTMLDivElement>(null);
  const move = (direction: number) => rail.current?.scrollBy({ left: direction * 390, behavior: "smooth" });

  if (isLoading) {
    return <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 3 }).map((_, index) => <div key={index} className="h-[430px] animate-pulse rounded-xl bg-slate-100" />)}</div>;
  }

  if (error || !data) {
    return <p role="alert" className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-800">Featured certifications are temporarily unavailable.</p>;
  }

  return (
    <div>
      <div className="mb-5 flex justify-end gap-2">
        <Button variant="outline" size="icon" onClick={() => move(-1)} aria-label="Previous featured certification" className="border-slate-300 bg-white">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={() => move(1)} aria-label="Next featured certification" className="border-slate-300 bg-white">
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>
      <div ref={rail} className="scrollbar-none -mx-4 flex snap-x snap-mandatory gap-5 overflow-x-auto px-4 pb-5 sm:-mx-0 sm:px-0">
        {data.map(certification => (
          <div key={certification.id} className="w-[88vw] max-w-[380px] shrink-0 snap-start sm:w-[360px]">
            <CertificationCard certification={certification} />
          </div>
        ))}
      </div>
    </div>
  );
}
