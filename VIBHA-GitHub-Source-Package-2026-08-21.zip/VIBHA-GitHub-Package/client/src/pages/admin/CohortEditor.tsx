import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { cohortInputSchema, type CohortInput } from "@shared/administration";
import { ArrowLeft, ExternalLink, FileUp, Link2, Loader2, Mail, Plus, Save, Trash2, UserPlus } from "lucide-react";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Link, useLocation, useParams } from "wouter";

const emptyCohort: CohortInput = {
  title: "",
  slug: "",
  certificationId: 0,
  instructorId: null,
  certificateSignatoryInstructorId: null,
  status: "draft",
  startAt: null,
  endAt: null,
  timeZone: "America/New_York",
  scheduleSummary: null,
  zoomUrl: "",
  zoomMeetingId: null,
  zoomPasscode: null,
  administratorNotes: null,
};

const allowedMimeTypes = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "text/csv",
  "text/plain",
] as const;

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function toInputDate(value: Date | null) {
  if (!value) return "";
  const date = new Date(value);
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function Editor({ id }: { id?: number }) {
  const editing = Boolean(id);
  const [, navigate] = useLocation();
  const [form, setForm] = useState<CohortInput>(emptyCohort);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [slugEdited, setSlugEdited] = useState(false);
  const [studentName, setStudentName] = useState("");
  const [studentEmail, setStudentEmail] = useState("");
  const [linkTitle, setLinkTitle] = useState("");
  const [linkUrl, setLinkUrl] = useState("");
  const [linkType, setLinkType] = useState<"syllabus" | "schedule" | "document" | "link" | "other">("link");
  const [linkAudience, setLinkAudience] = useState<"all" | "students" | "instructors" | "administrators">("students");
  const [linkOrder, setLinkOrder] = useState(0);
  const [fileTitle, setFileTitle] = useState("");
  const [fileType, setFileType] = useState<"syllabus" | "schedule" | "document" | "other">("document");
  const [fileAudience, setFileAudience] = useState<"all" | "students" | "instructors" | "administrators">("students");
  const [fileOrder, setFileOrder] = useState(0);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [statusMessage, setStatusMessage] = useState("");
  const options = trpc.adminCohorts.options.useQuery();
  const existing = trpc.adminCohorts.getById.useQuery({ id: id ?? 0 }, { enabled: editing });
  const utils = trpc.useUtils();
  const createMutation = trpc.adminCohorts.create.useMutation();
  const updateMutation = trpc.adminCohorts.update.useMutation();
  const addStudent = trpc.adminCohorts.addStudent.useMutation();
  const removeStudent = trpc.adminCohorts.removeStudent.useMutation();
  const addLink = trpc.adminCohorts.addResourceLink.useMutation();
  const uploadResource = trpc.adminCohorts.uploadResource.useMutation();
  const setResourceStatus = trpc.adminCohorts.setResourceStatus.useMutation();
  const updateResourceSettings = trpc.adminCohorts.updateResourceSettings.useMutation();
  const pending = createMutation.isPending || updateMutation.isPending;

  useEffect(() => {
    if (!existing.data) return;
    setForm({
      title: existing.data.title,
      slug: existing.data.slug,
      certificationId: existing.data.certificationId,
      instructorId: existing.data.instructorId,
      certificateSignatoryInstructorId: existing.data.certificateSignatoryInstructorId,
      status: existing.data.status,
      startAt: existing.data.startAt,
      endAt: existing.data.endAt,
      timeZone: existing.data.timeZone,
      scheduleSummary: existing.data.scheduleSummary,
      zoomUrl: existing.data.zoomUrl ?? "",
      zoomMeetingId: existing.data.zoomMeetingId,
      zoomPasscode: existing.data.zoomPasscode,
      administratorNotes: existing.data.administratorNotes,
    });
    setSlugEdited(true);
  }, [existing.data]);

  useEffect(() => {
    if (!editing && form.certificationId === 0 && options.data?.programs[0]) {
      setForm(current => ({ ...current, certificationId: options.data!.programs[0].id }));
    }
  }, [editing, form.certificationId, options.data]);

  function update<K extends keyof CohortInput>(key: K, value: CohortInput[K]) {
    setForm(current => ({ ...current, [key]: value }));
    setErrors(current => ({ ...current, [key]: "" }));
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    const parsed = cohortInputSchema.safeParse(form);
    if (!parsed.success) {
      const next: Record<string, string> = {};
      parsed.error.issues.forEach(issue => { next[String(issue.path[0])] ??= issue.message; });
      setErrors(next);
      setStatusMessage("Cohort was not saved. Review the highlighted fields.");
      requestAnimationFrame(() => document.getElementById("cohort-errors")?.focus());
      return;
    }
    try {
      const saved = editing ? await updateMutation.mutateAsync({ id: id!, data: parsed.data }) : await createMutation.mutateAsync(parsed.data);
      await Promise.all([utils.adminCohorts.invalidate(), utils.adminInstructors.invalidate()]);
      const message = editing ? "Cohort updated." : "Cohort created. Roster and resource controls are now available.";
      setStatusMessage(message);
      toast.success(message);
      navigate(`/admin/cohorts/${saved!.id}/edit`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The cohort could not be saved.";
      setStatusMessage(`Save failed: ${message}`);
      toast.error(message);
    }
  }

  async function addRosterStudent(event: FormEvent) {
    event.preventDefault();
    if (!id) return;
    try {
      await addStudent.mutateAsync({ cohortId: id, data: { name: studentName, email: studentEmail, status: "active" } });
      setStudentName(""); setStudentEmail("");
      await utils.adminCohorts.getById.invalidate({ id });
      toast.success("Student added to the cohort.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Student could not be added."); }
  }

  async function removeRosterStudent(studentId: number) {
    if (!id || !window.confirm("Remove this student from the cohort roster?")) return;
    try { await removeStudent.mutateAsync({ id: studentId }); await utils.adminCohorts.getById.invalidate({ id }); toast.success("Student removed from the roster."); } catch (error) { toast.error(error instanceof Error ? error.message : "Student could not be removed."); }
  }

  async function addResourceLink(event: FormEvent) {
    event.preventDefault();
    if (!id) return;
    try { await addLink.mutateAsync({ cohortId: id, title: linkTitle, description: null, resourceType: linkType, audience: linkAudience, url: linkUrl, displayOrder: linkOrder, isActive: true }); setLinkTitle(""); setLinkUrl(""); setLinkOrder(0); await utils.adminCohorts.getById.invalidate({ id }); toast.success("Resource link added."); } catch (error) { toast.error(error instanceof Error ? error.message : "Link could not be added."); }
  }

  async function uploadFile(event: FormEvent) {
    event.preventDefault();
    if (!id || !selectedFile) return;
    if (!allowedMimeTypes.includes(selectedFile.type as typeof allowedMimeTypes[number])) { toast.error("Use PDF, DOCX, XLSX, PPTX, CSV, or plain text files."); return; }
    if (selectedFile.size > 10 * 1024 * 1024) { toast.error("Files must be 10 MB or smaller."); return; }
    const dataBase64 = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result).split(",")[1] ?? ""); reader.onerror = () => reject(reader.error); reader.readAsDataURL(selectedFile); });
    try { await uploadResource.mutateAsync({ cohortId: id, title: fileTitle || selectedFile.name, description: null, resourceType: fileType, audience: fileAudience, fileName: selectedFile.name, mimeType: selectedFile.type as typeof allowedMimeTypes[number], dataBase64, displayOrder: fileOrder }); setFileTitle(""); setFileOrder(0); setSelectedFile(null); const input = document.getElementById("cohort-file") as HTMLInputElement | null; if (input) input.value = ""; await utils.adminCohorts.getById.invalidate({ id }); toast.success("Cohort document uploaded securely."); } catch (error) { toast.error(error instanceof Error ? error.message : "Document could not be uploaded."); }
  }

  const fieldError = (key: keyof CohortInput) => errors[key] ? <p className="mt-1 text-sm text-red-700">{errors[key]}</p> : null;
  const roster = existing.data?.students ?? [];
  const resources = existing.data?.resources ?? [];
  const communications = existing.data?.communications ?? [];
  const communicationSummary = useMemo(() => communications.length ? `${communications.length} communication${communications.length === 1 ? "" : "s"} recorded` : "No cohort communications have been sent.", [communications.length]);

  if (editing && existing.isLoading) return <div role="status" className="mx-auto flex max-w-4xl items-center gap-3 rounded-xl border border-slate-200 bg-white p-8"><Loader2 className="h-5 w-5 animate-spin" />Loading cohort workspace…</div>;
  if (editing && existing.error) return <div role="alert" className="mx-auto max-w-4xl rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{existing.error.message}</div>;

  return (
    <div className="mx-auto max-w-7xl">
      <p role="status" aria-live="polite" className="sr-only">{pending ? "Saving cohort." : statusMessage}</p>
      <form onSubmit={save} noValidate>
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><Link href="/admin/cohorts" className="inline-flex items-center gap-2 text-sm font-bold text-[#173b70] hover:underline"><ArrowLeft className="h-4 w-4" />Cohort operations</Link><h1 className="mt-4 text-4xl font-bold text-[#071f49]">{editing ? "Manage cohort" : "Create cohort"}</h1><p className="mt-3 text-slate-600">Configure the program and faculty first. Roster, resource, and communication controls become available after the cohort is created.</p></div><Button type="submit" disabled={pending} className="bg-[#071f49] font-bold text-white hover:bg-[#173b70]">{pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Save cohort</Button></div>
        {Object.keys(errors).length ? <div id="cohort-errors" tabIndex={-1} role="alert" className="mt-6 rounded-xl border border-red-200 bg-red-50 p-5 text-red-800"><p className="font-bold">Review the highlighted cohort fields.</p></div> : null}
        <div className="mt-8 grid gap-6 xl:grid-cols-2">
          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Program and ownership</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div className="sm:col-span-2"><Label htmlFor="cohort-title">Cohort title</Label><Input id="cohort-title" className="mt-2" value={form.title} onChange={event => { const title = event.target.value; update("title", title); if (!slugEdited) update("slug", slugify(title)); }} aria-invalid={Boolean(errors.title)} />{fieldError("title")}</div><div className="sm:col-span-2"><Label htmlFor="cohort-slug">Cohort slug</Label><Input id="cohort-slug" className="mt-2 font-mono" value={form.slug} onChange={event => { setSlugEdited(true); update("slug", slugify(event.target.value)); }} aria-invalid={Boolean(errors.slug)} />{fieldError("slug")}</div><div><Label htmlFor="cohort-program">Certification or program</Label><select id="cohort-program" value={form.certificationId} onChange={event => update("certificationId", Number(event.target.value))} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value={0}>Select program</option>{options.data?.programs.map(program => <option key={program.id} value={program.id}>{program.title}{program.status === "published" ? "" : ` (${program.status})`}</option>)}</select>{fieldError("certificationId")}</div><div><Label htmlFor="cohort-instructor">Instructor</Label><select id="cohort-instructor" value={form.instructorId ?? 0} onChange={event => update("instructorId", Number(event.target.value) || null)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value={0}>Not assigned</option>{options.data?.instructors.map(instructor => <option key={instructor.id} value={instructor.id}>{instructor.name}{instructor.isActive ? "" : " (inactive)"}</option>)}</select></div><div className="sm:col-span-2 rounded-lg border border-[#173b70]/20 bg-[#f7faff] p-4"><Label htmlFor="cohort-certificate-signatory">Certificate signing instructor override</Label><select id="cohort-certificate-signatory" value={form.certificateSignatoryInstructorId ?? 0} onChange={event => update("certificateSignatoryInstructorId", Number(event.target.value) || null)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value={0}>Use certificate template or assigned instructor</option>{options.data?.instructors.map(instructor => <option key={instructor.id} value={instructor.id}>{instructor.name}{instructor.title ? ` — ${instructor.title}` : ""}{instructor.isActive ? "" : " (inactive)"}</option>)}</select><p className="mt-1 text-xs leading-5 text-slate-600">Use this only when this cohort needs a different instructor signature and signatory block than the course default.</p></div><div><Label htmlFor="cohort-status">Status</Label><select id="cohort-status" value={form.status} onChange={event => update("status", event.target.value as CohortInput["status"])} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="draft">Draft</option><option value="planned">Planned</option><option value="active">Active</option><option value="completed">Completed</option><option value="cancelled">Cancelled</option><option value="archived">Archived</option></select></div><div><Label htmlFor="cohort-timezone">Time zone</Label><select id="cohort-timezone" value={form.timeZone} onChange={event => update("timeZone", event.target.value)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="America/New_York">Eastern Time</option><option value="America/Chicago">Central Time</option><option value="America/Denver">Mountain Time</option><option value="America/Los_Angeles">Pacific Time</option></select></div></div></section>
          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Schedule and virtual classroom</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><Label htmlFor="cohort-start">Start</Label><Input id="cohort-start" type="datetime-local" className="mt-2" value={toInputDate(form.startAt)} onChange={event => update("startAt", event.target.value ? new Date(event.target.value) : null)} /></div><div><Label htmlFor="cohort-end">End</Label><Input id="cohort-end" type="datetime-local" className="mt-2" value={toInputDate(form.endAt)} onChange={event => update("endAt", event.target.value ? new Date(event.target.value) : null)} />{fieldError("endAt")}</div><div className="sm:col-span-2"><Label htmlFor="cohort-schedule">Class schedule</Label><Textarea id="cohort-schedule" rows={4} className="mt-2 resize-y" value={form.scheduleSummary ?? ""} onChange={event => update("scheduleSummary", event.target.value || null)} placeholder="Weekly meeting cadence, dates, breaks, and key deadlines" /></div><div className="sm:col-span-2"><Label htmlFor="cohort-zoom">Zoom join URL</Label><Input id="cohort-zoom" type="url" className="mt-2" value={form.zoomUrl} onChange={event => update("zoomUrl", event.target.value)} aria-invalid={Boolean(errors.zoomUrl)} />{fieldError("zoomUrl")}</div><div><Label htmlFor="cohort-meeting-id">Meeting ID</Label><Input id="cohort-meeting-id" className="mt-2" value={form.zoomMeetingId ?? ""} onChange={event => update("zoomMeetingId", event.target.value || null)} /></div><div><Label htmlFor="cohort-passcode">Passcode</Label><Input id="cohort-passcode" className="mt-2" value={form.zoomPasscode ?? ""} onChange={event => update("zoomPasscode", event.target.value || null)} /></div><div className="sm:col-span-2"><Label htmlFor="cohort-notes">Administrator notes</Label><Textarea id="cohort-notes" rows={4} className="mt-2 resize-y" value={form.administratorNotes ?? ""} onChange={event => update("administratorNotes", event.target.value || null)} /><p className="mt-1 text-xs text-slate-500">Internal only. Do not enter clinical or protected health information.</p></div></div></section>
        </div>
      </form>

      {!editing ? <div className="mt-8 rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center"><h2 className="text-2xl font-bold text-[#071f49]">Save the cohort to continue.</h2><p className="mt-2 text-slate-600">The student roster, resources, and communication workspace require a cohort record.</p></div> : null}

      {editing ? <>
        <div className="mt-8 grid gap-6 xl:grid-cols-2">
          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div className="flex items-start justify-between gap-4"><div><h2 className="text-2xl font-bold text-[#071f49]">Student roster</h2><p className="mt-2 text-sm leading-6 text-slate-600">Store only the name and email needed for educational operations. Each email may appear once per cohort.</p></div><Badge className="bg-[#071f49] text-white">{roster.length} students</Badge></div><form onSubmit={addRosterStudent} className="mt-6 grid gap-3 sm:grid-cols-[1fr_1fr_auto]"><div><Label htmlFor="student-name">Student name</Label><Input id="student-name" className="mt-2" value={studentName} onChange={event => setStudentName(event.target.value)} required /></div><div><Label htmlFor="student-email">Student email</Label><Input id="student-email" type="email" className="mt-2" value={studentEmail} onChange={event => setStudentEmail(event.target.value)} required /></div><Button type="submit" disabled={addStudent.isPending} className="self-end bg-[#071f49] text-white hover:bg-[#173b70]"><UserPlus className="mr-2 h-4 w-4" />Add</Button></form><div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">{roster.map(student => <div key={student.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-bold text-[#071f49]">{student.name}</p><p className="mt-1 text-sm text-slate-600">{student.email}</p></div><div className="flex items-center gap-2"><Badge className="bg-slate-100 text-slate-700">{student.status}</Badge><Button type="button" variant="outline" size="sm" className="border-rose-200 bg-white text-rose-800" onClick={() => removeRosterStudent(student.id)}><Trash2 className="mr-1.5 h-4 w-4" />Remove</Button></div></div>)}{roster.length === 0 ? <p className="p-5 text-sm text-slate-600">No students have been added.</p> : null}</div></section>
          <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
            <h2 className="text-2xl font-bold text-[#071f49]">Cohort resources</h2>
            <p className="mt-2 text-sm leading-6 text-slate-600">Upload syllabi, class schedules, and documents to managed storage, or add an approved external link. Audience and display order determine how resources are distributed.</p>
            <div className="mt-6 grid gap-6 sm:grid-cols-2">
              <form onSubmit={uploadFile} className="rounded-lg border border-slate-200 p-4">
                <FileUp className="h-5 w-5 text-[#b94700]" />
                <h3 className="mt-3 font-bold text-[#071f49]">Upload document</h3>
                <Label htmlFor="file-title" className="mt-4 block">Display title</Label>
                <Input id="file-title" className="mt-2" value={fileTitle} onChange={event => setFileTitle(event.target.value)} placeholder="Course syllabus" />
                <Label htmlFor="file-type" className="mt-4 block">Resource type</Label>
                <select id="file-type" value={fileType} onChange={event => setFileType(event.target.value as typeof fileType)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="syllabus">Syllabus</option><option value="schedule">Schedule</option><option value="document">Document</option><option value="other">Other</option></select>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div><Label htmlFor="file-audience">Audience</Label><select id="file-audience" value={fileAudience} onChange={event => setFileAudience(event.target.value as typeof fileAudience)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="students">Students</option><option value="instructors">Instructors</option><option value="all">All cohort members</option><option value="administrators">Administrators</option></select></div>
                  <div><Label htmlFor="file-order">Display order</Label><Input id="file-order" type="number" min={0} className="mt-2" value={fileOrder} onChange={event => setFileOrder(Number(event.target.value))} /></div>
                </div>
                <Label htmlFor="cohort-file" className="mt-4 block">File</Label>
                <Input id="cohort-file" type="file" className="mt-2" accept=".pdf,.docx,.xlsx,.pptx,.csv,.txt" onChange={event => setSelectedFile(event.target.files?.[0] ?? null)} required />
                <p className="mt-2 text-xs text-slate-500">PDF, DOCX, XLSX, PPTX, CSV, or TXT. Maximum 10 MB.</p>
                <Button type="submit" disabled={uploadResource.isPending || !selectedFile} className="mt-4 w-full bg-[#071f49] text-white hover:bg-[#173b70]">{uploadResource.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <FileUp className="mr-2 h-4 w-4" />}Upload</Button>
              </form>
              <form onSubmit={addResourceLink} className="rounded-lg border border-slate-200 p-4">
                <Link2 className="h-5 w-5 text-[#b94700]" />
                <h3 className="mt-3 font-bold text-[#071f49]">Add resource link</h3>
                <Label htmlFor="link-title" className="mt-4 block">Display title</Label>
                <Input id="link-title" className="mt-2" value={linkTitle} onChange={event => setLinkTitle(event.target.value)} required />
                <Label htmlFor="link-type" className="mt-4 block">Resource type</Label>
                <select id="link-type" value={linkType} onChange={event => setLinkType(event.target.value as typeof linkType)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="link">Link</option><option value="syllabus">Syllabus</option><option value="schedule">Schedule</option><option value="document">Document</option><option value="other">Other</option></select>
                <div className="mt-4 grid gap-3 sm:grid-cols-2">
                  <div><Label htmlFor="link-audience">Audience</Label><select id="link-audience" value={linkAudience} onChange={event => setLinkAudience(event.target.value as typeof linkAudience)} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="students">Students</option><option value="instructors">Instructors</option><option value="all">All cohort members</option><option value="administrators">Administrators</option></select></div>
                  <div><Label htmlFor="link-order">Display order</Label><Input id="link-order" type="number" min={0} className="mt-2" value={linkOrder} onChange={event => setLinkOrder(Number(event.target.value))} /></div>
                </div>
                <Label htmlFor="link-url" className="mt-4 block">URL</Label>
                <Input id="link-url" type="url" className="mt-2" value={linkUrl} onChange={event => setLinkUrl(event.target.value)} required />
                <Button type="submit" disabled={addLink.isPending} className="mt-4 w-full bg-[#071f49] text-white hover:bg-[#173b70]"><Plus className="mr-2 h-4 w-4" />Add link</Button>
              </form>
            </div>
            <div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">
              {resources.map(resource => (
                <div key={resource.id} className="grid gap-4 p-4 lg:grid-cols-[1fr_170px_110px_auto] lg:items-end">
                  <div><div className="flex items-center gap-2"><p className="font-bold text-[#071f49]">{resource.title}</p><Badge className={resource.isActive ? "bg-emerald-100 text-emerald-900" : "bg-slate-200 text-slate-700"}>{resource.isActive ? "Active" : "Inactive"}</Badge></div><p className="mt-1 text-xs uppercase tracking-wide text-slate-500">{resource.resourceType} · {resource.sourceType}{resource.fileSize ? ` · ${(resource.fileSize / 1024).toFixed(0)} KB` : ""}</p></div>
                  <div><Label htmlFor={`resource-audience-${resource.id}`}>Audience</Label><select id={`resource-audience-${resource.id}`} defaultValue={resource.audience} onChange={async event => { await updateResourceSettings.mutateAsync({ id: resource.id, audience: event.target.value as typeof resource.audience, displayOrder: resource.displayOrder }); await utils.adminCohorts.getById.invalidate({ id: id! }); toast.success("Resource audience updated."); }} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="students">Students</option><option value="instructors">Instructors</option><option value="all">All</option><option value="administrators">Administrators</option></select></div>
                  <div><Label htmlFor={`resource-order-${resource.id}`}>Order</Label><Input id={`resource-order-${resource.id}`} type="number" min={0} defaultValue={resource.displayOrder} onBlur={async event => { await updateResourceSettings.mutateAsync({ id: resource.id, audience: resource.audience, displayOrder: Number(event.target.value) }); await utils.adminCohorts.getById.invalidate({ id: id! }); toast.success("Resource order updated."); }} className="mt-2" /></div>
                  <div className="flex gap-2"><Button asChild type="button" variant="outline" size="sm" className="border-slate-300 bg-white"><a href={resource.url} target="_blank" rel="noreferrer">Open <ExternalLink className="ml-1.5 h-4 w-4" /></a></Button><Button type="button" variant="outline" size="sm" disabled={setResourceStatus.isPending} onClick={async () => { await setResourceStatus.mutateAsync({ id: resource.id, isActive: !resource.isActive }); await utils.adminCohorts.getById.invalidate({ id: id! }); }} className="border-slate-300 bg-white">{resource.isActive ? "Remove" : "Restore"}</Button></div>
                </div>
              ))}
              {resources.length === 0 ? <p className="p-5 text-sm text-slate-600">No cohort resources have been added.</p> : null}
            </div>
          </section>
        </div>
        <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><h2 className="text-2xl font-bold text-[#071f49]">Cohort communications</h2><p className="mt-2 text-sm text-slate-600">{communicationSummary}</p></div><Button asChild className="bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><Link href={`/admin/cohorts/${id}/communications`}><Mail className="mr-2 h-4 w-4" />Compose cohort message</Link></Button></div><div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">{communications.map(item => <div key={item.id} className="grid gap-3 p-4 sm:grid-cols-[1fr_150px_180px] sm:items-center"><div><p className="font-bold text-[#071f49]">{item.subject}</p><p className="mt-1 text-xs text-slate-500">{item.communicationType.replace("_", " ")}</p></div><Badge className="w-fit bg-slate-100 text-slate-700">{item.status}</Badge><p className="text-sm text-slate-600">{item.deliveredCount}/{item.recipientCount} delivered</p></div>)}{communications.length === 0 ? <p className="p-5 text-sm text-slate-600">Messages will appear here after delivery is configured and a confirmed send is completed.</p> : null}</div></section>
      </> : null}
    </div>
  );
}

export default function CohortEditor() {
  const params = useParams<{ id?: string }>();
  const id = params.id ? Number(params.id) : undefined;
  return <DashboardLayout><Editor id={id} /></DashboardLayout>;
}
