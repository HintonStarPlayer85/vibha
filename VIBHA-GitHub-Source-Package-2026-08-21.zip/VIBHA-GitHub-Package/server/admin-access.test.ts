import type { TrpcContext } from "./_core/context";
import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";

const accessMocks = vi.hoisted(() => ({
  createAdministratorInvitation: vi.fn(),
  getAdministratorInvitationPreview: vi.fn(),
  acceptAdministratorInvitation: vi.fn(),
  listAdministratorAccess: vi.fn(),
  revokeAdministratorInvitation: vi.fn(),
  setAdministratorRole: vi.fn(),
  recordAdministrationAudit: vi.fn(),
}));

vi.mock("./administrationDb", async () => {
  const actual = await vi.importActual<typeof import("./administrationDb")>("./administrationDb");
  return { ...actual, ...accessMocks };
});

import { appRouter } from "./routers";
import { hashInvitationToken } from "./routers/adminAccess";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function context(role: AuthenticatedUser["role"] | null): TrpcContext {
  const user = role
    ? ({
        id: role === "owner" ? 1 : 2,
        openId: `${role}-open-id`,
        email: `${role}@example.com`,
        name: role,
        loginMethod: "manus",
        role,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      } satisfies AuthenticatedUser)
    : null;
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("administrator access security", () => {
  beforeEach(() => vi.clearAllMocks());

  it("hashes invitation tokens before persistence or lookup", () => {
    const token = "secure-invitation-token-with-sufficient-length";
    expect(hashInvitationToken(token)).toMatch(/^[a-f0-9]{64}$/);
    expect(hashInvitationToken(token)).not.toContain(token);
    expect(hashInvitationToken(token)).toBe(hashInvitationToken(token));
  });

  it("allows the owner through existing admin procedures", async () => {
    accessMocks.listAdministratorAccess.mockResolvedValue({ administrators: [], invitations: [], auditEvents: [] });
    const caller = appRouter.createCaller(context("owner"));
    await expect(caller.adminAccess.list()).resolves.toEqual({ administrators: [], invitations: [], auditEvents: [] });
  });

  it("rejects a standard administrator from owner-only access management", async () => {
    const caller = appRouter.createCaller(context("admin"));
    await expect(caller.adminAccess.list()).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
  });

  it("creates a one-time invitation URL while storing only the token hash", async () => {
    accessMocks.createAdministratorInvitation.mockImplementation(async input => ({
      id: 9,
      email: input.email,
      expiresAt: input.expiresAt,
    }));
    const caller = appRouter.createCaller(context("owner"));
    const result = await caller.adminAccess.createInvitation({
      email: "Invitee@Example.com",
      expiresInDays: 7,
      origin: "https://vibha.example",
    });
    expect(result.email).toBe("invitee@example.com");
    expect(result.invitationUrl).toMatch(/^https:\/\/vibha\.example\/admin\/register\?token=/);
    const persisted = accessMocks.createAdministratorInvitation.mock.calls[0][0];
    expect(persisted.tokenHash).toMatch(/^[a-f0-9]{64}$/);
    expect(result.invitationUrl).not.toContain(persisted.tokenHash);
  });

  it("requires authentication before accepting an invitation", async () => {
    const caller = appRouter.createCaller(context(null));
    await expect(
      caller.adminAccess.acceptInvitation({
        token: "x".repeat(40),
        confirmEmail: "invitee@example.com",
      }),
    ).rejects.toMatchObject<Partial<TRPCError>>({ code: "UNAUTHORIZED" });
  });

  it("binds invitation acceptance to the authenticated user and token hash", async () => {
    accessMocks.acceptAdministratorInvitation.mockResolvedValue({ success: true, role: "admin" });
    const caller = appRouter.createCaller(context("user"));
    await expect(
      caller.adminAccess.acceptInvitation({
        token: "a".repeat(40),
        confirmEmail: "user@example.com",
      }),
    ).resolves.toEqual({ success: true, role: "admin" });
    expect(accessMocks.acceptAdministratorInvitation).toHaveBeenCalledWith(
      expect.objectContaining({
        userId: 2,
        userEmail: "user@example.com",
        confirmEmail: "user@example.com",
        tokenHash: expect.stringMatching(/^[a-f0-9]{64}$/),
      }),
    );
  });
});
