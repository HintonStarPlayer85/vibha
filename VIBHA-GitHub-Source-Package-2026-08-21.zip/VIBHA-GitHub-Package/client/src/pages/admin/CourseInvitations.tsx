import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Mail, Send, ShieldCheck } from "lucide-react";
import { FormEvent, useState } from "react";
import { toast } from "sonner";
import { Link, useParams } from "wouter";

function InvitationWorkspace({ id }: { id: number }) {
  const course = trpc.adminOnlineLearning.getById.useQuery({ id });
  const invitations = trpc.adminLearnerEngagement.invitations.useQuery({ courseId: id });
  const invite = trpc.adminLearnerEngagement.invite.useMutation();
  const utils = trpc.useUtils();
  const [recipientName, setRecipientName] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  async function send(event: FormEvent) {
    event.preventDefault();
    try {
      await invite.mutateAsync({ courseId: id, recipientName, recipientEmail, origin: window.location.origin });
      setRecipientName(""); setRecipientEmail("");
      await utils.adminLearnerEngagement.invitations.invalidate({ courseId: id });
      toast.success("Course invitation sent. The learner must sign in with the invited email address.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Course invitation could not be sent."); }
  }
  if (course.isLoading) return <div className="p-8 text-slate-600">Loading invitation workspace…</div>;
  if (course.error || !course.data) return <div role="alert" className="p-8 text-red-800">{course.error?.message ?? "Course not found."}</div>;
  const published = course.data.status === "published";
  return <main className="mx-auto max-w-5xl pb-12"><Link href="/admin/online-learning" className="inline-flex items-center gap-2 text-sm font-bold text-[#173b70] hover:underline"><ArrowLeft className="h-4 w-4" />Online Learning</Link><div className="mt-5"><p className="text-sm font-bold uppercase tracking-[0.16em] text-[#b94700]">Learner access</p><h1 className="mt-2 text-4xl font-bold text-[#071f49]">Course invitations</h1><p className="mt-3 max-w-3xl leading-7 text-slate-600">Invite one learner at a time to <strong>{course.data.certificationTitle}</strong>. Each invitation is tied to its recipient email, expires after 14 days, and creates the learner’s course enrollment only after acceptance.</p></div><section className="mt-8 rounded-xl border border-[#f47a20]/35 bg-[#fff7f2] p-5"><div className="flex gap-3"><ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-[#b94700]" /><p className="text-sm leading-6 text-[#5a2a07]">Recipient addresses are visible only to authorized administrators. Invitations are sent individually through VIBHA’s configured email service; learners must sign in with the same email that received the invitation.</p></div></section><section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Send learner invitation</h2>{!published ? <p className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">Publish the reviewed self-paced course before inviting learners.</p> : <form className="mt-6 grid gap-4 sm:grid-cols-2" onSubmit={send}><div><Label htmlFor="invitation-name">Learner name</Label><Input id="invitation-name" className="mt-2" value={recipientName} onChange={event => setRecipientName(event.target.value)} required /></div><div><Label htmlFor="invitation-email">Learner email</Label><Input id="invitation-email" type="email" className="mt-2" value={recipientEmail} onChange={event => setRecipientEmail(event.target.value)} required /></div><div className="sm:col-span-2"><Button disabled={invite.isPending} className="bg-[#071f49] text-white hover:bg-[#173b70]"><Send className="mr-2 h-4 w-4" />Send course invitation</Button></div></form>}</section><section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div className="flex items-center gap-3"><Mail className="h-5 w-5 text-[#b94700]" /><div><h2 className="text-2xl font-bold text-[#071f49]">Invitation history</h2><p className="mt-1 text-sm text-slate-600">Delivery and acceptance are recorded for this course.</p></div></div><div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">{invitations.data?.map(item => <div key={item.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold text-[#071f49]">{item.recipientName}</p><p className="mt-1 text-sm text-slate-600">{item.recipientEmail}</p>{item.deliveryError ? <p className="mt-2 text-xs text-rose-700">Delivery error: {item.deliveryError}</p> : null}</div><div className="flex gap-2"><Badge className={item.deliveryStatus === "sent" ? "bg-emerald-100 text-emerald-800" : item.deliveryStatus === "failed" ? "bg-rose-100 text-rose-800" : "bg-slate-100 text-slate-700"}>{item.deliveryStatus}</Badge><Badge className={item.status === "accepted" ? "bg-emerald-100 text-emerald-800" : item.status === "pending" ? "bg-blue-100 text-blue-800" : "bg-slate-100 text-slate-700"}>{item.status}</Badge></div></div>)}{!invitations.isLoading && invitations.data?.length === 0 ? <p className="p-6 text-center text-sm text-slate-600">No learner invitations have been sent for this course.</p> : null}</div></section></main>;
}

export default function CourseInvitations() { const params = useParams<{ id: string }>(); const id = Number(params.id); return <DashboardLayout>{Number.isInteger(id) && id > 0 ? <InvitationWorkspace id={id} /> : <div role="alert" className="p-8 text-red-800">Invalid Online Learning course.</div>}</DashboardLayout>; }
