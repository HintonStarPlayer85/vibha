ALTER TABLE `certificate_program_profiles` ADD `executiveSignatureStorageKey` varchar(800);--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `executiveSignatureUrl` varchar(1000);--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `executiveSignatureMimeType` varchar(80);--> statement-breakpoint
ALTER TABLE `cohorts` ADD `certificateSignatoryInstructorId` int;--> statement-breakpoint
ALTER TABLE `cohorts` ADD CONSTRAINT `cohort_cert_signatory_instructor_fk` FOREIGN KEY (`certificateSignatoryInstructorId`) REFERENCES `instructors`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `cohort_certificate_signatory_instructor_idx` ON `cohorts` (`certificateSignatoryInstructorId`);
