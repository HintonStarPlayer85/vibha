import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { instructorInputSchema, type InstructorInput } from "@shared/administration";
import { ArrowLeft, ImagePlus, Loader2, Save, Trash2 } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";
import { Link, useLocation, useParams } from "wouter";

type SignatureCrop = { x: number; y: number; size: number; zoom: number };
type SignatureSource = { fileName: string; dataUrl: string };

const emptyInstructor: InstructorInput = {
  name: "",
  slug: "",
  email: "",
  credentials: null,
  title: null,
  biography: null,
  expertise: [],
  photoUrl: "",
  isActive: true,
  certificationIds: [],
};

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

function Editor({ id }: { id?: number }) {
  const editing = Boolean(id);
  const [, navigate] = useLocation();
  const [form, setForm] = useState<InstructorInput>(emptyInstructor);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [slugEdited, setSlugEdited] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [signatureSource, setSignatureSource] = useState<SignatureSource | null>(null);
  const [signatureCrop, setSignatureCrop] = useState<SignatureCrop>({ x: 0.5, y: 0.5, size: 1, zoom: 1 });
  const [croppedSignature, setCroppedSignature] = useState<string | null>(null);
  const existing = trpc.adminInstructors.getById.useQuery({ id: id ?? 0 }, { enabled: editing });
  const options = trpc.adminInstructors.options.useQuery();
  const createMutation = trpc.adminInstructors.create.useMutation();
  const updateMutation = trpc.adminInstructors.update.useMutation();
  const uploadSignature = trpc.adminInstructors.uploadSignature.useMutation();
  const removeSignature = trpc.adminInstructors.removeSignature.useMutation();
  const utils = trpc.useUtils();
  const pending = createMutation.isPending || updateMutation.isPending || uploadSignature.isPending || removeSignature.isPending;

  useEffect(() => {
    if (!existing.data) return;
    setForm({
      name: existing.data.name,
      slug: existing.data.slug,
      email: existing.data.email ?? "",
      credentials: existing.data.credentials,
      title: existing.data.title,
      biography: existing.data.biography,
      expertise: existing.data.expertise ?? [],
      photoUrl: existing.data.photoUrl ?? "",
      isActive: existing.data.isActive,
      certificationIds: existing.data.certificationIds,
    });
    setSlugEdited(true);
  }, [existing.data]);

  useEffect(() => {
    if (!signatureSource) { setCroppedSignature(null); return; }
    let active = true;
    const image = new Image();
    image.onload = () => {
      const targetWidth = 800; const targetHeight = 240; const targetRatio = targetWidth / targetHeight;
      const sourceRatio = image.width / image.height;
      const baseWidth = sourceRatio > targetRatio ? image.height * targetRatio : image.width;
      const baseHeight = sourceRatio > targetRatio ? image.height : image.width / targetRatio;
      const cropWidth = baseWidth / signatureCrop.zoom; const cropHeight = baseHeight / signatureCrop.zoom;
      const sx = Math.max(0, Math.min(image.width - cropWidth, (image.width - cropWidth) * signatureCrop.x));
      const sy = Math.max(0, Math.min(image.height - cropHeight, (image.height - cropHeight) * signatureCrop.y));
      const canvas = document.createElement("canvas"); canvas.width = targetWidth; canvas.height = targetHeight;
      canvas.getContext("2d")?.drawImage(image, sx, sy, cropWidth, cropHeight, 0, 0, targetWidth, targetHeight);
      if (active) setCroppedSignature(canvas.toDataURL("image/png"));
    };
    image.src = signatureSource.dataUrl;
    return () => { active = false; };
  }, [signatureSource, signatureCrop]);

  function update<K extends keyof InstructorInput>(key: K, value: InstructorInput[K]) {
    setForm(current => ({ ...current, [key]: value }));
    setErrors(current => ({ ...current, [key]: "" }));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    const parsed = instructorInputSchema.safeParse(form);
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) next[String(issue.path[0])] ??= issue.message;
      setErrors(next);
      setStatusMessage("Instructor was not saved. Review the highlighted fields.");
      requestAnimationFrame(() => document.getElementById("instructor-errors")?.focus());
      return;
    }
    try {
      const saved = editing ? await updateMutation.mutateAsync({ id: id!, data: parsed.data }) : await createMutation.mutateAsync(parsed.data);
      await Promise.all([utils.adminInstructors.invalidate(), utils.adminCertifications.invalidate(), utils.certifications.invalidate()]);
      const message = editing ? "Instructor updated." : "Instructor registered.";
      setStatusMessage(message);
      toast.success(message);
      navigate(`/admin/instructors/${saved!.id}/edit`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The instructor could not be saved.";
      setStatusMessage(`Save failed: ${message}`);
      toast.error(message);
    }
  }

  async function selectSignature(file?: File) {
    if (!file || !id) return;
    if (!(file.type === "image/png" || file.type === "image/jpeg") || file.size > 2 * 1024 * 1024) { toast.error("Select a PNG or JPEG signature image no larger than 2 MB."); return; }
    const dataUrl = await new Promise<string>((resolve, reject) => { const reader = new FileReader(); reader.onerror = () => reject(new Error("The signature image could not be read.")); reader.onload = () => resolve(String(reader.result)); reader.readAsDataURL(file); });
    setSignatureSource({ fileName: file.name, dataUrl }); setSignatureCrop({ x: 0.5, y: 0.5, size: 1, zoom: 1 });
  }
  async function saveCroppedSignature() {
    if (!id || !signatureSource || !croppedSignature) return;
    try { await uploadSignature.mutateAsync({ instructorId: id, fileName: signatureSource.fileName.replace(/\.[^.]+$/, "") + "-cropped.png", mimeType: "image/png", dataBase64: croppedSignature.split(",")[1] ?? "", crop: signatureCrop }); await utils.adminInstructors.getById.invalidate({ id }); setSignatureSource(null); toast.success("Cropped digital signature saved for future certificates."); } catch (error) { toast.error(error instanceof Error ? error.message : "Signature upload failed."); }
  }
  async function deleteSignature() { if (!id || !window.confirm("Remove this instructor signature image? Existing certificates are unchanged.")) return; try { await removeSignature.mutateAsync({ instructorId: id }); await utils.adminInstructors.getById.invalidate({ id }); toast.success("Digital signature removed."); } catch (error) { toast.error(error instanceof Error ? error.message : "Signature removal failed."); } }

  if (editing && existing.isLoading) return <div role="status" className="mx-auto flex max-w-4xl items-center gap-3 rounded-xl border border-slate-200 bg-white p-8"><Loader2 className="h-5 w-5 animate-spin" />Loading instructor editor…</div>;
  if (editing && existing.error) return <div role="alert" className="mx-auto max-w-4xl rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{existing.error.message}</div>;
  const fieldError = (name: keyof InstructorInput) => errors[name] ? <p className="mt-1 text-sm text-red-700">{errors[name]}</p> : null;

  return (
    <form onSubmit={submit} noValidate className="mx-auto max-w-6xl">
      <p role="status" aria-live="polite" className="sr-only">{pending ? "Saving instructor." : statusMessage}</p>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><Link href="/admin/instructors" className="inline-flex items-center gap-2 text-sm font-bold text-[#173b70] hover:underline"><ArrowLeft className="h-4 w-4" />Instructor directory</Link><h1 className="mt-4 text-4xl font-bold text-[#071f49]">{editing ? "Edit instructor" : "Register instructor"}</h1><p className="mt-3 text-slate-600">One instructor profile can be assigned to multiple certifications and cohorts.</p></div><Button type="submit" disabled={pending} className="bg-[#071f49] font-bold text-white hover:bg-[#173b70]">{pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Save instructor</Button></div>
      {Object.keys(errors).length ? <div id="instructor-errors" tabIndex={-1} role="alert" className="mt-6 rounded-xl border border-red-200 bg-red-50 p-5 text-red-800"><p className="font-bold">Review the highlighted instructor fields.</p></div> : null}
      <div className="mt-8 grid gap-6 xl:grid-cols-[1fr_420px]">
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Identity and qualifications</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><Label htmlFor="instructor-name">Name</Label><Input id="instructor-name" className="mt-2" value={form.name} onChange={event => { const name = event.target.value; update("name", name); if (!slugEdited) update("slug", slugify(name)); }} aria-invalid={Boolean(errors.name)} />{fieldError("name")}</div><div><Label htmlFor="instructor-email">Email</Label><Input id="instructor-email" type="email" className="mt-2" value={form.email} onChange={event => update("email", event.target.value)} aria-invalid={Boolean(errors.email)} />{fieldError("email")}</div><div><Label htmlFor="instructor-slug">Profile slug</Label><Input id="instructor-slug" className="mt-2 font-mono" value={form.slug} onChange={event => { setSlugEdited(true); update("slug", slugify(event.target.value)); }} aria-invalid={Boolean(errors.slug)} />{fieldError("slug")}</div><div><Label htmlFor="instructor-credentials">Credentials</Label><Input id="instructor-credentials" className="mt-2" placeholder="MSHRM, QMHP" value={form.credentials ?? ""} onChange={event => update("credentials", event.target.value || null)} /></div><div className="sm:col-span-2"><Label htmlFor="instructor-title">Institutional title</Label><Input id="instructor-title" className="mt-2" value={form.title ?? ""} onChange={event => update("title", event.target.value || null)} /></div><div className="sm:col-span-2"><Label htmlFor="instructor-biography">Biography</Label><Textarea id="instructor-biography" rows={8} className="mt-2 resize-y" value={form.biography ?? ""} onChange={event => update("biography", event.target.value || null)} /></div><div className="sm:col-span-2"><Label htmlFor="instructor-expertise">Expertise</Label><Textarea id="instructor-expertise" rows={5} className="mt-2 resize-y" value={form.expertise.join("\n")} onChange={event => update("expertise", event.target.value.split("\n").map(value => value.trim()).filter(Boolean))} /><p className="mt-1 text-xs text-slate-500">Enter one area of expertise per line.</p></div><div className="sm:col-span-2"><Label htmlFor="instructor-photo">Profile image URL</Label><Input id="instructor-photo" type="url" className="mt-2" value={form.photoUrl} onChange={event => update("photoUrl", event.target.value)} /></div><label className="sm:col-span-2 flex items-center gap-3 rounded-lg border border-slate-200 p-4 text-sm font-semibold text-[#071f49]"><input type="checkbox" checked={form.isActive} onChange={event => update("isActive", event.target.checked)} className="h-5 w-5 accent-[#071f49]" />Instructor is available for assignment</label></div></section>
        <div className="space-y-6"><section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Certification assignments</h2><p className="mt-2 text-sm leading-6 text-slate-600">These assignments appear in the certification editor and public certification details.</p>{options.isLoading ? <p role="status" className="mt-5 text-sm text-slate-600">Loading certifications…</p> : null}<div className="mt-5 max-h-[460px] space-y-2 overflow-y-auto pr-1">{options.data?.map(certification => <label key={certification.id} className="flex items-start gap-3 rounded-lg border border-slate-200 p-3 text-sm"><input type="checkbox" className="mt-0.5 h-5 w-5 shrink-0 accent-[#071f49]" checked={form.certificationIds.includes(certification.id)} onChange={event => update("certificationIds", event.target.checked ? Array.from(new Set([...form.certificationIds, certification.id])) : form.certificationIds.filter(value => value !== certification.id))} /><span><strong className="block text-[#071f49]">{certification.title}</strong><span className="text-xs text-slate-500">{certification.status.replace("_", " ")}</span></span></label>)}</div></section><section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Digital certificate signature</h2><p className="mt-2 text-sm leading-6 text-slate-600">Upload a transparent or white-background PNG or JPEG. Crop it into a clean signature strip before it is embedded on future certificates. Existing issued certificates remain unchanged.</p>{!editing ? <p className="mt-4 rounded-lg bg-slate-50 p-3 text-sm text-slate-600">Save this instructor first, then return here to upload a signature.</p> : <div className="mt-5">{existing.data?.signatureUrl ? <div className="rounded-lg border border-slate-200 bg-slate-50 p-3"><img src={existing.data.signatureUrl} alt={`Stored signature for ${existing.data.name}`} className="h-20 max-w-full object-contain object-left" /><p className="mt-2 text-xs text-slate-500">{existing.data.signatureFileName ?? "Stored signature image"}</p><Button type="button" variant="outline" disabled={pending} onClick={deleteSignature} className="mt-3 border-red-200 bg-white text-red-800 hover:bg-red-50"><Trash2 className="mr-1.5 h-4 w-4" />Remove signature</Button></div> : <p className="rounded-lg bg-slate-50 p-3 text-sm text-slate-600">No signature image has been saved.</p>}<Label htmlFor="instructor-signature" className="mt-4 block">{existing.data?.signatureUrl ? "Replace signature image" : "Choose signature image"}</Label><Input id="instructor-signature" type="file" accept="image/png,image/jpeg" className="mt-2 cursor-pointer" disabled={pending} onChange={event => { void selectSignature(event.target.files?.[0]); event.currentTarget.value = ""; }} /><p className="mt-1 text-xs text-slate-500">PNG or JPEG only, up to 2 MB.</p>{signatureSource ? <div className="mt-5 rounded-lg border border-[#173b70]/25 bg-[#f7faff] p-4"><h3 className="font-bold text-[#071f49]">Crop and prepare signature</h3><p className="mt-1 text-xs leading-5 text-slate-600">Adjust zoom and position, then save the cropped preview. The stored signature is converted to a clean PNG strip.</p>{croppedSignature ? <img src={croppedSignature} alt="Cropped signature preview" className="mt-4 h-20 w-full rounded border border-slate-200 bg-white object-contain" /> : <p className="mt-4 text-sm text-slate-600">Preparing preview…</p>}<div className="mt-4 space-y-3"><div><Label htmlFor="signature-zoom" className="text-xs">Zoom: {signatureCrop.zoom.toFixed(1)}×</Label><input id="signature-zoom" type="range" min="1" max="3" step="0.1" value={signatureCrop.zoom} onChange={event => setSignatureCrop(current => ({ ...current, zoom: Number(event.target.value), size: 1 / Number(event.target.value) }))} className="mt-1 w-full accent-[#071f49]" /></div><div><Label htmlFor="signature-horizontal" className="text-xs">Horizontal position</Label><input id="signature-horizontal" type="range" min="0" max="1" step="0.01" value={signatureCrop.x} onChange={event => setSignatureCrop(current => ({ ...current, x: Number(event.target.value) }))} className="mt-1 w-full accent-[#071f49]" /></div><div><Label htmlFor="signature-vertical" className="text-xs">Vertical position</Label><input id="signature-vertical" type="range" min="0" max="1" step="0.01" value={signatureCrop.y} onChange={event => setSignatureCrop(current => ({ ...current, y: Number(event.target.value) }))} className="mt-1 w-full accent-[#071f49]" /></div></div><div className="mt-4 flex flex-wrap gap-2"><Button type="button" variant="outline" onClick={() => setSignatureCrop({ x: 0.5, y: 0.5, size: 1, zoom: 1 })}>Reset crop</Button><Button type="button" disabled={pending || !croppedSignature} onClick={saveCroppedSignature} className="bg-[#071f49] text-white hover:bg-[#173b70]"><ImagePlus className="mr-1.5 h-4 w-4" />Save cropped signature</Button><Button type="button" variant="ghost" onClick={() => setSignatureSource(null)}>Cancel</Button></div></div> : null}</div>}</section></div>
      </div>
      <div className="mt-6 flex justify-end rounded-xl border border-slate-200 bg-white p-4 shadow-sm"><Button type="submit" disabled={pending} className="w-full bg-[#071f49] px-6 font-bold text-white hover:bg-[#173b70] sm:w-auto"><Save className="mr-2 h-4 w-4" />Save instructor</Button></div>
    </form>
  );
}

export default function InstructorEditor() {
  const params = useParams<{ id?: string }>();
  const id = params.id ? Number(params.id) : undefined;
  return <DashboardLayout><Editor id={id} /></DashboardLayout>;
}
