import { TRPCError } from "@trpc/server";
import {
  onlineCourseEnrollmentSchema,
  onlineCoursePublicQuerySchema,
  onlineInstructorQuestionSchema,
  onlineLessonProgressSchema,
  onlineModuleQuizQuestionSchema,
  onlineModuleQuizQuestionUpdateSchema,
  onlineModuleQuizSchema,
  onlineModuleQuizSubmissionSchema,
} from "../../shared/onlineLearning";
import {
  createModuleQuizQuestion,
  enrollLearnerInCourse,
  getLearnerCourseBySlug,
  learnerLearningErrors,
  listLearnerDashboard,
  submitLearnerModuleQuiz,
  updateLearnerLessonProgress,
  updateModuleQuizQuestion,
  upsertModuleQuiz,
} from "../learnerLearningDb";
import { answerOnlineInstructor } from "../onlineLearningService";
import { adminProcedure, protectedProcedure, router } from "../_core/trpc";

function translateLearnerError(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === learnerLearningErrors.courseNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "This self-paced course is not available for enrollment." });
  if (message === learnerLearningErrors.enrollmentNotFound) throw new TRPCError({ code: "FORBIDDEN", message: "Enroll in this course before accessing its learning content." });
  if (message === learnerLearningErrors.lessonOutsideCourse || message === learnerLearningErrors.lessonNotFound) throw new TRPCError({ code: "FORBIDDEN", message: "That lesson is not available in your enrolled course." });
  if (message === learnerLearningErrors.quizNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "This module quiz is not available." });
  if (message === learnerLearningErrors.quizNotReady) throw new TRPCError({ code: "BAD_REQUEST", message: "This quiz is not ready for learner attempts." });
  if (message === learnerLearningErrors.answersInvalid) throw new TRPCError({ code: "BAD_REQUEST", message: "Answer every quiz question before submitting." });
  if (message === learnerLearningErrors.moduleNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "Learning module not found." });
  throw error;
}

export const learnerLearningRouter = router({
  dashboard: protectedProcedure.query(({ ctx }) => listLearnerDashboard(ctx.user.id)),
  enroll: protectedProcedure.input(onlineCourseEnrollmentSchema).mutation(async ({ input, ctx }) => { try { return await enrollLearnerInCourse(input.courseSlug, ctx.user.id); } catch (error) { translateLearnerError(error); } }),
  getCourse: protectedProcedure.input(onlineCoursePublicQuerySchema).query(async ({ input, ctx }) => { try { return await getLearnerCourseBySlug(input.slug, ctx.user.id); } catch (error) { translateLearnerError(error); } }),
  updateLessonProgress: protectedProcedure.input(onlineLessonProgressSchema).mutation(async ({ input, ctx }) => { try { return await updateLearnerLessonProgress(input.courseSlug, input.lessonId, input.completed, ctx.user.id); } catch (error) { translateLearnerError(error); } }),
  submitModuleQuiz: protectedProcedure.input(onlineModuleQuizSubmissionSchema).mutation(async ({ input, ctx }) => { try { return await submitLearnerModuleQuiz(input, ctx.user.id); } catch (error) { translateLearnerError(error); } }),
  askInstructor: protectedProcedure.input(onlineInstructorQuestionSchema).mutation(async ({ input, ctx }) => {
    try { await getLearnerCourseBySlug(input.courseSlug, ctx.user.id); return await answerOnlineInstructor(input.courseSlug, input.question); } catch (error) { translateLearnerError(error); }
  }),
});

export const adminModuleQuizzesRouter = router({
  upsert: adminProcedure.input(onlineModuleQuizSchema).mutation(async ({ input }) => { try { return await upsertModuleQuiz(input); } catch (error) { translateLearnerError(error); } }),
  createQuestion: adminProcedure.input(onlineModuleQuizQuestionSchema).mutation(async ({ input }) => { try { return await createModuleQuizQuestion(input); } catch (error) { translateLearnerError(error); } }),
  updateQuestion: adminProcedure.input(onlineModuleQuizQuestionUpdateSchema).mutation(async ({ input }) => { try { return await updateModuleQuizQuestion(input); } catch (error) { translateLearnerError(error); } }),
});
