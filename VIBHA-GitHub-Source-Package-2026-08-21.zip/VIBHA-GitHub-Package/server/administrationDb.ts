import { and, desc, eq, gt, ne } from "drizzle-orm";
import {
  administrationAuditEvents,
  administratorInvitations,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";

export const administrationErrors = {
  invitationExists: "INVITATION_EXISTS",
  invitationInvalid: "INVITATION_INVALID",
  invitationExpired: "INVITATION_EXPIRED",
  invitationEmailMismatch: "INVITATION_EMAIL_MISMATCH",
  ownerProtected: "OWNER_PROTECTED",
  userNotFound: "USER_NOT_FOUND",
} as const;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

function normalizedEmail(value: string | null | undefined) {
  return value?.trim().toLowerCase() ?? "";
}

export function maskEmail(email: string) {
  const [local, domain] = email.split("@");
  if (!domain) return "Invitation email unavailable";
  const shown = local.length <= 2 ? local.slice(0, 1) : local.slice(0, 2);
  return `${shown}${"•".repeat(Math.max(3, local.length - shown.length))}@${domain}`;
}

export async function recordAdministrationAudit(input: {
  actorUserId?: number | null;
  action: string;
  entityType: string;
  entityId?: string | number | null;
  targetUserId?: number | null;
  eventMetadata?: Record<string, string | number | boolean | null>;
}) {
  const db = await requireDb();
  await db.insert(administrationAuditEvents).values({
    actorUserId: input.actorUserId ?? null,
    action: input.action,
    entityType: input.entityType,
    entityId: input.entityId == null ? null : String(input.entityId),
    targetUserId: input.targetUserId ?? null,
    eventMetadata: input.eventMetadata ?? null,
  });
}

export async function createAdministratorInvitation(input: {
  email: string;
  tokenHash: string;
  expiresAt: Date;
  actorUserId: number;
}) {
  const db = await requireDb();
  const email = normalizedEmail(input.email);
  const active = await db
    .select({ id: administratorInvitations.id })
    .from(administratorInvitations)
    .where(
      and(
        eq(administratorInvitations.email, email),
        eq(administratorInvitations.status, "pending"),
        gt(administratorInvitations.expiresAt, new Date()),
      ),
    )
    .limit(1);
  if (active.length) throw new Error(administrationErrors.invitationExists);

  const result = await db.insert(administratorInvitations).values({
    email,
    tokenHash: input.tokenHash,
    expiresAt: input.expiresAt,
    invitedByUserId: input.actorUserId,
  });
  const id = Number(result[0].insertId);
  await recordAdministrationAudit({
    actorUserId: input.actorUserId,
    action: "administrator.invitation.created",
    entityType: "administrator_invitation",
    entityId: id,
    eventMetadata: { email, expiresAt: input.expiresAt.toISOString() },
  });
  return { id, email, expiresAt: input.expiresAt };
}

export async function getAdministratorInvitationPreview(tokenHash: string) {
  const db = await requireDb();
  const invitation = (
    await db
      .select({
        id: administratorInvitations.id,
        email: administratorInvitations.email,
        status: administratorInvitations.status,
        expiresAt: administratorInvitations.expiresAt,
      })
      .from(administratorInvitations)
      .where(eq(administratorInvitations.tokenHash, tokenHash))
      .limit(1)
  )[0];
  if (!invitation) return null;

  let status = invitation.status;
  if (status === "pending" && invitation.expiresAt.getTime() <= Date.now()) {
    status = "expired";
    await db
      .update(administratorInvitations)
      .set({ status: "expired" })
      .where(
        and(
          eq(administratorInvitations.id, invitation.id),
          eq(administratorInvitations.status, "pending"),
        ),
      );
  }
  return {
    id: invitation.id,
    maskedEmail: maskEmail(invitation.email),
    status,
    expiresAt: invitation.expiresAt,
  };
}

export async function acceptAdministratorInvitation(input: {
  tokenHash: string;
  confirmEmail: string;
  userId: number;
  userEmail: string | null | undefined;
}) {
  const db = await requireDb();
  const now = new Date();
  const confirmEmail = normalizedEmail(input.confirmEmail);
  const userEmail = normalizedEmail(input.userEmail);

  return db.transaction(async tx => {
    const invitation = (
      await tx
        .select()
        .from(administratorInvitations)
        .where(eq(administratorInvitations.tokenHash, input.tokenHash))
        .limit(1)
    )[0];
    if (!invitation || invitation.status !== "pending") {
      throw new Error(administrationErrors.invitationInvalid);
    }
    if (invitation.expiresAt.getTime() <= now.getTime()) {
      await tx
        .update(administratorInvitations)
        .set({ status: "expired" })
        .where(eq(administratorInvitations.id, invitation.id));
      throw new Error(administrationErrors.invitationExpired);
    }
    const invitationEmail = normalizedEmail(invitation.email);
    if (!userEmail || invitationEmail !== userEmail || invitationEmail !== confirmEmail) {
      throw new Error(administrationErrors.invitationEmailMismatch);
    }

    const claimed = await tx
      .update(administratorInvitations)
      .set({
        status: "accepted",
        acceptedByUserId: input.userId,
        acceptedAt: now,
      })
      .where(
        and(
          eq(administratorInvitations.id, invitation.id),
          eq(administratorInvitations.status, "pending"),
        ),
      );
    if (Number(claimed[0].affectedRows) !== 1) {
      throw new Error(administrationErrors.invitationInvalid);
    }
    await tx.update(users).set({ role: "admin" }).where(eq(users.id, input.userId));
    await tx.insert(administrationAuditEvents).values({
      actorUserId: input.userId,
      action: "administrator.invitation.accepted",
      entityType: "administrator_invitation",
      entityId: String(invitation.id),
      targetUserId: input.userId,
      eventMetadata: { email: invitationEmail },
    });
    return { success: true as const, role: "admin" as const };
  });
}

export async function listAdministratorAccess() {
  const db = await requireDb();
  const [administrators, invitations, auditEvents] = await Promise.all([
    db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        lastSignedIn: users.lastSignedIn,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(ne(users.role, "user"))
      .orderBy(desc(users.role), users.name),
    db
      .select({
        id: administratorInvitations.id,
        email: administratorInvitations.email,
        status: administratorInvitations.status,
        expiresAt: administratorInvitations.expiresAt,
        acceptedAt: administratorInvitations.acceptedAt,
        createdAt: administratorInvitations.createdAt,
      })
      .from(administratorInvitations)
      .orderBy(desc(administratorInvitations.createdAt)),
    db
      .select({
        id: administrationAuditEvents.id,
        action: administrationAuditEvents.action,
        entityType: administrationAuditEvents.entityType,
        entityId: administrationAuditEvents.entityId,
        eventMetadata: administrationAuditEvents.eventMetadata,
        createdAt: administrationAuditEvents.createdAt,
      })
      .from(administrationAuditEvents)
      .orderBy(desc(administrationAuditEvents.createdAt))
      .limit(50),
  ]);
  return { administrators, invitations, auditEvents };
}

export async function revokeAdministratorInvitation(input: {
  invitationId: number;
  actorUserId: number;
}) {
  const db = await requireDb();
  const now = new Date();
  const result = await db
    .update(administratorInvitations)
    .set({ status: "revoked", revokedByUserId: input.actorUserId, revokedAt: now })
    .where(
      and(
        eq(administratorInvitations.id, input.invitationId),
        eq(administratorInvitations.status, "pending"),
      ),
    );
  if (Number(result[0].affectedRows) !== 1) {
    throw new Error(administrationErrors.invitationInvalid);
  }
  await recordAdministrationAudit({
    actorUserId: input.actorUserId,
    action: "administrator.invitation.revoked",
    entityType: "administrator_invitation",
    entityId: input.invitationId,
  });
  return { success: true as const };
}

export async function setAdministratorRole(input: {
  userId: number;
  role: "user" | "admin";
  actorUserId: number;
}) {
  const db = await requireDb();
  const target = (
    await db
      .select({ id: users.id, role: users.role, email: users.email })
      .from(users)
      .where(eq(users.id, input.userId))
      .limit(1)
  )[0];
  if (!target) throw new Error(administrationErrors.userNotFound);
  if (target.role === "owner") throw new Error(administrationErrors.ownerProtected);
  await db.update(users).set({ role: input.role }).where(eq(users.id, input.userId));
  await recordAdministrationAudit({
    actorUserId: input.actorUserId,
    action: `administrator.role.${input.role === "admin" ? "granted" : "revoked"}`,
    entityType: "user",
    entityId: input.userId,
    targetUserId: input.userId,
    eventMetadata: { email: target.email ?? "", role: input.role },
  });
  return { success: true as const, role: input.role };
}
