import { createHash } from "node:crypto";
import { Resend } from "resend";
import type { CohortCommunicationConfirm, CohortCommunicationDraft } from "../shared/administration";
import {
  createCommunicationSnapshot,
  getCohortMessageContext,
  getRetryContext,
  incrementRecipientRetries,
  markRecipientsAccepted,
  markRecipientsFailed,
  recomputeCommunicationStatus,
  recordRetryAudit,
} from "./cohortCommunicationDb";

const chunkSize = 100;
const domainCacheDurationMs = 5 * 60 * 1000;

export type SenderDomainVerification = {
  domain: string | null;
  verified: boolean;
  status: string;
  checkedAt: string;
  error: string | null;
};

let senderDomainCache: { checkedAt: number; result: SenderDomainVerification } | null = null;

function htmlEscape(value: string) {
  return value.replace(/[&<>'"]/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    "'": "&#39;",
    '"': "&quot;",
  })[character]!);
}

function normalizeSender(value: string | undefined) {
  return value?.trim() || null;
}

export function getResendConfiguration() {
  const apiKey = normalizeSender(process.env.RESEND_API_KEY);
  const from = normalizeSender(process.env.RESEND_FROM_EMAIL);
  const replyTo = normalizeSender(process.env.RESEND_REPLY_TO_EMAIL);
  const webhookSecret = normalizeSender(process.env.RESEND_WEBHOOK_SECRET);
  const missing = [
    !apiKey ? "RESEND_API_KEY" : null,
    !from ? "RESEND_FROM_EMAIL" : null,
    !replyTo ? "RESEND_REPLY_TO_EMAIL" : null,
  ].filter((value): value is string => Boolean(value));
  return {
    readyToSend: missing.length === 0,
    webhookReady: Boolean(webhookSecret),
    missing,
    from,
    replyTo,
    apiKey,
    webhookSecret,
  };
}

export function extractSenderDomain(from: string | null | undefined) {
  if (!from) return null;
  const address = from.match(/<([^<>\s]+@[^<>\s]+)>/)?.[1] ?? from.match(/^([^<>\s]+@[^<>\s]+)$/)?.[1];
  return address?.split("@")[1]?.toLowerCase() ?? null;
}

export async function verifyResendSenderDomain(force = false): Promise<SenderDomainVerification> {
  const now = Date.now();
  if (!force && senderDomainCache && now - senderDomainCache.checkedAt < domainCacheDurationMs) return senderDomainCache.result;
  const config = getResendConfiguration();
  const domain = extractSenderDomain(config.from);
  const checkedAt = new Date(now).toISOString();
  if (!config.apiKey || !domain) {
    const result = { domain, verified: false, status: "not_configured", checkedAt, error: "A Resend API key and valid sender address are required." };
    senderDomainCache = { checkedAt: now, result };
    return result;
  }
  try {
    const response = await new Resend(config.apiKey).domains.list({ limit: 100 });
    if (response.error || !response.data) {
      const result = { domain, verified: false, status: "provider_error", checkedAt, error: response.error?.message || "Resend did not return the domain list." };
      senderDomainCache = { checkedAt: now, result };
      return result;
    }
    const matchingDomain = response.data.data.find(item => item.name.toLowerCase() === domain);
    const result = {
      domain,
      verified: matchingDomain?.status === "verified",
      status: matchingDomain?.status ?? "not_registered",
      checkedAt,
      error: matchingDomain ? null : `The sender domain ${domain} is not registered in Resend.`,
    };
    senderDomainCache = { checkedAt: now, result };
    return result;
  } catch (error) {
    const result = { domain, verified: false, status: "provider_error", checkedAt, error: error instanceof Error ? error.message : "Resend domain verification failed." };
    senderDomainCache = { checkedAt: now, result };
    return result;
  }
}

function hashPreview(value: unknown) {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

function formatDate(value: Date | null, timeZone: string) {
  if (!value) return null;
  return new Intl.DateTimeFormat("en-US", {
    dateStyle: "long",
    timeStyle: "short",
    timeZone,
  }).format(value);
}

function buildMessageBlocks(
  draft: CohortCommunicationDraft,
  context: Awaited<ReturnType<typeof getCohortMessageContext>>,
) {
  const zoom = draft.includeZoom
    ? {
        url: context.cohort.zoomUrl,
        meetingId: context.cohort.zoomMeetingId,
        passcode: context.cohort.zoomPasscode,
      }
    : null;
  if (draft.includeZoom && !zoom?.url) throw new Error("This cohort does not have a Zoom join URL configured.");
  return { zoom, resources: context.resources };
}

export async function previewCohortCommunication(draft: CohortCommunicationDraft) {
  const context = await getCohortMessageContext(draft);
  if (!context.recipients.length) throw new Error("Add at least one active student before preparing a cohort message.");
  const blocks = buildMessageBlocks(draft, context);
  const senderDomain = await verifyResendSenderDomain();
  const previewHash = hashPreview({
    draft,
    cohort: context.cohort,
    recipients: context.recipients.map(recipient => ({ id: recipient.id, email: recipient.email })),
    resources: context.resources.map(resource => ({ id: resource.id, url: resource.url, audience: resource.audience })),
  });
  const config = getResendConfiguration();
  return {
    previewHash,
    recipientCount: context.recipients.length,
    recipients: context.recipients,
    cohort: context.cohort,
    resources: blocks.resources,
    zoom: blocks.zoom,
    subject: draft.subject,
    message: draft.message,
    configuration: {
      readyToSend: config.readyToSend && senderDomain.verified,
      webhookReady: config.webhookReady,
      missing: config.missing,
      from: config.from,
      replyTo: config.replyTo,
      senderDomain,
    },
  };
}

function renderEmail(args: {
  studentName: string;
  draft: CohortCommunicationDraft;
  preview: Awaited<ReturnType<typeof previewCohortCommunication>>;
}) {
  const messageParagraphs = args.draft.message.split(/\n{2,}/).map(paragraph => `<p style="margin:0 0 16px;line-height:1.65;color:#34435a">${htmlEscape(paragraph).replace(/\n/g, "<br>")}</p>`).join("");
  const zoomHtml = args.preview.zoom ? `<div style="margin:24px 0;padding:18px;border-left:4px solid #f47a20;background:#f6f8fb"><strong style="color:#071f49">Virtual classroom</strong><p style="margin:10px 0 0"><a href="${htmlEscape(args.preview.zoom.url!)}" style="color:#b94700;font-weight:700">Join the Zoom session</a></p>${args.preview.zoom.meetingId ? `<p style="margin:8px 0 0;color:#34435a">Meeting ID: ${htmlEscape(args.preview.zoom.meetingId)}</p>` : ""}${args.preview.zoom.passcode ? `<p style="margin:4px 0 0;color:#34435a">Passcode: ${htmlEscape(args.preview.zoom.passcode)}</p>` : ""}</div>` : "";
  const resourcesHtml = args.preview.resources.length ? `<div style="margin-top:24px"><strong style="color:#071f49">Cohort resources</strong><ul style="padding-left:20px">${args.preview.resources.map(resource => `<li style="margin:8px 0"><a href="${htmlEscape(resource.url)}" style="color:#b94700;font-weight:700">${htmlEscape(resource.title)}</a></li>`).join("")}</ul></div>` : "";
  const html = `<!doctype html><html><body style="margin:0;background:#f6f8fb;font-family:Arial,sans-serif"><div style="display:none;max-height:0;overflow:hidden">${htmlEscape(args.draft.subject)}</div><div style="max-width:680px;margin:0 auto;padding:28px 16px"><div style="background:#071f49;padding:20px 24px;color:#fff"><strong style="font-size:22px">VIBHA</strong><div style="margin-top:4px;font-size:12px;letter-spacing:.08em">THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH &amp; ADVANCEMENT</div></div><div style="background:#fff;padding:28px 24px;border:1px solid #dce3ec"><p style="margin:0 0 18px;color:#34435a">Hello ${htmlEscape(args.studentName)},</p>${messageParagraphs}${zoomHtml}${resourcesHtml}<div style="margin-top:28px;padding-top:18px;border-top:1px solid #dce3ec;color:#667085;font-size:13px;line-height:1.6">This message relates to <strong>${htmlEscape(args.preview.cohort.title)}</strong> for ${htmlEscape(args.preview.cohort.certificationTitle)}. Reply to this email if you need assistance.</div></div></div></body></html>`;
  const textParts = [
    `Hello ${args.studentName},`,
    args.draft.message,
    args.preview.zoom ? `Zoom: ${args.preview.zoom.url}${args.preview.zoom.meetingId ? `\nMeeting ID: ${args.preview.zoom.meetingId}` : ""}${args.preview.zoom.passcode ? `\nPasscode: ${args.preview.zoom.passcode}` : ""}` : null,
    args.preview.resources.length ? `Resources:\n${args.preview.resources.map(resource => `- ${resource.title}: ${resource.url}`).join("\n")}` : null,
    `This message relates to ${args.preview.cohort.title} for ${args.preview.cohort.certificationTitle}.`,
  ].filter(Boolean);
  return { html, text: textParts.join("\n\n") };
}

function splitIntoChunks<T>(items: T[], size: number) {
  const chunks: T[][] = [];
  for (let index = 0; index < items.length; index += size) chunks.push(items.slice(index, index + size));
  return chunks;
}

async function dispatchRecipients(args: {
  communicationId: number;
  baseIdempotencyKey: string;
  draft: CohortCommunicationDraft;
  preview: Awaited<ReturnType<typeof previewCohortCommunication>>;
  recipients: Array<{ id: number; studentName: string; email: string }>;
}) {
  const config = getResendConfiguration();
  const senderDomain = await verifyResendSenderDomain(true);
  if (!config.readyToSend || !config.apiKey || !config.from || !config.replyTo || !senderDomain.verified) {
    if (!senderDomain.verified) throw new Error(`Resend delivery is disabled because sender domain ${senderDomain.domain || "unknown"} is ${senderDomain.status.replace(/_/g, " ")}.`);
    throw new Error(`Resend delivery is not configured. Missing: ${config.missing.join(", ")}.`);
  }
  const resend = new Resend(config.apiKey);
  const chunks = splitIntoChunks(args.recipients, chunkSize);
  for (let chunkIndex = 0; chunkIndex < chunks.length; chunkIndex += 1) {
    const chunk = chunks[chunkIndex]!;
    const payload = chunk.map(recipient => {
      const rendered = renderEmail({ studentName: recipient.studentName, draft: args.draft, preview: args.preview });
      return {
        from: config.from!,
        to: [recipient.email],
        replyTo: config.replyTo!,
        subject: args.draft.subject,
        html: rendered.html,
        text: rendered.text,
        tags: [
          { name: "cohort_id", value: String(args.draft.cohortId) },
          { name: "communication_id", value: String(args.communicationId) },
        ],
      };
    });
    try {
      const result = await resend.batch.send(payload, {
        idempotencyKey: `${args.baseIdempotencyKey}/${chunkIndex}`.slice(0, 256),
        batchValidation: "strict",
      });
      if (result.error || !result.data) {
        await markRecipientsFailed(chunk.map(recipient => recipient.id), result.error?.name || "resend_error", result.error?.message || "Resend did not accept this batch.");
        continue;
      }
      await markRecipientsAccepted(chunk.map((recipient, index) => ({ id: recipient.id, providerMessageId: result.data.data[index]!.id })));
    } catch (error) {
      await markRecipientsFailed(
        chunk.map(recipient => recipient.id),
        "resend_network_error",
        error instanceof Error ? error.message : "The Resend request did not complete.",
      );
    }
  }
  return recomputeCommunicationStatus(args.communicationId);
}

export async function sendConfirmedCohortCommunication(input: CohortCommunicationConfirm, actorUserId: number) {
  const draft: CohortCommunicationDraft = {
    cohortId: input.cohortId,
    communicationType: input.communicationType,
    subject: input.subject,
    message: input.message,
    includeZoom: input.includeZoom,
    resourceIds: input.resourceIds,
  };
  const preview = await previewCohortCommunication(draft);
  if (preview.previewHash !== input.previewHash) throw new Error("The cohort, roster, Zoom details, or resources changed after preview. Review the recipients and confirm again.");
  if (preview.recipientCount !== input.confirmedRecipientCount) throw new Error("The cohort roster changed after preview. Review the recipients and confirm again.");
  const snapshot = await createCommunicationSnapshot({
    draft,
    previewHash: input.previewHash,
    idempotencyKey: input.idempotencyKey,
    actorUserId,
    recipients: preview.recipients,
  });
  const queued = snapshot.recipientRows.filter(recipient => recipient.status === "queued");
  if (!queued.length) return recomputeCommunicationStatus(snapshot.communication.id);
  return dispatchRecipients({
    communicationId: snapshot.communication.id,
    baseIdempotencyKey: `vibha/${input.idempotencyKey}`,
    draft,
    preview,
    recipients: queued.map(recipient => ({ id: recipient.id, studentName: recipient.studentName, email: recipient.email })),
  });
}

export async function retryFailedCohortRecipients(
  input: { communicationId: number; recipientIds: number[] },
  actorUserId: number,
) {
  const context = await getRetryContext(input.communicationId, input.recipientIds);
  const draft: CohortCommunicationDraft = {
    cohortId: context.communication.cohortId,
    communicationType: context.communication.communicationType,
    subject: context.communication.subject,
    message: context.communication.message,
    includeZoom: context.communication.includeZoom,
    resourceIds: context.communication.resourceIds,
  };
  const preview = await previewCohortCommunication(draft);
  await incrementRecipientRetries(context.recipients.map(recipient => recipient.id));
  await recordRetryAudit(context.communication.id, context.recipients.length, actorUserId);
  const retryNumber = Math.max(...context.recipients.map(recipient => recipient.retryCount + 1));
  const recipientHash = hashPreview(context.recipients.map(recipient => recipient.id).sort((a, b) => a - b)).slice(0, 16);
  return dispatchRecipients({
    communicationId: context.communication.id,
    baseIdempotencyKey: `vibha-retry/${context.communication.id}/${retryNumber}/${recipientHash}`,
    draft,
    preview,
    recipients: context.recipients.map(recipient => ({ id: recipient.id, studentName: recipient.studentName, email: recipient.email })),
  });
}
