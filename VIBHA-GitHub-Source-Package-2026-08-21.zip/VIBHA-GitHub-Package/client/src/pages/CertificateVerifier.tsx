import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { usePageMeta } from "@/hooks/usePageMeta";
import { trpc } from "@/lib/trpc";
import { BadgeCheck, CircleAlert, Loader2, SearchCheck, ShieldCheck } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";

function formatDate(value: Date) {
  return new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" }).format(new Date(value));
}

export default function CertificateVerifier() {
  usePageMeta("Verify a VIBHA Certificate", "Verify the validity of a VIBHA issued certificate using its printed certificate number.");
  const initialReference = useMemo(() => new URLSearchParams(window.location.search).get("reference")?.toUpperCase() ?? "", []);
  const initialToken = useMemo(() => new URLSearchParams(window.location.search).get("token") ?? "", []);
  const [reference, setReference] = useState(initialReference);
  const [token, setToken] = useState(initialToken);
  const [submitted, setSubmitted] = useState(Boolean(initialReference));
  const [message, setMessage] = useState("");
  const input = useMemo(() => ({ reference: reference.trim().toUpperCase(), token: token.trim() || undefined }), [reference, token]);
  const verification = trpc.certificateVerification.verify.useQuery(input, { enabled: submitted && Boolean(input.reference), retry: false });

  function verify(event: FormEvent) {
    event.preventDefault();
    if (!reference.trim()) {
      setMessage("Enter the certificate number printed on the document.");
      document.getElementById("certificate-reference")?.focus();
      return;
    }
    setMessage("");
    setSubmitted(true);
    if (verification.data || verification.error) void verification.refetch();
  }

  const record = verification.data;

  return (
    <PublicLayout>
      <PageHero eyebrow="Certificate verification" title="Confirm a VIBHA-issued certificate." description="Outside agencies, employers, and partners can verify the current status of a certificate using its printed VIBHA certificate number or the QR code on the document." breadcrumbs={[{ label: "Certificate verification" }]} />
      <main className="bg-[#f6f8fb] py-16 sm:py-20">
        <div className="container grid gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:items-start">
          <section className="rounded-2xl bg-[#071f49] p-7 text-white shadow-institutional sm:p-9">
            <ShieldCheck className="h-9 w-9 text-[#ff9a52]" />
            <h1 className="mt-5 text-3xl font-bold">Verify a certificate record</h1>
            <p className="mt-4 leading-7 text-slate-300">Enter the certificate number exactly as printed. A QR-code scan fills the secure reference and verification token automatically.</p>
            <form className="mt-7 space-y-5" onSubmit={verify} noValidate>
              <div><Label htmlFor="certificate-reference" className="text-white">Certificate number</Label><Input id="certificate-reference" value={reference} onChange={event => { setReference(event.target.value.toUpperCase()); setSubmitted(false); }} className="mt-2 border-white/30 bg-white text-[#071f49]" placeholder="VIBHA-2026-XXXXXXXXXXXX" aria-describedby="certificate-reference-help" /><p id="certificate-reference-help" className="mt-2 text-xs leading-5 text-slate-300">Printed in the lower-left area of an issued VIBHA certificate.</p></div>
              <input type="hidden" value={token} onChange={() => undefined} />
              {message ? <p role="alert" className="rounded-lg border border-rose-200/40 bg-rose-950/30 p-3 text-sm text-rose-100">{message}</p> : null}
              <Button type="submit" className="min-h-12 w-full bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><SearchCheck className="mr-2 h-4 w-4" />Verify certificate</Button>
            </form>
          </section>

          <section aria-live="polite" className="min-h-[300px] rounded-2xl border border-slate-200 bg-white p-7 shadow-sm sm:p-9">
            {!submitted ? <div className="flex min-h-[230px] flex-col items-center justify-center text-center"><SearchCheck className="h-10 w-10 text-slate-400" /><h2 className="mt-4 text-2xl font-bold text-[#071f49]">Ready to verify</h2><p className="mt-2 max-w-md text-sm leading-6 text-slate-600">Verification returns the certificate’s current status and only the credential facts necessary for an external agency to confirm it.</p></div> : null}
            {submitted && verification.isLoading ? <div role="status" className="flex min-h-[230px] flex-col items-center justify-center text-center"><Loader2 className="h-9 w-9 animate-spin text-[#173b70]" /><p className="mt-4 text-sm font-semibold text-[#071f49]">Checking the VIBHA certificate repository…</p></div> : null}
            {submitted && verification.error ? <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-6 text-rose-900"><CircleAlert className="h-7 w-7" /><h2 className="mt-3 text-xl font-bold">Certificate could not be verified</h2><p className="mt-2 text-sm leading-6">{verification.error.message}</p></div> : null}
            {submitted && !verification.isLoading && !verification.error && !record ? <div className="rounded-xl border border-amber-200 bg-amber-50 p-6 text-amber-950"><CircleAlert className="h-7 w-7" /><h2 className="mt-3 text-xl font-bold">No matching certificate record found</h2><p className="mt-2 text-sm leading-6">Check the certificate number and try again. If you need assistance, contact VIBHA using the information on the certificate or through the VIBHA inquiry center.</p></div> : null}
            {submitted && record?.status === "issued" ? <div><div className="flex flex-wrap items-center gap-3"><BadgeCheck className="h-10 w-10 text-emerald-600" /><div><p className="text-sm font-bold uppercase tracking-[0.14em] text-emerald-700">Verified as valid</p><h2 className="mt-1 text-2xl font-bold text-[#071f49]">Active VIBHA certificate</h2></div></div><dl className="mt-7 divide-y divide-slate-200 rounded-xl border border-slate-200"><div className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]"><dt className="text-sm font-semibold text-slate-500">Certificate number</dt><dd className="font-mono text-sm font-bold text-[#071f49]">{record.certificateNumber}</dd></div><div className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]"><dt className="text-sm font-semibold text-slate-500">Certificate holder</dt><dd className="font-semibold text-[#071f49]">{record.recipientName}</dd></div><div className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]"><dt className="text-sm font-semibold text-slate-500">Credential</dt><dd className="text-[#071f49]">{record.credentialTitle}</dd></div><div className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]"><dt className="text-sm font-semibold text-slate-500">Cohort</dt><dd className="text-[#071f49]">{record.cohortTitle}</dd></div><div className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]"><dt className="text-sm font-semibold text-slate-500">Issued</dt><dd className="text-[#071f49]">{formatDate(record.issuedAt)}</dd></div>{record.ceuValue ? <div className="grid gap-1 p-4 sm:grid-cols-[180px_1fr]"><dt className="text-sm font-semibold text-slate-500">CEUs</dt><dd className="text-[#071f49]">{record.ceuValue}</dd></div> : null}</dl><p className="mt-6 text-xs leading-5 text-slate-500">This verification confirms a VIBHA-issued completion certificate. It does not independently establish professional licensure, governmental endorsement, or an employer’s credentialing determination.</p></div> : null}
            {submitted && record && record.status !== "issued" ? <div className="rounded-xl border border-rose-200 bg-rose-50 p-6 text-rose-950"><CircleAlert className="h-8 w-8" /><p className="mt-4 text-sm font-bold uppercase tracking-[0.14em]">Certificate not currently valid</p><h2 className="mt-2 text-2xl font-bold">This certificate has been {record.status}.</h2><p className="mt-3 text-sm leading-6">Certificate reference <span className="font-mono font-bold">{record.certificateNumber}</span> is retained in the VIBHA repository, but it should not be accepted as an active certificate.</p></div> : null}
          </section>
        </div>
      </main>
    </PublicLayout>
  );
}
