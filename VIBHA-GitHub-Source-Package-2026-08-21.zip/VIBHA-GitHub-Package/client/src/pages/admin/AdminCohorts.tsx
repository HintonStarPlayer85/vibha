import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { CalendarRange, FilePenLine, Loader2, Plus, Search, UsersRound } from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "wouter";

const cohortStatuses = ["draft", "planned", "active", "completed", "cancelled", "archived"] as const;

function formatDate(value: Date | null) {
  return value ? new Date(value).toLocaleDateString(undefined, { month: "short", day: "numeric", year: "numeric" }) : "Not scheduled";
}

function CohortIndex() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const input = useMemo(() => ({ q: query.trim() || undefined, status: status === "all" ? undefined : status as typeof cohortStatuses[number] }), [query, status]);
  const cohorts = trpc.adminCohorts.list.useQuery(input);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="text-sm font-bold uppercase tracking-[0.16em] text-[#b94700]">Cohort CMS</p><h1 className="mt-2 text-4xl font-bold text-[#071f49]">Cohort operations</h1><p className="mt-3 max-w-3xl leading-7 text-slate-600">Coordinate programs, faculty, student rosters, virtual-class details, learning resources, schedules, and cohort communications.</p></div>
        <Button asChild className="shrink-0 bg-[#071f49] font-bold text-white hover:bg-[#173b70]"><Link href="/admin/cohorts/new"><Plus className="mr-2 h-4 w-4" />Create cohort</Link></Button>
      </div>
      <div className="mt-8 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-[1fr_220px]">
        <div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input aria-label="Search cohorts" value={query} onChange={event => setQuery(event.target.value)} placeholder="Search cohort, program, or instructor" className="pl-10" /></div>
        <select aria-label="Filter cohorts by status" value={status} onChange={event => setStatus(event.target.value)} className="rounded-md border border-input bg-white px-3 text-sm"><option value="all">All statuses</option>{cohortStatuses.map(value => <option key={value} value={value}>{value.replace("_", " ")}</option>)}</select>
      </div>
      {cohorts.isLoading ? <div role="status" className="mt-8 flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-8 text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Loading cohorts…</div> : null}
      {cohorts.error ? <div role="alert" className="mt-8 rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{cohorts.error.message}</div> : null}
      {cohorts.data ? <div className="mt-8 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-200 px-5 py-4 text-sm text-slate-600"><strong className="text-[#071f49]">{cohorts.data.length}</strong> cohort{cohorts.data.length === 1 ? "" : "s"}</div><div className="divide-y divide-slate-200">{cohorts.data.map(cohort => <article key={cohort.id} className="grid gap-5 p-5 xl:grid-cols-[1.2fr_1fr_190px_180px_110px] xl:items-center"><div><div className="flex flex-wrap items-center gap-2"><h2 className="font-sans text-lg font-bold text-[#071f49]">{cohort.title}</h2><Badge className={cohort.status === "active" ? "bg-emerald-100 text-emerald-900" : cohort.status === "cancelled" ? "bg-rose-100 text-rose-900" : "bg-slate-200 text-slate-700"}>{cohort.status}</Badge></div><p className="mt-1 text-sm font-semibold text-slate-700">{cohort.certificationTitle}</p></div><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Instructor</p><p className="mt-1 text-sm text-slate-700">{cohort.instructorName || "Not assigned"}</p></div><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Schedule</p><p className="mt-1 text-sm text-slate-700">{formatDate(cohort.startAt)}{cohort.endAt ? ` – ${formatDate(cohort.endAt)}` : ""}</p></div><div className="flex gap-4 text-sm"><span><strong className="block text-[#071f49]">{cohort.studentCount}</strong> students</span><span><strong className="block text-[#071f49]">{cohort.communicationCount}</strong> sends</span><span><strong className="block text-[#071f49]">{cohort.latestCommunicationStatus?.replace("_", " ") || "none"}</strong> latest status</span></div><Button asChild size="sm" variant="outline" className="border-slate-300 bg-white"><Link href={`/admin/cohorts/${cohort.id}/edit`}><FilePenLine className="mr-1.5 h-4 w-4" />Manage</Link></Button></article>)}</div>{cohorts.data.length === 0 ? <div className="p-10 text-center"><UsersRound className="mx-auto h-9 w-9 text-[#b94700]" /><h2 className="mt-3 text-2xl font-bold text-[#071f49]">No cohorts match this view.</h2><p className="mt-2 text-sm text-slate-600">Change the filters or create the first cohort.</p></div> : null}</div> : null}
      <div className="mt-8 rounded-xl border border-slate-200 bg-white p-5 text-sm leading-6 text-slate-600"><CalendarRange className="h-5 w-5 text-[#b94700]" /><p className="mt-2"><strong className="text-[#071f49]">Operational boundary:</strong> Cohort records are educational operations data. Do not upload clinical records, protected health information, or unnecessary sensitive personal information.</p></div>
    </div>
  );
}

export default function AdminCohorts() {
  return <DashboardLayout><CohortIndex /></DashboardLayout>;
}
