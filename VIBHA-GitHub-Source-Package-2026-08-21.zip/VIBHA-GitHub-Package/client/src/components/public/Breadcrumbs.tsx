import { ChevronRight, Home } from "lucide-react";
import { Link } from "wouter";

export type BreadcrumbItem = { label: string; href?: string };

export function Breadcrumbs({ items, inverse = false }: { items: BreadcrumbItem[]; inverse?: boolean }) {
  return (
    <nav aria-label="Breadcrumb" className={inverse ? "text-slate-300" : "text-slate-600"}>
      <ol className="flex flex-wrap items-center gap-1.5 text-sm">
        <li>
          <Link href="/" aria-label="Home" className="rounded-sm hover:underline">
            <Home className="h-4 w-4" />
          </Link>
        </li>
        {items.map((item, index) => (
          <li key={`${item.label}-${index}`} className="flex items-center gap-1.5">
            <ChevronRight className="h-3.5 w-3.5 opacity-65" aria-hidden="true" />
            {item.href ? (
              <Link href={item.href} className="rounded-sm hover:underline">{item.label}</Link>
            ) : (
              <span aria-current="page" className={inverse ? "font-semibold text-white" : "font-semibold text-[#071f49]"}>
                {item.label}
              </span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

