export type CatalogUrlState = {
  q?: string;
  category?: string;
  format?: "virtual-live" | "hybrid" | "evening" | "weekend" | "onsite";
  ceu?: "not-listed" | "0.1-2" | "2.1-5" | "5-plus";
  cost?: "under-1000" | "1000-1499" | "1500-1999" | "2000-plus";
  page: number;
};

const allowed = {
  format: new Set(["virtual-live", "hybrid", "evening", "weekend", "onsite"]),
  ceu: new Set(["not-listed", "0.1-2", "2.1-5", "5-plus"]),
  cost: new Set(["under-1000", "1000-1499", "1500-1999", "2000-plus"]),
};

export function parseCatalogSearch(search: string): CatalogUrlState {
  const params = new URLSearchParams(search.startsWith("?") ? search.slice(1) : search);
  const pageValue = Number(params.get("page"));
  const state: CatalogUrlState = {
    page: Number.isInteger(pageValue) && pageValue > 0 ? pageValue : 1,
  };
  const q = params.get("q")?.trim();
  const category = params.get("category")?.trim();
  const format = params.get("format") ?? "";
  const ceu = params.get("ceu") ?? "";
  const cost = params.get("cost") ?? "";
  if (q) state.q = q.slice(0, 120);
  if (category && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(category)) state.category = category;
  if (allowed.format.has(format)) state.format = format as CatalogUrlState["format"];
  if (allowed.ceu.has(ceu)) state.ceu = ceu as CatalogUrlState["ceu"];
  if (allowed.cost.has(cost)) state.cost = cost as CatalogUrlState["cost"];
  return state;
}

export function serializeCatalogSearch(state: CatalogUrlState) {
  const params = new URLSearchParams();
  if (state.q) params.set("q", state.q);
  if (state.category) params.set("category", state.category);
  if (state.format) params.set("format", state.format);
  if (state.ceu) params.set("ceu", state.ceu);
  if (state.cost) params.set("cost", state.cost);
  if (state.page > 1) params.set("page", String(state.page));
  const query = params.toString();
  return query ? `?${query}` : "";
}

export function catalogReturnPath() {
  return `/certifications${window.location.search}`;
}

