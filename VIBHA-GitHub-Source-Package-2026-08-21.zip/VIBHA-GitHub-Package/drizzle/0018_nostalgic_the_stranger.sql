ALTER TABLE `certificate_preview_acknowledgements` ADD `acknowledgementNotes` text;--> statement-breakpoint
ALTER TABLE `certificate_preview_acknowledgements` ADD `acknowledgementNotes` text;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `previewAcknowledgementExpirationMinutes` int DEFAULT 30 NOT NULL;
