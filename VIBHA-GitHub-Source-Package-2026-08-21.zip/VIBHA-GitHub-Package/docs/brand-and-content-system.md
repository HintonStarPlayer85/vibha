# VIBHA Brand and Content System

## Institutional Positioning

VIBHA must read and behave like an established workforce institute or university continuing education division. The public experience prioritizes **institutional authority, structured discovery, operational credibility, and accessibility**. It must not use course-marketplace patterns, startup-style promotional language, unsupported outcome guarantees, or simulated portal functionality.

> **Primary positioning:** Developing the workforce behind behavioral health excellence.

The public conversion hierarchy is led by **Request Program Information**, followed by **Schedule an Agency Consultation**, **Browse Certifications**, and institutional trust-building content. Each page will maintain one visually dominant primary action.

## Brand Tokens

The supplied 2026 Program Guide establishes deep navy and vivid orange as the core identity. The website will interpret the requested “gold” direction through VIBHA’s approved orange-gold accent rather than introducing a separate yellow palette.

| Token | Value | Operational Use |
|---|---:|---|
| VIBHA Navy 950 | `#041634` | Footer, high-authority surfaces, deep contrast |
| VIBHA Navy 900 | `#071F49` | Primary navigation, headings, hero surfaces |
| VIBHA Navy 700 | `#173B70` | Secondary headings, links, supporting UI |
| VIBHA Orange-Gold | `#F47A20` | Primary actions, highlights, active states |
| VIBHA Orange Dark | `#B94700` | Small orange text and accessible links on white |
| White | `#FFFFFF` | Primary surfaces and reversed text |
| Neutral 50 | `#F6F8FB` | Section separation and filter surfaces |
| Neutral 200 | `#DCE3EC` | Borders and dividers |
| Neutral 700 | `#34435A` | Body copy |
| Success | `#18724A` | Confirmation states only |
| Warning | `#9A5D00` | Warning states only |
| Error | `#B42318` | Validation and error states only |

Normal-size text will not use the orange-gold token on white unless the contrast ratio is verified. Orange-gold buttons will use navy text; reversed white text will be reserved for navy surfaces.

## Typography and Layout

**Inter** will govern navigation, interface labels, filters, forms, facts, and body text. **Source Serif 4** will govern page titles and selected institutional statements. The maximum content width is 1360 pixels, with a 12-column desktop grid and fluid tablet and mobile layouts. Spacing follows an 8-pixel base rhythm, cards use restrained borders and radii, and motion remains under 300 milliseconds while respecting reduced-motion preferences.

## Source-of-Truth Content

The 2026 Program Guide is the approved source for VIBHA’s mission, vision, leadership identification, delivery formats, categories, certification names, durations, tuition, prerequisites, and program descriptions. The website specification governs architecture, accessibility, page requirements, conversion hierarchy, and quality controls. When the OCR extraction is ambiguous, the website will omit or generalize the uncertain field rather than publish an inferred claim.

| Content Area | Approved Direction |
|---|---|
| Mission | Develop and advance a competent, diverse, and sustainable behavioral health workforce through education, certification, and collaboration that improves lives and strengthens communities. |
| Vision | A Virginia where every community has access to high-quality behavioral health services delivered by a strong, prepared, and supported workforce. |
| Leadership | Jacquese Hinton, MSHRM, QMHP; Founder and Director of Institutional Strategy. |
| Delivery | Virtual live instruction, hybrid learning, weekend cohorts, evening cohorts, workforce bootcamps, executive intensives, and agency contract training. |
| Institutional pillars | People, standards, impact, and community. |
| Agency positioning | Organizational capability development, not bulk course purchasing. |

## Credential and Accreditation Guardrails

VIBHA programs will be described as **workforce education and institutional certifications**. The site will not state or imply that a certificate is a Virginia professional license, state-issued credential, university degree, governmental endorsement, or third-party accreditation unless documentation is later supplied and approved.

The About page will include an **Institutional Standing** section rather than an unsupported accreditation badge. It will explain that program applicability, employer recognition, continuing education acceptance, and professional eligibility can vary by role, employer, payer, and credentialing body; prospective learners should verify requirements before enrollment.

## Content Governance Rules

Certification records are the authoritative content layer for catalog cards, featured listings, detail pages, related-program modules, program inquiry routing, and CMS editing. Deactivation is non-destructive. A deactivated record remains available to administrators but is excluded from public catalog and detail queries. Stable slugs cannot collide, and public content may only render records with published status.

No testimonials, ratings, employment promises, salary claims, unsupported accreditation language, dead controls, or placeholder downloads will be introduced. All displayed calls to action must lead to a working route, form, or authenticated workflow.

## Approved Asset Inventory

| Asset | Storage Path | Use |
|---|---|---|
| 2026 institutional banner | `/manus-storage/vibha-2026-institutional-banner_63a8665f.png` | Homepage institutional artwork with explicit dimensions and responsive cropping |
| VIBHA navigation brand treatment | Text and reusable brand-mark component | Header and footer; avoids rendering the entire banner as a logo |

