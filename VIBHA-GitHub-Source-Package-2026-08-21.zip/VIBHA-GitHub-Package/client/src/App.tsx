import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BackToTop } from "@/components/interaction/BackToTop";
import { MotionController } from "@/components/interaction/MotionController";
import { lazy, Suspense } from "react";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

const About = lazy(() => import("./pages/About"));
const Leadership = lazy(() => import("./pages/Leadership"));
const Accessibility = lazy(() => import("./pages/Accessibility"));
const Contact = lazy(() => import("./pages/Contact"));
const CertificationDetail = lazy(() => import("./pages/CertificationDetail"));
const Certifications = lazy(() => import("./pages/Certifications"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Programs = lazy(() => import("./pages/Programs"));
const NotFound = lazy(() => import("./pages/NotFound"));
const AdminCertifications = lazy(() => import("./pages/admin/AdminCertifications"));
const CertificationEditor = lazy(() => import("./pages/admin/CertificationEditor"));
const AdminAccess = lazy(() => import("./pages/admin/AdminAccess"));
const AdminRegistration = lazy(() => import("./pages/admin/AdminRegistration"));
const AdminAccessManagement = lazy(() => import("./pages/admin/AdminAccessManagement"));
const AdminInstructors = lazy(() => import("./pages/admin/AdminInstructors"));
const InstructorEditor = lazy(() => import("./pages/admin/InstructorEditor"));
const AdminCohorts = lazy(() => import("./pages/admin/AdminCohorts"));
const CohortEditor = lazy(() => import("./pages/admin/CohortEditor"));
const CohortCommunications = lazy(() => import("./pages/admin/CohortCommunications"));
const SiteContentEditor = lazy(() => import("./pages/admin/SiteContentEditor"));
const CertificateRepository = lazy(() => import("./pages/admin/CertificateRepository"));
const CertificateTemplateSettings = lazy(() => import("./pages/admin/CertificateTemplateSettings"));
const CertificateApprovals = lazy(() => import("./pages/admin/CertificateApprovals"));
const CertificateVerifier = lazy(() => import("./pages/CertificateVerifier"));
const OnlineLearning = lazy(() => import("./pages/admin/OnlineLearning"));
const OnlineLearningEditor = lazy(() => import("./pages/admin/OnlineLearningEditor"));
const LearnCourse = lazy(() => import("./pages/LearnCourse"));
const LearnerDashboard = lazy(() => import("./pages/LearnerDashboard"));
const CourseInvitations = lazy(() => import("./pages/admin/CourseInvitations"));
const CourseInvitationAccept = lazy(() => import("./pages/CourseInvitationAccept"));

function PageLoading() {
  return (
    <div role="status" aria-live="polite" className="flex min-h-[60vh] items-center justify-center bg-[#f6f8fb]">
      <div className="text-center">
        <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-[#071f49]/20 border-t-[#f47a20] motion-reduce:animate-none" />
        <p className="mt-4 text-sm font-semibold text-[#071f49]">Loading VIBHA content…</p>
      </div>
    </div>
  );
}

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Suspense fallback={<PageLoading />}>
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/certifications"} component={Certifications} />
        <Route path={"/certifications/:slug"} component={CertificationDetail} />
        <Route path={"/programs"} component={Programs} />
        <Route path={"/learn/invite/:token"} component={CourseInvitationAccept} />
        <Route path={"/learn/:slug"} component={LearnCourse} />
        <Route path={"/learn"} component={LearnerDashboard} />
        <Route path={"/about/leadership"} component={Leadership} />
        <Route path={"/about"} component={About} />
        <Route path={"/contact"} component={Contact} />
        <Route path={"/verify-certificate"} component={CertificateVerifier} />
        <Route path={"/privacy"} component={Privacy} />
        <Route path={"/accessibility"} component={Accessibility} />
        <Route path={"/admin/access"} component={AdminAccess} />
        <Route path={"/admin/register"} component={AdminRegistration} />
        <Route path={"/admin/access-management"} component={AdminAccessManagement} />
        <Route path={"/admin/instructors"} component={AdminInstructors} />
        <Route path={"/admin/instructors/new"} component={InstructorEditor} />
        <Route path={"/admin/instructors/:id/edit"} component={InstructorEditor} />
        <Route path={"/admin/cohorts"} component={AdminCohorts} />
        <Route path={"/admin/cohorts/new"} component={CohortEditor} />
        <Route path={"/admin/cohorts/:id/communications"} component={CohortCommunications} />
        <Route path={"/admin/cohorts/:id/edit"} component={CohortEditor} />
        <Route path={"/admin/certificates/template"} component={CertificateTemplateSettings} />
        <Route path={"/admin/certificates/approvals"} component={CertificateApprovals} />
        <Route path={"/admin/certificates"} component={CertificateRepository} />
        <Route path={"/admin/online-learning"} component={OnlineLearning} />
        <Route path={"/admin/online-learning/:id/invitations"} component={CourseInvitations} />
        <Route path={"/admin/online-learning/:id"} component={OnlineLearningEditor} />
        <Route path={"/admin/content"} component={SiteContentEditor} />
        <Route path={"/admin/certifications"} component={AdminCertifications} />
        <Route path={"/admin/certifications/new"} component={CertificationEditor} />
        <Route path={"/admin/certifications/:id/edit"} component={CertificationEditor} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <span id="page-top" tabIndex={-1} className="sr-only">Top of page</span>
          <MotionController />
          <Router />
          <BackToTop />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
