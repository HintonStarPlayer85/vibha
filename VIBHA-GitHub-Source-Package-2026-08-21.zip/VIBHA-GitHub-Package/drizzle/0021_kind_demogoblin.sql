ALTER TABLE `certificate_program_profiles` ADD `previewReminderEmailSubject` varchar(240);--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `previewReminderEmailBody` text;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `approvalEscalationEmailSubject` varchar(240);--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `approvalEscalationEmailBody` text;