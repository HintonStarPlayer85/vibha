import {
  boolean,
  decimal,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  primaryKey,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "owner"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const certificationCategories = mysqlTable(
  "certification_categories",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 160 }).notNull(),
    slug: varchar("slug", { length: 180 }).notNull(),
    shortDescription: text("shortDescription").notNull(),
    description: text("description"),
    iconKey: varchar("iconKey", { length: 64 }).default("graduation-cap").notNull(),
    displayOrder: int("displayOrder").default(0).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    slugUnique: uniqueIndex("category_slug_unique").on(table.slug),
    activeOrderIdx: index("category_active_order_idx").on(table.isActive, table.displayOrder),
  }),
);

export const certifications = mysqlTable(
  "certifications",
  {
    id: int("id").autoincrement().primaryKey(),
    title: varchar("title", { length: 220 }).notNull(),
    shortTitle: varchar("shortTitle", { length: 120 }),
    slug: varchar("slug", { length: 240 }).notNull(),
    category: int("categoryId")
      .notNull()
      .references(() => certificationCategories.id),
    description: text("description").notNull(),
    summary: text("summary").notNull(),
    valueStatement: text("valueStatement"),
    objectives: json("objectives").$type<string[]>().notNull(),
    curriculumTopics: json("curriculumTopics").$type<string[]>().notNull(),
    idealAudience: json("idealAudience").$type<string[]>().notNull(),
    eligibilityRequirements: json("eligibilityRequirements").$type<string[]>().notNull(),
    prerequisites: text("prerequisites").notNull(),
    format: varchar("format", { length: 80 }).notNull(),
    deliveryLocation: varchar("deliveryLocation", { length: 180 }).default("Online").notNull(),
    deliveryMethods: json("deliveryMethods").$type<string[]>().notNull(),
    schedule: text("schedule").notNull(),
    duration: varchar("duration", { length: 80 }).notNull(),
    ceus: decimal("ceus", { precision: 5, scale: 2 }).default("0.00").notNull(),
    cost: int("costCents").notNull(),
    costDisplay: varchar("costDisplay", { length: 80 }).notNull(),
    level: varchar("level", { length: 60 }).notNull(),
    careerRelevance: text("careerRelevance"),
    enrollmentUrl: varchar("enrollmentUrl", { length: 500 }),
    inquiryType: varchar("inquiryType", { length: 80 }).default("program-information").notNull(),
    status: mysqlEnum("status", ["draft", "published", "coming_soon", "inactive", "archived"])
      .default("draft")
      .notNull(),
    isFeatured: boolean("isFeatured").default(false).notNull(),
    displayOrder: int("displayOrder").default(0).notNull(),
    seoTitle: varchar("seoTitle", { length: 180 }),
    seoDescription: varchar("seoDescription", { length: 320 }),
    publishedAt: timestamp("publishedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    slugUnique: uniqueIndex("certification_slug_unique").on(table.slug),
    statusCategoryIdx: index("certification_status_category_idx").on(table.status, table.category),
    featuredOrderIdx: index("certification_featured_order_idx").on(
      table.status,
      table.isFeatured,
      table.displayOrder,
    ),
    costIdx: index("certification_cost_idx").on(table.cost),
    ceusIdx: index("certification_ceus_idx").on(table.ceus),
  }),
);

export const instructors = mysqlTable(
  "instructors",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 180 }).notNull(),
    slug: varchar("slug", { length: 200 }).notNull(),
    email: varchar("email", { length: 320 }),
    credentials: varchar("credentials", { length: 220 }),
    title: varchar("title", { length: 220 }),
    biography: text("biography"),
    expertise: json("expertise").$type<string[]>(),
    photoUrl: varchar("photoUrl", { length: 600 }),
    signatureStorageKey: varchar("signatureStorageKey", { length: 800 }),
    signatureUrl: varchar("signatureUrl", { length: 1000 }),
    signatureFileName: varchar("signatureFileName", { length: 320 }),
    signatureMimeType: varchar("signatureMimeType", { length: 120 }),
    signatureCrop: json("signatureCrop").$type<{ x: number; y: number; size: number; zoom: number } | null>(),
    signatureUploadedAt: timestamp("signatureUploadedAt"),
    signatureUpdatedByUserId: int("signatureUpdatedByUserId").references(() => users.id, { onDelete: "set null" }),
    isActive: boolean("isActive").default(true).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    slugUnique: uniqueIndex("instructor_slug_unique").on(table.slug),
    emailUnique: uniqueIndex("instructor_email_unique").on(table.email),
  }),
);

export const certificationInstructors = mysqlTable(
  "certification_instructors",
  {
    certificationId: int("certificationId")
      .notNull()
      .references(() => certifications.id, { onDelete: "cascade" }),
    instructorId: int("instructorId")
      .notNull()
      .references(() => instructors.id, { onDelete: "cascade" }),
    displayOrder: int("displayOrder").default(0).notNull(),
  },
  table => ({
    pk: primaryKey({ columns: [table.certificationId, table.instructorId] }),
    instructorIdx: index("certification_instructor_lookup_idx").on(table.instructorId),
  }),
);

export const inquiries = mysqlTable(
  "inquiries",
  {
    id: int("id").autoincrement().primaryKey(),
    inquiryType: mysqlEnum("inquiryType", ["program", "agency", "general"])
      .default("general")
      .notNull(),
    certificationId: int("certificationId").references(() => certifications.id, {
      onDelete: "set null",
    }),
    programRoute: varchar("programRoute", { length: 180 }),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    phone: varchar("phone", { length: 40 }),
    organization: varchar("organization", { length: 220 }),
    organizationType: varchar("organizationType", { length: 120 }),
    workforceSize: varchar("workforceSize", { length: 80 }),
    priority: varchar("priority", { length: 180 }),
    timeline: varchar("timeline", { length: 120 }),
    message: text("message").notNull(),
    consent: boolean("consent").default(false).notNull(),
    sourcePath: varchar("sourcePath", { length: 500 }),
    status: mysqlEnum("status", ["new", "in_review", "responded", "closed"])
      .default("new")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    statusCreatedIdx: index("inquiry_status_created_idx").on(table.status, table.createdAt),
    certificationIdx: index("inquiry_certification_idx").on(table.certificationId),
    emailIdx: index("inquiry_email_idx").on(table.email),
  }),
);

export const administratorInvitations = mysqlTable(
  "administrator_invitations",
  {
    id: int("id").autoincrement().primaryKey(),
    email: varchar("email", { length: 320 }).notNull(),
    tokenHash: varchar("tokenHash", { length: 64 }).notNull(),
    invitedRole: mysqlEnum("invitedRole", ["admin"]).default("admin").notNull(),
    status: mysqlEnum("status", ["pending", "accepted", "revoked", "expired"])
      .default("pending")
      .notNull(),
    invitedByUserId: int("invitedByUserId")
      .notNull()
      .references(() => users.id),
    acceptedByUserId: int("acceptedByUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    revokedByUserId: int("revokedByUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    expiresAt: timestamp("expiresAt").notNull(),
    acceptedAt: timestamp("acceptedAt"),
    revokedAt: timestamp("revokedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    tokenUnique: uniqueIndex("administrator_invitation_token_unique").on(table.tokenHash),
    emailStatusIdx: index("administrator_invitation_email_status_idx").on(
      table.email,
      table.status,
    ),
    expiryIdx: index("administrator_invitation_expiry_idx").on(table.status, table.expiresAt),
  }),
);

export const cohorts = mysqlTable(
  "cohorts",
  {
    id: int("id").autoincrement().primaryKey(),
    title: varchar("title", { length: 220 }).notNull(),
    slug: varchar("slug", { length: 240 }).notNull(),
    certificationId: int("certificationId")
      .notNull()
      .references(() => certifications.id),
    instructorId: int("instructorId").references(() => instructors.id, {
      onDelete: "set null",
    }),
    certificateSignatoryInstructorId: int("certificateSignatoryInstructorId").references(() => instructors.id, {
      onDelete: "set null",
    }),
    status: mysqlEnum("status", ["draft", "planned", "active", "completed", "cancelled", "archived"])
      .default("draft")
      .notNull(),
    startAt: timestamp("startAt"),
    endAt: timestamp("endAt"),
    timeZone: varchar("timeZone", { length: 80 }).default("America/New_York").notNull(),
    scheduleSummary: text("scheduleSummary"),
    zoomUrl: varchar("zoomUrl", { length: 1000 }),
    zoomMeetingId: varchar("zoomMeetingId", { length: 120 }),
    zoomPasscode: varchar("zoomPasscode", { length: 120 }),
    administratorNotes: text("administratorNotes"),
    createdByUserId: int("createdByUserId")
      .notNull()
      .references(() => users.id),
    updatedByUserId: int("updatedByUserId")
      .notNull()
      .references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    slugUnique: uniqueIndex("cohort_slug_unique").on(table.slug),
    statusStartIdx: index("cohort_status_start_idx").on(table.status, table.startAt),
    certificationIdx: index("cohort_certification_idx").on(table.certificationId),
    instructorIdx: index("cohort_instructor_idx").on(table.instructorId),
    certificateSignatoryInstructorIdx: index("cohort_certificate_signatory_instructor_idx").on(table.certificateSignatoryInstructorId),
  }),
);

export const cohortStudents = mysqlTable(
  "cohort_students",
  {
    id: int("id").autoincrement().primaryKey(),
    cohortId: int("cohortId")
      .notNull()
      .references(() => cohorts.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 180 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    status: mysqlEnum("status", ["active", "inactive", "completed", "withdrawn"])
      .default("active")
      .notNull(),
    completionApprovalStatus: mysqlEnum("completionApprovalStatus", ["not_requested", "pending", "approved", "returned"])
      .default("not_requested")
      .notNull(),
    completionReviewedByUserId: int("completionReviewedByUserId").references(() => users.id, { onDelete: "set null" }),
    completionReviewedAt: timestamp("completionReviewedAt"),
    completionReviewNotes: text("completionReviewNotes"),
    completionFirstApprovedByUserId: int("completionFirstApprovedByUserId").references(() => users.id, { onDelete: "set null" }),
    completionFirstApprovedAt: timestamp("completionFirstApprovedAt"),
    completionApprovalRequestedAt: timestamp("completionApprovalRequestedAt"),
    createdByUserId: int("createdByUserId")
      .notNull()
      .references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    cohortEmailUnique: uniqueIndex("cohort_student_email_unique").on(table.cohortId, table.email),
    cohortStatusIdx: index("cohort_student_status_idx").on(table.cohortId, table.status),
    completionApprovalIdx: index("cohort_student_completion_approval_idx").on(table.cohortId, table.status, table.completionApprovalStatus),
    completionFirstApprovalIdx: index("cohort_student_first_approval_idx").on(table.completionFirstApprovedByUserId, table.completionFirstApprovedAt),
    completionEscalationIdx: index("cohort_student_completion_escalation_idx").on(table.status, table.completionApprovalStatus, table.completionApprovalRequestedAt),
  }),
);

export const cohortResources = mysqlTable(
  "cohort_resources",
  {
    id: int("id").autoincrement().primaryKey(),
    cohortId: int("cohortId")
      .notNull()
      .references(() => cohorts.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 220 }).notNull(),
    description: text("description"),
    resourceType: mysqlEnum("resourceType", ["syllabus", "schedule", "document", "link", "other"])
      .default("document")
      .notNull(),
    audience: mysqlEnum("audience", ["all", "students", "instructors", "administrators"])
      .default("students")
      .notNull(),
    sourceType: mysqlEnum("sourceType", ["file", "link"]).notNull(),
    url: varchar("url", { length: 1000 }).notNull(),
    storageKey: varchar("storageKey", { length: 800 }),
    fileName: varchar("fileName", { length: 320 }),
    mimeType: varchar("mimeType", { length: 160 }),
    fileSize: int("fileSize"),
    displayOrder: int("displayOrder").default(0).notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    createdByUserId: int("createdByUserId")
      .notNull()
      .references(() => users.id),
    updatedByUserId: int("updatedByUserId")
      .notNull()
      .references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    cohortActiveOrderIdx: index("cohort_resource_active_order_idx").on(
      table.cohortId,
      table.isActive,
      table.displayOrder,
    ),
  }),
);

export const cohortCommunications = mysqlTable(
  "cohort_communications",
  {
    id: int("id").autoincrement().primaryKey(),
    cohortId: int("cohortId")
      .notNull()
      .references(() => cohorts.id, { onDelete: "cascade" }),
    senderUserId: int("senderUserId")
      .notNull()
      .references(() => users.id),
    communicationType: mysqlEnum("communicationType", ["zoom_details", "resource_update", "schedule_update", "general"])
      .default("general")
      .notNull(),
    subject: varchar("subject", { length: 240 }).notNull(),
    contentSummary: varchar("contentSummary", { length: 500 }).default("").notNull(),
    message: text("message").notNull(),
    includeZoom: boolean("includeZoom").default(false).notNull(),
    resourceIds: json("resourceIds").$type<number[]>().notNull(),
    previewHash: varchar("previewHash", { length: 64 }).notNull(),
    idempotencyKey: varchar("idempotencyKey", { length: 64 }).notNull(),
    provider: varchar("provider", { length: 32 }).default("resend").notNull(),
    status: mysqlEnum("status", ["draft", "processing", "partial", "sent", "failed", "cancelled"])
      .default("draft")
      .notNull(),
    recipientCount: int("recipientCount").default(0).notNull(),
    acceptedCount: int("acceptedCount").default(0).notNull(),
    deliveredCount: int("deliveredCount").default(0).notNull(),
    failedCount: int("failedCount").default(0).notNull(),
    bouncedCount: int("bouncedCount").default(0).notNull(),
    complainedCount: int("complainedCount").default(0).notNull(),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    idempotencyUnique: uniqueIndex("cohort_communication_idempotency_unique").on(
      table.idempotencyKey,
    ),
    cohortCreatedIdx: index("cohort_communication_created_idx").on(
      table.cohortId,
      table.createdAt,
    ),
    statusIdx: index("cohort_communication_status_idx").on(table.status),
  }),
);

export const cohortCommunicationRecipients = mysqlTable(
  "cohort_communication_recipients",
  {
    id: int("id").autoincrement().primaryKey(),
    communicationId: int("communicationId")
      .notNull()
      .references(() => cohortCommunications.id, { onDelete: "cascade" }),
    studentId: int("studentId").references(() => cohortStudents.id, {
      onDelete: "set null",
    }),
    studentName: varchar("studentName", { length: 180 }).notNull(),
    email: varchar("email", { length: 320 }).notNull(),
    providerMessageId: varchar("providerMessageId", { length: 180 }),
    status: mysqlEnum("status", ["queued", "accepted", "delivered", "bounced", "complained", "failed"])
      .default("queued")
      .notNull(),
    retryCount: int("retryCount").default(0).notNull(),
    errorCode: varchar("errorCode", { length: 120 }),
    errorMessage: text("errorMessage"),
    sentAt: timestamp("sentAt"),
    deliveredAt: timestamp("deliveredAt"),
    lastEventAt: timestamp("lastEventAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    communicationEmailUnique: uniqueIndex("cohort_recipient_email_unique").on(
      table.communicationId,
      table.email,
    ),
    providerMessageUnique: uniqueIndex("cohort_recipient_provider_message_unique").on(
      table.providerMessageId,
    ),
    statusIdx: index("cohort_recipient_status_idx").on(table.communicationId, table.status),
  }),
);

export const cohortCommunicationEvents = mysqlTable(
  "cohort_communication_events",
  {
    id: int("id").autoincrement().primaryKey(),
    recipientId: int("recipientId")
      .notNull()
      .references(() => cohortCommunicationRecipients.id, { onDelete: "cascade" }),
    providerEventId: varchar("providerEventId", { length: 180 }).notNull(),
    eventType: varchar("eventType", { length: 80 }).notNull(),
    occurredAt: timestamp("occurredAt").notNull(),
    eventMetadata: json("eventMetadata").$type<Record<string, string | number | boolean | null>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    providerEventUnique: uniqueIndex("cohort_event_provider_unique").on(table.providerEventId),
    recipientOccurredIdx: index("cohort_event_recipient_occurred_idx").on(
      table.recipientId,
      table.occurredAt,
    ),
  }),
);

export const administrationAuditEvents = mysqlTable(
  "administration_audit_events",
  {
    id: int("id").autoincrement().primaryKey(),
    actorUserId: int("actorUserId").references(() => users.id, { onDelete: "set null" }),
    action: varchar("action", { length: 120 }).notNull(),
    entityType: varchar("entityType", { length: 80 }).notNull(),
    entityId: varchar("entityId", { length: 120 }),
    targetUserId: int("targetUserId").references(() => users.id, { onDelete: "set null" }),
    eventMetadata: json("eventMetadata").$type<Record<string, string | number | boolean | null>>(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    actorCreatedIdx: index("administration_audit_actor_created_idx").on(
      table.actorUserId,
      table.createdAt,
    ),
    entityIdx: index("administration_audit_entity_idx").on(table.entityType, table.entityId),
  }),
);

export const siteContentOverrides = mysqlTable(
  "site_content_overrides",
  {
    id: int("id").autoincrement().primaryKey(),
    contentKey: varchar("contentKey", { length: 180 }).notNull(),
    value: text("value").notNull(),
    updatedByUserId: int("updatedByUserId").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    contentKeyUnique: uniqueIndex("site_content_key_unique").on(table.contentKey),
    updatedAtIdx: index("site_content_updated_at_idx").on(table.updatedAt),
  }),
);

export const issuedCertificates = mysqlTable(
  "issued_certificates",
  {
    id: int("id").autoincrement().primaryKey(),
    certificateNumber: varchar("certificateNumber", { length: 64 }).notNull(),
    verificationToken: varchar("verificationToken", { length: 128 }).notNull(),
    activeIssuanceKey: varchar("activeIssuanceKey", { length: 80 }),
    cohortId: int("cohortId").notNull().references(() => cohorts.id),
    cohortStudentId: int("cohortStudentId").references(() => cohortStudents.id, { onDelete: "set null" }),
    certificationId: int("certificationId").notNull().references(() => certifications.id),
    recipientName: varchar("recipientName", { length: 180 }).notNull(),
    recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
    cohortTitle: varchar("cohortTitle", { length: 220 }).notNull(),
    credentialTitle: varchar("credentialTitle", { length: 220 }).notNull(),
    ceuValue: varchar("ceuValue", { length: 24 }),
    issuedAt: timestamp("issuedAt").notNull(),
    status: mysqlEnum("status", ["issued", "revoked", "superseded"]).default("issued").notNull(),
    revokedAt: timestamp("revokedAt"),
    revocationReason: varchar("revocationReason", { length: 500 }),
    reissueOfCertificateId: int("reissueOfCertificateId"),
    documentStorageKey: varchar("documentStorageKey", { length: 800 }).notNull(),
    documentUrl: varchar("documentUrl", { length: 1000 }).notNull(),
    documentSha256: varchar("documentSha256", { length: 64 }).notNull(),
    documentSnapshot: json("documentSnapshot").$type<Record<string, string | null> | null>(),
    issuedByUserId: int("issuedByUserId").notNull().references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    certificateNumberUnique: uniqueIndex("certificate_number_unique").on(table.certificateNumber),
    verificationTokenUnique: uniqueIndex("certificate_verification_token_unique").on(table.verificationToken),
    activeIssuanceUnique: uniqueIndex("certificate_active_issuance_unique").on(table.activeIssuanceKey),
    cohortIssuedIdx: index("certificate_cohort_issued_idx").on(table.cohortId, table.issuedAt),
    studentIssuedIdx: index("certificate_student_issued_idx").on(table.cohortStudentId, table.issuedAt),
    statusIssuedIdx: index("certificate_status_issued_idx").on(table.status, table.issuedAt),
  }),
);

export const certificatePreviewAcknowledgements = mysqlTable(
  "certificate_preview_acknowledgements",
  {
    id: int("id").autoincrement().primaryKey(),
    cohortStudentId: int("cohortStudentId").notNull().references(() => cohortStudents.id, { onDelete: "cascade" }),
    certificationId: int("certificationId").notNull().references(() => certifications.id, { onDelete: "cascade" }),
    acknowledgementToken: varchar("acknowledgementToken", { length: 64 }).notNull(),
    previewFingerprint: varchar("previewFingerprint", { length: 64 }).notNull(),
    previewedByUserId: int("previewedByUserId").notNull().references(() => users.id),
    acknowledgedAt: timestamp("acknowledgedAt").defaultNow().notNull(),
    acknowledgementNotes: text("acknowledgementNotes"),
    confirmedAt: timestamp("confirmedAt"),
    expiresAt: timestamp("expiresAt").notNull(),
    usedAt: timestamp("usedAt"),
    usedForCertificateId: int("usedForCertificateId").references(() => issuedCertificates.id, { onDelete: "set null" }),
  },
  table => ({
    tokenUnique: uniqueIndex("certificate_preview_ack_token_unique").on(table.acknowledgementToken),
    candidateActorIdx: index("certificate_preview_ack_candidate_actor_idx").on(table.cohortStudentId, table.previewedByUserId, table.expiresAt),
    issuedIdx: index("certificate_preview_ack_issued_idx").on(table.usedForCertificateId),
  }),
);

export const certificatePreviewReminderNotifications = mysqlTable(
  "certificate_preview_reminder_notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    acknowledgementId: int("acknowledgementId").notNull().references(() => certificatePreviewAcknowledgements.id, { onDelete: "cascade" }),
    recipientUserId: int("recipientUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    recipientName: varchar("recipientName", { length: 180 }).notNull(),
    recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
    subject: varchar("subject", { length: 240 }).notNull(),
    idempotencyKey: varchar("idempotencyKey", { length: 128 }).notNull(),
    providerMessageId: varchar("providerMessageId", { length: 180 }),
    status: mysqlEnum("status", ["queued", "accepted", "failed"]).default("queued").notNull(),
    retryCount: int("retryCount").default(0).notNull(),
    errorCode: varchar("errorCode", { length: 120 }),
    errorMessage: text("errorMessage"),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    acknowledgementUnique: uniqueIndex("certificate_preview_reminder_ack_unique").on(table.acknowledgementId),
    recipientStatusIdx: index("certificate_preview_reminder_recipient_status_idx").on(table.recipientUserId, table.status),
  }),
);

export const certificatePreviewReminderSchedules = mysqlTable(
  "certificate_preview_reminder_schedules",
  {
    id: int("id").autoincrement().primaryKey(),
    scheduleCronTaskUid: varchar("scheduleCronTaskUid", { length: 65 }).notNull(),
    cronExpression: varchar("cronExpression", { length: 64 }).notNull(),
    enabled: boolean("enabled").default(true).notNull(),
    lastRunAt: timestamp("lastRunAt"),
    lastRunSummary: text("lastRunSummary"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    taskUnique: uniqueIndex("certificate_preview_reminder_task_unique").on(table.scheduleCronTaskUid),
  }),
);

export const certificateApprovalEscalations = mysqlTable(
  "certificate_approval_escalations",
  {
    id: int("id").autoincrement().primaryKey(),
    cohortStudentId: int("cohortStudentId").notNull().references(() => cohortStudents.id, { onDelete: "cascade" }),
    certificationId: int("certificationId").notNull().references(() => certifications.id, { onDelete: "cascade" }),
    recipientUserId: int("recipientUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    recipientName: varchar("recipientName", { length: 180 }).notNull(),
    recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
    subject: varchar("subject", { length: 240 }).notNull(),
    idempotencyKey: varchar("idempotencyKey", { length: 128 }).notNull(),
    providerMessageId: varchar("providerMessageId", { length: 180 }),
    status: mysqlEnum("status", ["queued", "accepted", "failed"]).default("queued").notNull(),
    retryCount: int("retryCount").default(0).notNull(),
    errorCode: varchar("errorCode", { length: 120 }),
    errorMessage: text("errorMessage"),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    studentRecipientUnique: uniqueIndex("certificate_escalation_student_recipient_unique").on(table.cohortStudentId, table.recipientUserId),
    recipientStatusIdx: index("certificate_escalation_recipient_status_idx").on(table.recipientUserId, table.status),
  }),
);

export const certificateTemplateTestDeliveries = mysqlTable(
  "certificate_template_test_deliveries",
  {
    id: int("id").autoincrement().primaryKey(),
    certificationId: int("certificationId").notNull().references(() => certifications.id, { onDelete: "cascade" }),
    templateType: mysqlEnum("templateType", ["preview_reminder", "approval_escalation"]).notNull(),
    recipientUserId: int("recipientUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    recipientName: varchar("recipientName", { length: 180 }).notNull(),
    recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
    subject: varchar("subject", { length: 240 }).notNull(),
    providerMessageId: varchar("providerMessageId", { length: 180 }),
    status: mysqlEnum("status", ["queued", "accepted", "failed"]).default("queued").notNull(),
    errorMessage: text("errorMessage"),
    createdByUserId: int("createdByUserId").notNull().references(() => users.id),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    certificationCreatedIdx: index("certificate_template_test_cert_created_idx").on(table.certificationId, table.createdAt),
    recipientStatusIdx: index("certificate_template_test_recipient_status_idx").on(table.recipientUserId, table.status),
  }),
);

export const certificateApprovalHistoryReports = mysqlTable(
  "certificate_approval_history_reports",
  {
    id: int("id").autoincrement().primaryKey(),
    certificateId: int("certificateId").notNull().references(() => issuedCertificates.id, { onDelete: "cascade" }),
    exportedByUserId: int("exportedByUserId").notNull().references(() => users.id),
    exportedByName: varchar("exportedByName", { length: 180 }).notNull(),
    eventFilters: json("eventFilters").$type<string[] | null>(),
    reportSha256: varchar("reportSha256", { length: 64 }).notNull(),
    attestation: varchar("attestation", { length: 128 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    certificateCreatedIdx: index("certificate_history_report_created_idx").on(table.certificateId, table.createdAt),
  }),
);

export const certificateProgramProfiles = mysqlTable(
  "certificate_program_profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    certificationId: int("certificationId").notNull().references(() => certifications.id, { onDelete: "cascade" }),
    completionNarrative: text("completionNarrative"),
    instructionalHours: varchar("instructionalHours", { length: 160 }),
    supervisedPracticalTraining: varchar("supervisedPracticalTraining", { length: 180 }),
    complianceStatement: text("complianceStatement"),
    accreditingBodyName: varchar("accreditingBodyName", { length: 240 }),
    licenseNumber: varchar("licenseNumber", { length: 160 }),
    executiveName: varchar("executiveName", { length: 220 }).default("Jacquese Hinton").notNull(),
    executiveTitle: varchar("executiveTitle", { length: 220 }).default("Founder & Director of Institutional Strategy").notNull(),
    executiveSignatureStorageKey: varchar("executiveSignatureStorageKey", { length: 800 }),
    executiveSignatureUrl: varchar("executiveSignatureUrl", { length: 1000 }),
    executiveSignatureMimeType: varchar("executiveSignatureMimeType", { length: 80 }),
    executiveSignatureCrop: json("executiveSignatureCrop").$type<{ x: number; y: number; size: number; zoom: number } | null>(),
    courseInstructorSignatoryName: varchar("courseInstructorSignatoryName", { length: 220 }),
    courseInstructorSignatoryTitle: varchar("courseInstructorSignatoryTitle", { length: 220 }),
    isHighStakes: boolean("isHighStakes").default(false).notNull(),
    previewAcknowledgementExpirationMinutes: int("previewAcknowledgementExpirationMinutes").default(30).notNull(),
    previewReminderEnabled: boolean("previewReminderEnabled").default(true).notNull(),
    previewReminderLeadMinutes: int("previewReminderLeadMinutes").default(10).notNull(),
    previewReminderEmailSubject: varchar("previewReminderEmailSubject", { length: 240 }),
    previewReminderEmailBody: text("previewReminderEmailBody"),
    approvalEscalationEnabled: boolean("approvalEscalationEnabled").default(false).notNull(),
    approvalEscalationDelayMinutes: int("approvalEscalationDelayMinutes").default(1440).notNull(),
    approvalEscalationRecipientUserId: int("approvalEscalationRecipientUserId").references(() => users.id, { onDelete: "set null" }),
    approvalEscalationEmailSubject: varchar("approvalEscalationEmailSubject", { length: 240 }),
    approvalEscalationEmailBody: text("approvalEscalationEmailBody"),
    approvalSlaTargetMinutes: int("approvalSlaTargetMinutes"),
    updatedByUserId: int("updatedByUserId").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    certificationUnique: uniqueIndex("certificate_program_profile_cert_unique").on(table.certificationId),
    updatedIdx: index("certificate_program_profile_updated_idx").on(table.updatedAt),
    escalationRecipientIdx: index("certificate_program_profile_escalation_recipient_idx").on(table.approvalEscalationRecipientUserId),
  }),
);

export const completionDecisionNotifications = mysqlTable(
  "completion_decision_notifications",
  {
    id: int("id").autoincrement().primaryKey(),
    cohortStudentId: int("cohortStudentId").notNull().references(() => cohortStudents.id, { onDelete: "cascade" }),
    decision: mysqlEnum("decision", ["approved", "returned"]).notNull(),
    recipientName: varchar("recipientName", { length: 180 }).notNull(),
    recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
    subject: varchar("subject", { length: 240 }).notNull(),
    idempotencyKey: varchar("idempotencyKey", { length: 96 }).notNull(),
    providerMessageId: varchar("providerMessageId", { length: 180 }),
    status: mysqlEnum("status", ["queued", "accepted", "failed"]).default("queued").notNull(),
    retryCount: int("retryCount").default(0).notNull(),
    errorCode: varchar("errorCode", { length: 120 }),
    errorMessage: text("errorMessage"),
    createdByUserId: int("createdByUserId").notNull().references(() => users.id),
    sentAt: timestamp("sentAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    idempotencyUnique: uniqueIndex("completion_notification_idempotency_unique").on(table.idempotencyKey),
    studentCreatedIdx: index("completion_notification_student_created_idx").on(table.cohortStudentId, table.createdAt),
    statusIdx: index("completion_notification_status_idx").on(table.status, table.createdAt),
  }),
);

export const onlineCourses = mysqlTable(
  "online_courses",
  {
    id: int("id").autoincrement().primaryKey(),
    certificationId: int("certificationId").notNull().references(() => certifications.id),
    status: mysqlEnum("status", ["draft", "review", "published", "archived"]).default("draft").notNull(),
    courseOverview: text("courseOverview"),
    sourceGroundingNotice: text("sourceGroundingNotice"),
    aiInstructorName: varchar("aiInstructorName", { length: 100 }).default("VIBHA Learning Guide").notNull(),
    aiInstructorWelcome: text("aiInstructorWelcome"),
    aiInstructorScope: text("aiInstructorScope"),
    lastGeneratedAt: timestamp("lastGeneratedAt"),
    createdByUserId: int("createdByUserId").notNull().references(() => users.id),
    updatedByUserId: int("updatedByUserId").notNull().references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    certificationUnique: uniqueIndex("online_course_certification_unique").on(table.certificationId),
    statusUpdatedIdx: index("online_course_status_updated_idx").on(table.status, table.updatedAt),
  }),
);

export const onlineCourseMaterials = mysqlTable(
  "online_course_materials",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull().references(() => onlineCourses.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 220 }).notNull(),
    fileName: varchar("fileName", { length: 320 }).notNull(),
    mimeType: varchar("mimeType", { length: 160 }).notNull(),
    storageKey: varchar("storageKey", { length: 800 }).notNull(),
    url: varchar("url", { length: 1000 }).notNull(),
    fileSize: int("fileSize").notNull(),
    analysisStatus: mysqlEnum("analysisStatus", ["pending", "analyzed", "failed"]).default("pending").notNull(),
    analysisSummary: text("analysisSummary"),
    sourceExcerpt: text("sourceExcerpt"),
    analysisError: varchar("analysisError", { length: 1000 }),
    uploadedByUserId: int("uploadedByUserId").notNull().references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    courseCreatedIdx: index("online_material_course_created_idx").on(table.courseId, table.createdAt),
    analysisIdx: index("online_material_analysis_idx").on(table.courseId, table.analysisStatus),
  }),
);

export const onlineCourseGenerationRuns = mysqlTable(
  "online_course_generation_runs",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull().references(() => onlineCourses.id, { onDelete: "cascade" }),
    status: mysqlEnum("status", ["processing", "ready", "failed"]).default("processing").notNull(),
    model: varchar("model", { length: 120 }).notNull(),
    materialIds: json("materialIds").$type<number[]>().notNull(),
    outputSnapshot: json("outputSnapshot").$type<Record<string, unknown> | null>(),
    errorMessage: varchar("errorMessage", { length: 1000 }),
    createdByUserId: int("createdByUserId").notNull().references(() => users.id),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
  },
  table => ({
    courseCreatedIdx: index("online_generation_course_created_idx").on(table.courseId, table.createdAt),
    statusIdx: index("online_generation_status_idx").on(table.status, table.createdAt),
  }),
);

export const onlineCourseModules = mysqlTable(
  "online_course_modules",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull().references(() => onlineCourses.id, { onDelete: "cascade" }),
    generationRunId: int("generationRunId").references(() => onlineCourseGenerationRuns.id, { onDelete: "set null" }),
    position: int("position").notNull(),
    title: varchar("title", { length: 220 }).notNull(),
    learningObjective: text("learningObjective").notNull(),
    sourceGrounding: text("sourceGrounding").notNull(),
    visualPrompt: text("visualPrompt").notNull(),
    visualImageUrl: varchar("visualImageUrl", { length: 1000 }),
    videoBrief: text("videoBrief").notNull(),
    isPublished: boolean("isPublished").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    coursePositionUnique: uniqueIndex("online_module_course_position_unique").on(table.courseId, table.position),
    coursePublishedIdx: index("online_module_course_published_idx").on(table.courseId, table.isPublished, table.position),
  }),
);

export const onlineCourseLessons = mysqlTable(
  "online_course_lessons",
  {
    id: int("id").autoincrement().primaryKey(),
    moduleId: int("moduleId").notNull().references(() => onlineCourseModules.id, { onDelete: "cascade" }),
    position: int("position").notNull(),
    title: varchar("title", { length: 220 }).notNull(),
    estimatedMinutes: int("estimatedMinutes").notNull(),
    content: text("content").notNull(),
    knowledgeCheckQuestion: text("knowledgeCheckQuestion").notNull(),
    knowledgeCheckAnswer: text("knowledgeCheckAnswer").notNull(),
    isPublished: boolean("isPublished").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    modulePositionUnique: uniqueIndex("online_lesson_module_position_unique").on(table.moduleId, table.position),
    modulePublishedIdx: index("online_lesson_module_published_idx").on(table.moduleId, table.isPublished, table.position),
  }),
);

export const onlineCourseEnrollments = mysqlTable(
  "online_course_enrollments",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull().references(() => onlineCourses.id, { onDelete: "cascade" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    status: mysqlEnum("status", ["enrolled", "completed", "withdrawn"]).default("enrolled").notNull(),
    enrolledAt: timestamp("enrolledAt").defaultNow().notNull(),
    lastAccessedAt: timestamp("lastAccessedAt").defaultNow().notNull(),
    completedAt: timestamp("completedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    courseUserUnique: uniqueIndex("online_enrollment_course_user_unique").on(table.courseId, table.userId),
    userAccessIdx: index("online_enrollment_user_access_idx").on(table.userId, table.lastAccessedAt),
    courseStatusIdx: index("online_enrollment_course_status_idx").on(table.courseId, table.status),
  }),
);

export const onlineLessonProgress = mysqlTable(
  "online_lesson_progress",
  {
    id: int("id").autoincrement().primaryKey(),
    enrollmentId: int("enrollmentId").notNull().references(() => onlineCourseEnrollments.id, { onDelete: "cascade" }),
    lessonId: int("lessonId").notNull().references(() => onlineCourseLessons.id, { onDelete: "cascade" }),
    completed: boolean("completed").default(false).notNull(),
    firstCompletedAt: timestamp("firstCompletedAt"),
    lastOpenedAt: timestamp("lastOpenedAt").defaultNow().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    enrollmentLessonUnique: uniqueIndex("online_progress_enrollment_lesson_unique").on(table.enrollmentId, table.lessonId),
    enrollmentUpdatedIdx: index("online_progress_enrollment_updated_idx").on(table.enrollmentId, table.updatedAt),
  }),
);

export const onlineModuleQuizzes = mysqlTable(
  "online_module_quizzes",
  {
    id: int("id").autoincrement().primaryKey(),
    moduleId: int("moduleId").notNull().references(() => onlineCourseModules.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 220 }).notNull(),
    passingScore: int("passingScore").default(70).notNull(),
    isPublished: boolean("isPublished").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    moduleUnique: uniqueIndex("online_quiz_module_unique").on(table.moduleId),
    modulePublishedIdx: index("online_quiz_module_published_idx").on(table.moduleId, table.isPublished),
  }),
);

export const onlineModuleQuizQuestions = mysqlTable(
  "online_module_quiz_questions",
  {
    id: int("id").autoincrement().primaryKey(),
    quizId: int("quizId").notNull().references(() => onlineModuleQuizzes.id, { onDelete: "cascade" }),
    position: int("position").notNull(),
    prompt: text("prompt").notNull(),
    options: json("options").$type<string[]>().notNull(),
    correctOptionIndex: int("correctOptionIndex").notNull(),
    explanation: text("explanation").notNull(),
    isPublished: boolean("isPublished").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    quizPositionUnique: uniqueIndex("online_quiz_question_position_unique").on(table.quizId, table.position),
    quizPublishedIdx: index("online_quiz_question_published_idx").on(table.quizId, table.isPublished, table.position),
  }),
);

export const onlineModuleQuizAttempts = mysqlTable(
  "online_module_quiz_attempts",
  {
    id: int("id").autoincrement().primaryKey(),
    enrollmentId: int("enrollmentId").notNull().references(() => onlineCourseEnrollments.id, { onDelete: "cascade" }),
    quizId: int("quizId").notNull().references(() => onlineModuleQuizzes.id, { onDelete: "cascade" }),
    score: int("score").notNull(),
    passed: boolean("passed").notNull(),
    answers: json("answers").$type<Array<{ questionId: number; selectedOptionIndex: number }>>().notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({
    enrollmentQuizCreatedIdx: index("online_quiz_attempt_enrollment_created_idx").on(table.enrollmentId, table.quizId, table.createdAt),
    quizPassedIdx: index("online_quiz_attempt_quiz_passed_idx").on(table.quizId, table.passed),
  }),
);

export const onlineCompletionTranscripts = mysqlTable(
  "online_completion_transcripts",
  {
    id: int("id").autoincrement().primaryKey(),
    enrollmentId: int("enrollmentId").notNull().references(() => onlineCourseEnrollments.id, { onDelete: "cascade" }),
    recipientName: varchar("recipientName", { length: 220 }).notNull(),
    courseTitle: varchar("courseTitle", { length: 300 }).notNull(),
    courseSlug: varchar("courseSlug", { length: 240 }).notNull(),
    ceus: decimal("ceus", { precision: 6, scale: 2 }).notNull(),
    completedAtSnapshot: timestamp("completedAtSnapshot").notNull(),
    moduleCount: int("moduleCount").notNull(),
    lessonCount: int("lessonCount").notNull(),
    storageKey: varchar("storageKey", { length: 800 }).notNull(),
    url: varchar("url", { length: 1000 }).notNull(),
    checksum: varchar("checksum", { length: 128 }).notNull(),
    generatedAt: timestamp("generatedAt").defaultNow().notNull(),
  },
  table => ({
    enrollmentUnique: uniqueIndex("online_transcript_enrollment_unique").on(table.enrollmentId),
    courseGeneratedIdx: index("online_transcript_course_generated_idx").on(table.courseSlug, table.generatedAt),
  }),
);

export const onlineCourseInvitations = mysqlTable(
  "online_course_invitations",
  {
    id: int("id").autoincrement().primaryKey(),
    courseId: int("courseId").notNull().references(() => onlineCourses.id, { onDelete: "cascade" }),
    recipientName: varchar("recipientName", { length: 180 }).notNull(),
    recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
    tokenHash: varchar("tokenHash", { length: 128 }).notNull(),
    status: mysqlEnum("status", ["pending", "accepted", "expired", "canceled", "failed"]).default("pending").notNull(),
    deliveryStatus: mysqlEnum("deliveryStatus", ["queued", "sent", "failed"]).default("queued").notNull(),
    providerMessageId: varchar("providerMessageId", { length: 255 }),
    deliveryError: varchar("deliveryError", { length: 1000 }),
    invitedByUserId: int("invitedByUserId").notNull().references(() => users.id),
    acceptedByUserId: int("acceptedByUserId").references(() => users.id),
    sentAt: timestamp("sentAt"),
    acceptedAt: timestamp("acceptedAt"),
    expiresAt: timestamp("expiresAt").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    tokenUnique: uniqueIndex("online_invitation_token_unique").on(table.tokenHash),
    courseRecipientIdx: index("online_invitation_course_recipient_idx").on(table.courseId, table.recipientEmail, table.status),
    expiryIdx: index("online_invitation_expiry_idx").on(table.status, table.expiresAt),
  }),
);

export const onlineLearnerModuleNotes = mysqlTable(
  "online_learner_module_notes",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    courseId: int("courseId").notNull().references(() => onlineCourses.id, { onDelete: "cascade" }),
    moduleId: int("moduleId").notNull().references(() => onlineCourseModules.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    userModuleUnique: uniqueIndex("online_note_user_module_unique").on(table.userId, table.moduleId),
    userCourseUpdatedIdx: index("online_note_user_course_updated_idx").on(table.userId, table.courseId, table.updatedAt),
  }),
);

export type CertificationCategory = typeof certificationCategories.$inferSelect;
export type InsertCertificationCategory = typeof certificationCategories.$inferInsert;
export type Certification = typeof certifications.$inferSelect;
export type InsertCertification = typeof certifications.$inferInsert;
export type Instructor = typeof instructors.$inferSelect;
export type InsertInstructor = typeof instructors.$inferInsert;
export type Inquiry = typeof inquiries.$inferSelect;
export type InsertInquiry = typeof inquiries.$inferInsert;
export type AdministratorInvitation = typeof administratorInvitations.$inferSelect;
export type InsertAdministratorInvitation = typeof administratorInvitations.$inferInsert;
export type Cohort = typeof cohorts.$inferSelect;
export type InsertCohort = typeof cohorts.$inferInsert;
export type CohortStudent = typeof cohortStudents.$inferSelect;
export type InsertCohortStudent = typeof cohortStudents.$inferInsert;
export type CohortResource = typeof cohortResources.$inferSelect;
export type InsertCohortResource = typeof cohortResources.$inferInsert;
export type CohortCommunication = typeof cohortCommunications.$inferSelect;
export type InsertCohortCommunication = typeof cohortCommunications.$inferInsert;
export type CohortCommunicationRecipient = typeof cohortCommunicationRecipients.$inferSelect;
export type InsertCohortCommunicationRecipient = typeof cohortCommunicationRecipients.$inferInsert;
export type CohortCommunicationEvent = typeof cohortCommunicationEvents.$inferSelect;
export type InsertCohortCommunicationEvent = typeof cohortCommunicationEvents.$inferInsert;
export type AdministrationAuditEvent = typeof administrationAuditEvents.$inferSelect;
export type InsertAdministrationAuditEvent = typeof administrationAuditEvents.$inferInsert;
export type SiteContentOverride = typeof siteContentOverrides.$inferSelect;
export type InsertSiteContentOverride = typeof siteContentOverrides.$inferInsert;
export type IssuedCertificate = typeof issuedCertificates.$inferSelect;
export type InsertIssuedCertificate = typeof issuedCertificates.$inferInsert;
export type OnlineCourse = typeof onlineCourses.$inferSelect;
export type InsertOnlineCourse = typeof onlineCourses.$inferInsert;
export type OnlineCourseMaterial = typeof onlineCourseMaterials.$inferSelect;
export type InsertOnlineCourseMaterial = typeof onlineCourseMaterials.$inferInsert;
export type OnlineCourseGenerationRun = typeof onlineCourseGenerationRuns.$inferSelect;
export type InsertOnlineCourseGenerationRun = typeof onlineCourseGenerationRuns.$inferInsert;
export type OnlineCourseModule = typeof onlineCourseModules.$inferSelect;
export type InsertOnlineCourseModule = typeof onlineCourseModules.$inferInsert;
export type OnlineCourseLesson = typeof onlineCourseLessons.$inferSelect;
export type InsertOnlineCourseLesson = typeof onlineCourseLessons.$inferInsert;
export type OnlineCourseEnrollment = typeof onlineCourseEnrollments.$inferSelect;
export type InsertOnlineCourseEnrollment = typeof onlineCourseEnrollments.$inferInsert;
export type OnlineLessonProgress = typeof onlineLessonProgress.$inferSelect;
export type InsertOnlineLessonProgress = typeof onlineLessonProgress.$inferInsert;
export type OnlineModuleQuiz = typeof onlineModuleQuizzes.$inferSelect;
export type InsertOnlineModuleQuiz = typeof onlineModuleQuizzes.$inferInsert;
export type OnlineModuleQuizQuestion = typeof onlineModuleQuizQuestions.$inferSelect;
export type InsertOnlineModuleQuizQuestion = typeof onlineModuleQuizQuestions.$inferInsert;
export type OnlineModuleQuizAttempt = typeof onlineModuleQuizAttempts.$inferSelect;
export type InsertOnlineModuleQuizAttempt = typeof onlineModuleQuizAttempts.$inferInsert;
export type OnlineCompletionTranscript = typeof onlineCompletionTranscripts.$inferSelect;
export type InsertOnlineCompletionTranscript = typeof onlineCompletionTranscripts.$inferInsert;
export type OnlineCourseInvitation = typeof onlineCourseInvitations.$inferSelect;
export type InsertOnlineCourseInvitation = typeof onlineCourseInvitations.$inferInsert;
export type OnlineLearnerModuleNote = typeof onlineLearnerModuleNotes.$inferSelect;
export type InsertOnlineLearnerModuleNote = typeof onlineLearnerModuleNotes.$inferInsert;
