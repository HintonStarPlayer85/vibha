import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { certificateVerifySchema } from "../shared/certificates";

const certificateDbMocks = vi.hoisted(() => ({
  getCertificateById: vi.fn(),
  getCertificateProgramProfile: vi.fn(),
  getPublicCertificateVerification: vi.fn(),
  listCertificateCompletionReviews: vi.fn(),
  listCertificateProgramOptions: vi.fn(),
  listCertificateRepository: vi.fn(),
  listEligibleCertificateRecipients: vi.fn(),
  recordCertificatePreviewAcknowledgement: vi.fn(),
  confirmCertificatePreviewAcknowledgement: vi.fn(),
  exportCertificateApprovalHistoryCsv: vi.fn(),
  listCertificateApprovalHistory: vi.fn(),
  resubmitCertificateCompletion: vi.fn(),
  reviewCertificateCompletion: vi.fn(),
  upsertCertificateProgramProfile: vi.fn(),
  listCertificateTemplateTestDeliveryHistory: vi.fn(),
}));

const certificateServiceMocks = vi.hoisted(() => ({
  issueCertificate: vi.fn(),
  previewCertificate: vi.fn(),
  reissueCertificate: vi.fn(),
  revokeIssuedCertificate: vi.fn(),
}));

const governanceServiceMocks = vi.hoisted(() => ({
  getCertificateGovernanceDashboard: vi.fn(),
  listCertificateAdministratorOptions: vi.fn(),
  listCertificateGovernanceNotificationStatus: vi.fn(),
  resendCertificateApprovalEscalation: vi.fn(),
  reassignCertificateApprovalEscalation: vi.fn(),
  resendCertificatePreviewReminder: vi.fn(),
  generateCertificateApprovalHistoryPdf: vi.fn(),
  sendCertificateTemplateTest: vi.fn(),
  generateCertificateGovernanceDashboardCsv: vi.fn(),
  generateCertificateGovernanceDashboardPdf: vi.fn(),
}));

vi.mock("./certificateDb", async () => {
  const actual = await vi.importActual<typeof import("./certificateDb")>("./certificateDb");
  return { ...actual, ...certificateDbMocks };
});

vi.mock("./certificateService", async () => {
  const actual = await vi.importActual<typeof import("./certificateService")>("./certificateService");
  return { ...actual, ...certificateServiceMocks };
});

vi.mock("./certificateApprovalEscalationService", () => ({
  getCertificateGovernanceDashboard: governanceServiceMocks.getCertificateGovernanceDashboard,
  listCertificateAdministratorOptions: governanceServiceMocks.listCertificateAdministratorOptions,
  listCertificateGovernanceNotificationStatus: governanceServiceMocks.listCertificateGovernanceNotificationStatus,
  resendCertificateApprovalEscalation: governanceServiceMocks.resendCertificateApprovalEscalation,
  reassignCertificateApprovalEscalation: governanceServiceMocks.reassignCertificateApprovalEscalation,
}));

vi.mock("./certificatePreviewReminderService", () => ({ resendCertificatePreviewReminder: governanceServiceMocks.resendCertificatePreviewReminder }));
vi.mock("./certificateApprovalHistoryReportService", () => ({ generateCertificateApprovalHistoryPdf: governanceServiceMocks.generateCertificateApprovalHistoryPdf }));
vi.mock("./certificateTemplateTestService", () => ({ sendCertificateTemplateTest: governanceServiceMocks.sendCertificateTemplateTest }));
vi.mock("./certificateGovernanceDashboardReportService", () => ({ generateCertificateGovernanceDashboardCsv: governanceServiceMocks.generateCertificateGovernanceDashboardCsv, generateCertificateGovernanceDashboardPdf: governanceServiceMocks.generateCertificateGovernanceDashboardPdf }));

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function context(role?: AuthenticatedUser["role"]): TrpcContext {
  const user = role ? {
    id: 32,
    openId: `${role}-certificate-test`,
    email: `${role}@example.com`,
    name: "Certificate Test",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  } : null;
  return {
    user,
    req: { protocol: "https", headers: {}, get: (name: string) => name === "host" ? "thevibha.org" : undefined } as unknown as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("Certificate Repository", () => {
  beforeEach(() => vi.clearAllMocks());

  it("requires the VIBHA-issued certificate-number format", () => {
    expect(certificateVerifySchema.parse({ reference: "vibha-2026-a1b2c3d4" })).toMatchObject({ reference: "VIBHA-2026-A1B2C3D4" });
    expect(() => certificateVerifySchema.parse({ reference: "VIBHA-2026-NOT-A-CERTIFICATE" })).toThrow();
  });

  it("permits public verification without exposing a repository-management procedure", async () => {
    certificateDbMocks.getPublicCertificateVerification.mockResolvedValue({
      certificateNumber: "VIBHA-2026-A1B2C3D4",
      status: "issued",
      recipientName: "Jordan Avery",
      credentialTitle: "QMHP Foundations",
      cohortTitle: "Spring 2026 Cohort",
      ceuValue: "8.00",
      issuedAt: new Date("2026-03-10T00:00:00Z"),
    });
    const caller = appRouter.createCaller(context());
    await expect(caller.certificateVerification.verify({ reference: "VIBHA-2026-A1B2C3D4" })).resolves.toMatchObject({ status: "issued", recipientName: "Jordan Avery" });
  });

  it("allows administrators to issue a certificate and supplies a trusted verification origin", async () => {
    certificateServiceMocks.issueCertificate.mockResolvedValue({ certificateNumber: "VIBHA-2026-A1B2C3D4" });
    const caller = appRouter.createCaller(context("admin"));
    await expect(caller.adminCertificates.issue({ cohortStudentId: 55, previewAcknowledgementToken: "65aa0fc3-5c98-4146-8d13-807c355be122" })).resolves.toEqual({ certificateNumber: "VIBHA-2026-A1B2C3D4" });
    expect(certificateServiceMocks.issueCertificate).toHaveBeenCalledWith(55, "65aa0fc3-5c98-4146-8d13-807c355be122", 32, "https://thevibha.org");
  });

  it("limits non-persistent certificate previews to administrators", async () => {
    certificateServiceMocks.previewCertificate.mockResolvedValue({ fileName: "VIBHA-certificate-preview-jordan.pdf", dataBase64: "cHJldmlldy1wZGY=", previewFingerprint: "a".repeat(64), certificationId: 9, expirationMinutes: 45 });
    certificateDbMocks.recordCertificatePreviewAcknowledgement.mockResolvedValue({ acknowledgementToken: "preview-token", expiresAt: new Date() });
    await expect(appRouter.createCaller(context("user")).adminCertificates.preview({ cohortStudentId: 55 })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.preview({ cohortStudentId: 55 })).resolves.toMatchObject({ fileName: expect.stringMatching(/preview/), acknowledgement: { acknowledgementToken: "preview-token" } });
    expect(certificateServiceMocks.previewCertificate).toHaveBeenCalledWith(55, "https://thevibha.org");
    expect(certificateDbMocks.recordCertificatePreviewAcknowledgement).toHaveBeenCalledWith(expect.objectContaining({ cohortStudentId: 55, certificationId: 9, expiresAt: expect.any(Date) }));
  });

  it("requires an administrator to confirm a generated preview before the acknowledgement can authorize issuance", async () => {
    certificateDbMocks.confirmCertificatePreviewAcknowledgement.mockResolvedValue({ acknowledgementToken: "preview-token", confirmedAt: new Date() });
    await expect(appRouter.createCaller(context("user")).adminCertificates.confirmPreviewAcknowledgement({ acknowledgementToken: "65aa0fc3-5c98-4146-8d13-807c355be122", notes: "Review rationale" })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.confirmPreviewAcknowledgement({ acknowledgementToken: "65aa0fc3-5c98-4146-8d13-807c355be122", notes: "Review rationale" })).resolves.toMatchObject({ acknowledgementToken: "preview-token" });
    expect(certificateDbMocks.confirmCertificatePreviewAcknowledgement).toHaveBeenCalledWith("65aa0fc3-5c98-4146-8d13-807c355be122", "Review rationale", 32);
  });

  it("keeps certificate approval history inside protected administration and rejects malformed executive signature uploads", async () => {
    certificateDbMocks.listCertificateApprovalHistory.mockResolvedValue([{ id: 1, action: "certificate.completion.approved", actorName: "Certificate Test", createdAt: new Date() }]);
    await expect(appRouter.createCaller(context("user")).adminCertificates.approvalHistory({ certificateId: 8 })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.approvalHistory({ certificateId: 8 })).resolves.toHaveLength(1);
    certificateDbMocks.exportCertificateApprovalHistoryCsv.mockResolvedValue({ fileName: "VIBHA-2026-A1B2C3D4-approval-history.csv", dataBase64: "Y3N2" });
    await expect(appRouter.createCaller(context("user")).adminCertificates.exportApprovalHistory({ certificateId: 8 })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.exportApprovalHistory({ certificateId: 8 })).resolves.toMatchObject({ fileName: expect.stringMatching(/approval-history/) });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.uploadExecutiveSignature({ certificationId: 9, fileName: "signature.png", mimeType: "image/png", dataBase64: "not-a-png", crop: { x: 0.5, y: 0.5, size: 1, zoom: 1 } })).rejects.toMatchObject<Partial<TRPCError>>({ code: "BAD_REQUEST" });
  });

  it("returns a clear denial when a completed learner has not been approved for certificate issuance", async () => {
    certificateServiceMocks.issueCertificate.mockRejectedValue(new Error("CERTIFICATE_COMPLETION_NOT_APPROVED"));
    await expect(appRouter.createCaller(context("admin")).adminCertificates.issue({ cohortStudentId: 55, previewAcknowledgementToken: "65aa0fc3-5c98-4146-8d13-807c355be122" })).rejects.toMatchObject<Partial<TRPCError>>({ code: "BAD_REQUEST", message: expect.stringMatching(/approved/) });
  });

  it("limits completion review decisions to administrators and passes audited decision details", async () => {
    certificateDbMocks.reviewCertificateCompletion.mockResolvedValue({ id: 55, completionApprovalStatus: "approved" });
    await expect(appRouter.createCaller(context("user")).adminCertificates.reviewCompletion({ cohortStudentId: 55, decision: "approve" })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await appRouter.createCaller(context("admin")).adminCertificates.reviewCompletion({ cohortStudentId: 55, decision: "approve", notes: "Completion record reviewed." });
    expect(certificateDbMocks.reviewCertificateCompletion).toHaveBeenCalledWith(55, "approve", "Completion record reviewed.", 32);
  });

  it("reports the required independent second reviewer for high-stakes completion approvals", async () => {
    certificateDbMocks.reviewCertificateCompletion.mockRejectedValue(new Error("CERTIFICATE_DUPLICATE_HIGH_STAKES_REVIEWER"));
    await expect(appRouter.createCaller(context("admin")).adminCertificates.reviewCompletion({ cohortStudentId: 55, decision: "approve" })).rejects.toMatchObject<Partial<TRPCError>>({ code: "CONFLICT", message: expect.stringMatching(/different administrator/) });
  });

  it("denies standard users access to certificate repository controls", async () => {
    await expect(appRouter.createCaller(context("user")).adminCertificates.eligible()).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
  });

  it("routes replacement and revocation actions through authenticated administration", async () => {
    certificateServiceMocks.reissueCertificate.mockResolvedValue({ certificateNumber: "VIBHA-2026-B1C2D3E4" });
    certificateServiceMocks.revokeIssuedCertificate.mockResolvedValue({ id: 8, status: "revoked" });
    const caller = appRouter.createCaller(context("owner"));
    await caller.adminCertificates.reissue({ certificateId: 8 });
    await caller.adminCertificates.revoke({ certificateId: 8, reason: "Issued in error after enrollment correction." });
    expect(certificateServiceMocks.reissueCertificate).toHaveBeenCalledWith(8, 32, "https://thevibha.org");
    expect(certificateServiceMocks.revokeIssuedCertificate).toHaveBeenCalledWith(8, "Issued in error after enrollment correction.", 32);
  });

  it("limits certificate-template settings to administrators and records validated optional compliance fields", async () => {
    certificateDbMocks.upsertCertificateProgramProfile.mockResolvedValue({ certificationId: 9, accreditingBodyName: "Virginia DBHDS", licenseNumber: "VIBHA-001" });
    const input = { certificationId: 9, completionNarrative: "Approved training narrative.", instructionalHours: "90 Hours", supervisedPracticalTraining: "12 Weeks", complianceStatement: "Approved compliance language.", accreditingBodyName: "Virginia DBHDS", licenseNumber: "VIBHA-001", executiveName: "Jacquese Hinton", executiveTitle: "Founder & Director of Institutional Strategy" };
    await expect(appRouter.createCaller(context("user")).adminCertificates.saveProgramProfile(input)).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.saveProgramProfile(input)).resolves.toMatchObject({ certificationId: 9, licenseNumber: "VIBHA-001" });
    expect(certificateDbMocks.upsertCertificateProgramProfile).toHaveBeenCalledWith({ ...input, courseInstructorSignatoryName: "", courseInstructorSignatoryTitle: "", isHighStakes: false, previewAcknowledgementExpirationMinutes: 30, previewReminderEnabled: true, previewReminderLeadMinutes: 10, previewReminderEmailSubject: "", previewReminderEmailBody: "", approvalEscalationEnabled: false, approvalEscalationDelayMinutes: 1440, approvalEscalationRecipientUserId: null, approvalEscalationEmailSubject: "", approvalEscalationEmailBody: "", approvalSlaTargetMinutes: null }, 32);
  });

  it("limits reminder management and formal approval-history reports to administrators", async () => {
    governanceServiceMocks.listCertificateGovernanceNotificationStatus.mockResolvedValue([{ id: 4, type: "approval_escalation", status: "failed" }]);
    governanceServiceMocks.resendCertificateApprovalEscalation.mockResolvedValue({ result: { status: "accepted" } });
    governanceServiceMocks.generateCertificateApprovalHistoryPdf.mockResolvedValue({ fileName: "VIBHA-2026-A1B2C3D4-approval-history.pdf", dataBase64: "cGRm" });
    await expect(appRouter.createCaller(context("user")).adminCertificates.governanceNotificationStatus()).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.governanceNotificationStatus()).resolves.toHaveLength(1);
    await expect(appRouter.createCaller(context("admin")).adminCertificates.resendApprovalEscalation({ escalationId: 4 })).resolves.toMatchObject({ result: { status: "accepted" } });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.exportApprovalHistoryPdf({ certificateId: 8, eventTypes: ["certificate.issued"] })).resolves.toMatchObject({ fileName: expect.stringMatching(/\.pdf$/) });
  });

  it("limits dashboard workload metrics to administrators and rejects unsupported template merge fields", async () => {
    governanceServiceMocks.getCertificateGovernanceDashboard.mockResolvedValue({ byCertification: [], workload: { availableReviewTasks: 2, pendingSecondApprovals: 1, assignedEscalations: 1 } });
    await expect(appRouter.createCaller(context("user")).adminCertificates.governanceDashboard({})).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.myApprovalWorkload()).resolves.toMatchObject({ availableReviewTasks: 2, pendingSecondApprovals: 1, assignedEscalations: 1 });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.saveProgramProfile({ certificationId: 9, previewReminderEmailSubject: "Unsafe {{recipientEmail}}" })).rejects.toMatchObject<Partial<TRPCError>>({ code: "BAD_REQUEST" });
  });

  it("limits date-range analytics, template test sends, and escalation reassignment to administrators", async () => {
    governanceServiceMocks.getCertificateGovernanceDashboard.mockResolvedValue({ byCertification: [], trends: [], range: { fromDate: "2026-08-01", toDate: "2026-08-31" }, workload: { availableReviewTasks: 0, pendingSecondApprovals: 0, assignedEscalations: 0 } });
    governanceServiceMocks.sendCertificateTemplateTest.mockResolvedValue({ id: 7, status: "accepted" });
    governanceServiceMocks.reassignCertificateApprovalEscalation.mockResolvedValue({ result: { status: "accepted" } });
    await expect(appRouter.createCaller(context("user")).adminCertificates.governanceDashboard({ fromDate: "2026-08-01", toDate: "2026-08-31" })).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.sendTemplateTest({ certificationId: 9, templateType: "preview_reminder" })).resolves.toMatchObject({ status: "accepted" });
    expect(governanceServiceMocks.sendCertificateTemplateTest).toHaveBeenCalledWith({ certificationId: 9, templateType: "preview_reminder", actorUserId: 32 });
    await expect(appRouter.createCaller(context("admin")).adminCertificates.reassignApprovalEscalation({ escalationId: 7, recipientUserId: 88 })).resolves.toMatchObject({ result: { status: "accepted" } });
    expect(governanceServiceMocks.reassignCertificateApprovalEscalation).toHaveBeenCalledWith(7, 88, 32);
  });
});
