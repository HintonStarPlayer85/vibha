CREATE TABLE `site_content_overrides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`contentKey` varchar(180) NOT NULL,
	`value` text NOT NULL,
	`updatedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `site_content_overrides_id` PRIMARY KEY(`id`),
	CONSTRAINT `site_content_key_unique` UNIQUE(`contentKey`)
);
--> statement-breakpoint
ALTER TABLE `site_content_overrides` ADD CONSTRAINT `site_content_overrides_updatedByUserId_users_id_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `site_content_updated_at_idx` ON `site_content_overrides` (`updatedAt`);