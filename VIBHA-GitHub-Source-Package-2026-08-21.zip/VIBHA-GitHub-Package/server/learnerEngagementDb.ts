import { and, asc, desc, eq, gt, inArray } from "drizzle-orm";
import { certifications, onlineCompletionTranscripts, onlineCourseEnrollments, onlineCourseInvitations, onlineCourseLessons, onlineCourseModules, onlineCourses, onlineLearnerModuleNotes, users } from "../drizzle/schema";
import { getDb } from "./db";

export const learnerEngagementErrors = {
  transcriptNotEligible: "TRANSCRIPT_NOT_ELIGIBLE",
  transcriptNotFound: "TRANSCRIPT_NOT_FOUND",
  invitationInvalid: "COURSE_INVITATION_INVALID",
  invitationExpired: "COURSE_INVITATION_EXPIRED",
  invitationEmailMismatch: "COURSE_INVITATION_EMAIL_MISMATCH",
  invitationExists: "COURSE_INVITATION_EXISTS",
  courseNotPublished: "COURSE_INVITATION_COURSE_NOT_PUBLISHED",
  noteModuleInvalid: "LEARNER_NOTE_MODULE_INVALID",
  noteEnrollmentRequired: "LEARNER_NOTE_ENROLLMENT_REQUIRED",
} as const;

async function requireDb() { const db = await getDb(); if (!db) throw new Error("Database is not available."); return db; }
function normalizeEmail(value: string | null | undefined) { return value?.trim().toLowerCase() ?? ""; }

async function getLearnerEnrollment(courseSlug: string, userId: number) {
  const db = await requireDb();
  return (await db.select({ enrollment: onlineCourseEnrollments, course: onlineCourses, certification: certifications }).from(onlineCourseEnrollments).innerJoin(onlineCourses, eq(onlineCourseEnrollments.courseId, onlineCourses.id)).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(and(eq(certifications.slug, courseSlug), eq(onlineCourseEnrollments.userId, userId), inArray(onlineCourseEnrollments.status, ["enrolled", "completed"]))).limit(1))[0] ?? null;
}

export async function getTranscriptSource(courseSlug: string, userId: number) {
  const enrollment = await getLearnerEnrollment(courseSlug, userId);
  if (!enrollment || enrollment.enrollment.status !== "completed" || !enrollment.enrollment.completedAt) throw new Error(learnerEngagementErrors.transcriptNotEligible);
  const db = await requireDb();
  const modules = await db.select({ id: onlineCourseModules.id }).from(onlineCourseModules).where(and(eq(onlineCourseModules.courseId, enrollment.course.id), eq(onlineCourseModules.isPublished, true))).orderBy(asc(onlineCourseModules.position));
  const lessons = modules.length ? await db.select({ id: onlineCourseLessons.id }).from(onlineCourseLessons).where(and(inArray(onlineCourseLessons.moduleId, modules.map(module => module.id)), eq(onlineCourseLessons.isPublished, true))) : [];
  const learner = (await db.select({ name: users.name }).from(users).where(eq(users.id, userId)).limit(1))[0];
  return { enrollment: enrollment.enrollment, course: enrollment.course, certification: enrollment.certification, recipientName: learner?.name ?? "VIBHA Learner", moduleCount: modules.length, lessonCount: lessons.length };
}

export async function findTranscript(courseSlug: string, userId: number) {
  const source = await getTranscriptSource(courseSlug, userId);
  return (await (await requireDb()).select().from(onlineCompletionTranscripts).where(eq(onlineCompletionTranscripts.enrollmentId, source.enrollment.id)).limit(1))[0] ?? null;
}

export async function createTranscriptArtifact(input: { enrollmentId: number; recipientName: string; courseTitle: string; courseSlug: string; ceus: number; completedAt: Date; moduleCount: number; lessonCount: number; storageKey: string; url: string; checksum: string }) {
  const db = await requireDb();
  const result = await db.insert(onlineCompletionTranscripts).values({ enrollmentId: input.enrollmentId, recipientName: input.recipientName, courseTitle: input.courseTitle, courseSlug: input.courseSlug, ceus: String(input.ceus), completedAtSnapshot: input.completedAt, moduleCount: input.moduleCount, lessonCount: input.lessonCount, storageKey: input.storageKey, url: input.url, checksum: input.checksum });
  return (await db.select().from(onlineCompletionTranscripts).where(eq(onlineCompletionTranscripts.id, Number(result[0].insertId))).limit(1))[0]!;
}

export async function getTranscriptForDownload(courseSlug: string, userId: number) {
  const transcript = await findTranscript(courseSlug, userId);
  if (!transcript) throw new Error(learnerEngagementErrors.transcriptNotFound);
  return transcript;
}

export async function createCourseInvitationRecord(input: { courseId: number; recipientName: string; recipientEmail: string; tokenHash: string; expiresAt: Date; actorUserId: number }) {
  const db = await requireDb();
  const course = (await db.select({ id: onlineCourses.id, title: certifications.title, slug: certifications.slug }).from(onlineCourses).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(and(eq(onlineCourses.id, input.courseId), eq(onlineCourses.status, "published"), eq(certifications.status, "published"))).limit(1))[0];
  if (!course) throw new Error(learnerEngagementErrors.courseNotPublished);
  const recipientEmail = normalizeEmail(input.recipientEmail);
  const active = await db.select({ id: onlineCourseInvitations.id }).from(onlineCourseInvitations).where(and(eq(onlineCourseInvitations.courseId, input.courseId), eq(onlineCourseInvitations.recipientEmail, recipientEmail), eq(onlineCourseInvitations.status, "pending"), gt(onlineCourseInvitations.expiresAt, new Date()))).limit(1);
  if (active.length) throw new Error(learnerEngagementErrors.invitationExists);
  const result = await db.insert(onlineCourseInvitations).values({ courseId: input.courseId, recipientName: input.recipientName, recipientEmail, tokenHash: input.tokenHash, expiresAt: input.expiresAt, invitedByUserId: input.actorUserId });
  return { invitationId: Number(result[0].insertId), course };
}

export async function markCourseInvitationDelivery(input: { invitationId: number; providerMessageId?: string; error?: string }) {
  const db = await requireDb();
  await db.update(onlineCourseInvitations).set(input.error ? { deliveryStatus: "failed", deliveryError: input.error } : { deliveryStatus: "sent", providerMessageId: input.providerMessageId ?? null, sentAt: new Date(), deliveryError: null }).where(eq(onlineCourseInvitations.id, input.invitationId));
}

export async function listCourseInvitations(courseId: number) {
  const db = await requireDb();
  return db.select({ id: onlineCourseInvitations.id, recipientName: onlineCourseInvitations.recipientName, recipientEmail: onlineCourseInvitations.recipientEmail, status: onlineCourseInvitations.status, deliveryStatus: onlineCourseInvitations.deliveryStatus, sentAt: onlineCourseInvitations.sentAt, acceptedAt: onlineCourseInvitations.acceptedAt, expiresAt: onlineCourseInvitations.expiresAt, deliveryError: onlineCourseInvitations.deliveryError, createdAt: onlineCourseInvitations.createdAt }).from(onlineCourseInvitations).where(eq(onlineCourseInvitations.courseId, courseId)).orderBy(desc(onlineCourseInvitations.createdAt));
}

export async function acceptCourseInvitation(input: { tokenHash: string; userId: number; userEmail: string | null | undefined }) {
  const db = await requireDb(); const now = new Date(); const userEmail = normalizeEmail(input.userEmail);
  return db.transaction(async tx => {
    const invitation = (await tx.select().from(onlineCourseInvitations).where(eq(onlineCourseInvitations.tokenHash, input.tokenHash)).limit(1))[0];
    if (!invitation || invitation.status !== "pending") throw new Error(learnerEngagementErrors.invitationInvalid);
    if (invitation.expiresAt.getTime() <= now.getTime()) { await tx.update(onlineCourseInvitations).set({ status: "expired" }).where(eq(onlineCourseInvitations.id, invitation.id)); throw new Error(learnerEngagementErrors.invitationExpired); }
    if (!userEmail || normalizeEmail(invitation.recipientEmail) !== userEmail) throw new Error(learnerEngagementErrors.invitationEmailMismatch);
    const course = (await tx.select({ id: onlineCourses.id, slug: certifications.slug }).from(onlineCourses).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(and(eq(onlineCourses.id, invitation.courseId), eq(onlineCourses.status, "published"), eq(certifications.status, "published"))).limit(1))[0];
    if (!course) throw new Error(learnerEngagementErrors.courseNotPublished);
    const claimed = await tx.update(onlineCourseInvitations).set({ status: "accepted", acceptedByUserId: input.userId, acceptedAt: now }).where(and(eq(onlineCourseInvitations.id, invitation.id), eq(onlineCourseInvitations.status, "pending")));
    if (Number(claimed[0].affectedRows) !== 1) throw new Error(learnerEngagementErrors.invitationInvalid);
    const existing = (await tx.select().from(onlineCourseEnrollments).where(and(eq(onlineCourseEnrollments.courseId, course.id), eq(onlineCourseEnrollments.userId, input.userId))).limit(1))[0];
    if (existing?.status === "withdrawn") await tx.update(onlineCourseEnrollments).set({ status: "enrolled", completedAt: null, lastAccessedAt: now }).where(eq(onlineCourseEnrollments.id, existing.id));
    else if (!existing) await tx.insert(onlineCourseEnrollments).values({ courseId: course.id, userId: input.userId });
    return { courseSlug: course.slug, invitationId: invitation.id };
  });
}

export async function listLearnerNotes(courseSlug: string, userId: number) {
  const enrollment = await getLearnerEnrollment(courseSlug, userId); if (!enrollment) throw new Error(learnerEngagementErrors.noteEnrollmentRequired);
  const db = await requireDb();
  return db.select({ id: onlineLearnerModuleNotes.id, moduleId: onlineLearnerModuleNotes.moduleId, moduleTitle: onlineCourseModules.title, content: onlineLearnerModuleNotes.content, updatedAt: onlineLearnerModuleNotes.updatedAt }).from(onlineLearnerModuleNotes).innerJoin(onlineCourseModules, eq(onlineLearnerModuleNotes.moduleId, onlineCourseModules.id)).where(and(eq(onlineLearnerModuleNotes.userId, userId), eq(onlineLearnerModuleNotes.courseId, enrollment.course.id))).orderBy(desc(onlineLearnerModuleNotes.updatedAt));
}

export async function listAllLearnerNotes(userId: number) {
  const db = await requireDb();
  return db.select({ id: onlineLearnerModuleNotes.id, courseSlug: certifications.slug, courseTitle: certifications.title, moduleId: onlineLearnerModuleNotes.moduleId, moduleTitle: onlineCourseModules.title, content: onlineLearnerModuleNotes.content, updatedAt: onlineLearnerModuleNotes.updatedAt }).from(onlineLearnerModuleNotes).innerJoin(onlineCourses, eq(onlineLearnerModuleNotes.courseId, onlineCourses.id)).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).innerJoin(onlineCourseModules, eq(onlineLearnerModuleNotes.moduleId, onlineCourseModules.id)).where(eq(onlineLearnerModuleNotes.userId, userId)).orderBy(desc(onlineLearnerModuleNotes.updatedAt));
}

export async function upsertLearnerModuleNote(input: { courseSlug: string; moduleId: number; content: string; userId: number }) {
  const enrollment = await getLearnerEnrollment(input.courseSlug, input.userId); if (!enrollment) throw new Error(learnerEngagementErrors.noteEnrollmentRequired);
  const db = await requireDb();
  const module = (await db.select({ id: onlineCourseModules.id }).from(onlineCourseModules).where(and(eq(onlineCourseModules.id, input.moduleId), eq(onlineCourseModules.courseId, enrollment.course.id), eq(onlineCourseModules.isPublished, true))).limit(1))[0];
  if (!module) throw new Error(learnerEngagementErrors.noteModuleInvalid);
  await db.insert(onlineLearnerModuleNotes).values({ userId: input.userId, courseId: enrollment.course.id, moduleId: input.moduleId, content: input.content }).onDuplicateKeyUpdate({ set: { content: input.content, updatedAt: new Date() } });
  return (await db.select().from(onlineLearnerModuleNotes).where(and(eq(onlineLearnerModuleNotes.userId, input.userId), eq(onlineLearnerModuleNotes.moduleId, input.moduleId))).limit(1))[0]!;
}

export async function deleteLearnerModuleNote(input: { courseSlug: string; moduleId: number; userId: number }) {
  const enrollment = await getLearnerEnrollment(input.courseSlug, input.userId); if (!enrollment) throw new Error(learnerEngagementErrors.noteEnrollmentRequired);
  const db = await requireDb();
  await db.delete(onlineLearnerModuleNotes).where(and(eq(onlineLearnerModuleNotes.userId, input.userId), eq(onlineLearnerModuleNotes.courseId, enrollment.course.id), eq(onlineLearnerModuleNotes.moduleId, input.moduleId)));
  return { success: true as const };
}
