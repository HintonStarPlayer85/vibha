import {
  and,
  asc,
  count,
  desc,
  eq,
  gte,
  like,
  lte,
  ne,
  or,
  sql,
} from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  certificationCategories,
  certificationInstructors,
  certifications,
  inquiries,
  instructors,
  InsertUser,
  users,
} from "../drizzle/schema";
import type { CatalogQuery, CertificationInput, InquiryInput } from "../shared/catalog";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  textFields.forEach(field => {
    const value = user[field];
    if (value === undefined) return;
    values[field] = value ?? null;
    updateSet[field] = value ?? null;
  });
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "owner";
    updateSet.role = "owner";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  return (await db.select().from(users).where(eq(users.openId, openId)).limit(1))[0];
}

const publicFields = {
  id: certifications.id,
  title: certifications.title,
  shortTitle: certifications.shortTitle,
  slug: certifications.slug,
  description: certifications.description,
  summary: certifications.summary,
  valueStatement: certifications.valueStatement,
  objectives: certifications.objectives,
  curriculumTopics: certifications.curriculumTopics,
  idealAudience: certifications.idealAudience,
  eligibilityRequirements: certifications.eligibilityRequirements,
  prerequisites: certifications.prerequisites,
  format: certifications.format,
  deliveryLocation: certifications.deliveryLocation,
  deliveryMethods: certifications.deliveryMethods,
  schedule: certifications.schedule,
  duration: certifications.duration,
  ceus: certifications.ceus,
  costCents: certifications.cost,
  costDisplay: certifications.costDisplay,
  level: certifications.level,
  careerRelevance: certifications.careerRelevance,
  enrollmentUrl: certifications.enrollmentUrl,
  inquiryType: certifications.inquiryType,
  status: certifications.status,
  isFeatured: certifications.isFeatured,
  displayOrder: certifications.displayOrder,
  seoTitle: certifications.seoTitle,
  seoDescription: certifications.seoDescription,
  publishedAt: certifications.publishedAt,
  updatedAt: certifications.updatedAt,
  categoryId: certificationCategories.id,
  categoryName: certificationCategories.name,
  categorySlug: certificationCategories.slug,
  categoryDescription: certificationCategories.shortDescription,
};

function catalogConditions(input: CatalogQuery) {
  const conditions = [eq(certifications.status, "published"), eq(certificationCategories.isActive, true)];
  if (input.q) {
    const pattern = `%${input.q}%`;
    conditions.push(
      or(
        like(certifications.title, pattern),
        like(certifications.summary, pattern),
        like(certifications.description, pattern),
        like(certifications.level, pattern),
        like(certificationCategories.name, pattern),
        sql`CAST(${certifications.objectives} AS CHAR) LIKE ${pattern}`,
        sql`CAST(${certifications.idealAudience} AS CHAR) LIKE ${pattern}`,
      )!,
    );
  }
  if (input.category) conditions.push(eq(certificationCategories.slug, input.category));
  if (input.format) {
    const formatMap = {
      "virtual-live": "Virtual Live",
      hybrid: "Hybrid",
      evening: "Evening",
      weekend: "Weekend",
      onsite: "Onsite",
    } as const;
    const pattern = `%${formatMap[input.format]}%`;
    conditions.push(
      or(
        like(certifications.format, pattern),
        sql`CAST(${certifications.deliveryMethods} AS CHAR) LIKE ${pattern}`,
      )!,
    );
  }
  if (input.ceu === "not-listed") conditions.push(eq(certifications.ceus, "0.00"));
  if (input.ceu === "0.1-2")
    conditions.push(and(gte(certifications.ceus, "0.10"), lte(certifications.ceus, "2.00"))!);
  if (input.ceu === "2.1-5")
    conditions.push(and(gte(certifications.ceus, "2.01"), lte(certifications.ceus, "5.00"))!);
  if (input.ceu === "5-plus") conditions.push(gte(certifications.ceus, "5.01"));
  if (input.cost === "under-1000") conditions.push(lte(certifications.cost, 99999));
  if (input.cost === "1000-1499")
    conditions.push(and(gte(certifications.cost, 100000), lte(certifications.cost, 149999))!);
  if (input.cost === "1500-1999")
    conditions.push(and(gte(certifications.cost, 150000), lte(certifications.cost, 199999))!);
  if (input.cost === "2000-plus") conditions.push(gte(certifications.cost, 200000));
  return and(...conditions);
}

export async function getCertificationCategories(includeInactive = false) {
  const db = await requireDb();
  const where = includeInactive ? undefined : eq(certificationCategories.isActive, true);
  return db
    .select()
    .from(certificationCategories)
    .where(where)
    .orderBy(asc(certificationCategories.displayOrder), asc(certificationCategories.name));
}

export async function getCatalog(input: CatalogQuery) {
  const db = await requireDb();
  const where = catalogConditions(input);
  const offset = (input.page - 1) * input.pageSize;
  const items = await db
    .select(publicFields)
    .from(certifications)
    .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
    .where(where)
    .orderBy(asc(certifications.displayOrder), asc(certifications.title))
    .limit(input.pageSize)
    .offset(offset);
  const totalResult = await db
    .select({ total: count() })
    .from(certifications)
    .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
    .where(where);
  const total = Number(totalResult[0]?.total ?? 0);
  return {
    items: items.map(item => ({ ...item, ceus: Number(item.ceus) })),
    total,
    page: input.page,
    pageSize: input.pageSize,
    totalPages: Math.max(1, Math.ceil(total / input.pageSize)),
  };
}

export async function getFeaturedCertifications(limit = 8) {
  const db = await requireDb();
  const rows = await db
    .select(publicFields)
    .from(certifications)
    .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
    .where(
      and(
        eq(certifications.status, "published"),
        eq(certifications.isFeatured, true),
        eq(certificationCategories.isActive, true),
      ),
    )
    .orderBy(asc(certifications.displayOrder))
    .limit(limit);
  return rows.map(row => ({ ...row, ceus: Number(row.ceus) }));
}

export async function getCertificationBySlug(slug: string) {
  const db = await requireDb();
  const certification = (
    await db
      .select(publicFields)
      .from(certifications)
      .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
      .where(and(eq(certifications.slug, slug), eq(certifications.status, "published")))
      .limit(1)
  )[0];
  if (!certification) return null;

  const faculty = await db
    .select({
      id: instructors.id,
      name: instructors.name,
      credentials: instructors.credentials,
      title: instructors.title,
      biography: instructors.biography,
      photoUrl: instructors.photoUrl,
    })
    .from(certificationInstructors)
    .innerJoin(instructors, eq(certificationInstructors.instructorId, instructors.id))
    .where(
      and(
        eq(certificationInstructors.certificationId, certification.id),
        eq(instructors.isActive, true),
      ),
    )
    .orderBy(asc(certificationInstructors.displayOrder));

  const related = await db
    .select({
      id: certifications.id,
      title: certifications.title,
      slug: certifications.slug,
      summary: certifications.summary,
      level: certifications.level,
      duration: certifications.duration,
      costDisplay: certifications.costDisplay,
      categoryName: certificationCategories.name,
    })
    .from(certifications)
    .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
    .where(
      and(
        eq(certifications.status, "published"),
        eq(certifications.category, certification.categoryId),
        ne(certifications.id, certification.id),
      ),
    )
    .orderBy(asc(certifications.displayOrder))
    .limit(3);

  return { ...certification, ceus: Number(certification.ceus), instructors: faculty, related };
}

export async function getFilterOptions() {
  const db = await requireDb();
  const [categories, levels] = await Promise.all([
    getCertificationCategories(false),
    db
      .selectDistinct({ value: certifications.level })
      .from(certifications)
      .where(eq(certifications.status, "published"))
      .orderBy(asc(certifications.level)),
  ]);
  return {
    categories,
    levels: levels.map(level => level.value),
    formats: [
      { value: "virtual-live", label: "Virtual live" },
      { value: "hybrid", label: "Hybrid" },
      { value: "evening", label: "Evening" },
      { value: "weekend", label: "Weekend" },
      { value: "onsite", label: "Onsite / agency" },
    ],
    ceuRanges: [
      { value: "not-listed", label: "CEUs not yet listed" },
      { value: "0.1-2", label: "0.1–2.0 CEUs" },
      { value: "2.1-5", label: "2.1–5.0 CEUs" },
      { value: "5-plus", label: "More than 5 CEUs" },
    ],
    costRanges: [
      { value: "under-1000", label: "Under $1,000" },
      { value: "1000-1499", label: "$1,000–$1,499" },
      { value: "1500-1999", label: "$1,500–$1,999" },
      { value: "2000-plus", label: "$2,000 and above" },
    ],
  };
}

export async function getPublishedSitemapCertifications() {
  const db = await requireDb();
  return db
    .select({ slug: certifications.slug, updatedAt: certifications.updatedAt })
    .from(certifications)
    .where(eq(certifications.status, "published"))
    .orderBy(asc(certifications.slug));
}

export async function getAdminCatalog(input: { q?: string; status?: string }) {
  const db = await requireDb();
  const conditions = [];
  if (input.status) conditions.push(eq(certifications.status, input.status as typeof certifications.status.enumValues[number]));
  if (input.q) {
    const pattern = `%${input.q}%`;
    conditions.push(or(like(certifications.title, pattern), like(certifications.slug, pattern))!);
  }
  return db
    .select({
      ...publicFields,
      createdAt: certifications.createdAt,
    })
    .from(certifications)
    .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(certifications.updatedAt), asc(certifications.title));
}

export async function getAdminCertificationById(id: number) {
  const db = await requireDb();
  const certification = (
    await db
      .select({ ...publicFields, createdAt: certifications.createdAt })
      .from(certifications)
      .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
      .where(eq(certifications.id, id))
      .limit(1)
  )[0];
  if (!certification) return null;
  const assigned = await db
    .select({ id: instructors.id })
    .from(certificationInstructors)
    .innerJoin(instructors, eq(certificationInstructors.instructorId, instructors.id))
    .where(eq(certificationInstructors.certificationId, id));
  return { ...certification, ceus: Number(certification.ceus), instructorIds: assigned.map(row => row.id) };
}

export async function getInstructors() {
  const db = await requireDb();
  return db.select().from(instructors).where(eq(instructors.isActive, true)).orderBy(asc(instructors.name));
}

function nullable(value: string | null | undefined) {
  return value?.trim() ? value.trim() : null;
}

function inputValues(input: CertificationInput) {
  return {
    title: input.title,
    shortTitle: nullable(input.shortTitle),
    slug: input.slug,
    category: input.categoryId,
    description: input.description,
    summary: input.summary,
    valueStatement: nullable(input.valueStatement),
    objectives: input.objectives,
    curriculumTopics: input.curriculumTopics,
    idealAudience: input.idealAudience,
    eligibilityRequirements: input.eligibilityRequirements,
    prerequisites: input.prerequisites,
    format: input.format,
    deliveryLocation: input.deliveryLocation,
    deliveryMethods: input.deliveryMethods,
    schedule: input.schedule,
    duration: input.duration,
    ceus: input.ceus.toFixed(2),
    cost: input.costCents,
    costDisplay: input.costDisplay,
    level: input.level,
    careerRelevance: nullable(input.careerRelevance),
    enrollmentUrl: nullable(input.enrollmentUrl),
    inquiryType: input.inquiryType,
    status: input.status,
    isFeatured: input.isFeatured,
    displayOrder: input.displayOrder,
    seoTitle: nullable(input.seoTitle),
    seoDescription: nullable(input.seoDescription),
    publishedAt: input.status === "published" ? new Date() : null,
  };
}

async function assignInstructors(certificationId: number, instructorIds: number[]) {
  const db = await requireDb();
  await db.delete(certificationInstructors).where(eq(certificationInstructors.certificationId, certificationId));
  if (instructorIds.length) {
    await db.insert(certificationInstructors).values(
      instructorIds.map((instructorId, index) => ({
        certificationId,
        instructorId,
        displayOrder: (index + 1) * 10,
      })),
    );
  }
}

export async function createCertification(input: CertificationInput) {
  const db = await requireDb();
  const existing = await db
    .select({ id: certifications.id })
    .from(certifications)
    .where(eq(certifications.slug, input.slug))
    .limit(1);
  if (existing.length) throw new Error("SLUG_CONFLICT");
  await db.insert(certifications).values(inputValues(input));
  const created = (
    await db
      .select({ id: certifications.id })
      .from(certifications)
      .where(eq(certifications.slug, input.slug))
      .limit(1)
  )[0];
  if (!created) throw new Error("CREATE_FAILED");
  await assignInstructors(created.id, input.instructorIds);
  return getAdminCertificationById(created.id);
}

export async function updateCertification(id: number, input: CertificationInput) {
  const db = await requireDb();
  const conflict = await db
    .select({ id: certifications.id })
    .from(certifications)
    .where(and(eq(certifications.slug, input.slug), ne(certifications.id, id)))
    .limit(1);
  if (conflict.length) throw new Error("SLUG_CONFLICT");
  await db.update(certifications).set(inputValues(input)).where(eq(certifications.id, id));
  await assignInstructors(id, input.instructorIds);
  return getAdminCertificationById(id);
}

export async function setCertificationStatus(id: number, status: CertificationInput["status"]) {
  const db = await requireDb();
  await db
    .update(certifications)
    .set({ status, publishedAt: status === "published" ? new Date() : null })
    .where(eq(certifications.id, id));
  return getAdminCertificationById(id);
}

export async function createInquiry(input: InquiryInput) {
  const db = await requireDb();
  await db.insert(inquiries).values({
    inquiryType: input.inquiryType,
    certificationId: input.certificationId ?? null,
    programRoute: nullable(input.programRoute),
    name: input.name,
    email: input.email.toLowerCase(),
    phone: nullable(input.phone),
    organization: nullable(input.organization),
    organizationType: nullable(input.organizationType),
    workforceSize: nullable(input.workforceSize),
    priority: nullable(input.priority),
    timeline: nullable(input.timeline),
    message: input.message,
    consent: input.consent,
    sourcePath: nullable(input.sourcePath),
    status: "new",
  });
  return { success: true as const, route: input.programRoute ?? input.inquiryType };
}
