import { and, asc, countDistinct, desc, eq, like, or, sql } from "drizzle-orm";
import {
  administrationAuditEvents,
  certificationCategories,
  certifications,
  cohortCommunications,
  cohortResources,
  cohorts,
  cohortStudents,
  instructors,
} from "../drizzle/schema";
import type {
  CohortInput,
  CohortListQuery,
  CohortResourceLinkInput,
  CohortStudentInput,
} from "../shared/administration";
import { getDb } from "./db";

export const cohortErrors = {
  slugConflict: "COHORT_SLUG_CONFLICT",
  notFound: "COHORT_NOT_FOUND",
  studentNotFound: "COHORT_STUDENT_NOT_FOUND",
  duplicateStudent: "COHORT_STUDENT_DUPLICATE",
  resourceNotFound: "COHORT_RESOURCE_NOT_FOUND",
} as const;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

function cohortValues(input: CohortInput, actorUserId: number) {
  return {
    title: input.title,
    slug: input.slug,
    certificationId: input.certificationId,
    instructorId: input.instructorId,
    certificateSignatoryInstructorId: input.certificateSignatoryInstructorId,
    status: input.status,
    startAt: input.startAt,
    endAt: input.endAt,
    timeZone: input.timeZone,
    scheduleSummary: input.scheduleSummary || null,
    zoomUrl: input.zoomUrl || null,
    zoomMeetingId: input.zoomMeetingId || null,
    zoomPasscode: input.zoomPasscode || null,
    administratorNotes: input.administratorNotes || null,
    updatedByUserId: actorUserId,
  };
}

async function assertUniqueSlug(slug: string, ignoreId?: number) {
  const db = await requireDb();
  const match = (
    await db.select({ id: cohorts.id }).from(cohorts).where(eq(cohorts.slug, slug)).limit(1)
  )[0];
  if (match && match.id !== ignoreId) throw new Error(cohortErrors.slugConflict);
}

export async function listCohorts(query: CohortListQuery) {
  const db = await requireDb();
  const conditions = [];
  if (query.q) {
    const term = `%${query.q}%`;
    conditions.push(
      or(
        like(cohorts.title, term),
        like(cohorts.slug, term),
        like(certifications.title, term),
        like(instructors.name, term),
      ),
    );
  }
  if (query.status) conditions.push(eq(cohorts.status, query.status));
  return db
    .select({
      id: cohorts.id,
      title: cohorts.title,
      slug: cohorts.slug,
      status: cohorts.status,
      startAt: cohorts.startAt,
      endAt: cohorts.endAt,
      timeZone: cohorts.timeZone,
      certificationId: cohorts.certificationId,
      certificationTitle: certifications.title,
      instructorId: cohorts.instructorId,
      instructorName: instructors.name,
      studentCount: countDistinct(cohortStudents.id),
      communicationCount: countDistinct(cohortCommunications.id),
      latestCommunicationStatus: sql<"draft" | "processing" | "partial" | "sent" | "failed" | "cancelled" | null>`(
        SELECT communication.status
        FROM cohort_communications communication
        WHERE communication.cohortId = ${cohorts.id}
        ORDER BY communication.createdAt DESC
        LIMIT 1
      )`,
      updatedAt: cohorts.updatedAt,
    })
    .from(cohorts)
    .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
    .leftJoin(instructors, eq(cohorts.instructorId, instructors.id))
    .leftJoin(cohortStudents, and(eq(cohortStudents.cohortId, cohorts.id), eq(cohortStudents.status, "active")))
    .leftJoin(cohortCommunications, eq(cohortCommunications.cohortId, cohorts.id))
    .where(conditions.length ? and(...conditions) : undefined)
    .groupBy(cohorts.id, certifications.id, instructors.id)
    .orderBy(desc(cohorts.startAt), asc(cohorts.title));
}

export async function getCohortById(id: number) {
  const db = await requireDb();
  const cohort = (
    await db
      .select({
        id: cohorts.id,
        title: cohorts.title,
        slug: cohorts.slug,
        certificationId: cohorts.certificationId,
        certificationTitle: certifications.title,
        categoryName: certificationCategories.name,
        instructorId: cohorts.instructorId,
        instructorName: instructors.name,
        certificateSignatoryInstructorId: cohorts.certificateSignatoryInstructorId,
        status: cohorts.status,
        startAt: cohorts.startAt,
        endAt: cohorts.endAt,
        timeZone: cohorts.timeZone,
        scheduleSummary: cohorts.scheduleSummary,
        zoomUrl: cohorts.zoomUrl,
        zoomMeetingId: cohorts.zoomMeetingId,
        zoomPasscode: cohorts.zoomPasscode,
        administratorNotes: cohorts.administratorNotes,
        createdAt: cohorts.createdAt,
        updatedAt: cohorts.updatedAt,
      })
      .from(cohorts)
      .innerJoin(certifications, eq(cohorts.certificationId, certifications.id))
      .innerJoin(certificationCategories, eq(certifications.category, certificationCategories.id))
      .leftJoin(instructors, eq(cohorts.instructorId, instructors.id))
      .where(eq(cohorts.id, id))
      .limit(1)
  )[0];
  if (!cohort) return null;

  const [students, resources, communications] = await Promise.all([
    db.select().from(cohortStudents).where(eq(cohortStudents.cohortId, id)).orderBy(asc(cohortStudents.name)),
    db.select().from(cohortResources).where(eq(cohortResources.cohortId, id)).orderBy(asc(cohortResources.displayOrder), desc(cohortResources.createdAt)),
    db
      .select({
        id: cohortCommunications.id,
        communicationType: cohortCommunications.communicationType,
        subject: cohortCommunications.subject,
        status: cohortCommunications.status,
        recipientCount: cohortCommunications.recipientCount,
        acceptedCount: cohortCommunications.acceptedCount,
        deliveredCount: cohortCommunications.deliveredCount,
        failedCount: cohortCommunications.failedCount,
        bouncedCount: cohortCommunications.bouncedCount,
        complainedCount: cohortCommunications.complainedCount,
        sentAt: cohortCommunications.sentAt,
        createdAt: cohortCommunications.createdAt,
      })
      .from(cohortCommunications)
      .where(eq(cohortCommunications.cohortId, id))
      .orderBy(desc(cohortCommunications.createdAt)),
  ]);
  return { ...cohort, students, resources, communications };
}

export async function getCohortOptions() {
  const db = await requireDb();
  const [programs, faculty] = await Promise.all([
    db
      .select({ id: certifications.id, title: certifications.title, status: certifications.status })
      .from(certifications)
      .orderBy(asc(certifications.title)),
    db
      .select({ id: instructors.id, name: instructors.name, title: instructors.title, isActive: instructors.isActive })
      .from(instructors)
      .orderBy(desc(instructors.isActive), asc(instructors.name)),
  ]);
  return { programs, instructors: faculty };
}

export async function createCohort(input: CohortInput, actorUserId: number) {
  const db = await requireDb();
  await assertUniqueSlug(input.slug);
  const id = await db.transaction(async tx => {
    const result = await tx.insert(cohorts).values({
      ...cohortValues(input, actorUserId),
      createdByUserId: actorUserId,
    });
    const cohortId = Number(result[0].insertId);
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "cohort.created",
      entityType: "cohort",
      entityId: String(cohortId),
      eventMetadata: { certificationId: input.certificationId, status: input.status },
    });
    return cohortId;
  });
  return getCohortById(id);
}

export async function updateCohort(id: number, input: CohortInput, actorUserId: number) {
  const db = await requireDb();
  if (!(await getCohortById(id))) throw new Error(cohortErrors.notFound);
  await assertUniqueSlug(input.slug, id);
  await db.transaction(async tx => {
    await tx.update(cohorts).set(cohortValues(input, actorUserId)).where(eq(cohorts.id, id));
    await tx.insert(administrationAuditEvents).values({
      actorUserId,
      action: "cohort.updated",
      entityType: "cohort",
      entityId: String(id),
      eventMetadata: { certificationId: input.certificationId, status: input.status },
    });
  });
  return getCohortById(id);
}

export async function addCohortStudent(cohortId: number, input: CohortStudentInput, actorUserId: number) {
  const db = await requireDb();
  const duplicate = await db
    .select({ id: cohortStudents.id })
    .from(cohortStudents)
    .where(and(eq(cohortStudents.cohortId, cohortId), eq(cohortStudents.email, input.email)))
    .limit(1);
  if (duplicate.length) throw new Error(cohortErrors.duplicateStudent);
  const result = await db.insert(cohortStudents).values({ ...input, cohortId, createdByUserId: actorUserId });
  const id = Number(result[0].insertId);
  await db.insert(administrationAuditEvents).values({ actorUserId, action: "cohort.student.added", entityType: "cohort_student", entityId: String(id), eventMetadata: { cohortId } });
  return (await db.select().from(cohortStudents).where(eq(cohortStudents.id, id)).limit(1))[0];
}

export async function updateCohortStudent(id: number, input: CohortStudentInput, actorUserId: number) {
  const db = await requireDb();
  const current = (await db.select().from(cohortStudents).where(eq(cohortStudents.id, id)).limit(1))[0];
  if (!current) throw new Error(cohortErrors.studentNotFound);
  const duplicate = await db
    .select({ id: cohortStudents.id })
    .from(cohortStudents)
    .where(and(eq(cohortStudents.cohortId, current.cohortId), eq(cohortStudents.email, input.email)))
    .limit(1);
  if (duplicate[0] && duplicate[0].id !== id) throw new Error(cohortErrors.duplicateStudent);
  const reviewState = input.status !== "completed"
    ? { completionApprovalStatus: "not_requested" as const, completionReviewedByUserId: null, completionReviewedAt: null, completionReviewNotes: null, completionApprovalRequestedAt: null }
    : current.status !== "completed"
      ? { completionApprovalStatus: "pending" as const, completionReviewedByUserId: null, completionReviewedAt: null, completionReviewNotes: null, completionApprovalRequestedAt: new Date() }
      : {};
  await db.update(cohortStudents).set({ ...input, ...reviewState }).where(eq(cohortStudents.id, id));
  await db.insert(administrationAuditEvents).values({ actorUserId, action: input.status === "completed" && current.status !== "completed" ? "cohort.student.completion_submitted" : "cohort.student.updated", entityType: "cohort_student", entityId: String(id), eventMetadata: { cohortId: current.cohortId, status: input.status } });
  return (await db.select().from(cohortStudents).where(eq(cohortStudents.id, id)).limit(1))[0];
}

export async function removeCohortStudent(id: number, actorUserId: number) {
  const db = await requireDb();
  const current = (await db.select({ id: cohortStudents.id, cohortId: cohortStudents.cohortId }).from(cohortStudents).where(eq(cohortStudents.id, id)).limit(1))[0];
  if (!current) throw new Error(cohortErrors.studentNotFound);
  await db.delete(cohortStudents).where(eq(cohortStudents.id, id));
  await db.insert(administrationAuditEvents).values({ actorUserId, action: "cohort.student.removed", entityType: "cohort_student", entityId: String(id), eventMetadata: { cohortId: current.cohortId } });
  return { success: true as const };
}

export async function createCohortResource(input: {
  cohortId: number;
  title: string;
  description?: string | null;
  resourceType: "syllabus" | "schedule" | "document" | "link" | "other";
  audience: "all" | "students" | "instructors" | "administrators";
  sourceType: "file" | "link";
  url: string;
  storageKey?: string | null;
  fileName?: string | null;
  mimeType?: string | null;
  fileSize?: number | null;
  displayOrder: number;
  isActive?: boolean;
  actorUserId: number;
}) {
  const db = await requireDb();
  if (!(await getCohortById(input.cohortId))) throw new Error(cohortErrors.notFound);
  const result = await db.insert(cohortResources).values({
    cohortId: input.cohortId,
    title: input.title,
    description: input.description || null,
    resourceType: input.resourceType,
    audience: input.audience,
    sourceType: input.sourceType,
    url: input.url,
    storageKey: input.storageKey || null,
    fileName: input.fileName || null,
    mimeType: input.mimeType || null,
    fileSize: input.fileSize || null,
    displayOrder: input.displayOrder,
    isActive: input.isActive ?? true,
    createdByUserId: input.actorUserId,
    updatedByUserId: input.actorUserId,
  });
  const id = Number(result[0].insertId);
  await db.insert(administrationAuditEvents).values({ actorUserId: input.actorUserId, action: "cohort.resource.created", entityType: "cohort_resource", entityId: String(id), eventMetadata: { cohortId: input.cohortId, sourceType: input.sourceType } });
  return (await db.select().from(cohortResources).where(eq(cohortResources.id, id)).limit(1))[0];
}

export async function createCohortResourceLink(input: CohortResourceLinkInput, actorUserId: number) {
  return createCohortResource({ ...input, sourceType: "link", actorUserId });
}

export async function setCohortResourceStatus(id: number, isActive: boolean, actorUserId: number) {
  const db = await requireDb();
  const current = (await db.select({ id: cohortResources.id, cohortId: cohortResources.cohortId }).from(cohortResources).where(eq(cohortResources.id, id)).limit(1))[0];
  if (!current) throw new Error(cohortErrors.resourceNotFound);
  await db.update(cohortResources).set({ isActive, updatedByUserId: actorUserId }).where(eq(cohortResources.id, id));
  await db.insert(administrationAuditEvents).values({ actorUserId, action: isActive ? "cohort.resource.activated" : "cohort.resource.deactivated", entityType: "cohort_resource", entityId: String(id), eventMetadata: { cohortId: current.cohortId } });
  return { success: true as const, isActive };
}

export async function updateCohortResourceSettings(
  id: number,
  audience: "all" | "students" | "instructors" | "administrators",
  displayOrder: number,
  actorUserId: number,
) {
  const db = await requireDb();
  const current = (await db.select({ id: cohortResources.id, cohortId: cohortResources.cohortId }).from(cohortResources).where(eq(cohortResources.id, id)).limit(1))[0];
  if (!current) throw new Error(cohortErrors.resourceNotFound);
  await db.update(cohortResources).set({ audience, displayOrder, updatedByUserId: actorUserId }).where(eq(cohortResources.id, id));
  await db.insert(administrationAuditEvents).values({
    actorUserId,
    action: "cohort.resource.settings.updated",
    entityType: "cohort_resource",
    entityId: String(id),
    eventMetadata: { cohortId: current.cohortId, audience, displayOrder },
  });
  return { success: true as const, audience, displayOrder };
}
