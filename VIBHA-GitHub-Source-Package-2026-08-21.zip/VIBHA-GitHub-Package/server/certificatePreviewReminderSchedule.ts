import type { Express, Request, Response } from "express";
import { sdk } from "./_core/sdk";
import { runCertificatePreviewReminderSweep } from "./certificatePreviewReminderService";
import { runCertificateApprovalEscalationSweep } from "./certificateApprovalEscalationService";

export function registerCertificatePreviewReminderSchedule(app: Express) {
  app.post("/api/scheduled/certificate-preview-reminders", async (req: Request, res: Response) => {
    try {
      const user = await sdk.authenticateRequest(req);
      if (!user.isCron || !user.taskUid) return res.status(403).json({ error: "cron-only" });
      const [previewReminders, approvalEscalations] = await Promise.all([
        runCertificatePreviewReminderSweep(user.taskUid),
        runCertificateApprovalEscalationSweep(),
      ]);
      return res.json({ previewReminders, approvalEscalations });
    } catch (error) {
      const detail = error instanceof Error ? { message: error.message, stack: error.stack } : { message: String(error) };
      return res.status(500).json({ error: "certificate-preview-reminder-failed", detail, timestamp: new Date().toISOString() });
    }
  });
}
