import { randomUUID } from "node:crypto";
import { Resend } from "resend";
import { and, eq } from "drizzle-orm";
import { certificateProgramProfiles, certificateTemplateTestDeliveries, certifications, users } from "../drizzle/schema";
import { getDb } from "./db";
import { getResendConfiguration, verifyResendSenderDomain } from "./resendCohort";

const merge = (template: string, values: Record<string, string>) => template.replace(/\{\{\s*(administratorName|credentialTitle|cohortTitle|expiresAt|studentName)\s*\}\}/g, (_match, key: string) => values[key] ?? "");
const escapeHtml = (value: string) => value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]!);

export async function sendCertificateTemplateTest(input: { certificationId: number; templateType: "preview_reminder" | "approval_escalation"; actorUserId: number }) {
  const db = await getDb();
  if (!db) throw new Error("DATABASE_UNAVAILABLE");
  const row = (await db.select({ title: certifications.title, reminderSubject: certificateProgramProfiles.previewReminderEmailSubject, reminderBody: certificateProgramProfiles.previewReminderEmailBody, escalationSubject: certificateProgramProfiles.approvalEscalationEmailSubject, escalationBody: certificateProgramProfiles.approvalEscalationEmailBody, recipientName: users.name, recipientEmail: users.email }).from(certifications).leftJoin(certificateProgramProfiles, eq(certificateProgramProfiles.certificationId, certifications.id)).innerJoin(users, eq(users.id, input.actorUserId)).where(eq(certifications.id, input.certificationId)).limit(1))[0];
  if (!row?.recipientEmail) throw new Error("ADMINISTRATOR_EMAIL_REQUIRED");
  const subjectTemplate = input.templateType === "preview_reminder" ? row.reminderSubject : row.escalationSubject;
  const bodyTemplate = input.templateType === "preview_reminder" ? row.reminderBody : row.escalationBody;
  const values = { administratorName: row.recipientName ?? "Administrator", credentialTitle: row.title, cohortTitle: "Sample cohort", expiresAt: "Sample expiration", studentName: "Sample learner" };
  const fallback = input.templateType === "preview_reminder" ? "This is a test of the VIBHA certificate preview reminder template." : "This is a test of the VIBHA delayed-approval escalation template.";
  const subject = `[TEST] ${merge(subjectTemplate || fallback, values).slice(0, 232)}`;
  const body = merge(bodyTemplate || fallback, values);
  const inserted = await db.insert(certificateTemplateTestDeliveries).values({ certificationId: input.certificationId, templateType: input.templateType, recipientUserId: input.actorUserId, recipientName: values.administratorName, recipientEmail: row.recipientEmail, subject, status: "queued", createdByUserId: input.actorUserId });
  const id = Number(inserted[0].insertId);
  const config = getResendConfiguration();
  const sender = await verifyResendSenderDomain(true);
  if (!config.readyToSend || !config.apiKey || !config.from || !config.replyTo || !sender.verified) {
    const errorMessage = "VIBHA email sending is not configured or the sender domain is not verified.";
    await db.update(certificateTemplateTestDeliveries).set({ status: "failed", errorMessage }).where(eq(certificateTemplateTestDeliveries.id, id));
    return { id, status: "failed" as const, errorMessage };
  }
  try {
    const result = await new Resend(config.apiKey).emails.send({ from: config.from, to: [row.recipientEmail], replyTo: config.replyTo, subject, text: `TEST EMAIL — DO NOT ACT ON THIS MESSAGE\n\nHello ${values.administratorName},\n\n${body}`, html: `<div style="font-family:Arial,sans-serif"><p><strong>TEST EMAIL — DO NOT ACT ON THIS MESSAGE</strong></p><p>Hello ${escapeHtml(values.administratorName)},</p><p>${escapeHtml(body)}</p></div>`, tags: [{ name: "certificate_template_test", value: input.templateType }] }, { idempotencyKey: `certificate-template-test/${id}/${randomUUID()}` });
    if (result.error || !result.data?.id) throw new Error(result.error?.message || "Resend did not accept the template test.");
    await db.update(certificateTemplateTestDeliveries).set({ status: "accepted", providerMessageId: result.data.id, sentAt: new Date(), errorMessage: null }).where(eq(certificateTemplateTestDeliveries.id, id));
    return { id, status: "accepted" as const, errorMessage: null };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "The template test did not complete.";
    await db.update(certificateTemplateTestDeliveries).set({ status: "failed", errorMessage }).where(eq(certificateTemplateTestDeliveries.id, id));
    return { id, status: "failed" as const, errorMessage };
  }
}
