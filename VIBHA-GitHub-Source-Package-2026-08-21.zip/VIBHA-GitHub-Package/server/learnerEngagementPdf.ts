import { PDFDocument, StandardFonts, rgb } from "pdf-lib";

export type CompletionTranscriptInput = {
  recipientName: string;
  courseTitle: string;
  ceus: number;
  completedAt: Date;
  moduleCount: number;
  lessonCount: number;
};

function centered(page: any, text: string, font: any, size: number, y: number, color: any) {
  const { width } = page.getSize();
  page.drawText(text, { x: Math.max(40, (width - font.widthOfTextAtSize(text, size)) / 2), y, size, font, color });
}

export async function generateCompletionTranscriptPdf(input: CompletionTranscriptInput) {
  const document = await PDFDocument.create();
  const page = document.addPage([612, 792]);
  const navy = rgb(7 / 255, 31 / 255, 73 / 255);
  const orange = rgb(244 / 255, 122 / 255, 32 / 255);
  const ink = rgb(30 / 255, 41 / 255, 59 / 255);
  const muted = rgb(71 / 255, 85 / 255, 105 / 255);
  const serif = await document.embedFont(StandardFonts.TimesRoman);
  const serifBold = await document.embedFont(StandardFonts.TimesRomanBold);
  const sans = await document.embedFont(StandardFonts.Helvetica);
  const sansBold = await document.embedFont(StandardFonts.HelveticaBold);

  page.drawRectangle({ x: 0, y: 0, width: 612, height: 792, color: rgb(1, 1, 1) });
  page.drawRectangle({ x: 28, y: 28, width: 556, height: 736, borderColor: navy, borderWidth: 2.5 });
  page.drawRectangle({ x: 38, y: 38, width: 536, height: 716, borderColor: orange, borderWidth: 1 });
  page.drawRectangle({ x: 41, y: 690, width: 530, height: 61, color: navy });
  centered(page, "VIBHA", sansBold, 21, 723, rgb(1, 1, 1));
  centered(page, "THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH & ADVANCEMENT", sansBold, 7.5, 709, rgb(1, 1, 1));
  centered(page, "SELF-PACED COURSE COMPLETION TRANSCRIPT", serifBold, 22, 630, navy);
  centered(page, "This transcript confirms successful completion of the following VIBHA self-paced course.", sans, 9.5, 600, muted);
  centered(page, input.recipientName, serifBold, 24, 545, navy);
  page.drawLine({ start: { x: 90, y: 516 }, end: { x: 522, y: 516 }, thickness: 0.75, color: rgb(203 / 255, 213 / 255, 225 / 255) });
  centered(page, input.courseTitle, serifBold, 18, 470, ink);
  const date = new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" }).format(input.completedAt);
  const rows = [
    ["Completion date", date],
    ["Continuing education units", `${input.ceus.toFixed(2)} CEUs`],
    ["Completed modules", String(input.moduleCount)],
    ["Completed lessons", String(input.lessonCount)],
  ];
  let y = 393;
  rows.forEach(([label, value]) => {
    page.drawRectangle({ x: 95, y: y - 12, width: 422, height: 42, color: rgb(248 / 255, 250 / 255, 252 / 255), borderColor: rgb(226 / 255, 232 / 255, 240 / 255), borderWidth: 0.5 });
    page.drawText(label, { x: 112, y: y + 5, size: 9, font: sansBold, color: muted });
    page.drawText(value, { x: 322, y: y + 5, size: 10, font: sansBold, color: ink });
    y -= 52;
  });
  centered(page, "This document is a learner completion transcript and is retained in the learner’s private VIBHA account.", sans, 8.5, 138, muted);
  centered(page, "Issued by VIBHA | thevibha.org", sansBold, 8.5, 116, navy);
  document.setTitle(`VIBHA Completion Transcript — ${input.courseTitle}`);
  document.setAuthor("VIBHA | The Virginia Institute for Behavioral Health & Advancement");
  document.setSubject("Self-paced course completion transcript");
  return document.save();
}
