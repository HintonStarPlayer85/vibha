import { CertificationCard } from "@/components/certifications/CertificationCard";
import { InquiryForm } from "@/components/contact/InquiryForm";
import { Breadcrumbs } from "@/components/public/Breadcrumbs";
import { PublicLayout } from "@/components/public/PublicLayout";
import { TitleSectionBackground } from "@/components/public/TitleSectionBackground";
import { Button } from "@/components/ui/button";
import { usePageMeta, useStructuredData } from "@/hooks/usePageMeta";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  ArrowRight,
  Award,
  BookOpenCheck,
  CalendarClock,
  CheckCircle2,
  Clock3,
  GraduationCap,
  Laptop2,
  MapPin,
  ShieldCheck,
  UserRound,
  UsersRound,
  WalletCards,
} from "lucide-react";
import { Link, useParams } from "wouter";

function safeReturnPath() {
  const value = new URLSearchParams(window.location.search).get("returnTo");
  if (!value) return "/certifications";
  try {
    const decoded = decodeURIComponent(value);
    return decoded.startsWith("/certifications") ? decoded : "/certifications";
  } catch {
    return "/certifications";
  }
}

export default function CertificationDetail() {
  const { slug = "" } = useParams<{ slug: string }>();
  const { data, isLoading, error } = trpc.certifications.bySlug.useQuery({ slug }, { retry: false });
  usePageMeta(data?.seoTitle ?? "Certification | VIBHA", data?.seoDescription ?? "VIBHA behavioral health workforce certification details.");
  useStructuredData(
    "vibha-course-schema",
    data
      ? {
          "@context": "https://schema.org",
          "@type": "Course",
          name: data.title,
          description: data.summary,
          provider: {
            "@type": "EducationalOrganization",
            name: "VIBHA",
            sameAs: window.location.origin,
          },
          educationalLevel: data.level,
          courseMode: data.deliveryMethods,
          offers: {
            "@type": "Offer",
            price: (data.costCents / 100).toFixed(2),
            priceCurrency: "USD",
            availability: data.enrollmentUrl
              ? "https://schema.org/InStock"
              : "https://schema.org/PreOrder",
            url: data.enrollmentUrl ?? window.location.href,
          },
        }
      : null,
  );

  if (isLoading) {
    return <PublicLayout><div className="container min-h-screen py-24"><div className="h-14 w-3/4 animate-pulse rounded-lg bg-slate-100" /><div className="mt-8 h-80 animate-pulse rounded-2xl bg-slate-100" /></div></PublicLayout>;
  }

  if (error || !data) {
    return <PublicLayout><section className="container py-24 text-center"><h1 className="text-5xl font-bold text-[#071f49]">Certification not available</h1><p className="mx-auto mt-5 max-w-xl text-lg leading-8 text-slate-600">This program may be inactive, unpublished, or no longer available at this address.</p><Button asChild className="mt-7 bg-[#071f49] text-white"><Link href="/certifications"><ArrowLeft className="mr-2 h-4 w-4" />Return to certifications</Link></Button></section></PublicLayout>;
  }

  const facts = [
    { icon: GraduationCap, label: "Category", value: data.categoryName },
    { icon: BookOpenCheck, label: "Level", value: data.level },
    { icon: Award, label: "CEUs", value: data.ceus > 0 ? String(data.ceus) : "To be confirmed" },
    { icon: Laptop2, label: "Format", value: data.format },
    { icon: Clock3, label: "Duration", value: data.duration },
    { icon: WalletCards, label: "Cost", value: data.costDisplay },
  ];

  return (
    <PublicLayout>
      <section className="vibha-grid relative min-h-[1160px] overflow-hidden bg-[#071f49] text-white sm:min-h-[1100px] xl:aspect-video xl:min-h-0">
        <TitleSectionBackground />
        <div className="container relative pb-10 pt-48 sm:pb-12 sm:pt-[26rem] xl:py-14">
          <div data-reveal="left" data-mobile-title-load className="w-[66%] sm:w-full sm:max-w-[55%] lg:max-w-[42%]">
            <Breadcrumbs inverse items={[{ label: "Certifications", href: safeReturnPath() }, { label: data.categoryName, href: `/certifications?category=${data.categorySlug}` }, { label: data.title }]} />
            <div className="mt-5 lg:mt-7">
              <div><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#ff9a52] sm:text-sm">{data.categoryName}</p><h1 className="mt-3 text-balance text-2xl font-bold leading-[1.08] min-[430px]:text-3xl lg:mt-4 lg:text-4xl">{data.title}</h1><p className="mt-4 text-pretty text-sm leading-6 text-slate-200 lg:mt-5 lg:text-base lg:leading-7">{data.summary}</p></div>
              <div className="mt-5 rounded-xl border border-white/20 bg-[#071f49] p-4 lg:mt-7 lg:p-5"><p className="text-xs font-bold uppercase tracking-wide text-[#ff9a52] sm:text-sm">Program information</p><p className="mt-3 text-sm leading-6 text-slate-200">Cohort schedules and delivery availability are confirmed during the inquiry process.</p><Button asChild className="mt-4 min-h-11 w-full whitespace-normal bg-[#f47a20] px-3 py-3 text-xs font-bold leading-4 text-[#041634] hover:bg-[#ff9648] sm:text-sm lg:mt-5"><a href="#program-inquiry">Request Program Information <ArrowRight className="ml-1.5 h-4 w-4 shrink-0" /></a></Button></div>
            </div>
          </div>
        </div>
      </section>
      <section className="border-b border-slate-200 bg-white"><div className="container grid grid-cols-2 gap-px bg-slate-200 sm:grid-cols-3 lg:grid-cols-6">{facts.map(fact => <dl key={fact.label} className="bg-white p-5"><dt className="flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-slate-500"><fact.icon className="h-4 w-4 text-[#b94700]" />{fact.label}</dt><dd className="mt-2 text-sm font-bold leading-5 text-[#071f49]">{fact.value}</dd></dl>)}</div></section>
      <section aria-label="Enrollment status" className="border-b border-slate-200 bg-[#fff8f0]">
        <div className="container flex flex-col gap-4 py-6 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#b94700]">Enrollment</p>
            <p className="mt-1 font-semibold text-[#071f49]">
              {data.enrollmentUrl
                ? "Online enrollment is available for this certification."
                : "Online enrollment is not yet open. VIBHA can provide current cohort and enrollment guidance."}
            </p>
          </div>
          {data.enrollmentUrl ? (
            <Button asChild className="shrink-0 bg-[#071f49] font-bold text-white hover:bg-[#173b70]">
              <a
                href={data.enrollmentUrl}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`Enroll in ${data.title} (opens in a new tab)`}
              >
                Enroll or apply now <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          ) : (
            <Button asChild className="shrink-0 bg-[#071f49] font-bold text-white hover:bg-[#173b70]">
              <a href="#program-inquiry">Request enrollment information <ArrowRight className="ml-2 h-4 w-4" /></a>
            </Button>
          )}
        </div>
      </section>
      <section className="py-16 sm:py-20"><div className="container grid gap-12 lg:grid-cols-[1fr_340px] lg:items-start"><div className="space-y-14"><section><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Program overview</p><h2 className="mt-3 text-4xl font-bold text-[#071f49]">What this certification addresses</h2><p className="mt-5 text-lg leading-8 text-slate-600">{data.description}</p>{data.valueStatement ? <blockquote className="mt-7 border-l-4 border-[#f47a20] bg-[#fff8f0] p-6 font-serif text-xl font-semibold leading-8 text-[#071f49]">{data.valueStatement}</blockquote> : null}</section><section><h2 className="text-3xl font-bold text-[#071f49]">Learning objectives</h2><ul className="mt-6 grid gap-4">{data.objectives.map(objective => <li key={objective} className="flex gap-3 rounded-xl border border-slate-200 p-5"><CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-700" /><span className="leading-7 text-slate-700">{objective}</span></li>)}</ul></section><div className="grid gap-10 md:grid-cols-2"><section><h2 className="text-3xl font-bold text-[#071f49]">Ideal audience</h2><ul className="mt-5 space-y-3">{data.idealAudience.map(item => <li key={item} className="flex gap-3 leading-7 text-slate-700"><UsersRound className="mt-1 h-4 w-4 shrink-0 text-[#b94700]" />{item}</li>)}</ul></section><section><h2 className="text-3xl font-bold text-[#071f49]">Eligibility requirements</h2><ul className="mt-5 space-y-3">{data.eligibilityRequirements.map(item => <li key={item} className="flex gap-3 leading-7 text-slate-700"><ShieldCheck className="mt-1 h-4 w-4 shrink-0 text-[#b94700]" />{item}</li>)}</ul><p className="mt-4 text-sm leading-6 text-slate-500">Prospective learners should verify employer, payer, credentialing, and role-specific requirements before enrollment.</p></section></div><section><h2 className="text-3xl font-bold text-[#071f49]">Curriculum topics</h2><div className="mt-6 grid gap-3 sm:grid-cols-2">{data.curriculumTopics.map((topic, index) => <div key={topic} className="flex gap-3 rounded-lg bg-[#f6f8fb] p-4"><span className="font-serif text-xl font-bold text-[#b94700]">{String(index + 1).padStart(2, "0")}</span><span className="text-sm font-semibold leading-6 text-slate-700">{topic}</span></div>)}</div></section><section><h2 className="text-3xl font-bold text-[#071f49]">Schedule and delivery</h2><div className="mt-6 grid gap-4 sm:grid-cols-2"><div className="rounded-xl border border-slate-200 p-5"><CalendarClock className="h-6 w-6 text-[#b94700]" /><h3 className="mt-4 text-xl font-bold text-[#071f49]">Schedule</h3><p className="mt-2 text-sm leading-6 text-slate-600">{data.schedule}</p></div><div className="rounded-xl border border-slate-200 p-5"><MapPin className="h-6 w-6 text-[#b94700]" /><h3 className="mt-4 text-xl font-bold text-[#071f49]">Location and methods</h3><p className="mt-2 text-sm font-semibold text-slate-700">{data.deliveryLocation}</p><p className="mt-2 text-sm leading-6 text-slate-600">{data.deliveryMethods.join(" · ")}</p></div></div></section><section><h2 className="text-3xl font-bold text-[#071f49]">Instructor information</h2><div className="mt-6 space-y-4">{data.instructors.map(instructor => <article key={instructor.id} className="flex gap-5 rounded-xl border border-slate-200 p-6"><div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#071f49] text-white"><UserRound className="h-6 w-6" /></div><div><h3 className="text-xl font-bold text-[#071f49]">{instructor.name}</h3>{instructor.title ? <p className="mt-1 text-sm font-semibold text-[#b94700]">{instructor.title}</p> : null}{instructor.biography ? <p className="mt-3 text-sm leading-6 text-slate-600">{instructor.biography}</p> : null}</div></article>)}</div></section>{data.careerRelevance ? <section><h2 className="text-3xl font-bold text-[#071f49]">Career relevance</h2><p className="mt-5 text-lg leading-8 text-slate-600">{data.careerRelevance}</p></section> : null}</div><aside className="sticky top-32 rounded-xl border border-slate-200 bg-[#f6f8fb] p-6"><p className="text-xs font-bold uppercase tracking-[0.16em] text-[#b94700]">Program summary</p><dl className="mt-5 space-y-4 text-sm">{[{ label: "Prerequisites", value: data.prerequisites }, { label: "Duration", value: data.duration }, { label: "Format", value: data.format }, { label: "Published tuition", value: data.costDisplay }, { label: "CEUs", value: data.ceus > 0 ? String(data.ceus) : "To be confirmed" }].map(item => <div key={item.label} className="border-b border-slate-200 pb-4"><dt className="font-semibold text-slate-500">{item.label}</dt><dd className="mt-1 font-bold leading-6 text-[#071f49]">{item.value}</dd></div>)}</dl><Button asChild className="mt-6 w-full bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><a href="#program-inquiry">Request Information</a></Button><Link href={safeReturnPath()} className="mt-4 flex items-center justify-center gap-2 rounded-sm text-sm font-bold text-[#173b70] hover:underline"><ArrowLeft className="h-4 w-4" />Back to catalog</Link></aside></div></section>
      {data.related.length ? <section className="bg-[#f6f8fb] py-16 sm:py-20"><div className="container"><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Related programs</p><h2 className="mt-3 text-4xl font-bold text-[#071f49]">Continue within this pathway.</h2><div className="mt-8 grid gap-6 md:grid-cols-3">{data.related.map(item => <CertificationCard key={item.id} certification={{ ...item, categorySlug: data.categorySlug, ceus: 0, format: "Virtual live" }} returnTo={safeReturnPath()} />)}</div></div></section> : null}
      <section id="program-inquiry" className="scroll-mt-28 bg-white py-16 sm:py-20"><div className="container grid gap-10 lg:grid-cols-[0.7fr_1.3fr] lg:items-start"><div><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Program inquiry</p><h2 className="mt-4 text-4xl font-bold text-[#071f49]">Request information about this certification.</h2><p className="mt-5 text-lg leading-8 text-slate-600">Ask about upcoming cohorts, delivery availability, prerequisites, CEU status, and next enrollment steps.</p></div><InquiryForm certificationId={data.id} certificationTitle={data.title} /></div></section>
    </PublicLayout>
  );
}
