import { createHash } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";

const certificateDbMocks = vi.hoisted(() => ({
  createIssuedCertificate: vi.fn(),
  getCertificateById: vi.fn(),
  getCertificateCandidate: vi.fn(),
  validateCertificatePreviewAcknowledgement: vi.fn(),
  markCertificatePreviewAcknowledgementUsed: vi.fn(),
  revokeIssuedCertificate: vi.fn(),
}));

const pdfMocks = vi.hoisted(() => ({ generateCertificatePdf: vi.fn() }));
const storageMocks = vi.hoisted(() => ({ storagePut: vi.fn(), storageGetSignedUrl: vi.fn() }));

vi.mock("./certificateDb", async () => {
  const actual = await vi.importActual<typeof import("./certificateDb")>("./certificateDb");
  return { ...actual, ...certificateDbMocks };
});
vi.mock("./certificatePdf", () => pdfMocks);
vi.mock("./storage", () => storageMocks);

import { generateCertificateNumber, issueCertificate, previewCertificate } from "./certificateService";

describe("Certificate issuance service", () => {
  afterEach(() => vi.unstubAllGlobals());
  it("creates unique, format-valid VIBHA certificate numbers", () => {
    const numbers = Array.from({ length: 100 }, () => generateCertificateNumber());
    expect(new Set(numbers).size).toBe(numbers.length);
    numbers.forEach(number => expect(number).toMatch(/^VIBHA-\d{4}-[A-F0-9]{12}$/));
  });

  it("generates, hashes, stores, and records a certificate exclusively on the server", async () => {
    const candidate = {
      cohortId: 14,
      cohortStudentId: 33,
      certificationId: 9,
      recipientName: "Jordan Avery",
      recipientEmail: "jordan@example.com",
      cohortTitle: "Spring 2026 Cohort",
      credentialTitle: "Behavioral Health Workforce Foundations",
      ceuValue: "8.00",
      instructorName: "Beverly Loftin Cobbs, LCSW",
      instructorTitle: "Director of Clinical Education",
      cohortSignatoryInstructorId: null,
      deliveryMode: "Hybrid Instruction",
      completionNarrative: "Approved program narrative.",
      instructionalHours: "90 Hours",
      supervisedPracticalTraining: "12 Weeks",
      complianceStatement: "Approved compliance language.",
      accreditingBodyName: "Virginia DBHDS",
      licenseNumber: "VIBHA-001",
      executiveName: "Jacquese Hinton",
      executiveTitle: "Founder & Director of Institutional Strategy",
      executiveSignatureStorageKey: "certificate-executive-signatures/9/signature.png",
      executiveSignatureUrl: "/manus-storage/certificate-executive-signatures/9/signature.png",
      executiveSignatureMimeType: "image/png" as const,
      instructorSignatureStorageKey: "instructor-signatures/2/signature_test.png",
      instructorSignatureUrl: "/manus-storage/instructor-signatures/2/signature_test.png",
      instructorSignatureMimeType: "image/png" as const,
    };
    const bytes = Buffer.from("server-generated-certificate-pdf");
    certificateDbMocks.getCertificateCandidate.mockResolvedValue(candidate);
    certificateDbMocks.validateCertificatePreviewAcknowledgement.mockResolvedValue({ id: 44 });
    pdfMocks.generateCertificatePdf.mockResolvedValue(bytes);
    storageMocks.storageGetSignedUrl.mockResolvedValue("https://storage.example/signature");
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, arrayBuffer: async () => Buffer.from("signature-bytes") }));
    storageMocks.storagePut.mockResolvedValue({ key: "certificates/2026/certificate.pdf", url: "/manus-storage/certificates/2026/certificate.pdf" });
    certificateDbMocks.createIssuedCertificate.mockResolvedValue({ id: 1, certificateNumber: "VIBHA-2026-A1B2C3D4E5F6" });

    await issueCertificate(33, "65aa0fc3-5c98-4146-8d13-807c355be122", 7, "https://thevibha.org");

    expect(pdfMocks.generateCertificatePdf).toHaveBeenCalledWith(expect.objectContaining({
      recipientName: candidate.recipientName,
      credentialTitle: candidate.credentialTitle,
      verificationUrl: expect.stringMatching(/^https:\/\/thevibha\.org\/verify-certificate\?reference=VIBHA-/),
      instructorName: candidate.instructorName,
      accreditingBodyName: candidate.accreditingBodyName,
      licenseNumber: candidate.licenseNumber,
      instructorSignature: expect.objectContaining({ mimeType: "image/png" }),
      executiveSignature: expect.objectContaining({ mimeType: "image/png" }),
    }));
    expect(storageMocks.storagePut).toHaveBeenCalledWith(expect.stringMatching(/^certificates\/\d{4}\/VIBHA-\d{4}-[A-F0-9]{12}\.pdf$/), bytes, "application/pdf");
    expect(certificateDbMocks.createIssuedCertificate).toHaveBeenCalledWith(expect.objectContaining({
      ...candidate,
      activeIssuanceKey: "14:33",
      documentStorageKey: "certificates/2026/certificate.pdf",
      documentSha256: createHash("sha256").update(bytes).digest("hex"),
      documentSnapshot: expect.objectContaining({ instructorName: candidate.instructorName, instructionalHours: "90 Hours", licenseNumber: "VIBHA-001" }),
      actorUserId: 7,
    }));
    expect(certificateDbMocks.markCertificatePreviewAcknowledgementUsed).toHaveBeenCalledWith(44, 1, 7);
  });

  it("renders a clearly marked preview without creating storage or certificate records", async () => {
    vi.clearAllMocks();
    certificateDbMocks.getCertificateCandidate.mockResolvedValue({ cohortId: 14, cohortStudentId: 33, certificationId: 9, recipientName: "Jordan Avery", recipientEmail: "jordan@example.com", cohortTitle: "Spring 2026 Cohort", credentialTitle: "Behavioral Health Workforce Foundations", ceuValue: "8.00", instructorName: "Beverly Loftin Cobbs, LCSW", instructorTitle: "Director of Clinical Education", cohortSignatoryInstructorId: 2, courseInstructorSignatoryName: "Program default signer", courseInstructorSignatoryTitle: "Program default title", instructorSignatureStorageKey: null, instructorSignatureUrl: null, instructorSignatureMimeType: null, executiveSignatureStorageKey: null, executiveSignatureUrl: null, executiveSignatureMimeType: null, deliveryMode: "Hybrid Instruction", completionNarrative: null, instructionalHours: null, supervisedPracticalTraining: null, complianceStatement: null, accreditingBodyName: null, licenseNumber: null, executiveName: "Jacquese Hinton", executiveTitle: "Founder & Director of Institutional Strategy" });
    pdfMocks.generateCertificatePdf.mockResolvedValue(Buffer.from("preview-pdf"));
    const preview = await previewCertificate(33, "https://thevibha.org");
    expect(preview.fileName).toContain("preview");
    expect(pdfMocks.generateCertificatePdf).toHaveBeenCalledWith(expect.objectContaining({ isPreview: true, certificateNumber: "PREVIEW-NOT-ISSUED", instructorName: "Beverly Loftin Cobbs, LCSW" }));
    expect(certificateDbMocks.createIssuedCertificate).not.toHaveBeenCalled();
    expect(storageMocks.storagePut).not.toHaveBeenCalled();
  });
});
