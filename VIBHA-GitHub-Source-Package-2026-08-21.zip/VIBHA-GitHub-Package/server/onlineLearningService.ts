import { generateImage } from "./_core/imageGeneration";
import { invokeLLM, listLLMModels, type Message } from "./_core/llm";
import { generatedCourseSchema } from "../shared/onlineLearning";
import {
  completeGenerationRun,
  createGenerationRun,
  failGenerationRun,
  getOnlineCourseAdminById,
  getOnlineModuleForGeneration,
  getOnlineCourseMaterials,
  getPublicOnlineCourseBySlug,
  onlineLearningErrors,
  replaceGeneratedCourseContent,
  updateMaterialAnalysis,
  updateOnlineModuleVisual,
} from "./onlineLearningDb";
import { storageGetSignedUrl } from "./storage";

type MaterialAnalysis = { summary: string; sourceExcerpt: string };

const materialAnalysisSchema = {
  type: "json_schema" as const,
  json_schema: {
    name: "online_material_analysis",
    strict: true,
    schema: {
      type: "object",
      properties: {
        summary: { type: "string" },
        sourceExcerpt: { type: "string" },
      },
      required: ["summary", "sourceExcerpt"],
      additionalProperties: false,
    },
  },
};

const generatedCourseResponseSchema = {
  type: "json_schema" as const,
  json_schema: {
    name: "generated_online_course",
    strict: true,
    schema: {
      type: "object",
      properties: {
        courseOverview: { type: "string" },
        sourceGroundingNotice: { type: "string" },
        aiInstructorName: { type: "string" },
        aiInstructorWelcome: { type: "string" },
        aiInstructorScope: { type: "string" },
        modules: {
          type: "array",
          items: {
            type: "object",
            properties: {
              position: { type: "integer" }, title: { type: "string" }, learningObjective: { type: "string" }, sourceGrounding: { type: "string" }, visualPrompt: { type: "string" }, videoBrief: { type: "string" },
              lessons: {
                type: "array",
                items: { type: "object", properties: { position: { type: "integer" }, title: { type: "string" }, estimatedMinutes: { type: "integer" }, content: { type: "string" }, knowledgeCheckQuestion: { type: "string" }, knowledgeCheckAnswer: { type: "string" } }, required: ["position", "title", "estimatedMinutes", "content", "knowledgeCheckQuestion", "knowledgeCheckAnswer"], additionalProperties: false },
              },
            },
            required: ["position", "title", "learningObjective", "sourceGrounding", "visualPrompt", "videoBrief", "lessons"],
            additionalProperties: false,
          },
        },
      },
      required: ["courseOverview", "sourceGroundingNotice", "aiInstructorName", "aiInstructorWelcome", "aiInstructorScope", "modules"],
      additionalProperties: false,
    },
  },
};

function textFromResponse(response: Awaited<ReturnType<typeof invokeLLM>>) {
  const content = response.choices[0]?.message.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) return content.filter(item => item.type === "text").map(item => item.text).join("\n");
  return "";
}

async function resolveGenerationModel() {
  const { data } = await listLLMModels();
  return data.find(model => model.id === "gemini-3-flash-preview")?.id
    ?? data.find(model => model.id === "gpt-5-mini")?.id
    ?? data[0]?.id
    ?? (() => { throw new Error("No AI model is currently available for Online Learning generation."); })();
}

function parseJson<T>(value: string): T {
  try { return JSON.parse(value) as T; } catch { throw new Error("AI generation returned an unreadable structured response."); }
}

async function readTextMaterial(storageKey: string) {
  const url = await storageGetSignedUrl(storageKey);
  const response = await fetch(url);
  if (!response.ok) throw new Error("The uploaded text material could not be read for analysis.");
  return (await response.text()).slice(0, 120_000);
}

async function analyzeSingleMaterial(material: { id: number; title: string; mimeType: string; storageKey: string }, model: string): Promise<MaterialAnalysis> {
  const instructions = "Analyze this administrator-uploaded VIBHA learning material. Return only concepts, procedures, boundaries, and learning content stated in the source. Do not add clinical, legal, or accreditation claims not present in the material. Produce a concise summary and a short source excerpt or topic inventory that can ground a course authoring workflow.";
  let content: Message["content"];
  if (material.mimeType === "application/pdf") {
    const url = await storageGetSignedUrl(material.storageKey);
    content = [{ type: "text", text: instructions }, { type: "file_url", file_url: { url, mime_type: "application/pdf" } }];
  } else {
    const text = await readTextMaterial(material.storageKey);
    content = `${instructions}\n\nMaterial title: ${material.title}\n\nSOURCE TEXT:\n${text}`;
  }
  const response = await invokeLLM({ model, messages: [{ role: "user", content }], response_format: materialAnalysisSchema, maxTokens: 2400 });
  const output = parseJson<MaterialAnalysis>(textFromResponse(response));
  if (!output.summary.trim() || !output.sourceExcerpt.trim()) throw new Error("AI material analysis returned incomplete content.");
  return { summary: output.summary.trim().slice(0, 8000), sourceExcerpt: output.sourceExcerpt.trim().slice(0, 16000) };
}

export async function analyzeCourseMaterials(courseId: number) {
  const course = await getOnlineCourseAdminById(courseId);
  if (!course) throw new Error(onlineLearningErrors.courseNotFound);
  const model = await resolveGenerationModel();
  const materials = await getOnlineCourseMaterials(courseId);
  if (!materials.length) throw new Error(onlineLearningErrors.materialsRequired);
  const results = [];
  for (const material of materials) {
    try {
      const output = await analyzeSingleMaterial(material, model);
      results.push(await updateMaterialAnalysis(material.id, { status: "analyzed", analysisSummary: output.summary, sourceExcerpt: output.sourceExcerpt, analysisError: null }));
    } catch (error) {
      const message = error instanceof Error ? error.message : "Material analysis failed.";
      results.push(await updateMaterialAnalysis(material.id, { status: "failed", analysisSummary: null, sourceExcerpt: null, analysisError: message }));
    }
  }
  return results;
}

export async function generateCourseFromMaterials(courseId: number, actorUserId: number) {
  const course = await getOnlineCourseAdminById(courseId);
  if (!course) throw new Error(onlineLearningErrors.courseNotFound);
  if (course.status === "published") throw new Error(onlineLearningErrors.courseIsPublished);
  if (!course.materials.length) throw new Error(onlineLearningErrors.materialsRequired);
  if (course.materials.some(material => material.analysisStatus !== "analyzed" || !material.analysisSummary || !material.sourceExcerpt)) throw new Error(onlineLearningErrors.materialsNotAnalyzed);
  const model = await resolveGenerationModel();
  const runId = await createGenerationRun(courseId, model, course.materials.map(material => material.id), actorUserId);
  const sourceDigest = course.materials.map(material => `SOURCE: ${material.title}\nSUMMARY: ${material.analysisSummary}\nGROUNDING: ${material.sourceExcerpt}`).join("\n\n---\n\n").slice(0, 70_000);
  const prompt = `Create a reviewable self-paced online course draft for VIBHA. You must use only the certification metadata and SOURCE DIGEST below. Do not invent legal, clinical, accreditation, licensing, assessment, or policy facts. If the sources do not support a topic, omit it. The videoBrief must be a production-ready lesson script and storyboard brief, not a claim that a video file has already been created. Visual prompts must depict general educational concepts and no clinical encounters. The AI instructor must clearly state that it answers only from the approved course content and should defer unsupported questions.\n\nCERTIFICATION METADATA\nTitle: ${course.certificationTitle}\nSummary: ${course.certificationSummary}\nObjectives: ${(course.certificationObjectives as string[]).join("; ")}\nCurriculum topics: ${(course.certificationTopics as string[]).join("; ")}\nAudience: ${(course.certificationAudience as string[]).join("; ")}\nDuration: ${course.certificationDuration}\nCEUs: ${course.certificationCeus}\n\nSOURCE DIGEST\n${sourceDigest}`;
  try {
    const response = await invokeLLM({ model, messages: [{ role: "user", content: prompt }], response_format: generatedCourseResponseSchema, maxTokens: 15000 });
    const generated = generatedCourseSchema.parse(parseJson(textFromResponse(response)));
    const saved = await replaceGeneratedCourseContent(courseId, runId, generated, actorUserId);
    await completeGenerationRun(runId, generated as unknown as Record<string, unknown>, actorUserId);
    return saved;
  } catch (error) {
    const message = error instanceof Error ? error.message : "Course generation failed.";
    await failGenerationRun(runId, message);
    throw error;
  }
}

export async function generateOnlineModuleVisual(moduleId: number, actorUserId: number) {
  const module = await getOnlineModuleForGeneration(moduleId);
  if (!module) throw new Error(onlineLearningErrors.moduleNotFound);
  const result = await generateImage({
    prompt: `Create an original, professional instructional illustration for the VIBHA self-paced course "${module.courseTitle}". Module: "${module.title}". Learning objective: "${module.learningObjective}". Visual direction: ${module.visualPrompt}. Use an accessible, clean institutional educational style; include no readable text, logos, patient records, clinical encounters, or claims not supplied.`,
    quality: "medium",
  });
  if (!result.url) throw new Error("Instructional visual generation did not return an asset URL.");
  return updateOnlineModuleVisual(moduleId, result.url, actorUserId);
}

export async function answerOnlineInstructor(courseSlug: string, question: string) {
  const course = await getPublicOnlineCourseBySlug(courseSlug);
  if (!course) throw new Error(onlineLearningErrors.courseNotPublic);
  const model = await resolveGenerationModel();
  const learningContext = [
    course.courseOverview ?? "",
    course.sourceGroundingNotice ?? "",
    ...course.modules.flatMap(module => [
      `MODULE: ${module.title}\nOBJECTIVE: ${module.learningObjective}\nGROUNDING: ${module.sourceGrounding}`,
      ...module.lessons.map(lesson => `LESSON: ${lesson.title}\n${lesson.content}`),
    ]),
  ].join("\n\n").slice(0, 70_000);
  const response = await invokeLLM({
    model,
    messages: [
      { role: "system", content: `You are ${course.aiInstructorName}, a text-based VIBHA learning guide. Answer only from the approved course context. If the answer is not supported by the course, say so clearly and direct the learner to the course materials or VIBHA. Do not provide clinical, legal, licensing, crisis, or individual professional advice. Keep answers clear, educational, and under 350 words.\n\nAPPROVED COURSE CONTEXT:\n${learningContext}` },
      { role: "user", content: question },
    ],
    maxTokens: 900,
  });
  const answer = textFromResponse(response).trim();
  if (!answer) throw new Error("The AI instructor did not return a response.");
  return { answer, instructorName: course.aiInstructorName };
}
