import { ArrowRight, ChevronDown } from "lucide-react";
import { useEffect, useMemo } from "react";
import { Link } from "wouter";
import { PublicLayout } from "@/components/public/PublicLayout";
import { PageHero } from "@/components/public/PageHero";
import { SectionHeading } from "@/components/public/SectionHeading";
import { Button } from "@/components/ui/button";
import { getLeadershipTeam } from "@/data/leadership";
import { usePageMeta, useStructuredData } from "@/hooks/usePageMeta";
import { useSiteContent } from "@/hooks/useSiteContent";

export default function Leadership() {
  const { content, overrides } = useSiteContent();
  const team = useMemo(() => getLeadershipTeam(overrides), [overrides]);
  usePageMeta(
    "Leadership | VIBHA",
    "Meet the leadership team guiding institutional strategy, educational operations, clinical education, workforce development, and business development at VIBHA.",
  );
  const structuredData = useMemo(
    () => ({
      "@context": "https://schema.org",
      "@type": "ItemList",
      name: "VIBHA Leadership",
      itemListElement: team.map((profile, index) => ({
        "@type": "ListItem",
        position: index + 1,
        item: {
          "@type": "Person",
          name: profile.name,
          jobTitle: profile.title,
          description: profile.biography.join(" "),
          image: `${window.location.origin}${profile.image.large}`,
          worksFor: {
            "@type": "EducationalOrganization",
            name: "The Virginia Institute for Behavioral Health & Advancement",
            alternateName: "VIBHA",
          },
        },
      })),
    }),
    [team],
  );
  useStructuredData("vibha-leadership-jsonld", structuredData);

  useEffect(() => {
    const focusHashTarget = () => {
      const id = decodeURIComponent(window.location.hash.slice(1));
      if (!id) return;
      window.requestAnimationFrame(() => {
        const target = document.getElementById(id);
        if (!target) return;
        const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        target.scrollIntoView({ behavior: reduceMotion ? "auto" : "smooth", block: "start" });
        target.focus({ preventScroll: true });
      });
    };
    focusHashTarget();
    window.addEventListener("hashchange", focusHashTarget);
    return () => window.removeEventListener("hashchange", focusHashTarget);
  }, []);

  return (
    <PublicLayout>
      <PageHero
        eyebrow="Leadership"
        title={content["leadership.hero.title"]}
        description={content["leadership.hero.description"]}
        breadcrumbs={[{ label: "About", href: "/about" }, { label: "Leadership" }]}
        actions={
          <Button asChild className="bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">
            <a href="#leadership-directory">Meet the leadership team <ChevronDown className="ml-2 h-4 w-4" /></a>
          </Button>
        }
      />

      <section id="leadership-directory" className="scroll-mt-28 border-b border-slate-200 bg-[#f6f8fb] py-16 sm:py-20">
        <div className="container">
          <SectionHeading
            align="center"
            eyebrow="Leadership directory"
            title={content["leadership.directory.title"]}
            description={content["leadership.directory.description"]}
          />
          <nav aria-label="Leadership profile directory" className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {team.map(profile => (
              <a
                key={profile.id}
                href={`#${profile.id}`}
                className="flex min-h-14 items-center justify-between rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-[#071f49] shadow-sm transition hover:-translate-y-0.5 hover:border-[#f47a20] hover:shadow-md motion-reduce:transform-none"
              >
                {profile.name}
                <ChevronDown className="ml-3 h-4 w-4 shrink-0 text-[#b94700]" />
              </a>
            ))}
          </nav>
        </div>
      </section>

      <div>
        {team.map((profile, index) => (
          <section
            key={profile.id}
            id={profile.id}
            tabIndex={-1}
            aria-labelledby={`${profile.id}-name`}
            className={`scroll-mt-24 py-20 sm:py-24 ${index % 2 === 1 ? "bg-[#f6f8fb]" : "bg-white"}`}
          >
            <div className="container grid gap-10 lg:grid-cols-[0.72fr_1.28fr] lg:items-start lg:gap-16">
              <div className={`overflow-hidden rounded-2xl border border-slate-200 bg-[#e8edf4] shadow-md ${index % 2 === 1 ? "lg:order-2" : ""}`}>
                <div className="aspect-[4/5]">
                  <img
                    src={profile.image.large}
                    srcSet={`${profile.image.small} 480w, ${profile.image.large} 960w`}
                    sizes="(min-width: 1024px) 38vw, 100vw"
                    width={profile.image.width}
                    height={profile.image.height}
                    alt={profile.image.alt}
                    loading={index === 0 ? "eager" : "lazy"}
                    fetchPriority={index === 0 ? "high" : "auto"}
                    decoding="async"
                    className="h-full w-full object-cover object-top"
                  />
                </div>
              </div>
              <div className={index % 2 === 1 ? "lg:order-1" : ""}>
                <p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">{profile.title}</p>
                <h2 id={`${profile.id}-name`} className="mt-4 text-4xl font-bold leading-tight text-[#071f49] sm:text-5xl">
                  {profile.name}
                </h2>
                <div className="mt-8 space-y-6 text-lg leading-8 text-slate-600">
                  {profile.biography.map(paragraph => <p key={paragraph}>{paragraph}</p>)}
                </div>
                <a href="#leadership-directory" className="mt-8 inline-flex min-h-11 items-center text-sm font-bold text-[#071f49] hover:text-[#b94700]">
                  Return to leadership directory <ChevronDown className="ml-2 h-4 w-4 rotate-180" />
                </a>
              </div>
            </div>
          </section>
        ))}
      </div>

      <section className="bg-[#071f49] py-16 text-white sm:py-20">
        <div className="container flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-3xl">
            <p className="text-sm font-bold uppercase tracking-[0.18em] text-[#ff9a52]">Connect with VIBHA</p>
            <h2 className="mt-4 text-4xl font-bold">{content["leadership.cta.title"]}</h2>
            <p className="mt-4 text-lg leading-8 text-slate-300">{content["leadership.cta.description"]}</p>
          </div>
          <Button asChild size="lg" className="shrink-0 bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">
            <Link href="/contact">Contact VIBHA <ArrowRight className="ml-2 h-4 w-4" /></Link>
          </Button>
        </div>
      </section>
    </PublicLayout>
  );
}
