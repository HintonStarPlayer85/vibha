import type { Express, Request, Response } from "express";
import express from "express";
import { Resend } from "resend";
import { z } from "zod";
import { applyResendWebhookEvent } from "./cohortCommunicationDb";
import { getResendConfiguration } from "./resendCohort";

const resendEventSchema = z.object({
  type: z.string().min(1).max(80),
  created_at: z.string().datetime(),
  data: z.object({
    email_id: z.string().min(1).max(180),
    bounce: z.object({
      type: z.string().max(120).optional(),
      subType: z.string().max(120).optional(),
    }).optional(),
  }).passthrough(),
}).passthrough();

async function receiveResendWebhook(req: Request, res: Response) {
  const config = getResendConfiguration();
  if (!config.webhookSecret) {
    res.status(503).json({ error: "Webhook verification is not configured." });
    return;
  }
  const signatureHeaders = {
    id: req.header("svix-id") || "",
    timestamp: req.header("svix-timestamp") || "",
    signature: req.header("svix-signature") || "",
  };
  if (!signatureHeaders.id || !signatureHeaders.timestamp || !signatureHeaders.signature) {
    res.status(400).json({ error: "Missing webhook signature headers." });
    return;
  }
  try {
    const payload = Buffer.isBuffer(req.body) ? req.body.toString("utf8") : String(req.body || "");
    const resend = new Resend(config.apiKey || "re_webhook_verification_only");
    const verified = resend.webhooks.verify({
      payload,
      headers: signatureHeaders,
      webhookSecret: config.webhookSecret,
    });
    const event = resendEventSchema.parse(verified);
    const metadata: Record<string, string | number | boolean | null> = {};
    if (event.data.bounce?.type) metadata.bounceType = event.data.bounce.type;
    if (event.data.bounce?.subType) metadata.bounceSubType = event.data.bounce.subType;
    const result = await applyResendWebhookEvent({
      providerEventId: signatureHeaders.id,
      providerMessageId: event.data.email_id,
      eventType: event.type,
      occurredAt: new Date(event.created_at),
      eventMetadata: metadata,
    });
    res.status(200).json({ received: true, processed: result.processed });
  } catch {
    res.status(400).json({ error: "Invalid webhook." });
  }
}

export function registerResendWebhook(app: Express) {
  app.post(
    "/api/webhooks/resend",
    express.raw({ type: "application/json", limit: "1mb" }),
    receiveResendWebhook,
  );
}
