import { Button } from "@/components/ui/button";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { ArrowRight, LockKeyhole, ShieldCheck, UserCheck } from "lucide-react";
import { Link } from "wouter";

export default function AdminAccess() {
  const { user, loading, logout } = useAuth();
  const canAdminister = user?.role === "admin" || user?.role === "owner";

  return (
    <main id="main-content" className="min-h-screen bg-[#f6f8fb] px-5 py-12 sm:py-20">
      <div className="mx-auto max-w-5xl">
        <div className="rounded-3xl bg-[#071f49] p-7 text-white shadow-institutional sm:p-12">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-[#f47a20] text-[#041634]">
            <LockKeyhole className="h-7 w-7" aria-hidden="true" />
          </div>
          <p className="mt-8 text-sm font-bold uppercase tracking-[0.18em] text-[#ffab6b]">Content Administration</p>
          <h1 className="mt-3 max-w-3xl text-4xl font-bold text-white sm:text-6xl">Secure institutional access.</h1>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-200">
            Certification, instructor, cohort, roster, resource, and communication records are restricted to authorized VIBHA administrators.
          </p>
        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-2">
          <section className="rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
            <ShieldCheck className="h-8 w-8 text-[#b94700]" aria-hidden="true" />
            <h2 className="mt-5 text-3xl font-bold text-[#071f49]">Administrator sign-in</h2>
            <p className="mt-3 leading-7 text-slate-600">Use your approved account. Authentication alone does not grant administrative permission.</p>
            {loading ? <p role="status" className="mt-6 font-semibold text-slate-600">Checking access…</p> : null}
            {!loading && !user ? (
              <Button className="mt-6 bg-[#071f49] text-white hover:bg-[#173b70]" onClick={() => startLogin("/admin/access")}>Sign in securely <ArrowRight className="ml-2 h-4 w-4" /></Button>
            ) : null}
            {!loading && canAdminister ? (
              <Button asChild className="mt-6 bg-[#071f49] text-white hover:bg-[#173b70]"><Link href="/admin/certifications">Enter Content Administration <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
            ) : null}
            {!loading && user && !canAdminister ? (
              <div role="status" className="mt-6 rounded-xl border border-amber-200 bg-amber-50 p-5 text-amber-950">
                <p className="font-bold">This account is not permissioned.</p>
                <p className="mt-2 text-sm leading-6">Ask the VIBHA owner for an administrator invitation addressed to {user.email ?? "your sign-in email"}.</p>
                <Button variant="outline" className="mt-4 border-amber-300 bg-white" onClick={logout}>Sign out</Button>
              </div>
            ) : null}
          </section>

          <section className="rounded-2xl border border-slate-200 bg-white p-7 shadow-sm">
            <UserCheck className="h-8 w-8 text-[#b94700]" aria-hidden="true" />
            <h2 className="mt-5 text-3xl font-bold text-[#071f49]">Administrator registration</h2>
            <p className="mt-3 leading-7 text-slate-600">Registration is invitation-only. Open the unique link issued by the VIBHA owner, sign in with the invited email address, and complete identity binding.</p>
            <div className="mt-6 rounded-xl bg-[#f6f8fb] p-5 text-sm leading-6 text-slate-700">
              <strong className="text-[#071f49]">No open registration.</strong> Invitation links expire, work once, and cannot be transferred to a different email account.
            </div>
          </section>
        </div>
        <p className="mt-8 text-center text-sm text-slate-500"><Link href="/" className="font-bold text-[#173b70] hover:underline">Return to the VIBHA public website</Link></p>
      </div>
    </main>
  );
}
