import type { ReactNode } from "react";
import { SiteFooter } from "./SiteFooter";
import { SiteHeader } from "./SiteHeader";

export function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen bg-white text-[#16243a]">
      <SiteHeader />
      <main id="main-content" className="overflow-x-clip">
        {children}
      </main>
      <SiteFooter />
    </div>
  );
}
