import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { trpc } from "@/lib/trpc";
import { FilePenLine, Loader2, Plus, Search, UserRoundCheck } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Link } from "wouter";

function InstructorIndex() {
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");
  const [statusMessage, setStatusMessage] = useState("");
  const input = useMemo(() => ({ q: query.trim() || undefined, status: status === "all" ? undefined : status as "active" | "inactive" }), [query, status]);
  const instructors = trpc.adminInstructors.list.useQuery(input);
  const utils = trpc.useUtils();
  const statusMutation = trpc.adminInstructors.setStatus.useMutation({
    onSuccess: async item => {
      const message = `${item?.name ?? "Instructor"} ${item?.isActive ? "activated" : "deactivated"}.`;
      setStatusMessage(message);
      toast.success(message);
      await Promise.all([utils.adminInstructors.list.invalidate(), utils.adminCertifications.invalidate(), utils.certifications.invalidate()]);
    },
    onError: error => {
      setStatusMessage(`Status update failed: ${error.message}`);
      toast.error(error.message);
    },
  });

  return (
    <div className="mx-auto max-w-7xl">
      <p role="status" aria-live="polite" className="sr-only">{statusMutation.isPending ? "Updating instructor status." : statusMessage}</p>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="text-sm font-bold uppercase tracking-[0.16em] text-[#b94700]">Instructor CMS</p><h1 className="mt-2 text-4xl font-bold text-[#071f49]">Instructor directory</h1><p className="mt-3 max-w-3xl leading-7 text-slate-600">Register instructional faculty once, maintain credentials and expertise, and assign each instructor across the certification portfolio.</p></div>
        <Button asChild className="shrink-0 bg-[#071f49] font-bold text-white hover:bg-[#173b70]"><Link href="/admin/instructors/new"><Plus className="mr-2 h-4 w-4" />Register instructor</Link></Button>
      </div>
      <div className="mt-8 grid gap-3 rounded-xl border border-slate-200 bg-white p-4 shadow-sm sm:grid-cols-[1fr_220px]">
        <div className="relative"><Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input aria-label="Search instructors" value={query} onChange={event => setQuery(event.target.value)} placeholder="Search by name, email, title, or credentials" className="pl-10" /></div>
        <select aria-label="Filter instructors by status" value={status} onChange={event => setStatus(event.target.value)} className="rounded-md border border-input bg-white px-3 text-sm"><option value="all">All statuses</option><option value="active">Active</option><option value="inactive">Inactive</option></select>
      </div>
      {instructors.isLoading ? <div role="status" className="mt-8 flex items-center gap-3 rounded-xl border border-slate-200 bg-white p-8 text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Loading instructors…</div> : null}
      {instructors.error ? <div role="alert" className="mt-8 rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{instructors.error.message}</div> : null}
      {instructors.data ? <div className="mt-8 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm"><div className="border-b border-slate-200 px-5 py-4 text-sm text-slate-600"><strong className="text-[#071f49]">{instructors.data.length}</strong> instructor record{instructors.data.length === 1 ? "" : "s"}</div><div className="divide-y divide-slate-200">{instructors.data.map(instructor => <article key={instructor.id} className="grid gap-5 p-5 lg:grid-cols-[1fr_220px_150px_230px] lg:items-center"><div><div className="flex flex-wrap items-center gap-2"><h2 className="font-sans text-lg font-bold text-[#071f49]">{instructor.name}</h2><Badge className={instructor.isActive ? "bg-emerald-100 text-emerald-900" : "bg-slate-200 text-slate-700"}>{instructor.isActive ? "Active" : "Inactive"}</Badge></div><p className="mt-1 text-sm text-slate-600">{[instructor.credentials, instructor.title].filter(Boolean).join(" · ") || "Credentials and title not entered"}</p><p className="mt-1 text-xs text-slate-500">{instructor.email || "Email not entered"}</p></div><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Expertise</p><p className="mt-1 text-sm text-slate-700">{instructor.expertise?.slice(0, 3).join(", ") || "Not entered"}</p></div><div><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Assignments</p><p className="mt-1 font-bold text-[#071f49]">{instructor.certificationCount} certification{instructor.certificationCount === 1 ? "" : "s"}</p></div><div className="flex flex-wrap gap-2 lg:justify-end"><Button asChild size="sm" variant="outline" className="border-slate-300 bg-white"><Link href={`/admin/instructors/${instructor.id}/edit`}><FilePenLine className="mr-1.5 h-4 w-4" />Edit</Link></Button><Button size="sm" variant="outline" disabled={statusMutation.isPending} onClick={() => statusMutation.mutate({ id: instructor.id, isActive: !instructor.isActive })} className="border-slate-300 bg-white">{instructor.isActive ? "Deactivate" : "Activate"}</Button></div></article>)}</div>{instructors.data.length === 0 ? <div className="p-10 text-center"><UserRoundCheck className="mx-auto h-9 w-9 text-[#b94700]" /><h2 className="mt-3 text-2xl font-bold text-[#071f49]">No instructors match this view.</h2><p className="mt-2 text-sm text-slate-600">Change the filters or register a new instructor.</p></div> : null}</div> : null}
    </div>
  );
}

export default function AdminInstructors() {
  return <DashboardLayout><InstructorIndex /></DashboardLayout>;
}
