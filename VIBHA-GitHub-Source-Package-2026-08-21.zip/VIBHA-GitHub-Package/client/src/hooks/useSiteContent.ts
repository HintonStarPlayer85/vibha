import { trpc } from "@/lib/trpc";
import { mergeSiteContent } from "@shared/siteContent";
import { useMemo } from "react";

export function useSiteContent() {
  const query = trpc.siteContent.list.useQuery(undefined, { staleTime: 30_000 });
  const overrides = useMemo(
    () => Object.fromEntries((query.data ?? []).map(item => [item.key, item.value])),
    [query.data],
  );

  return {
    content: mergeSiteContent(overrides),
    overrides,
    isLoading: query.isLoading,
    isError: query.isError,
  };
}
