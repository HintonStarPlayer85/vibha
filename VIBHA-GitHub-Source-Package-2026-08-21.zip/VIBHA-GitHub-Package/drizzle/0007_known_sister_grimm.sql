CREATE TABLE `issued_certificates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`certificateNumber` varchar(64) NOT NULL,
	`verificationToken` varchar(128) NOT NULL,
	`activeIssuanceKey` varchar(80),
	`cohortId` int NOT NULL,
	`cohortStudentId` int,
	`certificationId` int NOT NULL,
	`recipientName` varchar(180) NOT NULL,
	`recipientEmail` varchar(320) NOT NULL,
	`cohortTitle` varchar(220) NOT NULL,
	`credentialTitle` varchar(220) NOT NULL,
	`ceuValue` varchar(24),
	`issuedAt` timestamp NOT NULL,
	`status` enum('issued','revoked','superseded') NOT NULL DEFAULT 'issued',
	`revokedAt` timestamp,
	`revocationReason` varchar(500),
	`reissueOfCertificateId` int,
	`documentStorageKey` varchar(800) NOT NULL,
	`documentUrl` varchar(1000) NOT NULL,
	`documentSha256` varchar(64) NOT NULL,
	`issuedByUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `issued_certificates_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificate_number_unique` UNIQUE(`certificateNumber`),
	CONSTRAINT `certificate_verification_token_unique` UNIQUE(`verificationToken`),
	CONSTRAINT `certificate_active_issuance_unique` UNIQUE(`activeIssuanceKey`)
);
--> statement-breakpoint
ALTER TABLE `issued_certificates` ADD CONSTRAINT `issued_certificates_cohortId_cohorts_id_fk` FOREIGN KEY (`cohortId`) REFERENCES `cohorts`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issued_certificates` ADD CONSTRAINT `issued_certificates_cohortStudentId_cohort_students_id_fk` FOREIGN KEY (`cohortStudentId`) REFERENCES `cohort_students`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issued_certificates` ADD CONSTRAINT `issued_certificates_certificationId_certifications_id_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `issued_certificates` ADD CONSTRAINT `issued_certificates_issuedByUserId_users_id_fk` FOREIGN KEY (`issuedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_cohort_issued_idx` ON `issued_certificates` (`cohortId`,`issuedAt`);--> statement-breakpoint
CREATE INDEX `certificate_student_issued_idx` ON `issued_certificates` (`cohortStudentId`,`issuedAt`);--> statement-breakpoint
CREATE INDEX `certificate_status_issued_idx` ON `issued_certificates` (`status`,`issuedAt`);