import { createHash, createHmac } from "node:crypto";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { administrationAuditEvents } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getDb } from "./db";

type DashboardRow = {
  certificationId: number;
  certificationTitle: string;
  delayedApprovals: number;
  escalationRecords: number;
  deliveredEscalations: number;
  oldestRequestedAt: Date | null;
  elapsedMinutes: number;
  slaTargetMinutes: number | null;
  slaBreached: boolean;
};

type Dashboard = {
  byCertification: DashboardRow[];
  trends: Array<{ date: string; total: number; delivered: number }>;
  range: { fromDate: string; toDate: string };
  generatedAt: string;
  workload: { availableReviewTasks: number; pendingSecondApprovals: number; assignedEscalations: number };
};

type ExportInput = {
  dashboard: Dashboard;
  exporter: { id: number; name: string; openId: string };
};

function safeCsvCell(value: string | number | boolean | Date | null | undefined) {
  const text = value == null ? "" : value instanceof Date ? value.toISOString() : String(value);
  const formulaSafe = /^[=+\-@]/.test(text) ? `'${text}` : text;
  return `"${formulaSafe.replaceAll('"', '""')}"`;
}

function createAttestation(input: ExportInput) {
  return createHmac("sha256", ENV.cookieSecret || "certificate-dashboard-export-fallback")
    .update(JSON.stringify({
      range: input.dashboard.range,
      generatedAt: input.dashboard.generatedAt,
      exporter: input.exporter.openId,
      rows: input.dashboard.byCertification.map(row => [row.certificationId, row.delayedApprovals, row.escalationRecords, row.slaBreached]),
      trend: input.dashboard.trends,
    }))
    .digest("hex");
}

async function recordExport(input: ExportInput, format: "csv" | "pdf", attestation: string, reportSha256: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  await db.insert(administrationAuditEvents).values({
    actorUserId: input.exporter.id,
    action: `certificate.governance_dashboard.${format}_exported`,
    entityType: "certificate_governance_dashboard",
    entityId: `${input.dashboard.range.fromDate}:${input.dashboard.range.toDate}`,
    eventMetadata: {
      fromDate: input.dashboard.range.fromDate,
      toDate: input.dashboard.range.toDate,
      reportSha256,
      attestation,
      certificationCount: input.dashboard.byCertification.length,
    },
  });
}

export async function generateCertificateGovernanceDashboardCsv(input: ExportInput) {
  const exportedAt = new Date();
  const attestation = createAttestation(input);
  const metadata = [
    ["Report", "VIBHA Certificate Governance Dashboard Metrics"],
    ["Date range", `${input.dashboard.range.fromDate} to ${input.dashboard.range.toDate}`],
    ["Export timestamp (UTC)", exportedAt.toISOString()],
    ["Exported by", input.exporter.name],
    ["Administrator identity", input.exporter.openId],
    ["Export attestation (HMAC-SHA256)", attestation],
    [],
  ];
  const header = ["Certification", "Delayed approvals", "Escalation records", "Delivered escalations", "Oldest pending request (UTC)", "Elapsed minutes", "SLA target (minutes)", "SLA breached"];
  const rows = input.dashboard.byCertification.map(row => [row.certificationTitle, row.delayedApprovals, row.escalationRecords, row.deliveredEscalations, row.oldestRequestedAt, row.elapsedMinutes, row.slaTargetMinutes, row.slaBreached ? "Yes" : "No"]);
  const trendHeader = ["Trend date", "Escalations created", "Escalations delivered"];
  const trendRows = input.dashboard.trends.map(row => [row.date, row.total, row.delivered]);
  const csv = [...metadata, header, ...rows, [], trendHeader, ...trendRows].map(row => row.map(value => safeCsvCell(value as string | number | boolean | Date | null | undefined)).join(",")).join("\r\n");
  const bytes = Buffer.from(csv, "utf8");
  const reportSha256 = createHash("sha256").update(bytes).digest("hex");
  await recordExport(input, "csv", attestation, reportSha256);
  return { fileName: `vibha-governance-metrics-${input.dashboard.range.fromDate}-to-${input.dashboard.range.toDate}.csv`, dataBase64: bytes.toString("base64"), exportedAt: exportedAt.toISOString(), attestation, reportSha256 };
}

export async function generateCertificateGovernanceDashboardPdf(input: ExportInput) {
  const exportedAt = new Date();
  const attestation = createAttestation(input);
  const pdf = await PDFDocument.create();
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const navy = rgb(0.027, 0.122, 0.286);
  let page = pdf.addPage([792, 612]);
  let y = 540;
  const addHeader = (target: typeof page, title: string) => {
    target.drawRectangle({ x: 0, y: 548, width: 792, height: 64, color: navy });
    target.drawText("VIBHA", { x: 42, y: 578, size: 22, font: bold, color: rgb(1, 1, 1) });
    target.drawText(title, { x: 42, y: 558, size: 10, font: regular, color: rgb(1, 1, 1) });
  };
  addHeader(page, "Certificate Governance Dashboard Metrics");
  const metadata = [
    `Date range: ${input.dashboard.range.fromDate} to ${input.dashboard.range.toDate}`,
    `Exported: ${exportedAt.toISOString()} UTC`,
    `Exported by: ${input.exporter.name} (${input.exporter.openId})`,
    `Workload snapshot: ${input.dashboard.workload.availableReviewTasks} review tasks · ${input.dashboard.workload.pendingSecondApprovals} second approvals · ${input.dashboard.workload.assignedEscalations} assigned escalations`,
  ];
  for (const line of metadata) { page.drawText(line, { x: 42, y, size: 9, font: regular, color: rgb(0.12, 0.16, 0.23) }); y -= 14; }
  y -= 8;
  const columnX = [42, 276, 392, 484, 572, 670];
  ["Certification", "Delayed", "Escalations", "Delivered", "SLA", "Breach"].forEach((label, index) => page.drawText(label, { x: columnX[index]!, y, size: 8, font: bold, color: navy }));
  y -= 16;
  for (const row of input.dashboard.byCertification) {
    if (y < 60) { page = pdf.addPage([792, 612]); addHeader(page, "Certificate Governance Dashboard Metrics (continued)"); y = 530; }
    const sla = row.slaTargetMinutes ? `${row.elapsedMinutes}/${row.slaTargetMinutes} min` : "Not set";
    page.drawText(row.certificationTitle.slice(0, 40), { x: columnX[0]!, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23) });
    page.drawText(String(row.delayedApprovals), { x: columnX[1]!, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23) });
    page.drawText(String(row.escalationRecords), { x: columnX[2]!, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23) });
    page.drawText(String(row.deliveredEscalations), { x: columnX[3]!, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23) });
    page.drawText(sla, { x: columnX[4]!, y, size: 7.5, font: regular, color: row.slaBreached ? rgb(0.65, 0.1, 0.1) : rgb(0.15, 0.18, 0.23) });
    page.drawText(row.slaBreached ? "BREACHED" : "Within target", { x: columnX[5]!, y, size: 7.5, font: bold, color: row.slaBreached ? rgb(0.65, 0.1, 0.1) : rgb(0.08, 0.4, 0.25) });
    y -= 17;
  }
  page.drawText(`Report attestation (HMAC-SHA256): ${attestation}`, { x: 42, y: 34, size: 6.5, font: regular, color: rgb(0.35, 0.4, 0.48) });
  const bytes = await pdf.save();
  const reportSha256 = createHash("sha256").update(bytes).digest("hex");
  await recordExport(input, "pdf", attestation, reportSha256);
  return { fileName: `vibha-governance-metrics-${input.dashboard.range.fromDate}-to-${input.dashboard.range.toDate}.pdf`, dataBase64: Buffer.from(bytes).toString("base64"), exportedAt: exportedAt.toISOString(), attestation, reportSha256 };
}
