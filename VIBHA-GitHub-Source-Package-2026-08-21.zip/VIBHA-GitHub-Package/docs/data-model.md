# VIBHA Data Model

The public catalog is centered on the `certifications` table. Categories and instructors are normalized to prevent repeated content, while JSON fields preserve ordered educational content such as objectives, audiences, delivery methods, and curriculum topics. Inquiry records retain program-routing context without coupling the public form to a specific CRM.

| Entity | Responsibility | Scale Control |
|---|---|---|
| `certification_categories` | Topic areas, display order, descriptive program-page content | Unique slug and active index |
| `certifications` | Public and admin-managed certification records | Unique slug, lifecycle status, category/status indexes, non-destructive deactivation |
| `instructors` | Reusable instructor identities and biographies | Unique slug and active status |
| `certification_instructors` | Ordered many-to-many instructor assignment | Composite primary key |
| `inquiries` | Individual, agency, and general contact submissions | Routing, status, certification relation, consent, audit timestamps |

Tuition is stored in cents for deterministic filtering and paired with `costDisplay` for presentation. CEUs use a two-decimal numeric field. All list-oriented academic content is stored as JSON arrays and validated by the API before persistence.

