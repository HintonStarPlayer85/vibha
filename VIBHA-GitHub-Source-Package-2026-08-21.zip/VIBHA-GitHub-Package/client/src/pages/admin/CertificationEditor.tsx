import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { certificationInputSchema, type CertificationInput } from "@shared/catalog";
import { ArrowLeft, ExternalLink, Loader2, Save } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { toast } from "sonner";
import { Link, useLocation, useParams } from "wouter";

const emptyCertification: CertificationInput = {
  title: "",
  shortTitle: null,
  slug: "",
  categoryId: 0,
  description: "",
  summary: "",
  valueStatement: null,
  objectives: [""],
  curriculumTopics: [""],
  idealAudience: [""],
  eligibilityRequirements: [""],
  prerequisites: "",
  format: "Virtual live",
  deliveryLocation: "Online; agency-based delivery available by arrangement",
  deliveryMethods: ["Virtual Live Instruction", "Hybrid Learning", "Evening Cohorts"],
  schedule: "Cohort-based scheduling. Contact VIBHA for upcoming dates and delivery availability.",
  duration: "",
  ceus: 0,
  costCents: 0,
  costDisplay: "Contact VIBHA",
  level: "Foundational",
  careerRelevance: null,
  enrollmentUrl: "",
  inquiryType: "program-information",
  status: "draft",
  isFeatured: false,
  displayOrder: 0,
  seoTitle: null,
  seoDescription: null,
  instructorIds: [],
};

function slugify(value: string) {
  return value.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}

function lines(value: string) {
  return value.split("\n").map(item => item.trim()).filter(Boolean);
}

function EditorContent({ id }: { id?: number }) {
  const editing = Boolean(id);
  const [, navigate] = useLocation();
  const [form, setForm] = useState<CertificationInput>(emptyCertification);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [statusMessage, setStatusMessage] = useState("");
  const [slugEdited, setSlugEdited] = useState(false);
  const utils = trpc.useUtils();
  const options = trpc.adminCertifications.options.useQuery();
  const existing = trpc.adminCertifications.getById.useQuery({ id: id ?? 0 }, { enabled: editing });
  const createMutation = trpc.adminCertifications.create.useMutation();
  const updateMutation = trpc.adminCertifications.update.useMutation();
  const pending = createMutation.isPending || updateMutation.isPending;

  useEffect(() => {
    if (!existing.data) return;
    setForm({
      title: existing.data.title,
      shortTitle: existing.data.shortTitle,
      slug: existing.data.slug,
      categoryId: existing.data.categoryId,
      description: existing.data.description,
      summary: existing.data.summary,
      valueStatement: existing.data.valueStatement,
      objectives: existing.data.objectives,
      curriculumTopics: existing.data.curriculumTopics,
      idealAudience: existing.data.idealAudience,
      eligibilityRequirements: existing.data.eligibilityRequirements,
      prerequisites: existing.data.prerequisites,
      format: existing.data.format,
      deliveryLocation: existing.data.deliveryLocation,
      deliveryMethods: existing.data.deliveryMethods,
      schedule: existing.data.schedule,
      duration: existing.data.duration,
      ceus: existing.data.ceus,
      costCents: existing.data.costCents,
      costDisplay: existing.data.costDisplay,
      level: existing.data.level,
      careerRelevance: existing.data.careerRelevance,
      enrollmentUrl: existing.data.enrollmentUrl ?? "",
      inquiryType: existing.data.inquiryType,
      status: existing.data.status,
      isFeatured: existing.data.isFeatured,
      displayOrder: existing.data.displayOrder,
      seoTitle: existing.data.seoTitle,
      seoDescription: existing.data.seoDescription,
      instructorIds: existing.data.instructorIds,
    });
    setSlugEdited(true);
  }, [existing.data]);

  useEffect(() => {
    if (!editing && options.data?.categories[0] && form.categoryId === 0) {
      setForm(current => ({ ...current, categoryId: options.data!.categories[0].id }));
    }
  }, [editing, form.categoryId, options.data]);

  function update<K extends keyof CertificationInput>(key: K, value: CertificationInput[K]) {
    setForm(current => ({ ...current, [key]: value }));
    setErrors(current => ({ ...current, [key]: "" }));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    const parsed = certificationInputSchema.safeParse(form);
    if (!parsed.success) {
      const next: Record<string, string> = {};
      for (const issue of parsed.error.issues) next[String(issue.path[0])] ??= issue.message;
      setErrors(next);
      setStatusMessage("Certification was not saved. Review the highlighted fields.");
      document.getElementById("editor-errors")?.focus();
      return;
    }
    try {
      const saved = editing
        ? await updateMutation.mutateAsync({ id: id!, data: parsed.data })
        : await createMutation.mutateAsync(parsed.data);
      await Promise.all([utils.adminCertifications.list.invalidate(), utils.certifications.invalidate()]);
      const message = editing ? "Certification updated." : "Certification created.";
      setStatusMessage(message);
      toast.success(message);
      navigate(`/admin/certifications/${saved!.id}/edit`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "The certification could not be saved.";
      setStatusMessage(`Save failed: ${message}`);
      toast.error(message);
    }
  }

  if (editing && existing.isLoading) return <div className="mx-auto flex max-w-4xl items-center gap-3 rounded-xl border border-slate-200 bg-white p-8"><Loader2 className="h-5 w-5 animate-spin" />Loading certification editor…</div>;
  if (editing && existing.error) return <div role="alert" className="mx-auto max-w-4xl rounded-xl border border-red-200 bg-red-50 p-6 text-red-800">{existing.error.message}</div>;

  const fieldError = (name: keyof CertificationInput) => errors[name] ? <p className="mt-1 text-sm text-red-700">{errors[name]}</p> : null;
  const listField = (name: "objectives" | "curriculumTopics" | "idealAudience" | "eligibilityRequirements" | "deliveryMethods", label: string, rows = 5) => (
    <div><Label htmlFor={name}>{label}</Label><Textarea id={name} rows={rows} className="mt-2 resize-y" value={form[name].join("\n")} onChange={event => update(name, lines(event.target.value))} aria-invalid={Boolean(errors[name])} /><p className="mt-1 text-xs text-slate-500">Enter one item per line.</p>{fieldError(name)}</div>
  );

  return (
    <form onSubmit={submit} noValidate className="mx-auto max-w-6xl">
      <p role="status" aria-live="polite" className="sr-only">{pending ? "Saving certification." : statusMessage}</p>
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><Link href="/admin/certifications" className="inline-flex items-center gap-2 text-sm font-bold text-[#173b70] hover:underline"><ArrowLeft className="h-4 w-4" />Certification listings</Link><h1 className="mt-4 text-4xl font-bold text-[#071f49]">{editing ? "Edit certification" : "Create certification"}</h1><p className="mt-3 text-slate-600">All fields below power the public catalog card and certification detail route.</p></div><div className="flex gap-2">{editing && form.status === "published" ? <Button asChild type="button" variant="outline" className="border-slate-300 bg-white"><Link href={`/certifications/${form.slug}`}><ExternalLink className="mr-2 h-4 w-4" />View public page</Link></Button> : null}<Button type="submit" disabled={pending} className="bg-[#071f49] font-bold text-white hover:bg-[#173b70]">{pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Save certification</Button></div></div>
      {Object.keys(errors).length ? <div id="editor-errors" tabIndex={-1} role="alert" className="mt-6 rounded-xl border border-red-200 bg-red-50 p-5 text-red-800"><p className="font-bold">Review the highlighted fields before saving.</p><p className="mt-1 text-sm">The server applies the same validation rules.</p></div> : null}
      <div className="mt-8 space-y-6">
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Identity and catalog content</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><Label htmlFor="title">Official title</Label><Input id="title" className="mt-2" value={form.title} onChange={event => { const title = event.target.value; update("title", title); if (!slugEdited) update("slug", slugify(title)); }} aria-invalid={Boolean(errors.title)} />{fieldError("title")}</div><div><Label htmlFor="shortTitle">Short title</Label><Input id="shortTitle" className="mt-2" value={form.shortTitle ?? ""} onChange={event => update("shortTitle", event.target.value)} />{fieldError("shortTitle")}</div><div><Label htmlFor="slug">URL slug</Label><Input id="slug" className="mt-2 font-mono" value={form.slug} onChange={event => { setSlugEdited(true); update("slug", slugify(event.target.value)); }} aria-invalid={Boolean(errors.slug)} />{fieldError("slug")}</div><div><Label htmlFor="category">Category</Label><select id="category" value={form.categoryId} onChange={event => update("categoryId", Number(event.target.value))} className="mt-2 h-10 w-full rounded-md border border-input bg-white px-3 text-sm">{options.data?.categories.map(category => <option key={category.id} value={category.id}>{category.name}{category.isActive ? "" : " (inactive)"}</option>)}</select>{fieldError("categoryId")}</div><div><Label htmlFor="status">Status</Label><select id="status" value={form.status} onChange={event => update("status", event.target.value as CertificationInput["status"])} className="mt-2 h-10 w-full rounded-md border border-input bg-white px-3 text-sm"><option value="draft">Draft</option><option value="published">Published</option><option value="coming_soon">Coming soon</option><option value="inactive">Inactive</option><option value="archived">Archived</option></select></div><div><Label htmlFor="level">Level</Label><Input id="level" className="mt-2" value={form.level} onChange={event => update("level", event.target.value)} aria-invalid={Boolean(errors.level)} />{fieldError("level")}</div><div className="sm:col-span-2"><Label htmlFor="summary">Catalog summary</Label><Textarea id="summary" rows={3} className="mt-2 resize-y" value={form.summary} onChange={event => update("summary", event.target.value)} aria-invalid={Boolean(errors.summary)} />{fieldError("summary")}</div><div className="sm:col-span-2"><Label htmlFor="description">Full description</Label><Textarea id="description" rows={6} className="mt-2 resize-y" value={form.description} onChange={event => update("description", event.target.value)} aria-invalid={Boolean(errors.description)} />{fieldError("description")}</div><div className="sm:col-span-2"><Label htmlFor="valueStatement">Value statement</Label><Textarea id="valueStatement" rows={2} className="mt-2 resize-y" value={form.valueStatement ?? ""} onChange={event => update("valueStatement", event.target.value)} /></div></div></section>
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Academic and audience content</h2><div className="mt-6 grid gap-6 sm:grid-cols-2">{listField("objectives", "Learning objectives")}{listField("curriculumTopics", "Curriculum topics")}{listField("idealAudience", "Ideal audience")}{listField("eligibilityRequirements", "Eligibility requirements")}<div className="sm:col-span-2"><Label htmlFor="prerequisites">Prerequisites</Label><Textarea id="prerequisites" rows={3} className="mt-2 resize-y" value={form.prerequisites} onChange={event => update("prerequisites", event.target.value)} aria-invalid={Boolean(errors.prerequisites)} />{fieldError("prerequisites")}</div><div><Label htmlFor="ceus">CEUs</Label><Input id="ceus" type="number" min="0" step="0.01" className="mt-2" value={form.ceus} onChange={event => update("ceus", Number(event.target.value))} aria-invalid={Boolean(errors.ceus)} />{fieldError("ceus")}</div><div><Label htmlFor="careerRelevance">Career relevance</Label><Textarea id="careerRelevance" rows={3} className="mt-2 resize-y" value={form.careerRelevance ?? ""} onChange={event => update("careerRelevance", event.target.value)} /></div></div></section>
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Delivery, schedule, and enrollment</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><Label htmlFor="format">Primary format</Label><Input id="format" className="mt-2" value={form.format} onChange={event => update("format", event.target.value)} aria-invalid={Boolean(errors.format)} />{fieldError("format")}</div><div><Label htmlFor="deliveryLocation">Delivery location</Label><Input id="deliveryLocation" className="mt-2" value={form.deliveryLocation} onChange={event => update("deliveryLocation", event.target.value)} aria-invalid={Boolean(errors.deliveryLocation)} />{fieldError("deliveryLocation")}</div><div className="sm:col-span-2">{listField("deliveryMethods", "Delivery methods", 3)}</div><div><Label htmlFor="duration">Duration</Label><Input id="duration" className="mt-2" value={form.duration} onChange={event => update("duration", event.target.value)} aria-invalid={Boolean(errors.duration)} />{fieldError("duration")}</div><div><Label htmlFor="schedule">Schedule</Label><Textarea id="schedule" rows={3} className="mt-2 resize-y" value={form.schedule} onChange={event => update("schedule", event.target.value)} aria-invalid={Boolean(errors.schedule)} />{fieldError("schedule")}</div><div><Label htmlFor="costDollars">Cost in dollars</Label><Input id="costDollars" type="number" min="0" step="0.01" className="mt-2" value={(form.costCents / 100).toFixed(2)} onChange={event => update("costCents", Math.round(Number(event.target.value) * 100))} /></div><div><Label htmlFor="costDisplay">Cost display</Label><Input id="costDisplay" className="mt-2" value={form.costDisplay} onChange={event => update("costDisplay", event.target.value)} aria-invalid={Boolean(errors.costDisplay)} />{fieldError("costDisplay")}</div><div className="sm:col-span-2"><Label htmlFor="enrollmentUrl">Enrollment URL</Label><Input id="enrollmentUrl" type="url" className="mt-2" placeholder="https://…" value={form.enrollmentUrl ?? ""} onChange={event => update("enrollmentUrl", event.target.value)} aria-invalid={Boolean(errors.enrollmentUrl)} /><p className="mt-1 text-xs text-slate-500">Leave blank to display the enrollment-information fallback.</p>{fieldError("enrollmentUrl")}</div></div></section>
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Faculty, routing, visibility, and search metadata</h2><div className="mt-6 grid gap-6 sm:grid-cols-2"><fieldset><legend className="text-sm font-medium">Assigned instructors</legend><div className="mt-3 space-y-2">{options.data?.instructors.map(instructor => <label key={instructor.id} className="flex items-start gap-3 rounded-lg border border-slate-200 p-3 text-sm"><input type="checkbox" className="mt-1 h-4 w-4 accent-[#071f49]" checked={form.instructorIds.includes(instructor.id)} onChange={event => update("instructorIds", event.target.checked ? [...form.instructorIds, instructor.id] : form.instructorIds.filter(value => value !== instructor.id))} /><span><strong className="block text-[#071f49]">{instructor.name}</strong><span className="text-slate-500">{instructor.title}</span></span></label>)}</div></fieldset><div className="space-y-5"><label className="flex items-center gap-3 rounded-lg border border-slate-200 p-4 text-sm font-semibold text-[#071f49]"><input type="checkbox" checked={form.isFeatured} onChange={event => update("isFeatured", event.target.checked)} className="h-4 w-4 accent-[#071f49]" />Feature on the homepage</label><div><Label htmlFor="displayOrder">Display order</Label><Input id="displayOrder" type="number" min="0" className="mt-2" value={form.displayOrder} onChange={event => update("displayOrder", Number(event.target.value))} /></div><div><Label htmlFor="inquiryType">Inquiry routing key</Label><Input id="inquiryType" className="mt-2" value={form.inquiryType} onChange={event => update("inquiryType", event.target.value)} aria-invalid={Boolean(errors.inquiryType)} /><p className="mt-1 text-xs text-slate-500">Used to classify and route program-specific inquiries.</p>{fieldError("inquiryType")}</div></div><div><Label htmlFor="seoTitle">SEO title</Label><Input id="seoTitle" className="mt-2" value={form.seoTitle ?? ""} onChange={event => update("seoTitle", event.target.value)} /></div><div><Label htmlFor="seoDescription">SEO description</Label><Textarea id="seoDescription" rows={3} className="mt-2 resize-y" value={form.seoDescription ?? ""} onChange={event => update("seoDescription", event.target.value)} /></div>{editing && existing.data ? <div className="sm:col-span-2 rounded-lg bg-[#f6f8fb] p-5"><h3 className="font-sans text-sm font-bold uppercase tracking-wide text-[#071f49]">System-managed content governance</h3><p className="mt-2 text-sm leading-6 text-slate-600">Publication and audit dates are controlled by the platform to preserve record integrity. Publishing sets the publication date; every save updates the audit timestamp.</p><dl className="mt-4 grid gap-4 text-sm sm:grid-cols-3"><div><dt className="font-semibold text-slate-500">Created</dt><dd className="mt-1 font-bold text-[#071f49]">{new Date(existing.data.createdAt).toLocaleString()}</dd></div><div><dt className="font-semibold text-slate-500">Published</dt><dd className="mt-1 font-bold text-[#071f49]">{existing.data.publishedAt ? new Date(existing.data.publishedAt).toLocaleString() : "Not published"}</dd></div><div><dt className="font-semibold text-slate-500">Last updated</dt><dd className="mt-1 font-bold text-[#071f49]">{new Date(existing.data.updatedAt).toLocaleString()}</dd></div></dl></div> : null}</div></section>
      </div>
      <div className="sticky bottom-4 mt-6 flex justify-end rounded-xl border border-slate-200 bg-white/95 p-4 shadow-xl backdrop-blur"><Button type="submit" disabled={pending} className="bg-[#071f49] px-6 font-bold text-white hover:bg-[#173b70]">{pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}Save certification</Button></div>
    </form>
  );
}

export default function CertificationEditor() {
  const params = useParams<{ id?: string }>();
  const id = params.id ? Number(params.id) : undefined;
  return <DashboardLayout><EditorContent id={id} /></DashboardLayout>;
}
