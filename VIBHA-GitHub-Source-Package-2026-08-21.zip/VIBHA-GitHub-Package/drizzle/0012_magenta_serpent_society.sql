ALTER TABLE `cohort_students` ADD `completionApprovalStatus` enum('not_requested','pending','approved','returned') DEFAULT 'not_requested' NOT NULL;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD `completionReviewedByUserId` int;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD `completionReviewedAt` timestamp;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD `completionReviewNotes` text;--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureStorageKey` varchar(800);--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureUrl` varchar(1000);--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureFileName` varchar(320);--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureMimeType` varchar(120);--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureUploadedAt` timestamp;--> statement-breakpoint
ALTER TABLE `instructors` ADD `signatureUpdatedByUserId` int;--> statement-breakpoint
ALTER TABLE `cohort_students` ADD CONSTRAINT `cohort_completion_reviewer_fk` FOREIGN KEY (`completionReviewedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `instructors` ADD CONSTRAINT `instructor_signature_updater_fk` FOREIGN KEY (`signatureUpdatedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `cohort_student_completion_approval_idx` ON `cohort_students` (`cohortId`,`status`,`completionApprovalStatus`);
