import { Button } from "@/components/ui/button";
import { backToTopThreshold, preferredScrollBehavior } from "@/lib/motion";
import { ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";

export function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      setVisible(window.scrollY > backToTopThreshold(window.innerHeight));
    };
    const onScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(update);
    };

    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);

  const returnToTop = () => {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    window.scrollTo({ top: 0, behavior: preferredScrollBehavior(reducedMotion) });
    window.setTimeout(() => document.getElementById("page-top")?.focus({ preventScroll: true }), reducedMotion ? 0 : 450);
  };

  return (
    <Button
        type="button"
        onClick={returnToTop}
        aria-label="Back to top"
        aria-hidden={!visible}
        tabIndex={visible ? 0 : -1}
        className={`fixed bottom-5 right-4 z-[70] h-12 min-w-12 rounded-full border border-white/20 bg-[#071f49] px-3 font-bold text-white shadow-[0_12px_35px_rgba(4,22,52,0.28)] transition-[opacity,transform,background-color] duration-200 hover:-translate-y-1 hover:bg-[#173b70] sm:right-6 sm:px-4 ${visible ? "pointer-events-auto translate-y-0 opacity-100" : "pointer-events-none translate-y-3 opacity-0"}`}
      >
        <ArrowUp className="h-5 w-5" aria-hidden="true" />
        <span className="hidden sm:inline">Back to top</span>
    </Button>
  );
}
