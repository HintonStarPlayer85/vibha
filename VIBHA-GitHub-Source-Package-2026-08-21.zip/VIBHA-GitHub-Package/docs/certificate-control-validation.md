# Certificate Control Validation Record

## Scope

This update adds a non-persistent pre-issuance certificate preview, executive signature-image management, and a cohort-specific signing instructor override.

## Validation Evidence

The Certificate Template Settings workflow was reviewed at desktop and 375-pixel mobile widths. The completed interface exposes an Executive Signature Image panel with PNG/JPEG upload, preview, replacement, and removal controls alongside the existing executive signatory name and title settings.

The Cohort Administration create workflow was reviewed at desktop and 375-pixel mobile widths. It exposes a clearly labeled **Certificate signing instructor override** selector. Leaving the selector unset retains the certification template or assigned instructor fallback; selecting an instructor makes that instructor’s identity and approved signature asset the effective signer for new certificates in that cohort.

The Certificate Repository contains a protected Preview action for each issuance-eligible learner. The preview invokes the same certificate renderer as issuance, is marked **PREVIEW ONLY — NOT ISSUED**, does not create a certificate number, QR verification record, S3 certificate artifact, or repository entry, and opens the generated PDF for administrator review.

## Automated Checks

The full Vitest suite passed with **21 test files and 102 tests**. TypeScript validation and the production build completed successfully. Coverage includes non-persistent preview authorization and service behavior, signatory precedence, snapshot continuity, certificate PDF rendering, and the existing protected certificate workflow tests.
