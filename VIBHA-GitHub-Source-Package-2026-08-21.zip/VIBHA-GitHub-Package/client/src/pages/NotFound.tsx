import { PublicLayout } from "@/components/public/PublicLayout";
import { Button } from "@/components/ui/button";
import { usePageMeta } from "@/hooks/usePageMeta";
import { ArrowRight, Home, Search } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  usePageMeta("Page not found | VIBHA", "The requested VIBHA page could not be found.");
  return (
    <PublicLayout>
      <section className="vibha-grid bg-[#071f49] py-24 text-white sm:py-32">
        <div className="container text-center">
          <p className="font-serif text-8xl font-bold text-[#f47a20]">404</p>
          <h1 className="mt-5 text-5xl font-bold">This page is not available.</h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-8 text-slate-200">
            The address may have changed, or the certification may no longer be publicly available. Use a verified pathway below to continue.
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button asChild className="bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">
              <Link href="/"><Home className="mr-2 h-4 w-4" />Return home</Link>
            </Button>
            <Button asChild variant="outline" className="border-white/40 bg-transparent font-bold text-white hover:bg-white/10 hover:text-white">
              <Link href="/certifications"><Search className="mr-2 h-4 w-4" />Browse certifications <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
