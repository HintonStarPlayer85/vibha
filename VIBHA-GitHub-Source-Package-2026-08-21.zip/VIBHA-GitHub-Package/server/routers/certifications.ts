import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { catalogQuerySchema, slugSchema } from "../../shared/catalog";
import {
  getCatalog,
  getCertificationBySlug,
  getCertificationCategories,
  getFeaturedCertifications,
  getFilterOptions,
} from "../db";
import { publicProcedure, router } from "../_core/trpc";

export const certificationsRouter = router({
  list: publicProcedure
    .input(catalogQuerySchema.optional())
    .query(({ input }) => getCatalog(catalogQuerySchema.parse(input ?? {}))),
  categories: publicProcedure.query(() => getCertificationCategories(false)),
  filterOptions: publicProcedure.query(() => getFilterOptions()),
  featured: publicProcedure
    .input(z.object({ limit: z.number().int().min(1).max(12).default(8) }).optional())
    .query(({ input }) => getFeaturedCertifications(input?.limit ?? 8)),
  bySlug: publicProcedure.input(z.object({ slug: slugSchema })).query(async ({ input }) => {
    const certification = await getCertificationBySlug(input.slug);
    if (!certification) throw new TRPCError({ code: "NOT_FOUND", message: "Certification not found." });
    return certification;
  }),
});

