import { ArrowRight, Award, BookOpenCheck, Clock3, Laptop2, WalletCards } from "lucide-react";
import { Link } from "wouter";

export type CertificationCardData = {
  id: number;
  title: string;
  slug: string;
  summary: string;
  categoryName: string;
  categorySlug: string;
  level: string;
  ceus: number;
  format: string;
  duration: string;
  costDisplay: string;
};

export function CertificationCard({
  certification,
  returnTo,
}: {
  certification: CertificationCardData;
  returnTo?: string;
}) {
  const detailHref = `/certifications/${certification.slug}${returnTo ? `?returnTo=${encodeURIComponent(returnTo)}` : ""}`;
  return (
    <article data-reveal="scale" className="vibha-card-interactive group flex h-full flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-[0_8px_30px_rgba(4,22,52,0.06)] hover:border-[#173b70]/40">
      <div className="h-1.5 bg-[#f47a20]" />
      <div className="flex flex-1 flex-col p-6">
        <Link
          href={`/certifications?category=${certification.categorySlug}`}
          className="w-fit rounded-full bg-[#eef3f9] px-3 py-1 text-xs font-bold uppercase tracking-[0.08em] text-[#173b70] hover:bg-[#dce6f2]"
        >
          {certification.categoryName}
        </Link>
        <h3 className="mt-4 text-2xl font-bold leading-tight text-[#071f49]">
          <Link className="rounded-sm decoration-[#f47a20] decoration-2 underline-offset-4 hover:underline" href={detailHref}>
            {certification.title}
          </Link>
        </h3>
        <p className="mt-3 line-clamp-3 text-sm leading-6 text-slate-600">{certification.summary}</p>
        <dl className="mt-6 grid grid-cols-2 gap-x-4 gap-y-4 border-y border-slate-200 py-5 text-sm">
          <div>
            <dt className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500"><BookOpenCheck className="h-3.5 w-3.5" /> Level</dt>
            <dd className="mt-1 font-semibold text-slate-800">{certification.level}</dd>
          </div>
          <div>
            <dt className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500"><Award className="h-3.5 w-3.5" /> CEUs</dt>
            <dd className="mt-1 font-semibold text-slate-800">{certification.ceus > 0 ? certification.ceus : "To be confirmed"}</dd>
          </div>
          <div>
            <dt className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500"><Laptop2 className="h-3.5 w-3.5" /> Format</dt>
            <dd className="mt-1 font-semibold text-slate-800">{certification.format}</dd>
          </div>
          <div>
            <dt className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-slate-500"><WalletCards className="h-3.5 w-3.5" /> Cost</dt>
            <dd className="mt-1 font-semibold text-slate-800">{certification.costDisplay}</dd>
          </div>
        </dl>
        <div className="mt-5 flex items-center justify-between gap-3">
          <span className="inline-flex items-center gap-1.5 text-sm text-slate-600"><Clock3 className="h-4 w-4 text-[#b94700]" /> {certification.duration}</span>
          <Link href={detailHref} className="vibha-icon-shift inline-flex items-center gap-1.5 rounded-sm text-sm font-bold text-[#173b70] hover:text-[#071f49] hover:underline">
            View program <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </article>
  );
}
