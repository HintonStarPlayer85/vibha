import { and, asc, desc, eq, inArray } from "drizzle-orm";
import {
  administrationAuditEvents,
  certifications,
  onlineCourseGenerationRuns,
  onlineCourseLessons,
  onlineCourseMaterials,
  onlineCourseModules,
  onlineCourses,
  onlineModuleQuizQuestions,
  onlineModuleQuizzes,
} from "../drizzle/schema";
import type { GeneratedCourse, OnlineCourseStatus } from "../shared/onlineLearning";
import { getDb } from "./db";

export const onlineLearningErrors = {
  courseNotFound: "ONLINE_COURSE_NOT_FOUND",
  materialNotFound: "ONLINE_MATERIAL_NOT_FOUND",
  moduleNotFound: "ONLINE_MODULE_NOT_FOUND",
  lessonNotFound: "ONLINE_LESSON_NOT_FOUND",
  certificationNotPublished: "ONLINE_CERTIFICATION_NOT_PUBLISHED",
  courseAlreadyActivated: "ONLINE_COURSE_ALREADY_ACTIVATED",
  materialsRequired: "ONLINE_MATERIALS_REQUIRED",
  materialsNotAnalyzed: "ONLINE_MATERIALS_NOT_ANALYZED",
  courseIsPublished: "ONLINE_COURSE_IS_PUBLISHED",
  generatedContentRequired: "ONLINE_GENERATED_CONTENT_REQUIRED",
  courseNotPublic: "ONLINE_COURSE_NOT_PUBLIC",
} as const;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

export async function listOnlineCourses() {
  const db = await requireDb();
  const rows = await db
    .select({
      id: onlineCourses.id,
      certificationId: onlineCourses.certificationId,
      certificationTitle: certifications.title,
      certificationSlug: certifications.slug,
      certificationStatus: certifications.status,
      status: onlineCourses.status,
      lastGeneratedAt: onlineCourses.lastGeneratedAt,
      updatedAt: onlineCourses.updatedAt,
    })
    .from(onlineCourses)
    .innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id))
    .orderBy(desc(onlineCourses.updatedAt), asc(certifications.title));
  return Promise.all(rows.map(async row => {
    const [materials, modules] = await Promise.all([
      db.select({ total: onlineCourseMaterials.id }).from(onlineCourseMaterials).where(eq(onlineCourseMaterials.courseId, row.id)),
      db.select({ total: onlineCourseModules.id }).from(onlineCourseModules).where(eq(onlineCourseModules.courseId, row.id)),
    ]);
    return { ...row, materialCount: materials.length, moduleCount: modules.length };
  }));
}

export async function listPublishedCertificationOptions() {
  const db = await requireDb();
  return db
    .select({ id: certifications.id, title: certifications.title, slug: certifications.slug, summary: certifications.summary })
    .from(certifications)
    .where(eq(certifications.status, "published"))
    .orderBy(asc(certifications.title));
}

export async function getOnlineCourseAdminById(id: number) {
  const db = await requireDb();
  const course = (await db
    .select({
      id: onlineCourses.id,
      certificationId: onlineCourses.certificationId,
      status: onlineCourses.status,
      courseOverview: onlineCourses.courseOverview,
      sourceGroundingNotice: onlineCourses.sourceGroundingNotice,
      aiInstructorName: onlineCourses.aiInstructorName,
      aiInstructorWelcome: onlineCourses.aiInstructorWelcome,
      aiInstructorScope: onlineCourses.aiInstructorScope,
      lastGeneratedAt: onlineCourses.lastGeneratedAt,
      createdAt: onlineCourses.createdAt,
      updatedAt: onlineCourses.updatedAt,
      certificationTitle: certifications.title,
      certificationSlug: certifications.slug,
      certificationStatus: certifications.status,
      certificationSummary: certifications.summary,
      certificationDescription: certifications.description,
      certificationObjectives: certifications.objectives,
      certificationTopics: certifications.curriculumTopics,
      certificationAudience: certifications.idealAudience,
      certificationDuration: certifications.duration,
      certificationCeus: certifications.ceus,
    })
    .from(onlineCourses)
    .innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id))
    .where(eq(onlineCourses.id, id))
    .limit(1))[0];
  if (!course) return null;

  const [materials, modules, generationRuns] = await Promise.all([
    db.select().from(onlineCourseMaterials).where(eq(onlineCourseMaterials.courseId, id)).orderBy(desc(onlineCourseMaterials.createdAt)),
    db.select().from(onlineCourseModules).where(eq(onlineCourseModules.courseId, id)).orderBy(asc(onlineCourseModules.position)),
    db.select({ id: onlineCourseGenerationRuns.id, status: onlineCourseGenerationRuns.status, model: onlineCourseGenerationRuns.model, materialIds: onlineCourseGenerationRuns.materialIds, errorMessage: onlineCourseGenerationRuns.errorMessage, createdAt: onlineCourseGenerationRuns.createdAt, completedAt: onlineCourseGenerationRuns.completedAt }).from(onlineCourseGenerationRuns).where(eq(onlineCourseGenerationRuns.courseId, id)).orderBy(desc(onlineCourseGenerationRuns.createdAt)),
  ]);
  const moduleIds = modules.map(module => module.id);
  const [lessons, quizzes] = await Promise.all([
    moduleIds.length ? db.select().from(onlineCourseLessons).where(inArray(onlineCourseLessons.moduleId, moduleIds)).orderBy(asc(onlineCourseLessons.moduleId), asc(onlineCourseLessons.position)) : [],
    moduleIds.length ? db.select().from(onlineModuleQuizzes).where(inArray(onlineModuleQuizzes.moduleId, moduleIds)) : [],
  ]);
  const quizIds = quizzes.map(quiz => quiz.id);
  const quizQuestions = quizIds.length ? await db.select().from(onlineModuleQuizQuestions).where(inArray(onlineModuleQuizQuestions.quizId, quizIds)).orderBy(asc(onlineModuleQuizQuestions.quizId), asc(onlineModuleQuizQuestions.position)) : [];
  return {
    ...course,
    certificationCeus: Number(course.certificationCeus),
    materials,
    modules: modules.map(module => {
      const quiz = quizzes.find(item => item.moduleId === module.id) ?? null;
      return { ...module, lessons: lessons.filter(lesson => lesson.moduleId === module.id), quiz: quiz ? { ...quiz, questions: quizQuestions.filter(question => question.quizId === quiz.id) } : null };
    }),
    generationRuns,
  };
}

export async function activateOnlineCourse(certificationId: number, actorUserId: number) {
  const db = await requireDb();
  const certification = (await db.select({ id: certifications.id, status: certifications.status }).from(certifications).where(eq(certifications.id, certificationId)).limit(1))[0];
  if (!certification || certification.status !== "published") throw new Error(onlineLearningErrors.certificationNotPublished);
  const existing = (await db.select({ id: onlineCourses.id }).from(onlineCourses).where(eq(onlineCourses.certificationId, certificationId)).limit(1))[0];
  if (existing) throw new Error(onlineLearningErrors.courseAlreadyActivated);
  const result = await db.transaction(async tx => {
    const inserted = await tx.insert(onlineCourses).values({ certificationId, createdByUserId: actorUserId, updatedByUserId: actorUserId });
    const id = Number(inserted[0].insertId);
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "online_course.activated", entityType: "online_course", entityId: String(id), eventMetadata: { certificationId } });
    return id;
  });
  return getOnlineCourseAdminById(result);
}

export async function createOnlineCourseMaterial(input: {
  courseId: number;
  title: string;
  fileName: string;
  mimeType: "application/pdf" | "text/plain";
  storageKey: string;
  url: string;
  fileSize: number;
  actorUserId: number;
}) {
  const db = await requireDb();
  const course = await getOnlineCourseAdminById(input.courseId);
  if (!course) throw new Error(onlineLearningErrors.courseNotFound);
  const result = await db.insert(onlineCourseMaterials).values({
    courseId: input.courseId,
    title: input.title,
    fileName: input.fileName,
    mimeType: input.mimeType,
    storageKey: input.storageKey,
    url: input.url,
    fileSize: input.fileSize,
    uploadedByUserId: input.actorUserId,
  });
  const id = Number(result[0].insertId);
  await db.insert(administrationAuditEvents).values({ actorUserId: input.actorUserId, action: "online_material.uploaded", entityType: "online_course_material", entityId: String(id), eventMetadata: { courseId: input.courseId, fileSize: input.fileSize } });
  return (await db.select().from(onlineCourseMaterials).where(eq(onlineCourseMaterials.id, id)).limit(1))[0]!;
}

export async function getOnlineCourseMaterials(courseId: number) {
  const db = await requireDb();
  return db.select().from(onlineCourseMaterials).where(eq(onlineCourseMaterials.courseId, courseId)).orderBy(asc(onlineCourseMaterials.createdAt));
}

export async function updateMaterialAnalysis(id: number, input: { status: "analyzed" | "failed"; analysisSummary?: string | null; sourceExcerpt?: string | null; analysisError?: string | null }) {
  const db = await requireDb();
  const material = (await db.select().from(onlineCourseMaterials).where(eq(onlineCourseMaterials.id, id)).limit(1))[0];
  if (!material) throw new Error(onlineLearningErrors.materialNotFound);
  await db.update(onlineCourseMaterials).set(input).where(eq(onlineCourseMaterials.id, id));
  return (await db.select().from(onlineCourseMaterials).where(eq(onlineCourseMaterials.id, id)).limit(1))[0]!;
}

export async function createGenerationRun(courseId: number, model: string, materialIds: number[], actorUserId: number) {
  const db = await requireDb();
  const result = await db.insert(onlineCourseGenerationRuns).values({ courseId, model, materialIds, createdByUserId: actorUserId });
  return Number(result[0].insertId);
}

export async function completeGenerationRun(runId: number, outputSnapshot: Record<string, unknown>, actorUserId: number) {
  const db = await requireDb();
  await db.update(onlineCourseGenerationRuns).set({ status: "ready", outputSnapshot, completedAt: new Date() }).where(eq(onlineCourseGenerationRuns.id, runId));
  const run = (await db.select().from(onlineCourseGenerationRuns).where(eq(onlineCourseGenerationRuns.id, runId)).limit(1))[0];
  if (run) await db.insert(administrationAuditEvents).values({ actorUserId, action: "online_course.generated", entityType: "online_course", entityId: String(run.courseId), eventMetadata: { generationRunId: runId } });
}

export async function failGenerationRun(runId: number, errorMessage: string) {
  const db = await requireDb();
  await db.update(onlineCourseGenerationRuns).set({ status: "failed", errorMessage: errorMessage.slice(0, 1000), completedAt: new Date() }).where(eq(onlineCourseGenerationRuns.id, runId));
}

export async function replaceGeneratedCourseContent(courseId: number, runId: number, generated: GeneratedCourse, actorUserId: number) {
  const db = await requireDb();
  const course = await getOnlineCourseAdminById(courseId);
  if (!course) throw new Error(onlineLearningErrors.courseNotFound);
  if (course.status === "published") throw new Error(onlineLearningErrors.courseIsPublished);
  await db.transaction(async tx => {
    await tx.delete(onlineCourseModules).where(eq(onlineCourseModules.courseId, courseId));
    for (const module of generated.modules) {
      const inserted = await tx.insert(onlineCourseModules).values({
        courseId,
        generationRunId: runId,
        position: module.position,
        title: module.title,
        learningObjective: module.learningObjective,
        sourceGrounding: module.sourceGrounding,
        visualPrompt: module.visualPrompt,
        videoBrief: module.videoBrief,
        isPublished: true,
      });
      const moduleId = Number(inserted[0].insertId);
      if (module.lessons.length) await tx.insert(onlineCourseLessons).values(module.lessons.map(lesson => ({
        moduleId,
        position: lesson.position,
        title: lesson.title,
        estimatedMinutes: lesson.estimatedMinutes,
        content: lesson.content,
        knowledgeCheckQuestion: lesson.knowledgeCheckQuestion,
        knowledgeCheckAnswer: lesson.knowledgeCheckAnswer,
        isPublished: true,
      })));
    }
    await tx.update(onlineCourses).set({
      status: "review",
      courseOverview: generated.courseOverview,
      sourceGroundingNotice: generated.sourceGroundingNotice,
      aiInstructorName: generated.aiInstructorName,
      aiInstructorWelcome: generated.aiInstructorWelcome,
      aiInstructorScope: generated.aiInstructorScope,
      lastGeneratedAt: new Date(),
      updatedByUserId: actorUserId,
    }).where(eq(onlineCourses.id, courseId));
  });
  return getOnlineCourseAdminById(courseId);
}

export async function updateOnlineCourseStatus(courseId: number, status: OnlineCourseStatus, actorUserId: number) {
  const db = await requireDb();
  const course = await getOnlineCourseAdminById(courseId);
  if (!course) throw new Error(onlineLearningErrors.courseNotFound);
  if (status === "published") {
    const hasVisibleLesson = course.modules.some(module => module.isPublished && module.lessons.some(lesson => lesson.isPublished));
    if (!hasVisibleLesson) throw new Error(onlineLearningErrors.generatedContentRequired);
  }
  await db.transaction(async tx => {
    await tx.update(onlineCourses).set({ status, updatedByUserId: actorUserId }).where(eq(onlineCourses.id, courseId));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: `online_course.${status}`, entityType: "online_course", entityId: String(courseId), eventMetadata: { certificationId: course.certificationId } });
  });
  return getOnlineCourseAdminById(courseId);
}

export async function updateOnlineModule(id: number, input: { title: string; learningObjective: string; visualPrompt: string; videoBrief: string; sourceGrounding: string; isPublished: boolean }, actorUserId: number) {
  const db = await requireDb();
  const module = (await db.select().from(onlineCourseModules).where(eq(onlineCourseModules.id, id)).limit(1))[0];
  if (!module) throw new Error(onlineLearningErrors.moduleNotFound);
  await db.transaction(async tx => {
    await tx.update(onlineCourseModules).set(input).where(eq(onlineCourseModules.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "online_module.updated", entityType: "online_course_module", entityId: String(id), eventMetadata: { courseId: module.courseId } });
  });
  return getOnlineCourseAdminById(module.courseId);
}

export async function updateOnlineModuleVisual(id: number, visualImageUrl: string, actorUserId: number) {
  const db = await requireDb();
  const module = (await db.select().from(onlineCourseModules).where(eq(onlineCourseModules.id, id)).limit(1))[0];
  if (!module) throw new Error(onlineLearningErrors.moduleNotFound);
  await db.transaction(async tx => {
    await tx.update(onlineCourseModules).set({ visualImageUrl }).where(eq(onlineCourseModules.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "online_module.visual_generated", entityType: "online_course_module", entityId: String(id), eventMetadata: { courseId: module.courseId } });
  });
  return getOnlineCourseAdminById(module.courseId);
}

export async function getOnlineModuleForGeneration(id: number) {
  const db = await requireDb();
  return (await db
    .select({
      id: onlineCourseModules.id,
      courseId: onlineCourseModules.courseId,
      title: onlineCourseModules.title,
      visualPrompt: onlineCourseModules.visualPrompt,
      learningObjective: onlineCourseModules.learningObjective,
      courseTitle: certifications.title,
    })
    .from(onlineCourseModules)
    .innerJoin(onlineCourses, eq(onlineCourseModules.courseId, onlineCourses.id))
    .innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id))
    .where(eq(onlineCourseModules.id, id))
    .limit(1))[0] ?? null;
}

export async function updateOnlineLesson(id: number, input: { title: string; estimatedMinutes: number; content: string; knowledgeCheckQuestion: string; knowledgeCheckAnswer: string; isPublished: boolean }, actorUserId: number) {
  const db = await requireDb();
  const lesson = (await db.select().from(onlineCourseLessons).where(eq(onlineCourseLessons.id, id)).limit(1))[0];
  if (!lesson) throw new Error(onlineLearningErrors.lessonNotFound);
  const module = (await db.select({ courseId: onlineCourseModules.courseId }).from(onlineCourseModules).where(eq(onlineCourseModules.id, lesson.moduleId)).limit(1))[0];
  if (!module) throw new Error(onlineLearningErrors.moduleNotFound);
  await db.transaction(async tx => {
    await tx.update(onlineCourseLessons).set(input).where(eq(onlineCourseLessons.id, id));
    await tx.insert(administrationAuditEvents).values({ actorUserId, action: "online_lesson.updated", entityType: "online_course_lesson", entityId: String(id), eventMetadata: { courseId: module.courseId } });
  });
  return getOnlineCourseAdminById(module.courseId);
}

export async function getPublicOnlineCourseBySlug(slug: string) {
  const db = await requireDb();
  const course = (await db
    .select({
      id: onlineCourses.id,
      status: onlineCourses.status,
      courseOverview: onlineCourses.courseOverview,
      sourceGroundingNotice: onlineCourses.sourceGroundingNotice,
      aiInstructorName: onlineCourses.aiInstructorName,
      aiInstructorWelcome: onlineCourses.aiInstructorWelcome,
      aiInstructorScope: onlineCourses.aiInstructorScope,
      certificationTitle: certifications.title,
      certificationSlug: certifications.slug,
      certificationSummary: certifications.summary,
      certificationDuration: certifications.duration,
      certificationCeus: certifications.ceus,
    })
    .from(onlineCourses)
    .innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id))
    .where(and(eq(certifications.slug, slug), eq(onlineCourses.status, "published"), eq(certifications.status, "published")))
    .limit(1))[0];
  if (!course) return null;
  const modules = await db.select().from(onlineCourseModules).where(and(eq(onlineCourseModules.courseId, course.id), eq(onlineCourseModules.isPublished, true))).orderBy(asc(onlineCourseModules.position));
  const moduleIds = modules.map(module => module.id);
  const lessons = moduleIds.length ? await db.select({ id: onlineCourseLessons.id, moduleId: onlineCourseLessons.moduleId, position: onlineCourseLessons.position, title: onlineCourseLessons.title, estimatedMinutes: onlineCourseLessons.estimatedMinutes, content: onlineCourseLessons.content, knowledgeCheckQuestion: onlineCourseLessons.knowledgeCheckQuestion }).from(onlineCourseLessons).where(and(inArray(onlineCourseLessons.moduleId, moduleIds), eq(onlineCourseLessons.isPublished, true))).orderBy(asc(onlineCourseLessons.moduleId), asc(onlineCourseLessons.position)) : [];
  return { ...course, certificationCeus: Number(course.certificationCeus), modules: modules.map(module => ({ ...module, lessons: lessons.filter(lesson => lesson.moduleId === module.id) })) };
}
