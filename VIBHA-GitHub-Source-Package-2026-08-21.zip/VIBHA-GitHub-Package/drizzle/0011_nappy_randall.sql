CREATE TABLE `certificate_program_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`certificationId` int NOT NULL,
	`completionNarrative` text,
	`instructionalHours` varchar(160),
	`supervisedPracticalTraining` varchar(180),
	`complianceStatement` text,
	`accreditingBodyName` varchar(240),
	`licenseNumber` varchar(160),
	`executiveName` varchar(220) NOT NULL DEFAULT 'Jacquese Hinton',
	`executiveTitle` varchar(220) NOT NULL DEFAULT 'Founder & Director of Institutional Strategy',
	`updatedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certificate_program_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificate_program_profile_cert_unique` UNIQUE(`certificationId`)
);
--> statement-breakpoint
ALTER TABLE `issued_certificates` ADD `documentSnapshot` json;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD CONSTRAINT `cert_profile_cert_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD CONSTRAINT `cert_profile_updater_fk` FOREIGN KEY (`updatedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_program_profile_updated_idx` ON `certificate_program_profiles` (`updatedAt`);
