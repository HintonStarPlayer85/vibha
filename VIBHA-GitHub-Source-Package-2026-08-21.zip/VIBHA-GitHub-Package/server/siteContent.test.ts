import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  siteContentBatchUpdateSchema,
  siteContentUpdateSchema,
} from "../shared/administration";
import { mergeSiteContent } from "../shared/siteContent";

const siteContentMocks = vi.hoisted(() => ({
  listSiteContentOverrides: vi.fn(),
  resetSiteContent: vi.fn(),
  updateSiteContent: vi.fn(),
}));

vi.mock("./siteContentDb", async () => {
  const actual = await vi.importActual<typeof import("./siteContentDb")>("./siteContentDb");
  return { ...actual, ...siteContentMocks };
});

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function context(role?: AuthenticatedUser["role"]): TrpcContext {
  const user = role
    ? {
        id: 19,
        openId: `${role}-content-editor-test`,
        email: `${role}@example.com`,
        name: "Content Editor Test",
        loginMethod: "manus",
        role,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      }
    : null;
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("Content Editor", () => {
  beforeEach(() => vi.clearAllMocks());

  it("uses safe published defaults for every untouched public field", () => {
    const content = mergeSiteContent({ "home.hero.title": "Updated headline" });
    expect(content["home.hero.title"]).toBe("Updated headline");
    expect(content["contact.hero.title"]).toBe("Start with the right conversation.");
  });

  it("accepts a known non-empty copy update and rejects unknown or duplicate fields", () => {
    expect(siteContentUpdateSchema.parse({ key: "home.hero.title", value: "Updated headline" })).toEqual({
      key: "home.hero.title",
      value: "Updated headline",
    });
    expect(() => siteContentUpdateSchema.parse({ key: "unknown.field", value: "Text" })).toThrow();
    expect(() => siteContentUpdateSchema.parse({ key: "home.hero.title", value: "   " })).toThrow();
    expect(() => siteContentBatchUpdateSchema.parse({
      values: [
        { key: "home.hero.title", value: "One" },
        { key: "home.hero.title", value: "Two" },
      ],
    })).toThrow();
  });

  it("allows public pages to retrieve approved copy overrides", async () => {
    siteContentMocks.listSiteContentOverrides.mockResolvedValue([{ key: "home.hero.title", value: "Updated headline" }]);
    const caller = appRouter.createCaller(context());
    await expect(caller.siteContent.list()).resolves.toEqual([{ key: "home.hero.title", value: "Updated headline" }]);
  });

  it("passes validated updates and the authenticated administrator to persistence", async () => {
    siteContentMocks.updateSiteContent.mockResolvedValue([]);
    const caller = appRouter.createCaller(context("admin"));
    await caller.adminSiteContent.update({ values: [{ key: "home.hero.title", value: "Updated headline" }] });
    expect(siteContentMocks.updateSiteContent).toHaveBeenCalledWith(
      [{ key: "home.hero.title", value: "Updated headline" }],
      19,
    );
  });

  it("allows owners and blocks standard users from content administration", async () => {
    siteContentMocks.listSiteContentOverrides.mockResolvedValue([]);
    await expect(appRouter.createCaller(context("owner")).adminSiteContent.list()).resolves.toEqual([]);
    await expect(appRouter.createCaller(context("user")).adminSiteContent.list()).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
  });

  it("records administrator-originated default restoration through the reset contract", async () => {
    siteContentMocks.resetSiteContent.mockResolvedValue({ key: "leadership.profile.welton-loftin.biography" });
    const caller = appRouter.createCaller(context("admin"));
    await expect(caller.adminSiteContent.reset({ key: "leadership.profile.welton-loftin.biography" })).resolves.toEqual({ key: "leadership.profile.welton-loftin.biography" });
    expect(siteContentMocks.resetSiteContent).toHaveBeenCalledWith("leadership.profile.welton-loftin.biography", 19);
  });
});
