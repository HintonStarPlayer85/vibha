import { inquiryInputSchema } from "../../shared/catalog";
import { createInquiry } from "../db";
import { publicProcedure, router } from "../_core/trpc";

export const inquiriesRouter = router({
  submit: publicProcedure.input(inquiryInputSchema).mutation(({ input }) => {
    if (input.website) return { success: true as const, route: "filtered" };
    return createInquiry(input);
  }),
});

