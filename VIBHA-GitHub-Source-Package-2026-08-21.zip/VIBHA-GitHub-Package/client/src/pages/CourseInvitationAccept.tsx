import { PublicLayout } from "@/components/public/PublicLayout";
import { PageHero } from "@/components/public/PageHero";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { useEffect } from "react";
import { Link, useParams } from "wouter";

export default function CourseInvitationAccept() {
  const { token = "" } = useParams<{ token: string }>();
  const { user, loading } = useAuth();
  const accept = trpc.learnerEngagement.acceptInvitation.useMutation();
  useEffect(() => { if (user && token && !accept.isPending && !accept.data && !accept.error) void accept.mutateAsync({ token }); }, [user, token, accept]);
  const body = loading ? <div role="status" className="flex items-center justify-center gap-3 py-16 text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Checking your account…</div> : !user ? <div className="rounded-xl border border-slate-200 bg-white p-8 text-center shadow-sm"><ShieldCheck className="mx-auto h-10 w-10 text-[#b94700]" /><h2 className="mt-4 text-2xl font-bold text-[#071f49]">Sign in to accept your invitation</h2><p className="mt-3 leading-7 text-slate-600">Use the same email address that received this VIBHA course invitation. After sign-in, you will return here to accept it securely.</p><Button className="mt-6 bg-[#071f49] text-white hover:bg-[#173b70]" onClick={() => startLogin()}>Sign in to continue</Button></div> : accept.isPending ? <div role="status" className="flex items-center justify-center gap-3 py-16 text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Accepting your course invitation…</div> : accept.error ? <div role="alert" className="rounded-xl border border-rose-200 bg-rose-50 p-7 text-center text-rose-900"><h2 className="text-2xl font-bold">Invitation unavailable</h2><p className="mt-3">{accept.error.message}</p><Link href="/learn" className="mt-6 inline-flex rounded-md bg-[#071f49] px-4 py-3 text-sm font-bold text-white">Go to learning dashboard</Link></div> : accept.data ? <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-8 text-center"><CheckCircle2 className="mx-auto h-11 w-11 text-emerald-700" /><h2 className="mt-4 text-2xl font-bold text-emerald-900">Course invitation accepted</h2><p className="mt-3 text-emerald-800">Your VIBHA learning record is ready. You can begin the course now or return to your dashboard.</p><div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row"><Link href={`/learn/${accept.data.courseSlug}`} className="rounded-md bg-[#071f49] px-4 py-3 text-sm font-bold text-white">Begin course</Link><Link href="/learn" className="rounded-md border border-[#071f49] bg-white px-4 py-3 text-sm font-bold text-[#071f49]">Learning dashboard</Link></div></div> : null;
  return <PublicLayout><PageHero eyebrow="VIBHA Learning" title="Course invitation" description="Accept a secure invitation to begin your approved VIBHA self-paced course." breadcrumbs={[{ label: "Learning", href: "/learn" }, { label: "Course invitation" }]} /><main className="container py-12 sm:py-16"><div className="mx-auto max-w-2xl">{body}</div></main></PublicLayout>;
}
