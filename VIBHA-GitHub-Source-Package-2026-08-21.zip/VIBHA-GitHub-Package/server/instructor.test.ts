import type { TrpcContext } from "./_core/context";
import { TRPCError } from "@trpc/server";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { instructorInputSchema } from "../shared/administration";

const instructorMocks = vi.hoisted(() => ({
  listInstructors: vi.fn(),
  getInstructorById: vi.fn(),
  getInstructorOptions: vi.fn(),
  createInstructor: vi.fn(),
  updateInstructor: vi.fn(),
  setInstructorStatus: vi.fn(),
}));

vi.mock("./instructorDb", async () => {
  const actual = await vi.importActual<typeof import("./instructorDb")>("./instructorDb");
  return { ...actual, ...instructorMocks };
});

import { appRouter } from "./routers";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function context(role: AuthenticatedUser["role"]): TrpcContext {
  const user: AuthenticatedUser = {
    id: 7,
    openId: `${role}-instructor-test`,
    email: `${role}@example.com`,
    name: "Instructor Test",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const validInstructor = {
  name: "Jordan Avery",
  slug: "jordan-avery",
  email: "JORDAN@EXAMPLE.COM",
  credentials: "LCSW",
  title: "Senior Instructor",
  biography: "Jordan provides workforce education across behavioral health systems.",
  expertise: ["Clinical documentation", "Supervision"],
  photoUrl: "",
  isActive: true,
  certificationIds: [2, 5],
};

describe("Instructor CMS", () => {
  beforeEach(() => vi.clearAllMocks());

  it("normalizes instructor email and preserves certification assignments", () => {
    const parsed = instructorInputSchema.parse(validInstructor);
    expect(parsed.email).toBe("jordan@example.com");
    expect(parsed.certificationIds).toEqual([2, 5]);
  });

  it("rejects invalid faculty email addresses", () => {
    expect(() => instructorInputSchema.parse({ ...validInstructor, email: "not-an-email" })).toThrow();
  });

  it("passes normalized assignments and the authenticated administrator to the create operation", async () => {
    instructorMocks.createInstructor.mockResolvedValue({ id: 12, ...validInstructor });
    const caller = appRouter.createCaller(context("admin"));
    await caller.adminInstructors.create(validInstructor);
    expect(instructorMocks.createInstructor).toHaveBeenCalledWith(
      expect.objectContaining({ email: "jordan@example.com", certificationIds: [2, 5] }),
      7,
    );
  });

  it("allows the project owner to manage instructors", async () => {
    instructorMocks.listInstructors.mockResolvedValue([]);
    const caller = appRouter.createCaller(context("owner"));
    await expect(caller.adminInstructors.list({})).resolves.toEqual([]);
  });

  it("denies Instructor CMS access to a standard authenticated user", async () => {
    const caller = appRouter.createCaller(context("user"));
    await expect(caller.adminInstructors.list({})).rejects.toMatchObject<Partial<TRPCError>>({ code: "FORBIDDEN" });
  });

  it("rejects malformed digital signature payloads before any storage write", async () => {
    const caller = appRouter.createCaller(context("admin"));
    await expect(caller.adminInstructors.uploadSignature({ instructorId: 1, fileName: "signature.png", mimeType: "image/png", dataBase64: Buffer.from("not-a-png").toString("base64") })).rejects.toMatchObject<Partial<TRPCError>>({ code: "BAD_REQUEST" });
  });

  it("accepts bounded normalized crop metadata with a valid signature-upload request shape", () => {
    expect(() => instructorInputSchema.parse(validInstructor)).not.toThrow();
  });
});
