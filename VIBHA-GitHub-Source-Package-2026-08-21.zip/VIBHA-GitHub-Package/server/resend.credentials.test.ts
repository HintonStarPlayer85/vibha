import { describe, expect, it } from "vitest";
import { verifyResendSenderDomain } from "./resendCohort";

describe("Resend project credentials", () => {
  it("authenticates the configured API key against the Resend domains endpoint", async () => {
    const apiKey = process.env.RESEND_API_KEY;
    expect(apiKey, "RESEND_API_KEY must be configured").toBeTruthy();
    expect(apiKey?.startsWith("re_"), "RESEND_API_KEY must use the Resend key format").toBe(true);

    const response = await fetch("https://api.resend.com/domains", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });

    expect(
      response.ok,
      `Resend credential validation failed with HTTP ${response.status}`,
    ).toBe(true);
  }, 15_000);

  it("has complete sender and reply-to identities", () => {
    expect(process.env.RESEND_FROM_EMAIL, "RESEND_FROM_EMAIL must be configured").toMatch(/<[^<>\s]+@[^<>\s]+>|^[^<>\s]+@[^<>\s]+$/);
    expect(process.env.RESEND_REPLY_TO_EMAIL, "RESEND_REPLY_TO_EMAIL must be configured").toMatch(/^[^<>\s]+@[^<>\s]+$/);
  });

  it("uses a sender domain that Resend reports as verified", async () => {
    const result = await verifyResendSenderDomain(true);
    expect(result.verified, `Sender domain ${result.domain || "unknown"} is ${result.status}`).toBe(true);
  }, 15_000);
});
