import { z } from "zod";

export const certificationStatuses = [
  "draft",
  "published",
  "coming_soon",
  "inactive",
  "archived",
] as const;

export const certificationStatusSchema = z.enum(certificationStatuses);
export const slugSchema = z
  .string()
  .trim()
  .min(3)
  .max(240)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use lowercase letters, numbers, and hyphens only.");

const requiredList = z.array(z.string().trim().min(2).max(500)).min(1).max(20);
const optionalText = (max: number) => z.string().trim().max(max).optional().nullable();

export const certificationInputSchema = z.object({
  title: z.string().trim().min(3).max(220),
  shortTitle: optionalText(120),
  slug: slugSchema,
  categoryId: z.number().int().positive(),
  description: z.string().trim().min(40).max(12000),
  summary: z.string().trim().min(20).max(700),
  valueStatement: optionalText(700),
  objectives: requiredList,
  curriculumTopics: requiredList,
  idealAudience: requiredList,
  eligibilityRequirements: requiredList,
  prerequisites: z.string().trim().min(2).max(1200),
  format: z.string().trim().min(2).max(80),
  deliveryLocation: z.string().trim().min(2).max(180),
  deliveryMethods: requiredList,
  schedule: z.string().trim().min(5).max(1200),
  duration: z.string().trim().min(2).max(80),
  ceus: z.number().min(0).max(999.99),
  costCents: z.number().int().min(0).max(100_000_000),
  costDisplay: z.string().trim().min(1).max(80),
  level: z.string().trim().min(2).max(60),
  careerRelevance: optionalText(2000),
  enrollmentUrl: z.union([z.string().trim().url().max(500), z.literal(""), z.null()]).optional(),
  inquiryType: z.string().trim().min(2).max(80).default("program-information"),
  status: certificationStatusSchema,
  isFeatured: z.boolean().default(false),
  displayOrder: z.number().int().min(0).max(100000).default(0),
  seoTitle: optionalText(180),
  seoDescription: optionalText(320),
  instructorIds: z.array(z.number().int().positive()).max(20).default([]),
});

export const catalogQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  category: z.string().trim().max(180).optional(),
  format: z.enum(["virtual-live", "hybrid", "evening", "weekend", "onsite"]).optional(),
  ceu: z.enum(["not-listed", "0.1-2", "2.1-5", "5-plus"]).optional(),
  cost: z.enum(["under-1000", "1000-1499", "1500-1999", "2000-plus"]).optional(),
  page: z.number().int().min(1).max(10000).default(1),
  pageSize: z.number().int().min(1).max(48).default(12),
});

export const adminCatalogQuerySchema = z.object({
  q: z.string().trim().max(120).optional(),
  status: certificationStatusSchema.optional(),
});

export const inquiryInputSchema = z.object({
  inquiryType: z.enum(["program", "agency", "general"]),
  certificationId: z.number().int().positive().optional().nullable(),
  programRoute: optionalText(180),
  name: z.string().trim().min(2).max(160),
  email: z.string().trim().email().max(320),
  phone: optionalText(40),
  organization: optionalText(220),
  organizationType: optionalText(120),
  workforceSize: optionalText(80),
  priority: optionalText(180),
  timeline: optionalText(120),
  message: z.string().trim().min(10).max(5000),
  consent: z.literal(true, { error: "Consent is required." }),
  sourcePath: optionalText(500),
  website: z.string().trim().max(120).optional(),
});

export type CertificationInput = z.infer<typeof certificationInputSchema>;
export type CatalogQuery = z.infer<typeof catalogQuerySchema>;
export type InquiryInput = z.infer<typeof inquiryInputSchema>;
