import { beforeEach, describe, expect, it, vi } from "vitest";

const dbMocks = vi.hoisted(() => ({
  acceptCourseInvitation: vi.fn(), deleteLearnerModuleNote: vi.fn(), listAllLearnerNotes: vi.fn(), listCourseInvitations: vi.fn(), listLearnerNotes: vi.fn(), upsertLearnerModuleNote: vi.fn(),
}));
const serviceMocks = vi.hoisted(() => ({ downloadLearnerTranscript: vi.fn(), generateLearnerTranscript: vi.fn(), sendCourseInvitation: vi.fn() }));
vi.mock("./learnerEngagementDb", async () => { const actual = await vi.importActual<typeof import("./learnerEngagementDb")>("./learnerEngagementDb"); return { ...actual, ...dbMocks }; });
vi.mock("./learnerEngagementService", () => serviceMocks);

import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { generateCompletionTranscriptPdf } from "./learnerEngagementPdf";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;
function context(role?: AuthenticatedUser["role"], email = `${role ?? "anonymous"}@example.com`): TrpcContext {
  const user = role ? { id: 84, openId: `${role}-engagement`, email, name: "Engagement Test", loginMethod: "manus", role, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() } : null;
  return { user, req: { protocol: "https", headers: {}, get: () => "thevibha.org" } as unknown as TrpcContext["req"], res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"] };
}

describe("Learner engagement router", () => {
  beforeEach(() => vi.clearAllMocks());
  it("requires learner authentication before a completion transcript can be requested", async () => {
    await expect(appRouter.createCaller(context()).learnerEngagement.generateTranscript({ courseSlug: "workforce-foundations" })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("generates a transcript only through the signed-in learner context", async () => {
    serviceMocks.generateLearnerTranscript.mockResolvedValue({ transcriptId: 3, url: "https://signed.example/transcript.pdf", generatedAt: new Date() });
    await expect(appRouter.createCaller(context("user")).learnerEngagement.generateTranscript({ courseSlug: "workforce-foundations" })).resolves.toMatchObject({ transcriptId: 3 });
    expect(serviceMocks.generateLearnerTranscript).toHaveBeenCalledWith("workforce-foundations", 84);
  });
  it("denies standard learners the ability to email course invitations", async () => {
    await expect(appRouter.createCaller(context("user")).adminLearnerEngagement.invite({ courseId: 8, recipientName: "Student Name", recipientEmail: "student@example.com", origin: "https://thevibha.org" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
  it("sends an administrator invitation through the server service with the administrator identity", async () => {
    serviceMocks.sendCourseInvitation.mockResolvedValue({ invitationId: 6, recipientEmail: "student@example.com" });
    await expect(appRouter.createCaller(context("admin")).adminLearnerEngagement.invite({ courseId: 8, recipientName: "Student Name", recipientEmail: "student@example.com", origin: "https://thevibha.org" })).resolves.toMatchObject({ invitationId: 6 });
    expect(serviceMocks.sendCourseInvitation).toHaveBeenCalledWith(expect.objectContaining({ courseId: 8, recipientEmail: "student@example.com", actorUserId: 84 }));
  });
  it("binds invitation acceptance to the current authenticated email and a hashed token", async () => {
    dbMocks.acceptCourseInvitation.mockResolvedValue({ courseSlug: "workforce-foundations", invitationId: 9 });
    await expect(appRouter.createCaller(context("user", "student@example.com")).learnerEngagement.acceptInvitation({ token: "a".repeat(43) })).resolves.toMatchObject({ courseSlug: "workforce-foundations" });
    expect(dbMocks.acceptCourseInvitation).toHaveBeenCalledWith(expect.objectContaining({ userId: 84, userEmail: "student@example.com", tokenHash: expect.stringMatching(/^[a-f0-9]{64}$/) }));
  });
  it("keeps saved module notes scoped to the signed-in learner", async () => {
    dbMocks.upsertLearnerModuleNote.mockResolvedValue({ id: 2, userId: 84, moduleId: 7, content: "Key takeaway" });
    await expect(appRouter.createCaller(context("user")).learnerEngagement.saveNote({ courseSlug: "workforce-foundations", moduleId: 7, content: "Key takeaway" })).resolves.toMatchObject({ id: 2, userId: 84 });
    expect(dbMocks.upsertLearnerModuleNote).toHaveBeenCalledWith({ courseSlug: "workforce-foundations", moduleId: 7, content: "Key takeaway", userId: 84 });
  });
});

describe("Completion transcript PDF", () => {
  it("creates a non-empty VIBHA-branded PDF completion transcript", async () => {
    const bytes = await generateCompletionTranscriptPdf({ recipientName: "Learner Name", courseTitle: "Workforce Foundations", ceus: 4.5, completedAt: new Date("2026-08-18T00:00:00Z"), moduleCount: 4, lessonCount: 12 });
    expect(Buffer.from(bytes).subarray(0, 4).toString()).toBe("%PDF");
    expect(bytes.length).toBeGreaterThan(1200);
  });
});
