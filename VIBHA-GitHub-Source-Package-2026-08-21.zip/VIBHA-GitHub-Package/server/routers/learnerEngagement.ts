import { createHash } from "crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { onlineCourseInvitationAcceptSchema, onlineCourseInvitationSchema, onlineModuleNoteDeleteSchema, onlineModuleNoteSchema, onlineTranscriptRequestSchema } from "../../shared/onlineLearning";
import { acceptCourseInvitation, deleteLearnerModuleNote, learnerEngagementErrors, listAllLearnerNotes, listCourseInvitations, listLearnerNotes, upsertLearnerModuleNote } from "../learnerEngagementDb";
import { downloadLearnerTranscript, generateLearnerTranscript, sendCourseInvitation } from "../learnerEngagementService";
import { adminProcedure, protectedProcedure, router } from "../_core/trpc";

function hashToken(token: string) { return createHash("sha256").update(token).digest("hex"); }
function translate(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === learnerEngagementErrors.transcriptNotEligible) throw new TRPCError({ code: "FORBIDDEN", message: "Complete every required lesson and module assessment before downloading this transcript." });
  if (message === learnerEngagementErrors.transcriptNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "No completion transcript has been generated for this course yet." });
  if (message === learnerEngagementErrors.invitationInvalid) throw new TRPCError({ code: "NOT_FOUND", message: "This course invitation is not available." });
  if (message === learnerEngagementErrors.invitationExpired) throw new TRPCError({ code: "BAD_REQUEST", message: "This course invitation has expired." });
  if (message === learnerEngagementErrors.invitationEmailMismatch) throw new TRPCError({ code: "FORBIDDEN", message: "Sign in with the email address that received this course invitation." });
  if (message === learnerEngagementErrors.invitationExists) throw new TRPCError({ code: "CONFLICT", message: "This learner already has an active invitation for the course." });
  if (message === learnerEngagementErrors.courseNotPublished) throw new TRPCError({ code: "BAD_REQUEST", message: "Only published self-paced courses can be invited." });
  if (message === learnerEngagementErrors.noteEnrollmentRequired) throw new TRPCError({ code: "FORBIDDEN", message: "Enroll in this course before saving private notes." });
  if (message === learnerEngagementErrors.noteModuleInvalid) throw new TRPCError({ code: "FORBIDDEN", message: "That module is not available in your enrolled course." });
  throw error;
}

export const learnerEngagementRouter = router({
  generateTranscript: protectedProcedure.input(onlineTranscriptRequestSchema).mutation(async ({ input, ctx }) => { try { return await generateLearnerTranscript(input.courseSlug, ctx.user.id); } catch (error) { translate(error); } }),
  downloadTranscript: protectedProcedure.input(onlineTranscriptRequestSchema).query(async ({ input, ctx }) => { try { return await downloadLearnerTranscript(input.courseSlug, ctx.user.id); } catch (error) { translate(error); } }),
  acceptInvitation: protectedProcedure.input(onlineCourseInvitationAcceptSchema).mutation(async ({ input, ctx }) => { try { return await acceptCourseInvitation({ tokenHash: hashToken(input.token), userId: ctx.user.id, userEmail: ctx.user.email }); } catch (error) { translate(error); } }),
  notes: protectedProcedure.input(z.object({ courseSlug: z.string().trim().min(3).max(240) })).query(async ({ input, ctx }) => { try { return await listLearnerNotes(input.courseSlug, ctx.user.id); } catch (error) { translate(error); } }),
  dashboardNotes: protectedProcedure.query(({ ctx }) => listAllLearnerNotes(ctx.user.id)),
  saveNote: protectedProcedure.input(onlineModuleNoteSchema).mutation(async ({ input, ctx }) => { try { return await upsertLearnerModuleNote({ ...input, userId: ctx.user.id }); } catch (error) { translate(error); } }),
  deleteNote: protectedProcedure.input(onlineModuleNoteDeleteSchema).mutation(async ({ input, ctx }) => { try { return await deleteLearnerModuleNote({ ...input, userId: ctx.user.id }); } catch (error) { translate(error); } }),
});

export const adminLearnerEngagementRouter = router({
  invite: adminProcedure.input(onlineCourseInvitationSchema).mutation(async ({ input, ctx }) => { try { return await sendCourseInvitation({ ...input, actorUserId: ctx.user.id }); } catch (error) { translate(error); } }),
  invitations: adminProcedure.input(z.object({ courseId: z.number().int().positive() })).query(({ input }) => listCourseInvitations(input.courseId)),
});
