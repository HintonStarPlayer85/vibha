import {
  siteContentBatchUpdateSchema,
  siteContentResetSchema,
} from "../../shared/administration";
import { adminProcedure, publicProcedure, router } from "../_core/trpc";
import { listSiteContentOverrides, resetSiteContent, updateSiteContent } from "../siteContentDb";

export const siteContentRouter = router({
  list: publicProcedure.query(() => listSiteContentOverrides()),
});

export const adminSiteContentRouter = router({
  list: adminProcedure.query(() => listSiteContentOverrides()),
  update: adminProcedure
    .input(siteContentBatchUpdateSchema)
    .mutation(({ input, ctx }) => updateSiteContent(input.values, ctx.user.id)),
  reset: adminProcedure
    .input(siteContentResetSchema)
    .mutation(({ input, ctx }) => resetSiteContent(input.key, ctx.user.id)),
});
