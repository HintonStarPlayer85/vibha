# VIBHA Education Platform

This repository contains the source code for **VIBHA — The Virginia Institute for Behavioral Health & Advancement**. It is an enterprise continuing-education platform supporting a public certification catalog, invitation-only administration, instructor and cohort management, Resend-based cohort communication, certificate issuance and verification, certificate governance, and self-paced learning with learner progress, quizzes, transcripts, invitations, and notes.

## Technology

| Layer | Implementation |
| --- | --- |
| Client | React 19, Vite, Tailwind CSS 4, Radix UI, TanStack Query, tRPC client |
| Server | Node.js, Express 4, tRPC 11, TypeScript |
| Data | Drizzle ORM with MySQL/TiDB-compatible migrations |
| Documents | `pdf-lib` for certificates and governance reports |
| Email | Resend transactional email with delivery audit records |
| Storage | S3-compatible storage through the configured storage service |
| Authentication | OAuth-backed, role-gated invitation administration |

## What Is Included

The package includes the full application source, database schema, Drizzle migrations, tests, lockfile, shared contracts, styling, reusable components, and project documentation. It deliberately excludes installed dependencies, compiled output, logs, workspace checkpoints, local editor files, local environment files, and deployed credentials.

## Upload to GitHub

1. Download and extract the accompanying archive.
2. In GitHub, create a new empty repository. Do not initialize it with a README, license, or `.gitignore`.
3. Upload the **contents** of the extracted `VIBHA-GitHub-Package` folder, not the outer folder itself, then commit to the default branch.
4. Confirm that `.env`, `node_modules`, `dist`, `.manus`, `.manus-logs`, and `client/public/__manus__` are absent from the commit.
5. Configure the required environment variables in the chosen hosting provider before building or deploying.

## Local Setup

Use Node.js 22+ and pnpm 10+. Copy `.env.example` to `.env` and replace every placeholder with a valid value for your environment.

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm test
pnpm build
pnpm dev
```

The application expects a MySQL/TiDB-compatible database. Before first use, set `DATABASE_URL`, review the migrations under `drizzle/`, and apply them through the project’s migration workflow:

```bash
pnpm drizzle-kit migrate
```

> Do not run migrations against a production database without first taking a tested backup and reviewing the SQL in `drizzle/`.

## Required Configuration

| Variable | Purpose |
| --- | --- |
| `DATABASE_URL` | MySQL/TiDB-compatible application database connection string. |
| `JWT_SECRET` | High-entropy secret for signed authentication cookies and report attestations. |
| `VITE_APP_ID` | OAuth application identifier. |
| `OAUTH_SERVER_URL` | OAuth provider base URL. |
| `OWNER_OPEN_ID` | Owner identity used by the application’s administrative authorization model. |
| `BUILT_IN_FORGE_API_URL` | Storage/AI service base URL when using the current service adapter. |
| `BUILT_IN_FORGE_API_KEY` | Server-side credential for the configured storage/AI service. |
| `RESEND_API_KEY` | Resend API credential for cohort, invitation, completion, and governance email. |
| `RESEND_FROM_EMAIL` | Verified VIBHA sender address. |
| `RESEND_REPLY_TO_EMAIL` | Reply-to address for transactional email. |
| `RESEND_WEBHOOK_SECRET` | Resend webhook validation secret. |

The current application uses OAuth and storage adapters supplied by its original managed environment. If you deploy outside that environment, configure compatible OAuth, storage, and AI service implementations before production use. The source archive does not contain secrets, live database data, uploaded S3 artifacts, managed authentication state, or email-provider configuration.

## Quality Gates

Run the following before every deployment:

```bash
pnpm check
pnpm test
pnpm build
```

## License

This repository retains the MIT license declaration present in `package.json`. Confirm organizational ownership, branding rights, and third-party service terms before making the repository public.
