import { ArrowUpRight, Mail, MapPin, Phone, ShieldCheck } from "lucide-react";
import { Link } from "wouter";
import { AccreditationPendingBadge } from "./AccreditationPendingBadge";
import { primaryNavigation } from "./SiteHeader";
import { VibhaBrand } from "./VibhaBrand";

const programLinks = [
  ["Workforce Entry & Foundations", "/certifications?category=workforce-entry-foundations"],
  ["Clinical Support & Community Services", "/certifications?category=clinical-support-community-services"],
  ["ACT, Crisis & Community Stabilization", "/certifications?category=act-crisis-community-stabilization"],
  ["Compliance, Documentation & Operations", "/certifications?category=compliance-documentation-operations"],
  ["Leadership, Executive & AI Governance", "/certifications?category=leadership-executive-ai-governance"],
  ["Virginia Behavioral Health Specialties", "/certifications?category=virginia-behavioral-health-specialties"],
] as const;

export function SiteFooter() {
  return (
    <footer className="bg-[#041634] text-slate-200">
      <div className="h-1 bg-[#f47a20]" />
      <div className="container grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-[1.4fr_0.75fr_1fr_0.9fr]">
        <div>
          <VibhaBrand inverse className="mb-5" />
          <p className="max-w-md text-sm leading-7 text-slate-300">
            VIBHA develops a competent, ethical, and sustainable behavioral health workforce through practical education, certification, and organizational training.
          </p>
          <p className="mt-5 text-sm font-semibold uppercase tracking-[0.14em] text-[#ff9a52]">
            Empower. Educate. Elevate.
          </p>
          <AccreditationPendingBadge inverse className="mt-6" />
        </div>
        <div>
          <h2 className="font-sans text-sm font-bold uppercase tracking-[0.14em] text-white">Explore</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {primaryNavigation.map(item => (
              <li key={item.href}>
                <Link className="rounded-sm hover:text-white hover:underline" href={item.href}>
                  {item.label}
                </Link>
              </li>
            ))}
            <li>
              <Link className="rounded-sm hover:text-white hover:underline" href="/about/leadership">
                Leadership
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <h2 className="font-sans text-sm font-bold uppercase tracking-[0.14em] text-white">Program Areas</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {programLinks.map(([label, href]) => (
              <li key={href}>
                <a className="rounded-sm hover:text-white hover:underline" href={`${href}#catalog-top`}>
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="font-sans text-sm font-bold uppercase tracking-[0.14em] text-white">Connect</h2>
          <ul className="mt-4 space-y-4 text-sm">
            <li className="flex gap-3">
              <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#f47a20]" /> Richmond, Virginia
            </li>
            <li>
              <a className="flex gap-3 hover:text-white" href="tel:+18042933341">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-[#f47a20]" /> 804-293-3341
              </a>
            </li>
            <li>
              <Link className="flex gap-3 hover:text-white" href="/contact">
                <Mail className="mt-0.5 h-4 w-4 shrink-0 text-[#f47a20]" /> Contact VIBHA
              </Link>
            </li>
            <li>
              <Link className="flex gap-3 hover:text-white" href="/verify-certificate">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#f47a20]" /> Verify a certificate
              </Link>
            </li>
            <li>
              <Link className="flex gap-3 hover:text-white" href="/learn">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[#f47a20]" /> Learning dashboard
              </Link>
            </li>
            <li>
              <Link className="flex gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400 hover:text-white" href="/admin/certifications">
                Content administration <ArrowUpRight className="h-3.5 w-3.5" />
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container flex flex-col gap-3 py-5 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1"><p>© {new Date().getFullYear()} VIBHA. All rights reserved.</p><p>This site was designed by <a href="https://www.designingvirtuosity.com" target="_blank" rel="noopener noreferrer" className="font-semibold text-slate-300 hover:text-white hover:underline">Designing Virtuosity<span className="sr-only"> (opens in a new tab)</span></a></p></div>
          <div className="flex flex-wrap gap-x-5 gap-y-2">
            <Link className="hover:text-white" href="/privacy">Privacy</Link>
            <Link className="hover:text-white" href="/accessibility">Accessibility</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
