import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { BookOpenCheck, ChevronRight, FileUp, GraduationCap, Loader2, Sparkles } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Link, useLocation } from "wouter";

function statusClass(status: string) {
  if (status === "published") return "bg-emerald-100 text-emerald-800";
  if (status === "review") return "bg-amber-100 text-amber-800";
  if (status === "archived") return "bg-slate-200 text-slate-700";
  return "bg-blue-100 text-blue-800";
}

function OnlineLearningHome() {
  const [, navigate] = useLocation();
  const courses = trpc.adminOnlineLearning.list.useQuery();
  const options = trpc.adminOnlineLearning.options.useQuery();
  const activate = trpc.adminOnlineLearning.activate.useMutation();
  const [certificationId, setCertificationId] = useState("");
  const utils = trpc.useUtils();
  const activatedCertificationIds = useMemo(() => new Set(courses.data?.map(course => course.certificationId) ?? []), [courses.data]);
  const availableCourses = options.data?.filter(course => !activatedCertificationIds.has(course.id)) ?? [];

  async function activateCourse() {
    if (!certificationId) return;
    try {
      const created = await activate.mutateAsync({ certificationId: Number(certificationId) });
      await utils.adminOnlineLearning.list.invalidate();
      toast.success("Online Learning workspace activated.");
      navigate(`/admin/online-learning/${created!.id}`);
    } catch (error) { toast.error(error instanceof Error ? error.message : "The Online Learning workspace could not be activated."); }
  }

  return <main className="mx-auto max-w-7xl pb-12">
    <div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between"><div><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Content Administration</p><h1 className="mt-3 text-4xl font-bold text-[#071f49]">Online Learning</h1><p className="mt-3 max-w-3xl text-slate-600">Activate a published VIBHA certification for self-paced delivery, upload approved source materials, generate a reviewable learning draft, and publish only after instructional review.</p></div></div>
    <section className="mt-8 rounded-2xl border border-[#f47a20]/35 bg-[#fff7f2] p-6"><div className="flex items-start gap-4"><Sparkles className="mt-0.5 h-6 w-6 shrink-0 text-[#b94700]" /><div><h2 className="text-xl font-bold text-[#071f49]">AI-assisted, administrator-governed</h2><p className="mt-2 max-w-4xl text-sm leading-6 text-slate-700">AI analyzes only uploaded materials and course metadata, then produces drafts for review. Visuals are generated one module at a time. Video outputs are production briefs and scripts, not rendered video files. Nothing becomes learner-visible until you publish it.</p></div></div></section>
    <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div className="flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between"><div><h2 className="text-2xl font-bold text-[#071f49]">Activate a self-paced course</h2><p className="mt-1 text-sm text-slate-600">Only active published certifications are available for activation.</p></div><div className="flex w-full flex-col gap-3 sm:flex-row lg:w-auto"><div className="min-w-0 sm:w-96"><Label htmlFor="online-course-select" className="sr-only">Published certification</Label><select id="online-course-select" value={certificationId} onChange={event => setCertificationId(event.target.value)} className="min-h-11 w-full rounded-md border border-slate-300 bg-white px-3 text-sm text-[#071f49]"><option value="">Select an active certification</option>{availableCourses.map(course => <option value={course.id} key={course.id}>{course.title}</option>)}</select></div><Button type="button" disabled={!certificationId || activate.isPending} onClick={activateCourse} className="min-h-11 bg-[#071f49] font-bold text-white hover:bg-[#173b70]">{activate.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <GraduationCap className="mr-2 h-4 w-4" />}Activate course</Button></div></div>{availableCourses.length === 0 && !options.isLoading ? <p className="mt-5 text-sm text-slate-600">Every currently published certification already has an Online Learning workspace, or no certification is published yet.</p> : null}</section>
    <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div><h2 className="text-2xl font-bold text-[#071f49]">Online Learning workspaces</h2><p className="mt-1 text-sm text-slate-600">Draft and review workspaces remain private to administrators. Published courses become available on the learner route.</p></div>{courses.isLoading ? <p role="status" className="mt-6 flex items-center gap-3 text-sm text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />Loading workspaces…</p> : null}{courses.error ? <p role="alert" className="mt-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800">{courses.error.message}</p> : null}<div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">{courses.data?.map(course => <Link key={course.id} href={`/admin/online-learning/${course.id}`} className="grid gap-3 p-5 hover:bg-slate-50 sm:grid-cols-[1fr_auto] sm:items-center"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-bold text-[#071f49]">{course.certificationTitle}</h3><Badge className={statusClass(course.status)}>{course.status}</Badge></div><p className="mt-2 text-sm text-slate-600">{course.materialCount} material{course.materialCount === 1 ? "" : "s"} · {course.moduleCount} module{course.moduleCount === 1 ? "" : "s"}</p></div><span className="inline-flex items-center gap-1.5 text-sm font-bold text-[#173b70]">Manage <ChevronRight className="h-4 w-4" /></span></Link>)}{!courses.isLoading && courses.data?.length === 0 ? <div className="p-8 text-center"><BookOpenCheck className="mx-auto h-9 w-9 text-slate-400" /><p className="mt-3 font-bold text-[#071f49]">No self-paced courses are active.</p><p className="mt-1 text-sm text-slate-600">Select a published certification above to create the first Online Learning workspace.</p></div> : null}</div></section>
    <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><h2 className="text-2xl font-bold text-[#071f49]">Invite learners</h2><p className="mt-1 text-sm text-slate-600">Send individually addressed invitations for any reviewed, published self-paced course.</p><div className="mt-5 grid gap-3 sm:grid-cols-2">{courses.data?.filter(course => course.status === "published").map(course => <Link key={course.id} href={`/admin/online-learning/${course.id}/invitations`} className="flex items-center justify-between rounded-lg border border-slate-200 p-4 font-semibold text-[#071f49] hover:border-[#173b70] hover:bg-[#f7faff]"><span>{course.certificationTitle}</span><ChevronRight className="h-4 w-4 shrink-0" /></Link>)}{!courses.isLoading && !courses.data?.some(course => course.status === "published") ? <p className="text-sm text-slate-600">Publish a reviewed course to enable learner invitations.</p> : null}</div></section>
  </main>;
}

export default function OnlineLearning() { return <DashboardLayout><OnlineLearningHome /></DashboardLayout>; }
