import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  onlineCourseActivationSchema,
  onlineCourseGenerationSchema,
  onlineCourseLessonUpdateSchema,
  onlineCourseMaterialUploadSchema,
  onlineCourseModuleUpdateSchema,
  onlineCoursePublicQuerySchema,
  onlineCourseStatusUpdateSchema,
  onlineModuleVisualSchema,
} from "../../shared/onlineLearning";
import {
  activateOnlineCourse,
  createOnlineCourseMaterial,
  getOnlineCourseAdminById,
  getPublicOnlineCourseBySlug,
  listOnlineCourses,
  listPublishedCertificationOptions,
  onlineLearningErrors,
  updateOnlineCourseStatus,
  updateOnlineLesson,
  updateOnlineModule,
} from "../onlineLearningDb";
import { analyzeCourseMaterials, generateCourseFromMaterials, generateOnlineModuleVisual } from "../onlineLearningService";
import { storagePut } from "../storage";
import { adminProcedure, publicProcedure, router } from "../_core/trpc";

function safeFileName(value: string) {
  return value.normalize("NFKD").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/-+/g, "-").slice(0, 180) || "course-material";
}

function translateOnlineLearningError(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === onlineLearningErrors.courseNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "Online Learning course not found." });
  if (message === onlineLearningErrors.moduleNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "Learning module not found." });
  if (message === onlineLearningErrors.lessonNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "Learning lesson not found." });
  if (message === onlineLearningErrors.certificationNotPublished) throw new TRPCError({ code: "BAD_REQUEST", message: "Only an active published certification can be activated for self-paced learning." });
  if (message === onlineLearningErrors.courseAlreadyActivated) throw new TRPCError({ code: "CONFLICT", message: "This certification already has an Online Learning workspace." });
  if (message === onlineLearningErrors.materialsRequired) throw new TRPCError({ code: "BAD_REQUEST", message: "Upload at least one course material before continuing." });
  if (message === onlineLearningErrors.materialsNotAnalyzed) throw new TRPCError({ code: "BAD_REQUEST", message: "Analyze every uploaded material before generating course content." });
  if (message === onlineLearningErrors.courseIsPublished) throw new TRPCError({ code: "BAD_REQUEST", message: "Unpublish this course before regenerating its curriculum." });
  if (message === onlineLearningErrors.generatedContentRequired) throw new TRPCError({ code: "BAD_REQUEST", message: "Generate and review at least one published lesson before publishing the self-paced course." });
  if (message === onlineLearningErrors.courseNotPublic) throw new TRPCError({ code: "NOT_FOUND", message: "This self-paced course is not publicly available." });
  throw error;
}

export const onlineLearningRouter = router({
  getBySlug: publicProcedure.input(onlineCoursePublicQuerySchema).query(async ({ input }) => {
    const course = await getPublicOnlineCourseBySlug(input.slug);
    if (!course) throw new TRPCError({ code: "NOT_FOUND", message: "This self-paced course is not currently available." });
    return course;
  }),
});

export const adminOnlineLearningRouter = router({
  list: adminProcedure.query(() => listOnlineCourses()),
  options: adminProcedure.query(() => listPublishedCertificationOptions()),
  getById: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
    const course = await getOnlineCourseAdminById(input.id);
    if (!course) throw new TRPCError({ code: "NOT_FOUND", message: "Online Learning course not found." });
    return course;
  }),
  activate: adminProcedure.input(onlineCourseActivationSchema).mutation(async ({ input, ctx }) => {
    try { return await activateOnlineCourse(input.certificationId, ctx.user.id); } catch (error) { translateOnlineLearningError(error); }
  }),
  uploadMaterial: adminProcedure.input(onlineCourseMaterialUploadSchema).mutation(async ({ input, ctx }) => {
    const bytes = Buffer.from(input.dataBase64, "base64");
    if (bytes.length === 0 || bytes.length > 15 * 1024 * 1024) throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Course materials must be 15 MB or smaller." });
    const fileName = safeFileName(input.fileName);
    const stored = await storagePut(`online-learning/${input.courseId}/materials/${Date.now()}-${fileName}`, bytes, input.mimeType);
    try {
      return await createOnlineCourseMaterial({ courseId: input.courseId, title: input.title, fileName, mimeType: input.mimeType, storageKey: stored.key, url: stored.url, fileSize: bytes.length, actorUserId: ctx.user.id });
    } catch (error) { translateOnlineLearningError(error); }
  }),
  analyzeMaterials: adminProcedure.input(onlineCourseGenerationSchema).mutation(async ({ input }) => {
    try { return await analyzeCourseMaterials(input.courseId); } catch (error) { translateOnlineLearningError(error); }
  }),
  generateCourse: adminProcedure.input(onlineCourseGenerationSchema).mutation(async ({ input, ctx }) => {
    try { return await generateCourseFromMaterials(input.courseId, ctx.user.id); } catch (error) { translateOnlineLearningError(error); }
  }),
  updateStatus: adminProcedure.input(onlineCourseStatusUpdateSchema).mutation(async ({ input, ctx }) => {
    try { return await updateOnlineCourseStatus(input.courseId, input.status, ctx.user.id); } catch (error) { translateOnlineLearningError(error); }
  }),
  updateModule: adminProcedure.input(onlineCourseModuleUpdateSchema).mutation(async ({ input, ctx }) => {
    try { const { moduleId, ...data } = input; return await updateOnlineModule(moduleId, data, ctx.user.id); } catch (error) { translateOnlineLearningError(error); }
  }),
  updateLesson: adminProcedure.input(onlineCourseLessonUpdateSchema).mutation(async ({ input, ctx }) => {
    try { const { lessonId, ...data } = input; return await updateOnlineLesson(lessonId, data, ctx.user.id); } catch (error) { translateOnlineLearningError(error); }
  }),
  generateVisual: adminProcedure.input(onlineModuleVisualSchema).mutation(async ({ input, ctx }) => {
    try { return await generateOnlineModuleVisual(input.moduleId, ctx.user.id); } catch (error) { translateOnlineLearningError(error); }
  }),
});
