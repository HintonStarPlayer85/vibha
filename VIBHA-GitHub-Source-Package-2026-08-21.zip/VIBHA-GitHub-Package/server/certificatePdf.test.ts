import { describe, expect, it } from "vitest";
import { generateCertificatePdf } from "./certificatePdf";

describe("Certificate PDF generator", () => {
  it("creates a branded PDF with a QR-backed verification artifact", async () => {
    const pdf = await generateCertificatePdf({
      certificateNumber: "VIBHA-2026-A1B2C3D4",
      recipientName: "Jordan Avery",
      credentialTitle: "Behavioral Health Workforce Foundations",
      cohortTitle: "Spring 2026 Cohort",
      issuedAt: new Date("2026-03-10T00:00:00Z"),
      verificationUrl: "https://thevibha.org/verify-certificate?reference=VIBHA-2026-A1B2C3D4&token=abc123",
      instructorName: "Beverly Loftin Cobbs, LCSW",
      instructorTitle: "Director of Clinical Education",
      deliveryMode: "Hybrid instruction",
      completionNarrative: "Ninety hours of formal instruction in approved behavioral health workforce competencies.",
      instructionalHours: "90 hours",
      supervisedPracticalTraining: "12 weeks",
      complianceStatement: "This program-specific disclosure is included only when approved for the credential.",
      accreditingBodyName: "Virginia DBHDS",
      licenseNumber: "VIBHA-APPROVAL-001",
      executiveName: "Jacquese Hinton",
      executiveTitle: "Founder & Director of Institutional Strategy",
      instructorSignature: { mimeType: "image/png", bytes: Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLZ9wAAAABJRU5ErkJggg==", "base64") },
    });
    expect(Buffer.from(pdf).subarray(0, 5).toString()).toBe("%PDF-");
    expect(pdf.length).toBeGreaterThan(3_500);
  });
});
