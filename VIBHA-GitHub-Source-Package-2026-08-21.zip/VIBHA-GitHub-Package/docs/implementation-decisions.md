# VIBHA Implementation Decisions

| Decision | Rationale | Control |
|---|---|---|
| Use the existing full-stack React, tRPC, Drizzle, and OAuth scaffold | Supports typed contracts, database content, and admin authorization without introducing a parallel stack | TypeScript checks, API tests, migration review |
| Keep public navigation separate from the admin dashboard shell | Preserves institutional clarity and prevents portal-style UI from appearing on the public site | Route-level layouts |
| Model certifications, categories, instructors, relations, and inquiries as separate entities | Prevents duplication and supports hundreds of records, reusable filters, and future integrations | Foreign keys, unique slugs, indexed status/category fields |
| Use URL query parameters as catalog state | Enables reload persistence, browser navigation, and shareable filtered views | Central parser/serializer with unit tests |
| Store tuition as integer cents plus a display label | Supports numeric cost filtering while preserving values such as “Contact for pricing” | Server validation and formatting helper |
| Store structured lists as JSON columns | Objectives, curriculum topics, delivery methods, and audience lists remain editable and typed without auxiliary table overhead | Zod schemas and form arrays |
| Treat “published” and “inactive” as distinct lifecycle states | Supports non-destructive CMS deactivation and prevents inactive public detail access | Public status predicates and admin-only mutations |
| Use the supplied program guide as initial production content | Avoids invented sample listings and aligns the experience with VIBHA’s approved catalog | Source notes and uncertainty exclusions |
| Present institutional standing rather than unsupported accreditation | Meets the About-page requirement without making unverified regulatory claims | Content governance review |
| Persist inquiries in the database with routing metadata | Delivers a working submission destination before a CRM or mailbox connector is approved | Server validation, consent, status, and admin-readable records |

