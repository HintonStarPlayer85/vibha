import { trpc } from "@/lib/trpc";
import {
  ArrowRight,
  ClipboardCheck,
  GraduationCap,
  HeartHandshake,
  Landmark,
  MapPinned,
  ShieldAlert,
  UsersRound,
} from "lucide-react";
import { Link } from "wouter";

const icons = {
  "users-round": UsersRound,
  "heart-handshake": HeartHandshake,
  "shield-alert": ShieldAlert,
  "clipboard-check": ClipboardCheck,
  landmark: Landmark,
  "map-pinned": MapPinned,
  "graduation-cap": GraduationCap,
} as const;

export function CategoryTiles({ limit }: { limit?: number }) {
  const { data, isLoading, error } = trpc.certifications.categories.useQuery();
  const categories = limit ? data?.slice(0, limit) : data;

  if (isLoading) {
    return (
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3" aria-label="Loading program categories">
        {Array.from({ length: limit ?? 6 }).map((_, index) => (
          <div key={index} className="h-64 animate-pulse rounded-xl bg-slate-100" />
        ))}
      </div>
    );
  }

  if (error || !categories) {
    return <p role="alert" className="rounded-lg border border-red-200 bg-red-50 p-4 text-red-800">Program categories are temporarily unavailable.</p>;
  }

  return (
    <div data-stagger className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {categories.map((category, index) => {
        const Icon = icons[category.iconKey as keyof typeof icons] ?? GraduationCap;
        return (
          <article key={category.id} data-reveal="scale" className="vibha-card-interactive group relative overflow-hidden rounded-xl border border-slate-200 bg-white p-6 shadow-[0_8px_30px_rgba(4,22,52,0.055)] hover:border-[#173b70]/35">
            <span className="absolute right-4 top-3 font-serif text-6xl font-bold text-[#6b7c95]" aria-hidden="true">{String(index + 1).padStart(2, "0")}</span>
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-[#071f49] text-white transition-transform duration-200 group-hover:rotate-3 group-hover:scale-105">
              <Icon className="h-6 w-6" aria-hidden="true" />
            </div>
            <h3 className="mt-5 text-2xl font-bold leading-tight text-[#071f49]">{category.name}</h3>
            <p className="mt-3 min-h-20 text-sm leading-6 text-slate-600">{category.shortDescription}</p>
            <Link href={`/certifications?category=${category.slug}`} className="vibha-icon-shift mt-5 inline-flex items-center gap-2 rounded-sm text-sm font-bold text-[#173b70] hover:text-[#071f49] hover:underline">
              Explore this area <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </article>
        );
      })}
    </div>
  );
}
