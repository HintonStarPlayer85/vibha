import { describe, expect, it, vi } from "vitest";

const dbMocks = vi.hoisted(() => ({
  completeGenerationRun: vi.fn(), createGenerationRun: vi.fn(), failGenerationRun: vi.fn(), getOnlineCourseAdminById: vi.fn(), getOnlineModuleForGeneration: vi.fn(), getOnlineCourseMaterials: vi.fn(), getPublicOnlineCourseBySlug: vi.fn(), replaceGeneratedCourseContent: vi.fn(), updateMaterialAnalysis: vi.fn(), updateOnlineModuleVisual: vi.fn(),
}));
const llmMocks = vi.hoisted(() => ({ invokeLLM: vi.fn(), listLLMModels: vi.fn() }));
const imageMocks = vi.hoisted(() => ({ generateImage: vi.fn() }));
const storageMocks = vi.hoisted(() => ({ storageGetSignedUrl: vi.fn() }));
vi.mock("./onlineLearningDb", async () => { const actual = await vi.importActual<typeof import("./onlineLearningDb")>("./onlineLearningDb"); return { ...actual, ...dbMocks }; });
vi.mock("./_core/llm", () => llmMocks);
vi.mock("./_core/imageGeneration", () => imageMocks);
vi.mock("./storage", () => storageMocks);

import { generateCourseFromMaterials } from "./onlineLearningService";

const generatedCourse = {
  courseOverview: "A source-grounded self-paced course that prepares learners to apply the approved course concepts.",
  sourceGroundingNotice: "Every lesson draft is based on the uploaded course materials and must be reviewed before publication.",
  aiInstructorName: "VIBHA Learning Guide",
  aiInstructorWelcome: "I can help you navigate the approved course concepts.",
  aiInstructorScope: "I answer only from the approved course content and defer unsupported questions to VIBHA.",
  modules: [{ position: 1, title: "Foundational concepts", learningObjective: "Explain the foundational concepts described in the uploaded material.", sourceGrounding: "The uploaded guide identifies the foundational concepts and required learning boundaries.", visualPrompt: "A clean conceptual diagram illustrating foundational learning concepts without text.", videoBrief: "A 3-minute narrated lesson opening with a concept overview, on-screen visual cues, and a recap.", lessons: [{ position: 1, title: "Introduction", estimatedMinutes: 10, content: "This lesson introduces the approved foundational concepts from the uploaded material and explains why they matter for the course.", knowledgeCheckQuestion: "What is the central foundational concept introduced in this lesson?", knowledgeCheckAnswer: "Review the source-backed concept summary and identify the central principle described in the lesson." }] }],
};

describe("Online Learning generation service", () => {
  it("generates a structured draft only from analyzed material summaries and source grounding", async () => {
    dbMocks.getOnlineCourseAdminById.mockResolvedValue({ id: 5, status: "draft", certificationTitle: "Foundations", certificationSummary: "A foundational VIBHA course.", certificationObjectives: ["Apply course concepts"], certificationTopics: ["Foundations"], certificationAudience: ["Learners"], certificationDuration: "8 hours", certificationCeus: 8, materials: [{ id: 1, analysisStatus: "analyzed", analysisSummary: "The guide defines a source-backed foundational concept.", sourceExcerpt: "Foundational concept: use the approved learning sequence." }] });
    llmMocks.listLLMModels.mockResolvedValue({ data: [{ id: "gemini-3-flash-preview" }] });
    dbMocks.createGenerationRun.mockResolvedValue(17);
    llmMocks.invokeLLM.mockResolvedValue({ choices: [{ message: { content: JSON.stringify(generatedCourse) } }] });
    dbMocks.replaceGeneratedCourseContent.mockResolvedValue({ id: 5, status: "review" });
    await generateCourseFromMaterials(5, 99);
    expect(llmMocks.invokeLLM).toHaveBeenCalledWith(expect.objectContaining({ model: "gemini-3-flash-preview", messages: [expect.objectContaining({ content: expect.stringContaining("SOURCE DIGEST") })] }));
    expect(dbMocks.replaceGeneratedCourseContent).toHaveBeenCalledWith(5, 17, expect.objectContaining({ modules: expect.any(Array) }), 99);
    expect(dbMocks.completeGenerationRun).toHaveBeenCalledWith(17, expect.any(Object), 99);
  });
});
