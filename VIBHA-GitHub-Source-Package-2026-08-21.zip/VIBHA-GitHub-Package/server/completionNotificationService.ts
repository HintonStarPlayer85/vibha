import { Resend } from "resend";
import {
  getCompletionNotificationDelivery,
  markCompletionNotificationAccepted,
  markCompletionNotificationFailed,
  prepareCompletionNotificationRetry,
} from "./certificateDb";
import { getResendConfiguration, verifyResendSenderDomain } from "./resendCohort";

function escapeHtml(value: string) {
  return value.replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]!);
}

function renderCompletionNotification(notification: NonNullable<Awaited<ReturnType<typeof getCompletionNotificationDelivery>>>) {
  const approved = notification.decision === "approved";
  const heading = approved ? "Your course completion is approved" : "Your course completion needs review";
  const message = approved
    ? `Your completion of ${notification.credentialTitle} in ${notification.cohortTitle} has been reviewed and approved by VIBHA. Certificate issuance may proceed through VIBHA administration.`
    : `Your completion of ${notification.credentialTitle} in ${notification.cohortTitle} has been returned for review. Please contact VIBHA if you need support with the next steps.`;
  const notes = !approved && notification.reviewNotes?.trim() ? `<div style="margin-top:18px;padding:16px;background:#f6f8fb;border-left:4px solid #f47a20"><strong>Review notes</strong><p style="margin:8px 0 0;line-height:1.6">${escapeHtml(notification.reviewNotes.trim())}</p></div>` : "";
  const html = `<!doctype html><html><body style="margin:0;background:#f6f8fb;font-family:Arial,sans-serif"><div style="max-width:680px;margin:0 auto;padding:28px 16px"><div style="background:#071f49;padding:20px 24px;color:#fff"><strong style="font-size:22px">VIBHA</strong><div style="margin-top:4px;font-size:12px;letter-spacing:.08em">THE VIRGINIA INSTITUTE FOR BEHAVIORAL HEALTH &amp; ADVANCEMENT</div></div><div style="background:#fff;padding:28px 24px;border:1px solid #dce3ec"><h1 style="margin:0 0 18px;font-size:22px;color:#071f49">${heading}</h1><p style="margin:0;color:#34435a;line-height:1.65">Hello ${escapeHtml(notification.recipientName)},</p><p style="margin:16px 0 0;color:#34435a;line-height:1.65">${escapeHtml(message)}</p>${notes}<p style="margin:28px 0 0;padding-top:18px;border-top:1px solid #dce3ec;color:#667085;font-size:13px;line-height:1.6">Reply to this email if you need assistance.</p></div></div></body></html>`;
  const text = [`Hello ${notification.recipientName},`, message, !approved && notification.reviewNotes?.trim() ? `Review notes: ${notification.reviewNotes.trim()}` : null].filter(Boolean).join("\n\n");
  return { html, text };
}

async function attemptDelivery(notification: NonNullable<Awaited<ReturnType<typeof getCompletionNotificationDelivery>>>, retrySuffix: string) {
  const config = getResendConfiguration();
  const senderDomain = await verifyResendSenderDomain(true);
  if (!config.readyToSend || !config.apiKey || !config.from || !config.replyTo || !senderDomain.verified) {
    const detail = !senderDomain.verified ? `Sender domain ${senderDomain.domain || "unknown"} is ${senderDomain.status.replace(/_/g, " ")}.` : `Missing: ${config.missing.join(", ")}.`;
    await markCompletionNotificationFailed(notification.id, "resend_not_ready", detail, retrySuffix !== "initial");
    return { status: "failed" as const, error: detail };
  }
  try {
    const rendered = renderCompletionNotification(notification);
    const result = await new Resend(config.apiKey).emails.send({
      from: config.from,
      to: [notification.recipientEmail],
      replyTo: config.replyTo,
      subject: notification.subject,
      html: rendered.html,
      text: rendered.text,
      tags: [{ name: "completion_decision", value: notification.decision }, { name: "completion_notification_id", value: String(notification.id) }],
    }, { idempotencyKey: notification.idempotencyKey.slice(0, 256) });
    if (result.error || !result.data?.id) {
      const error = result.error?.message || "Resend did not accept the completion notification.";
      await markCompletionNotificationFailed(notification.id, result.error?.name || "resend_error", error, retrySuffix !== "initial");
      return { status: "failed" as const, error };
    }
    await markCompletionNotificationAccepted(notification.id, result.data.id);
    return { status: "accepted" as const, error: null };
  } catch (error) {
    const detail = error instanceof Error ? error.message : "The completion notification request did not complete.";
    await markCompletionNotificationFailed(notification.id, "resend_network_error", detail, retrySuffix !== "initial");
    return { status: "failed" as const, error: detail };
  }
}

export async function deliverCompletionNotification(notificationId: number) {
  const notification = await getCompletionNotificationDelivery(notificationId);
  if (!notification) throw new Error("COMPLETION_NOTIFICATION_NOT_FOUND");
  if (notification.status === "accepted") return { status: "accepted" as const, retried: false };
  const first = await attemptDelivery(notification, "initial");
  if (first.status === "accepted") return { status: "accepted" as const, retried: false };
  const refreshed = await getCompletionNotificationDelivery(notificationId);
  if (!refreshed) throw new Error("COMPLETION_NOTIFICATION_NOT_FOUND");
  const retry = await attemptDelivery(refreshed, "automatic-retry");
  return { status: retry.status, retried: true, error: retry.error };
}

export async function resendCompletionNotification(notificationId: number, actorUserId: number) {
  await prepareCompletionNotificationRetry(notificationId, actorUserId);
  return deliverCompletionNotification(notificationId);
}
