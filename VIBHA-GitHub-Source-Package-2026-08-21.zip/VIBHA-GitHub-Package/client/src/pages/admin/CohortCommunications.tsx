import DashboardLayout from "@/components/DashboardLayout";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  FileText,
  Loader2,
  Mail,
  RefreshCw,
  Send,
  UsersRound,
  Video,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link, useRoute } from "wouter";
import { toast } from "sonner";

type CommunicationType = "zoom_details" | "resource_update" | "schedule_update" | "general";

function statusTone(status: string) {
  if (status === "sent" || status === "delivered") return "bg-emerald-100 text-emerald-900";
  if (status === "failed" || status === "bounced" || status === "complained") return "bg-rose-100 text-rose-900";
  if (status === "partial") return "bg-amber-100 text-amber-900";
  return "bg-slate-100 text-slate-700";
}

function CommunicationWorkspace() {
  const [, params] = useRoute("/admin/cohorts/:id/communications");
  const cohortId = Number(params?.id);
  const utils = trpc.useUtils();
  const cohort = trpc.adminCohorts.getById.useQuery({ id: cohortId }, { enabled: Number.isInteger(cohortId) && cohortId > 0 });
  const configuration = trpc.adminCohortCommunications.configuration.useQuery();
  const history = trpc.adminCohortCommunications.history.useQuery({ cohortId }, { enabled: Number.isInteger(cohortId) && cohortId > 0 });
  const previewMutation = trpc.adminCohortCommunications.preview.useMutation();
  const sendMutation = trpc.adminCohortCommunications.send.useMutation();
  const retryMutation = trpc.adminCohortCommunications.retry.useMutation();

  const [communicationType, setCommunicationType] = useState<CommunicationType>("general");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [includeZoom, setIncludeZoom] = useState(false);
  const [resourceIds, setResourceIds] = useState<number[]>([]);
  const [preview, setPreview] = useState<Awaited<ReturnType<typeof previewMutation.mutateAsync>> | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState("");
  const [announcedStatus, setAnnouncedStatus] = useState("");

  const studentResources = useMemo(
    () => (cohort.data?.resources ?? []).filter(resource => resource.isActive && (resource.audience === "students" || resource.audience === "all")),
    [cohort.data?.resources],
  );

  const draft = { cohortId, communicationType, subject, message, includeZoom, resourceIds };
  const invalidatePreview = () => { setPreview(null); setIdempotencyKey(""); };

  async function preparePreview() {
    try {
      const result = await previewMutation.mutateAsync(draft);
      setPreview(result);
      setIdempotencyKey(crypto.randomUUID());
      setAnnouncedStatus(`Preview prepared for ${result.recipientCount} recipients.`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The message preview could not be prepared.");
    }
  }

  async function confirmSend() {
    if (!preview || !idempotencyKey) return;
    try {
      const result = await sendMutation.mutateAsync({
        ...draft,
        previewHash: preview.previewHash,
        idempotencyKey,
        confirmedRecipientCount: preview.recipientCount,
        confirmation: true,
      });
      setAnnouncedStatus(`Send completed with ${result.accepted} accepted and ${result.failed + result.bounced + result.complained} adverse outcomes.`);
      toast.success("Cohort message submitted to Resend.");
      setPreview(null);
      setIdempotencyKey("");
      await Promise.all([
        utils.adminCohortCommunications.history.invalidate({ cohortId }),
        utils.adminCohorts.getById.invalidate({ id: cohortId }),
        utils.adminCohorts.list.invalidate(),
      ]);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The cohort message could not be sent.");
    }
  }

  async function retryFailed(communicationId: number, recipientIds: number[]) {
    try {
      await retryMutation.mutateAsync({ communicationId, recipientIds, confirmation: true });
      toast.success("Failed recipients were resubmitted.");
      setAnnouncedStatus(`${recipientIds.length} failed recipient${recipientIds.length === 1 ? " was" : "s were"} resubmitted.`);
      await Promise.all([
        utils.adminCohortCommunications.history.invalidate({ cohortId }),
        utils.adminCohorts.getById.invalidate({ id: cohortId }),
        utils.adminCohorts.list.invalidate(),
      ]);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "The failed recipients could not be retried.");
    }
  }

  if (!Number.isInteger(cohortId) || cohortId < 1) return <div className="p-8">Invalid cohort.</div>;
  if (cohort.isLoading) return <div role="status" className="flex min-h-[50vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-[#071f49]" /><span className="sr-only">Loading cohort communications</span></div>;
  if (!cohort.data) return <div className="p-8"><h1 className="text-2xl font-bold text-[#071f49]">Cohort not found</h1><Button asChild className="mt-4"><Link href="/admin/cohorts">Return to Cohorts</Link></Button></div>;

  const ready = configuration.data?.readyToSend ?? false;
  const webhookReady = configuration.data?.webhookReady ?? false;

  return (
    <div className="min-w-0 p-4 sm:p-6 lg:p-8">
      <div aria-live="polite" className="sr-only">{announcedStatus}</div>
      <Link href={`/admin/cohorts/${cohortId}/edit`} className="inline-flex min-h-11 items-center gap-2 font-semibold text-[#173b70] hover:text-[#b94700]"><ArrowLeft className="h-4 w-4" />Cohort record</Link>
      <header className="mt-3 flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
        <div><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Cohort Communications</p><h1 className="mt-2 text-4xl font-bold text-[#071f49]">{cohort.data.title}</h1><p className="mt-3 max-w-3xl text-slate-600">Preview recipients and operational content before sending. Each student receives a separate message so addresses are never exposed to the cohort.</p></div>
        <div className="rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm"><strong className="text-[#071f49]">Sender:</strong> {configuration.data?.from || "Not configured"}<br /><strong className="text-[#071f49]">Reply to:</strong> {configuration.data?.replyTo || "Not configured"}</div>
      </header>

      {!ready ? <Alert className="mt-6 border-rose-200 bg-rose-50"><AlertTriangle className="h-5 w-5 text-rose-800" /><AlertTitle className="text-rose-950">Resend delivery is disabled</AlertTitle><AlertDescription className="text-rose-900">{configuration.data?.missing.length ? `Missing configuration: ${configuration.data.missing.join(", ")}.` : configuration.data?.senderDomain ? `Sender domain ${configuration.data.senderDomain.domain || "unknown"} is ${configuration.data.senderDomain.status.replaceAll("_", " ")}. Verify the domain in Resend before sending.` : "Configuration is still being verified."}</AlertDescription></Alert> : null}
      {ready && !webhookReady ? <Alert className="mt-6 border-amber-200 bg-amber-50"><AlertTriangle className="h-5 w-5 text-amber-800" /><AlertTitle className="text-amber-950">Delivery-event tracking is not active</AlertTitle><AlertDescription className="text-amber-900">Messages can be sent, but delivery, bounce, and complaint updates require the Resend webhook signing secret.</AlertDescription></Alert> : null}

      <div className="mt-8 grid gap-6 xl:grid-cols-[1.1fr_.9fr]">
        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
          <h2 className="text-2xl font-bold text-[#071f49]">Compose message</h2>
          <div className="mt-6 grid gap-5">
            <div><Label htmlFor="communication-type">Message type</Label><select id="communication-type" value={communicationType} onChange={event => { setCommunicationType(event.target.value as CommunicationType); invalidatePreview(); }} className="mt-2 w-full rounded-md border border-input bg-white px-3"><option value="general">General update</option><option value="zoom_details">Zoom details</option><option value="schedule_update">Schedule update</option><option value="resource_update">Resource update</option></select></div>
            <div><Label htmlFor="communication-subject">Subject</Label><Input id="communication-subject" value={subject} onChange={event => { setSubject(event.target.value); invalidatePreview(); }} placeholder="Important information for your VIBHA cohort" /></div>
            <div><Label htmlFor="communication-message">Message</Label><Textarea id="communication-message" value={message} onChange={event => { setMessage(event.target.value); invalidatePreview(); }} rows={9} placeholder="Provide the cohort update, instructions, and any required next steps." /><p className="mt-2 text-xs text-slate-500">Do not include clinical information, protected health information, or unnecessary sensitive personal data.</p></div>
            <label className="flex min-h-11 items-start gap-3 rounded-lg border border-slate-200 p-3" style={{ minHeight: 44 }}><input type="checkbox" checked={includeZoom} onChange={event => { setIncludeZoom(event.target.checked); invalidatePreview(); }} className="mt-1 h-5 w-5 accent-[#071f49]" /><span><strong className="text-[#071f49]">Include Zoom details</strong><span className="mt-1 block text-sm text-slate-600">Adds the configured join URL, meeting ID, and passcode to each private email.</span></span></label>
            <div><p className="font-semibold text-[#071f49]">Include student resources</p><div className="mt-2 grid gap-2">{studentResources.map(resource => <label key={resource.id} className="flex min-h-11 items-center gap-3 rounded-lg border border-slate-200 px-3 py-2" style={{ minHeight: 44 }}><input type="checkbox" checked={resourceIds.includes(resource.id)} onChange={event => { setResourceIds(current => event.target.checked ? [...current, resource.id] : current.filter(id => id !== resource.id)); invalidatePreview(); }} className="h-5 w-5 accent-[#071f49]" /><FileText className="h-4 w-4 text-[#b94700]" /><span className="text-sm font-semibold text-slate-700">{resource.title}</span></label>)}{studentResources.length === 0 ? <p className="text-sm text-slate-600">No active student-facing resources are available.</p> : null}</div></div>
            <Button type="button" disabled={!ready || previewMutation.isPending || subject.trim().length < 3 || message.trim().length < 10} onClick={preparePreview} className="bg-[#071f49] text-white hover:bg-[#173b70]">{previewMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UsersRound className="mr-2 h-4 w-4" />}Preview recipients and content</Button>
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
          <h2 className="text-2xl font-bold text-[#071f49]">Confirmed-send control</h2>
          {!preview ? <div className="mt-6 rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6 text-center"><Mail className="mx-auto h-8 w-8 text-[#b94700]" /><p className="mt-3 font-bold text-[#071f49]">Prepare a preview before sending.</p><p className="mt-2 text-sm text-slate-600">A new preview is required whenever the roster, message, Zoom details, or selected resources change.</p></div> : <div className="mt-6">
            <div className="grid gap-3 sm:grid-cols-2"><div className="rounded-lg bg-[#f6f8fb] p-4"><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Recipients</p><p className="mt-1 text-2xl font-bold text-[#071f49]">{preview.recipientCount}</p></div><div className="rounded-lg bg-[#f6f8fb] p-4"><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Privacy mode</p><p className="mt-1 font-bold text-[#071f49]">Individual delivery</p></div></div>
            <div className="mt-5 max-h-60 overflow-auto rounded-lg border border-slate-200"><table className="w-full text-left text-sm"><caption className="sr-only">Confirmed cohort recipients</caption><thead className="sticky top-0 bg-slate-50"><tr><th className="px-3 py-2">Student</th><th className="px-3 py-2">Email</th></tr></thead><tbody className="divide-y divide-slate-200">{preview.recipients.map(recipient => <tr key={recipient.id}><td className="px-3 py-2 font-semibold text-[#071f49]">{recipient.name}</td><td className="px-3 py-2 text-slate-600">{recipient.email}</td></tr>)}</tbody></table></div>
            <div className="mt-5 rounded-lg border border-slate-200 p-4"><p className="text-xs font-bold uppercase tracking-wide text-slate-500">Subject</p><p className="mt-1 font-bold text-[#071f49]">{preview.subject}</p><p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-slate-700">{preview.message}</p>{preview.zoom ? <p className="mt-3 flex items-center gap-2 text-sm font-semibold text-[#173b70]"><Video className="h-4 w-4" />Zoom details included</p> : null}{preview.resources.length ? <p className="mt-2 text-sm font-semibold text-[#173b70]">{preview.resources.length} resource link{preview.resources.length === 1 ? "" : "s"} included</p> : null}</div>
            <AlertDialog>
              <AlertDialogTrigger asChild><Button type="button" disabled={sendMutation.isPending} className="mt-5 w-full bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]"><Send className="mr-2 h-4 w-4" />Send to {preview.recipientCount} recipient{preview.recipientCount === 1 ? "" : "s"}</Button></AlertDialogTrigger>
              <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Confirm cohort email distribution</AlertDialogTitle><AlertDialogDescription>You are about to send “{preview.subject}” as {preview.recipientCount} separate email{preview.recipientCount === 1 ? "" : "s"}. Recipient addresses will not be shared. This action is recorded in the administration audit trail.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Return to preview</AlertDialogCancel><AlertDialogAction onClick={confirmSend} className="bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">Confirm and send</AlertDialogAction></AlertDialogFooter></AlertDialogContent>
            </AlertDialog>
          </div>}
        </section>
      </div>

      <section className="mt-8 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
        <h2 className="text-2xl font-bold text-[#071f49]">Communication history</h2>
        <p className="mt-2 text-sm text-slate-600">Review accepted, delivered, failed, bounced, and complaint outcomes. Only failed delivery attempts are eligible for a confirmed retry.</p>
        <div className="mt-6 grid gap-4">{history.data?.map(item => {
          const failedRecipients = item.recipients.filter(recipient => recipient.status === "failed");
          return <article key={item.id} className="rounded-lg border border-slate-200 p-4 sm:p-5"><div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-bold text-[#071f49]">{item.subject}</h3><Badge className={statusTone(item.status)}>{item.status}</Badge></div><p className="mt-1 text-xs uppercase tracking-wide text-slate-500">{item.communicationType.replace("_", " ")} · {new Date(item.createdAt).toLocaleString()}</p><p className="mt-3 max-w-3xl text-sm leading-6 text-slate-600">{item.contentSummary}</p></div><div className="flex flex-wrap gap-3 text-sm text-slate-600"><span><strong className="text-[#071f49]">{item.recipientCount}</strong> recipients</span><span><strong className="text-[#071f49]">{item.deliveredCount}</strong> delivered</span><span><strong className="text-[#071f49]">{item.failedCount + item.bouncedCount + item.complainedCount}</strong> adverse</span></div></div><details className="mt-4"><summary className="min-h-11 cursor-pointer py-2 font-semibold text-[#173b70]">View recipient outcomes</summary><div className="mt-2 overflow-x-auto"><table className="w-full min-w-[620px] text-left text-sm"><thead className="bg-slate-50"><tr><th className="px-3 py-2">Student</th><th className="px-3 py-2">Email</th><th className="px-3 py-2">Status</th><th className="px-3 py-2">Retries</th></tr></thead><tbody className="divide-y divide-slate-200">{item.recipients.map(recipient => <tr key={recipient.id}><td className="px-3 py-2 font-semibold text-[#071f49]">{recipient.studentName}</td><td className="px-3 py-2 text-slate-600">{recipient.email}</td><td className="px-3 py-2"><Badge className={statusTone(recipient.status)}>{recipient.status}</Badge></td><td className="px-3 py-2 text-slate-600">{recipient.retryCount}</td></tr>)}</tbody></table></div>{failedRecipients.length ? <AlertDialog><AlertDialogTrigger asChild><Button type="button" variant="outline" className="mt-4 border-rose-300 bg-white text-rose-800"><RefreshCw className="mr-2 h-4 w-4" />Retry {failedRecipients.length} failed recipient{failedRecipients.length === 1 ? "" : "s"}</Button></AlertDialogTrigger><AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Confirm failed-recipient retry</AlertDialogTitle><AlertDialogDescription>This sends the original message only to the {failedRecipients.length} recipient{failedRecipients.length === 1 ? "" : "s"} with a failed delivery attempt. Other cohort members will not receive another copy.</AlertDialogDescription></AlertDialogHeader><AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel><AlertDialogAction onClick={() => retryFailed(item.id, failedRecipients.map(recipient => recipient.id))}>Confirm retry</AlertDialogAction></AlertDialogFooter></AlertDialogContent></AlertDialog> : null}</details></article>;
        })}{history.data?.length === 0 ? <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-8 text-center"><CheckCircle2 className="mx-auto h-8 w-8 text-[#b94700]" /><p className="mt-3 font-bold text-[#071f49]">No messages have been sent.</p></div> : null}</div>
      </section>
    </div>
  );
}

export default function CohortCommunications() {
  return <DashboardLayout><CommunicationWorkspace /></DashboardLayout>;
}
