import { createHash, createHmac } from "node:crypto";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { administrationAuditEvents, certificateApprovalHistoryReports } from "../drizzle/schema";
import { ENV } from "./_core/env";
import { getDb } from "./db";
import { getCertificateById, listCertificateApprovalHistory } from "./certificateDb";

export async function generateCertificateApprovalHistoryPdf(input: { certificateId: number; eventTypes?: string[]; exporter: { id: number; name: string; openId: string } }) {
  const certificate = await getCertificateById(input.certificateId);
  if (!certificate) throw new Error("CERTIFICATE_NOT_FOUND");
  const history = await listCertificateApprovalHistory(input.certificateId, input.eventTypes);
  const exportedAt = new Date();
  const attestationPayload = JSON.stringify({ certificateNumber: certificate.certificateNumber, exportedAt: exportedAt.toISOString(), exporter: input.exporter.openId, eventTypes: input.eventTypes ?? [], events: history.map(event => [event.action, event.actorName, event.createdAt?.toISOString() ?? null, event.details]) });
  const attestation = createHmac("sha256", ENV.cookieSecret || "certificate-export-fallback").update(attestationPayload).digest("hex");
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([612, 792]);
  const regular = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const navy = rgb(0.027, 0.122, 0.286);
  page.drawRectangle({ x: 0, y: 724, width: 612, height: 68, color: navy });
  page.drawText("VIBHA", { x: 42, y: 756, size: 24, font: bold, color: rgb(1, 1, 1) });
  page.drawText("Certificate Approval History Report", { x: 42, y: 736, size: 11, font: regular, color: rgb(1, 1, 1) });
  const meta = [
    `Certificate: ${certificate.certificateNumber}`,
    `Recipient: ${certificate.recipientName}`,
    `Credential: ${certificate.credentialTitle}`,
    `Exported: ${exportedAt.toISOString()} UTC`,
    `Exported by: ${input.exporter.name} (${input.exporter.openId})`,
    `Filters: ${input.eventTypes?.length ? input.eventTypes.join(", ") : "All certificate history events"}`,
  ];
  let y = 696;
  for (const line of meta) { page.drawText(line, { x: 42, y, size: 9, font: regular, color: rgb(0.12, 0.16, 0.23) }); y -= 15; }
  page.drawLine({ start: { x: 42, y: y - 2 }, end: { x: 570, y: y - 2 }, thickness: 1, color: rgb(0.8, 0.84, 0.9) }); y -= 20;
  page.drawText("Timestamp (UTC)", { x: 42, y, size: 8, font: bold, color: navy });
  page.drawText("Event", { x: 174, y, size: 8, font: bold, color: navy });
  page.drawText("Administrator / Notes", { x: 318, y, size: 8, font: bold, color: navy }); y -= 14;
  for (const event of history) {
    const timestamp = event.createdAt ? event.createdAt.toISOString().replace("T", " ").slice(0, 19) : "Unavailable";
    const detail = `${event.actorName ?? "Former administrator"}${event.details ? ` — ${event.details}` : ""}`.slice(0, 95);
    if (y < 78) { const next = pdf.addPage([612, 792]); y = 742; next.drawText("VIBHA Certificate Approval History (continued)", { x: 42, y: 758, size: 11, font: bold, color: navy }); }
    const target = pdf.getPages()[pdf.getPageCount() - 1]!;
    target.drawText(timestamp, { x: 42, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23) });
    target.drawText(event.action.slice(0, 24), { x: 174, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23) });
    target.drawText(detail, { x: 318, y, size: 7.5, font: regular, color: rgb(0.15, 0.18, 0.23), maxWidth: 248 });
    y -= 25;
  }
  const last = pdf.getPages()[pdf.getPageCount() - 1]!;
  last.drawText(`Report attestation (HMAC-SHA256): ${attestation}`, { x: 42, y: 38, size: 6.5, font: regular, color: rgb(0.35, 0.4, 0.48) });
  const bytes = await pdf.save();
  const reportSha256 = createHash("sha256").update(bytes).digest("hex");
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  await db.transaction(async tx => {
    await tx.insert(certificateApprovalHistoryReports).values({ certificateId: input.certificateId, exportedByUserId: input.exporter.id, exportedByName: input.exporter.name, eventFilters: input.eventTypes ?? null, reportSha256, attestation });
    await tx.insert(administrationAuditEvents).values({ actorUserId: input.exporter.id, action: "certificate.history.pdf_exported", entityType: "issued_certificate", entityId: String(input.certificateId), eventMetadata: { reportSha256, eventTypes: input.eventTypes?.join("|") ?? "all", exportedAt: exportedAt.toISOString() } });
  });
  return { fileName: `${certificate.certificateNumber}-approval-history.pdf`, dataBase64: Buffer.from(bytes).toString("base64"), exportedAt: exportedAt.toISOString(), attestation, reportSha256 };
}
