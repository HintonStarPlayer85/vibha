import type { Express, Request } from "express";
import { getPublishedSitemapCertifications } from "./db";

function originFrom(request: Request) {
  const forwardedProto = request.headers["x-forwarded-proto"];
  const protocol = Array.isArray(forwardedProto)
    ? forwardedProto[0]
    : forwardedProto?.split(",")[0] || request.protocol;
  const forwardedHost = request.headers["x-forwarded-host"];
  const host = Array.isArray(forwardedHost)
    ? forwardedHost[0]
    : forwardedHost?.split(",")[0] || request.get("host");
  return `${protocol}://${host}`;
}

function escapeXml(value: string) {
  return value.replace(/[<>&'\"]/g, character => {
    const entities: Record<string, string> = {
      "<": "&lt;",
      ">": "&gt;",
      "&": "&amp;",
      "'": "&apos;",
      '"': "&quot;",
    };
    return entities[character];
  });
}

export function registerSeoRoutes(app: Express) {
  app.get("/robots.txt", (request, response) => {
    const origin = originFrom(request);
    response
      .type("text/plain")
      .send(`User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: ${origin}/sitemap.xml\n`);
  });

  app.get("/sitemap.xml", async (request, response) => {
    const origin = originFrom(request);
    const certifications = await getPublishedSitemapCertifications();
    const publicRoutes = ["/", "/certifications", "/programs", "/about", "/about/leadership", "/contact", "/privacy", "/accessibility"];
    const urls = [
      ...publicRoutes.map(path => ({ location: `${origin}${path}`, lastModified: null as Date | null })),
      ...certifications.map(item => ({
        location: `${origin}/certifications/${item.slug}`,
        lastModified: item.updatedAt,
      })),
    ];
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
      .map(item => `  <url>\n    <loc>${escapeXml(item.location)}</loc>${item.lastModified ? `\n    <lastmod>${item.lastModified.toISOString()}</lastmod>` : ""}\n  </url>`)
      .join("\n")}\n</urlset>`;
    response.type("application/xml").send(xml);
  });
}
