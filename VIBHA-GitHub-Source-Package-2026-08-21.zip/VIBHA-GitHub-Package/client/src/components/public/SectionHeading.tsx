import { cn } from "@/lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  inverse = false,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: "left" | "center";
  inverse?: boolean;
}) {
  return (
    <div className={cn("max-w-3xl", align === "center" && "mx-auto text-center")}>
      {eyebrow ? (
        <p className={cn("text-sm font-bold uppercase tracking-[0.18em]", inverse ? "text-[#ff9a52]" : "text-[#b94700]")}>
          {eyebrow}
        </p>
      ) : null}
      <h2 className={cn("mt-3 text-balance text-3xl font-bold leading-tight sm:text-4xl", inverse ? "text-white" : "text-[#071f49]")}>{title}</h2>
      {description ? (
        <p className={cn("mt-4 text-pretty text-lg leading-8", inverse ? "text-slate-300" : "text-slate-600")}>{description}</p>
      ) : null}
    </div>
  );
}

