import "dotenv/config";
import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import {
  certificationCategories,
  certificationInstructors,
  certifications,
  instructors,
} from "../drizzle/schema";

type SeedCertification = {
  title: string;
  slug: string;
  categorySlug: string;
  description: string;
  prerequisites: string;
  duration: string;
  costCents: number;
  level: string;
  featured?: boolean;
};

const categories = [
  {
    name: "Workforce Entry & Foundations",
    slug: "workforce-entry-foundations",
    shortDescription: "Career-entry preparation and essential behavioral health workforce competencies.",
    description:
      "Foundational certifications for professionals entering behavioral health services or strengthening core documentation, communication, ethics, trauma-informed practice, and recovery-oriented skills.",
    iconKey: "users-round",
    displayOrder: 10,
  },
  {
    name: "Clinical Support & Community Services",
    slug: "clinical-support-community-services",
    shortDescription: "Community-based service delivery, coordination, supervision, and stabilization skills.",
    description:
      "Workforce certifications aligned with person-centered, community-based behavioral health service delivery and multidisciplinary coordination.",
    iconKey: "heart-handshake",
    displayOrder: 20,
  },
  {
    name: "ACT, Crisis & Community Stabilization",
    slug: "act-crisis-community-stabilization",
    shortDescription: "High-acuity operations, crisis response, and stabilization systems.",
    description:
      "Advanced certifications for professionals working in intensive programs where rapid response, operational precision, and interdisciplinary coordination are critical.",
    iconKey: "shield-alert",
    displayOrder: 30,
  },
  {
    name: "Compliance, Documentation & Operations",
    slug: "compliance-documentation-operations",
    shortDescription: "Documentation integrity, Medicaid compliance, audit readiness, billing, and operations.",
    description:
      "Operational certifications that strengthen documentation defensibility, compliance governance, quality assurance, billing integrity, and sustainable service systems.",
    iconKey: "clipboard-check",
    displayOrder: 40,
  },
  {
    name: "Leadership, Executive & AI Governance",
    slug: "leadership-executive-ai-governance",
    shortDescription: "Strategic leadership, supervision, governance, entrepreneurship, and responsible AI oversight.",
    description:
      "Executive-level certifications for leaders responsible for workforce stability, compliance, growth, governance, and organizational sustainability.",
    iconKey: "landmark",
    displayOrder: 50,
  },
  {
    name: "Virginia Behavioral Health Specialties",
    slug: "virginia-behavioral-health-specialties",
    shortDescription: "Specialized operational roles supporting Virginia behavioral health organizations.",
    description:
      "Role-specific certifications addressing emerging workforce gaps in human resources, recruiting, intake, training, housing, vocational services, and documentation review.",
    iconKey: "map-pinned",
    displayOrder: 60,
  },
] as const;

const entries: SeedCertification[] = [
  {
    title: "QMHP Readiness Certification",
    slug: "qmhp-readiness-certification",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "Bachelor's degree and background check.",
    duration: "8 weeks",
    costCents: 195000,
    level: "Foundational",
    featured: true,
    description:
      "Prepares individuals pursuing QMHP-track roles with foundational competencies in behavioral health documentation, communication strategies, ethics, recovery-oriented service delivery, ISP implementation fundamentals, crisis awareness, Medicaid service understanding, and professional conduct within community-based behavioral health environments.",
  },
  {
    title: "PPMH Workforce Readiness Program",
    slug: "ppmh-workforce-readiness-program",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "High school diploma.",
    duration: "10 weeks",
    costCents: 225000,
    level: "Foundational",
    description:
      "Comprehensive workforce preparation for paraprofessionals entering mental health skill building and community stabilization environments, with emphasis on independent living support, service documentation, behavioral interventions, community engagement, crisis identification, and Virginia program expectations.",
  },
  {
    title: "Behavioral Health Foundations",
    slug: "behavioral-health-foundations",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "None confirmed.",
    duration: "4 weeks",
    costCents: 89500,
    level: "Entry",
    description:
      "Introduces mental health systems, human behavior, trauma-informed care, communication strategies, recovery principles, ethics, service structures, and the operational foundations of behavioral health care delivery.",
  },
  {
    title: "Peer Recovery Specialist Preparation",
    slug: "peer-recovery-specialist-preparation",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "Lived recovery experience preferred.",
    duration: "5 weeks",
    costCents: 97500,
    level: "Foundational",
    description:
      "Foundational peer support preparation centered on advocacy, recovery engagement, wellness support, lived-experience integration, motivational support strategies, and recovery-oriented service delivery practices.",
  },
  {
    title: "Trauma-Informed Support Certification",
    slug: "trauma-informed-support-certification",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "None confirmed.",
    duration: "4 weeks",
    costCents: 85000,
    level: "Foundational",
    description:
      "Examines how trauma affects emotional regulation, relationships, cognition, and behavior while preparing professionals to apply approaches that strengthen safety, trust, stabilization, and service engagement.",
  },
  {
    title: "Behavioral Health Documentation Essentials",
    slug: "behavioral-health-documentation-essentials",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "None confirmed.",
    duration: "3 weeks",
    costCents: 79500,
    level: "Foundational",
    description:
      "Introduces progress note writing, ISP alignment, service justification, compliance expectations, documentation defensibility, audit-risk reduction, and operational quality.",
  },
  {
    title: "Behavioral Health Technician Certification",
    slug: "behavioral-health-technician-certification",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "High school diploma or GED and background check.",
    duration: "8 weeks (64 hours)",
    costCents: 169500,
    level: "Intermediate",
    featured: true,
    description:
      "Prepares individuals to deliver essential direct support services across a variety of behavioral health settings through structured workforce-focused instruction and practical application.",
  },
  {
    title: "Behavioral Health Technician Assistant Certification",
    slug: "behavioral-health-technician-assistant-certification",
    categorySlug: "workforce-entry-foundations",
    prerequisites: "High school diploma or GED and background check.",
    duration: "6 weeks (48 hours)",
    costCents: 129500,
    level: "Entry",
    description:
      "Designed for individuals entering the behavioral health field who want to build foundational skills and provide essential support under supervision.",
  },
  {
    title: "ACT Team Specialist Certification",
    slug: "act-team-specialist-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "Behavioral health experience preferred.",
    duration: "8 weeks",
    costCents: 215000,
    level: "Advanced",
    featured: true,
    description:
      "Advanced operational training for Assertive Community Treatment programs covering acuity-driven service delivery, multidisciplinary coordination, crisis response systems, community-based interventions, psychiatric support integration, service intensity management, documentation defensibility, and ACT fidelity principles.",
  },
  {
    title: "Psychosocial Rehabilitation Certification",
    slug: "psychosocial-rehabilitation-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "High school diploma.",
    duration: "6 weeks",
    costCents: 165000,
    level: "Intermediate",
    description:
      "Prepares professionals to facilitate structured psychosocial rehabilitation services that support social functioning, emotional regulation, behavioral stability, independent living, recovery engagement, and community reintegration.",
  },
  {
    title: "Intensive In-Home Behavioral Support Certification",
    slug: "intensive-in-home-behavioral-support-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "Behavioral health or human services experience preferred.",
    duration: "5 weeks",
    costCents: 145000,
    level: "Intermediate",
    description:
      "Specialized training in family stabilization, youth-focused behavioral intervention, de-escalation, trauma-informed support, home-based service delivery, caregiver collaboration, and intensive community support practices.",
  },
  {
    title: "Case Management Certification",
    slug: "case-management-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "Associate degree or equivalent experience.",
    duration: "4 weeks",
    costCents: 129500,
    level: "Intermediate",
    description:
      "Develops competency in care coordination, referral management, discharge planning, benefits navigation, community resource integration, service linkage systems, treatment collaboration, and client advocacy.",
  },
  {
    title: "Crisis Intervention Certification",
    slug: "crisis-intervention-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "None confirmed.",
    duration: "2 weeks",
    costCents: 69500,
    level: "Foundational",
    description:
      "Covers behavioral stabilization, crisis communication, de-escalation, suicide-risk awareness, emergency response fundamentals, conflict reduction, and immediate intervention procedures for behavioral health settings.",
  },
  {
    title: "QMHP Supervisor Training Certification",
    slug: "qmhp-supervisor-training-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "Bachelor's degree and current QMHP credential or role eligibility.",
    duration: "8 weeks",
    costCents: 225000,
    level: "Advanced",
    description:
      "Equips QMHPs with supervision competencies in staff oversight, performance evaluation, clinical guidance, documentation review, legal and ethical considerations, risk management, and team development.",
  },
  {
    title: "Community Stabilization Services Certification",
    slug: "community-stabilization-services-certification",
    categorySlug: "clinical-support-community-services",
    prerequisites: "Behavioral health experience preferred.",
    duration: "5 weeks",
    costCents: 149500,
    level: "Intermediate",
    description:
      "Focused preparation in rapid stabilization workflows, crisis diversion, short-term intervention planning, discharge coordination, behavioral health triage support, transitional systems, and community-based crisis response operations.",
  },
  {
    title: "ACT Operations & Fidelity Certification",
    slug: "act-operations-fidelity-certification",
    categorySlug: "act-crisis-community-stabilization",
    prerequisites: "ACT team employment, supervisory track, or behavioral health experience preferred.",
    duration: "10 weeks",
    costCents: 245000,
    level: "Advanced",
    featured: true,
    description:
      "Advanced training focused on ACT structure, fidelity standards, acuity stratification, service intensity management, multidisciplinary coordination, psychiatric integration, scheduling architecture, documentation defensibility, crisis workflows, and long-term stabilization systems.",
  },
  {
    title: "Mobile Crisis Response Certification",
    slug: "mobile-crisis-response-certification",
    categorySlug: "act-crisis-community-stabilization",
    prerequisites: "Behavioral health experience preferred.",
    duration: "8 weeks",
    costCents: 215000,
    level: "Advanced",
    description:
      "Field-based crisis response training covering assessment, de-escalation, safety planning, rapid stabilization, law-enforcement coordination, community diversion, emergency behavioral response protocols, and mobile crisis operational standards.",
  },
  {
    title: "Crisis Receiving Center Operations Certification",
    slug: "crisis-receiving-center-operations-certification",
    categorySlug: "act-crisis-community-stabilization",
    prerequisites: "Supervisory, crisis services, or behavioral health operations background preferred.",
    duration: "6 weeks",
    costCents: 195000,
    level: "Advanced",
    description:
      "Prepares frontline staff and operational leaders to support crisis receiving and assessment environments through triage systems, intake stabilization workflows, staffing coordination, risk escalation, and emergency operations.",
  },
  {
    title: "Behavioral Health Emergency Response Certification",
    slug: "behavioral-health-emergency-response-certification",
    categorySlug: "act-crisis-community-stabilization",
    prerequisites: "None confirmed.",
    duration: "4 weeks",
    costCents: 119500,
    level: "Intermediate",
    description:
      "Introduces emergency behavioral health response principles, crisis communication, stabilization techniques, emergency coordination, safety procedures, escalation prevention, and foundational intervention strategies.",
  },
  {
    title: "BERT Certification",
    slug: "bert-certification",
    categorySlug: "act-crisis-community-stabilization",
    prerequisites: "Behavioral health experience required.",
    duration: "6 weeks",
    costCents: 125000,
    level: "Intermediate",
    description:
      "Equips professionals to support individuals experiencing behavioral escalation through de-escalation, safety planning, verbal intervention, clear communication, risk reduction, and post-incident support.",
  },
  {
    title: "High Acuity Case Coordination Certification",
    slug: "high-acuity-case-coordination-certification",
    categorySlug: "act-crisis-community-stabilization",
    prerequisites: "None confirmed.",
    duration: "4 weeks",
    costCents: 119500,
    level: "Advanced",
    description:
      "Focuses on complex cases involving severe mental illness, co-occurring disorders, housing instability, repeated hospitalization, high utilization, crisis recurrence, and intensive multidisciplinary coordination.",
  },
  {
    title: "Documentation & Medicaid Compliance Certification",
    slug: "documentation-medicaid-compliance-certification",
    categorySlug: "compliance-documentation-operations",
    prerequisites: "Current employment in a behavioral health setting preferred.",
    duration: "4 weeks (32 hours)",
    costCents: 125000,
    level: "Intermediate",
    featured: true,
    description:
      "Comprehensive training in documentation standards, Virginia Medicaid expectations, medical necessity, ISP alignment, audit-risk reduction, defensible progress notes, compliance workflows, reimbursement integrity, and operational accountability.",
  },
  {
    title: "Medicaid Appeals & Service Authorization Certification",
    slug: "medicaid-appeals-service-authorization-certification",
    categorySlug: "compliance-documentation-operations",
    prerequisites: "Documentation experience preferred.",
    duration: "5 weeks (40 hours)",
    costCents: 149500,
    level: "Advanced",
    description:
      "Prepares professionals to navigate service authorization systems, appeal denials, develop clinical justifications, communicate with managed care organizations, reduce authorization vulnerabilities, and support continuity of care.",
  },
  {
    title: "Compliance Officer Certification",
    slug: "compliance-officer-certification",
    categorySlug: "compliance-documentation-operations",
    prerequisites: "Supervisory experience preferred.",
    duration: "8 weeks (64 hours)",
    costCents: 245000,
    level: "Advanced",
    description:
      "Advanced compliance training covering internal monitoring, risk management, corrective action planning, audit preparation, regulatory oversight, workforce accountability, governance, and organizational protection frameworks.",
  },
  {
    title: "Quality Assurance & Audit Readiness",
    slug: "quality-assurance-audit-readiness",
    categorySlug: "compliance-documentation-operations",
    prerequisites: "Compliance or supervisory role preferred.",
    duration: "5 weeks (40 hours)",
    costCents: 149500,
    level: "Advanced",
    description:
      "Develops expertise in quality improvement, documentation auditing, performance monitoring, corrective action workflows, trend analysis, vulnerability identification, and audit readiness frameworks.",
  },
  {
    title: "Behavioral Health Operations Certification",
    slug: "behavioral-health-operations-certification",
    categorySlug: "compliance-documentation-operations",
    prerequisites: "Leadership or operations role preferred.",
    duration: "6 weeks",
    costCents: 185000,
    level: "Advanced",
    description:
      "Operational systems training in workflow management, staffing structures, scheduling architecture, service coordination, productivity oversight, interdisciplinary communication, stabilization, and sustainable infrastructure.",
  },
  {
    title: "Behavioral Health Billing Fundamentals",
    slug: "behavioral-health-billing-fundamentals",
    categorySlug: "compliance-documentation-operations",
    prerequisites: "None confirmed.",
    duration: "4 weeks (32 hours)",
    costCents: 125000,
    level: "Foundational",
    description:
      "Introduces claims workflows, documentation-to-billing alignment, denial prevention, revenue-cycle fundamentals, Medicaid billing structures, compliance safeguards, and reimbursement accuracy.",
  },
  {
    title: "Program Director Certification",
    slug: "program-director-certification",
    categorySlug: "leadership-executive-ai-governance",
    prerequisites: "Supervisory experience; bachelor's degree preferred.",
    duration: "12 weeks",
    costCents: 325000,
    level: "Executive",
    featured: true,
    description:
      "Advanced leadership training focused on workforce management, staffing systems, compliance oversight, program development, service coordination, quality improvement, documentation accountability, organizational communication, and behavioral health operations.",
  },
  {
    title: "Entrepreneurship in Behavioral Health",
    slug: "entrepreneurship-in-behavioral-health",
    categorySlug: "leadership-executive-ai-governance",
    prerequisites: "Management experience or business background.",
    duration: "10 weeks",
    costCents: 295000,
    level: "Executive",
    description:
      "Comprehensive business and operational training for professionals seeking to launch, structure, stabilize, and scale behavioral health organizations.",
  },
  {
    title: "Leadership & Supervision Certification",
    slug: "leadership-supervision-certification",
    categorySlug: "leadership-executive-ai-governance",
    prerequisites: "Current or emerging leadership role.",
    duration: "8 weeks",
    costCents: 199500,
    level: "Advanced",
    description:
      "Develops supervision competencies for workforce stabilization, conflict resolution, performance management, team development, operational oversight, and professional leadership practice.",
  },
  {
    title: "AI Governance in Behavioral Health",
    slug: "ai-governance-in-behavioral-health",
    categorySlug: "leadership-executive-ai-governance",
    prerequisites: "Leadership role or operational background.",
    duration: "6 weeks",
    costCents: 195000,
    level: "Executive",
    description:
      "Executive-level preparation focused on responsible artificial intelligence governance, organizational oversight, risk awareness, policy alignment, and accountable adoption within behavioral health systems.",
  },
  {
    title: "Behavioral Health Strategic Operations Certification",
    slug: "behavioral-health-strategic-operations-certification",
    categorySlug: "leadership-executive-ai-governance",
    prerequisites: "Leadership experience preferred.",
    duration: "6 weeks",
    costCents: 215000,
    level: "Executive",
    description:
      "Advanced systems training in organizational scaling, workflow architecture, governance structures, staffing models, compliance integration, service coordination, stabilization, strategic planning, and sustainability.",
  },
  {
    title: "Executive Compliance Leadership Certification",
    slug: "executive-compliance-leadership-certification",
    categorySlug: "leadership-executive-ai-governance",
    prerequisites: "Executive or senior management role.",
    duration: "5 weeks",
    costCents: 245000,
    level: "Executive",
    description:
      "Executive-level compliance and risk governance for leaders responsible for accountability, operational protection, audit defensibility, workforce oversight, corrective action, governance, and compliance infrastructure.",
  },
  {
    title: "Behavioral Health Human Resources Certification",
    slug: "behavioral-health-human-resources-certification",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Behavioral health, human resources, or management experience preferred.",
    duration: "5 weeks",
    costCents: 149500,
    level: "Intermediate",
    featured: true,
    description:
      "Specialized training in hiring systems, onboarding, credential management, retention, workforce compliance, employee documentation, staffing stabilization, corrective action, and operational workforce management.",
  },
  {
    title: "Behavioral Health Recruiting & Talent Acquisition",
    slug: "behavioral-health-recruiting-talent-acquisition",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Recruiting, human resources, or operational experience preferred.",
    duration: "4 weeks",
    costCents: 129500,
    level: "Intermediate",
    description:
      "Strengthens recruitment systems through sourcing strategy, workflows, candidate evaluation, onboarding coordination, retention-focused hiring, and workforce pipeline development specific to behavioral health.",
  },
  {
    title: "Clinical Documentation Reviewer Certification",
    slug: "clinical-documentation-reviewer-certification",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Behavioral health documentation experience preferred.",
    duration: "4 weeks",
    costCents: 135000,
    level: "Advanced",
    description:
      "Advanced review training in quality assurance monitoring, compliance auditing, correction workflows, ISP alignment, audit defensibility, clinical risk identification, and documentation oversight systems.",
  },
  {
    title: "Behavioral Health Intake & Assessment Coordination",
    slug: "behavioral-health-intake-assessment-coordination",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Behavioral health or administrative coordination experience preferred.",
    duration: "5 weeks",
    costCents: 149500,
    level: "Intermediate",
    description:
      "Prepares professionals to coordinate intake systems, referrals, screening, assessment scheduling, onboarding, service placement, authorization preparation, and operational intake management.",
  },
  {
    title: "Behavioral Health Workforce Trainer Certification",
    slug: "behavioral-health-workforce-trainer-certification",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Training, supervision, or workforce-development experience preferred.",
    duration: "6 weeks",
    costCents: 165000,
    level: "Advanced",
    description:
      "Designed for professionals responsible for staff education, covering training needs assessment, curriculum development, delivery methods, competency development, retention support, and workforce stabilization.",
  },
  {
    title: "Vocational Specialist Certification",
    slug: "vocational-specialist-certification",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Behavioral health, employment services, or human services experience preferred.",
    duration: "6 weeks",
    costCents: 159500,
    level: "Intermediate",
    description:
      "Prepares professionals to support employment readiness, job development, employer engagement, job coaching, benefits counseling, vocational assessment, and community integration.",
  },
  {
    title: "Housing Stability & Support Services Certification",
    slug: "housing-stability-support-services-certification",
    categorySlug: "virginia-behavioral-health-specialties",
    prerequisites: "Housing, case management, or behavioral health experience preferred.",
    duration: "Contact VIBHA",
    costCents: 0,
    level: "Intermediate",
    description:
      "Focused preparation in supportive housing systems, housing coordination, homelessness stabilization, community reintegration, benefits navigation, tenancy support, behavioral stabilization in housing environments, and long-term support practices.",
  },
];

function toTopics(description: string) {
  const normalized = description
    .replace(/^(Introduces|Prepares professionals to|Prepares individuals to|Advanced training focused on|Focused preparation in|Designed for professionals responsible for)\s+/i, "")
    .replace(/\.$/, "");
  return normalized
    .split(/,| through | covering | with emphasis on /i)
    .map(item => item.trim())
    .filter(item => item.length > 4)
    .slice(0, 6);
}

function summaryFrom(description: string) {
  if (description.length <= 650) return description;
  const boundary = description.slice(0, 647).lastIndexOf(" ");
  return `${description.slice(0, boundary > 500 ? boundary : 647).trim()}…`;
}

function seoDescriptionFrom(description: string) {
  if (description.length <= 158) return description;
  const boundary = description.slice(0, 157).lastIndexOf(" ");
  return `${description.slice(0, boundary > 120 ? boundary : 157).trim()}…`;
}

function objectivesFor(title: string) {
  return [
    `Explain the core principles and workforce expectations addressed in ${title}.`,
    "Apply structured practices to realistic behavioral health service and operational scenarios.",
    "Identify ethical, communication, documentation, safety, and compliance considerations relevant to the program scope.",
  ];
}

async function seed() {
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL is required to seed VIBHA content.");
  }

  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  const db = drizzle(connection);

  try {

  for (const category of categories) {
    await db
      .insert(certificationCategories)
      .values(category)
      .onDuplicateKeyUpdate({
        set: {
          name: category.name,
          shortDescription: category.shortDescription,
          description: category.description,
          iconKey: category.iconKey,
          displayOrder: category.displayOrder,
          isActive: true,
        },
      });
  }

  await db
    .insert(instructors)
    .values({
      name: "VIBHA Instructional Faculty",
      slug: "vibha-instructional-faculty",
      title: "Behavioral Health Workforce Education",
      biography:
        "Cohorts are facilitated by VIBHA instructional faculty with relevant behavioral health, workforce, operational, and compliance experience. Faculty assignments are confirmed for each scheduled cohort.",
      isActive: true,
    })
    .onDuplicateKeyUpdate({
      set: {
        title: "Behavioral Health Workforce Education",
        biography:
          "Cohorts are facilitated by VIBHA instructional faculty with relevant behavioral health, workforce, operational, and compliance experience. Faculty assignments are confirmed for each scheduled cohort.",
        isActive: true,
      },
    });

  const categoryRows = await db.select().from(certificationCategories);
  const categoryIds = new Map(categoryRows.map(category => [category.slug, category.id]));
  const facultyRows = await db
    .select()
    .from(instructors)
    .where(eq(instructors.slug, "vibha-instructional-faculty"))
    .limit(1);
  const faculty = facultyRows[0];

  for (const [index, entry] of entries.entries()) {
    const categoryId = categoryIds.get(entry.categorySlug);
    if (!categoryId) throw new Error(`Missing category ${entry.categorySlug}`);

    const costDisplay = entry.costCents > 0 ? `$${(entry.costCents / 100).toLocaleString("en-US")}` : "Contact VIBHA";
    const topics = toTopics(entry.description);
    await db
      .insert(certifications)
      .values({
        title: entry.title,
        slug: entry.slug,
        category: categoryId,
        description: entry.description,
        summary: summaryFrom(entry.description),
        valueStatement: "Workforce-focused education grounded in practical behavioral health service and operational expectations.",
        objectives: objectivesFor(entry.title),
        curriculumTopics: topics.length > 0 ? topics : ["Behavioral health workforce practice"],
        idealAudience: [
          entry.level === "Executive"
            ? "Behavioral health executives, owners, directors, and senior leaders"
            : "Professionals entering or advancing within behavioral health services",
        ],
        eligibilityRequirements: [entry.prerequisites],
        prerequisites: entry.prerequisites,
        format: "Virtual live",
        deliveryLocation: "Online; agency-based delivery available by arrangement",
        deliveryMethods: ["Virtual Live Instruction", "Hybrid Learning", "Evening Cohorts"],
        schedule: "Cohort-based scheduling. Contact VIBHA for upcoming dates and delivery availability.",
        duration: entry.duration,
        ceus: "0.00",
        cost: entry.costCents,
        costDisplay,
        level: entry.level,
        careerRelevance:
          "Designed to strengthen role readiness, operational confidence, and applied workforce capability within behavioral health environments.",
        inquiryType: "program-information",
        status: "published",
        isFeatured: entry.featured ?? false,
        displayOrder: (index + 1) * 10,
        seoTitle: `${entry.title} | VIBHA`,
        seoDescription: seoDescriptionFrom(entry.description),
        publishedAt: new Date(),
      })
      .onDuplicateKeyUpdate({
        set: {
          category: categoryId,
          description: entry.description,
          summary: summaryFrom(entry.description),
          prerequisites: entry.prerequisites,
          duration: entry.duration,
          cost: entry.costCents,
          costDisplay,
          level: entry.level,
          status: "published",
          isFeatured: entry.featured ?? false,
          displayOrder: (index + 1) * 10,
          seoTitle: `${entry.title} | VIBHA`,
          seoDescription: seoDescriptionFrom(entry.description),
        },
      });
  }

  if (faculty) {
    const certificationRows = await db.select({ id: certifications.id }).from(certifications);
    for (const certification of certificationRows) {
      await db
        .insert(certificationInstructors)
        .values({
          certificationId: certification.id,
          instructorId: faculty.id,
          displayOrder: 10,
        })
        .onDuplicateKeyUpdate({ set: { displayOrder: 10 } });
    }
  }

    const verification = await db
      .select({ id: certifications.id })
      .from(certifications)
      .where(eq(certifications.status, "published"));
    console.log(
      `Seeded ${categories.length} categories and verified ${verification.length} published certifications.`,
    );
  } finally {
    await connection.end();
  }
}

seed()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
