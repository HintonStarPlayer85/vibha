CREATE TABLE `certification_categories` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(160) NOT NULL,
	`slug` varchar(180) NOT NULL,
	`shortDescription` text NOT NULL,
	`description` text,
	`iconKey` varchar(64) NOT NULL DEFAULT 'graduation-cap',
	`displayOrder` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certification_categories_id` PRIMARY KEY(`id`),
	CONSTRAINT `category_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `certification_instructors` (
	`certificationId` int NOT NULL,
	`instructorId` int NOT NULL,
	`displayOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `certification_instructors_certificationId_instructorId_pk` PRIMARY KEY(`certificationId`,`instructorId`)
);
--> statement-breakpoint
CREATE TABLE `certifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(220) NOT NULL,
	`shortTitle` varchar(120),
	`slug` varchar(240) NOT NULL,
	`categoryId` int NOT NULL,
	`description` text NOT NULL,
	`summary` text NOT NULL,
	`valueStatement` text,
	`objectives` json NOT NULL,
	`curriculumTopics` json NOT NULL,
	`idealAudience` json NOT NULL,
	`eligibilityRequirements` json NOT NULL,
	`prerequisites` text NOT NULL,
	`format` varchar(80) NOT NULL,
	`deliveryMethods` json NOT NULL,
	`schedule` text NOT NULL,
	`duration` varchar(80) NOT NULL,
	`ceus` decimal(5,2) NOT NULL DEFAULT '0.00',
	`costCents` int NOT NULL,
	`costDisplay` varchar(80) NOT NULL,
	`level` varchar(60) NOT NULL,
	`careerRelevance` text,
	`enrollmentUrl` varchar(500),
	`inquiryType` varchar(80) NOT NULL DEFAULT 'program-information',
	`status` enum('draft','published','coming_soon','inactive','archived') NOT NULL DEFAULT 'draft',
	`isFeatured` boolean NOT NULL DEFAULT false,
	`displayOrder` int NOT NULL DEFAULT 0,
	`seoTitle` varchar(180),
	`seoDescription` varchar(320),
	`publishedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `certifications_id` PRIMARY KEY(`id`),
	CONSTRAINT `certification_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
CREATE TABLE `inquiries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inquiryType` enum('program','agency','general') NOT NULL DEFAULT 'general',
	`certificationId` int,
	`programRoute` varchar(180),
	`name` varchar(160) NOT NULL,
	`email` varchar(320) NOT NULL,
	`phone` varchar(40),
	`organization` varchar(220),
	`organizationType` varchar(120),
	`workforceSize` varchar(80),
	`priority` varchar(180),
	`timeline` varchar(120),
	`message` text NOT NULL,
	`consent` boolean NOT NULL DEFAULT false,
	`sourcePath` varchar(500),
	`status` enum('new','in_review','responded','closed') NOT NULL DEFAULT 'new',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `inquiries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `instructors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(180) NOT NULL,
	`slug` varchar(200) NOT NULL,
	`credentials` varchar(220),
	`title` varchar(220),
	`biography` text,
	`photoUrl` varchar(600),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `instructors_id` PRIMARY KEY(`id`),
	CONSTRAINT `instructor_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `certification_instructors` ADD CONSTRAINT `certification_instructors_certificationId_certifications_id_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certification_instructors` ADD CONSTRAINT `certification_instructors_instructorId_instructors_id_fk` FOREIGN KEY (`instructorId`) REFERENCES `instructors`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certifications` ADD CONSTRAINT `certifications_categoryId_certification_categories_id_fk` FOREIGN KEY (`categoryId`) REFERENCES `certification_categories`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `inquiries` ADD CONSTRAINT `inquiries_certificationId_certifications_id_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `category_active_order_idx` ON `certification_categories` (`isActive`,`displayOrder`);--> statement-breakpoint
CREATE INDEX `certification_instructor_lookup_idx` ON `certification_instructors` (`instructorId`);--> statement-breakpoint
CREATE INDEX `certification_status_category_idx` ON `certifications` (`status`,`categoryId`);--> statement-breakpoint
CREATE INDEX `certification_featured_order_idx` ON `certifications` (`status`,`isFeatured`,`displayOrder`);--> statement-breakpoint
CREATE INDEX `certification_cost_idx` ON `certifications` (`costCents`);--> statement-breakpoint
CREATE INDEX `certification_ceus_idx` ON `certifications` (`ceus`);--> statement-breakpoint
CREATE INDEX `inquiry_status_created_idx` ON `inquiries` (`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `inquiry_certification_idx` ON `inquiries` (`certificationId`);--> statement-breakpoint
CREATE INDEX `inquiry_email_idx` ON `inquiries` (`email`);