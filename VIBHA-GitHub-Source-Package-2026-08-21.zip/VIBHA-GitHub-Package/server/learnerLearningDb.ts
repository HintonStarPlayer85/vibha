import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import {
  certifications,
  onlineCourseEnrollments,
  onlineCourseLessons,
  onlineCourseModules,
  onlineCourses,
  onlineLessonProgress,
  onlineModuleQuizAttempts,
  onlineModuleQuizQuestions,
  onlineModuleQuizzes,
} from "../drizzle/schema";
import { getDb } from "./db";

export const learnerLearningErrors = {
  courseNotFound: "LEARNER_COURSE_NOT_FOUND",
  enrollmentNotFound: "LEARNER_ENROLLMENT_NOT_FOUND",
  lessonNotFound: "LEARNER_LESSON_NOT_FOUND",
  lessonOutsideCourse: "LEARNER_LESSON_OUTSIDE_COURSE",
  quizNotFound: "LEARNER_QUIZ_NOT_FOUND",
  quizNotReady: "LEARNER_QUIZ_NOT_READY",
  answersInvalid: "LEARNER_QUIZ_ANSWERS_INVALID",
  moduleNotFound: "LEARNER_MODULE_NOT_FOUND",
} as const;

async function requireDb() {
  const db = await getDb();
  if (!db) throw new Error("Database is not available.");
  return db;
}

async function findPublishedCourseBySlug(slug: string) {
  const db = await requireDb();
  return (await db.select({ id: onlineCourses.id, certificationId: onlineCourses.certificationId, courseTitle: certifications.title, slug: certifications.slug, summary: certifications.summary, duration: certifications.duration, ceus: certifications.ceus, aiInstructorName: onlineCourses.aiInstructorName, aiInstructorWelcome: onlineCourses.aiInstructorWelcome, aiInstructorScope: onlineCourses.aiInstructorScope }).from(onlineCourses).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(and(eq(certifications.slug, slug), eq(onlineCourses.status, "published"), eq(certifications.status, "published"))).limit(1))[0] ?? null;
}

async function getEnrollment(courseId: number, userId: number) {
  const db = await requireDb();
  return (await db.select().from(onlineCourseEnrollments).where(and(eq(onlineCourseEnrollments.courseId, courseId), eq(onlineCourseEnrollments.userId, userId))).limit(1))[0] ?? null;
}

export async function enrollLearnerInCourse(courseSlug: string, userId: number) {
  const db = await requireDb();
  const course = await findPublishedCourseBySlug(courseSlug);
  if (!course) throw new Error(learnerLearningErrors.courseNotFound);
  const existing = await getEnrollment(course.id, userId);
  if (existing) {
    if (existing.status === "withdrawn") await db.update(onlineCourseEnrollments).set({ status: "enrolled", completedAt: null, lastAccessedAt: new Date() }).where(eq(onlineCourseEnrollments.id, existing.id));
    return getLearnerCourseBySlug(courseSlug, userId);
  }
  await db.insert(onlineCourseEnrollments).values({ courseId: course.id, userId });
  return getLearnerCourseBySlug(courseSlug, userId);
}

async function getModuleQuizState(moduleIds: number[], enrollmentId: number, learnerView: boolean) {
  const db = await requireDb();
  if (!moduleIds.length) return new Map<number, any>();
  const quizzes = await db.select().from(onlineModuleQuizzes).where(inArray(onlineModuleQuizzes.moduleId, moduleIds)).orderBy(asc(onlineModuleQuizzes.moduleId));
  const quizIds = quizzes.map(quiz => quiz.id);
  const [questions, attempts] = await Promise.all([
    quizIds.length ? db.select().from(onlineModuleQuizQuestions).where(learnerView ? and(inArray(onlineModuleQuizQuestions.quizId, quizIds), eq(onlineModuleQuizQuestions.isPublished, true)) : inArray(onlineModuleQuizQuestions.quizId, quizIds)).orderBy(asc(onlineModuleQuizQuestions.quizId), asc(onlineModuleQuizQuestions.position)) : [],
    quizIds.length && enrollmentId ? db.select().from(onlineModuleQuizAttempts).where(and(inArray(onlineModuleQuizAttempts.quizId, quizIds), eq(onlineModuleQuizAttempts.enrollmentId, enrollmentId))).orderBy(desc(onlineModuleQuizAttempts.createdAt)) : [],
  ]);
  return new Map(quizzes.map(quiz => [quiz.moduleId, {
    ...quiz,
    questions: questions.filter(question => question.quizId === quiz.id).map(question => learnerView ? ({ id: question.id, position: question.position, prompt: question.prompt, options: question.options }) : question),
    latestAttempt: attempts.find(attempt => attempt.quizId === quiz.id) ?? null,
    attemptCount: attempts.filter(attempt => attempt.quizId === quiz.id).length,
  }]));
}

export async function getLearnerCourseBySlug(courseSlug: string, userId: number) {
  const db = await requireDb();
  const course = await findPublishedCourseBySlug(courseSlug);
  if (!course) throw new Error(learnerLearningErrors.courseNotFound);
  const enrollment = await getEnrollment(course.id, userId);
  if (!enrollment || enrollment.status === "withdrawn") throw new Error(learnerLearningErrors.enrollmentNotFound);
  const modules = await db.select().from(onlineCourseModules).where(and(eq(onlineCourseModules.courseId, course.id), eq(onlineCourseModules.isPublished, true))).orderBy(asc(onlineCourseModules.position));
  const moduleIds = modules.map(module => module.id);
  const lessons = moduleIds.length ? await db.select().from(onlineCourseLessons).where(and(inArray(onlineCourseLessons.moduleId, moduleIds), eq(onlineCourseLessons.isPublished, true))).orderBy(asc(onlineCourseLessons.moduleId), asc(onlineCourseLessons.position)) : [];
  const [progressRows, quizByModule] = await Promise.all([
    db.select().from(onlineLessonProgress).where(eq(onlineLessonProgress.enrollmentId, enrollment.id)),
    getModuleQuizState(moduleIds, enrollment.id, true),
  ]);
  const progressByLesson = new Map(progressRows.map(progress => [progress.lessonId, progress]));
  const shapedModules = modules.map(module => {
    const moduleLessons = lessons.filter(lesson => lesson.moduleId === module.id).map(lesson => ({ ...lesson, progress: progressByLesson.get(lesson.id) ?? null }));
    const quiz = quizByModule.get(module.id) ?? null;
    const lessonsComplete = moduleLessons.length > 0 && moduleLessons.every(lesson => lesson.progress?.completed);
    const quizComplete = !quiz || !quiz.isPublished || Boolean(quiz.latestAttempt?.passed);
    return { ...module, lessons: moduleLessons, quiz, isComplete: lessonsComplete && quizComplete, completedLessonCount: moduleLessons.filter(lesson => lesson.progress?.completed).length };
  });
  const allLessons = shapedModules.flatMap(module => module.lessons);
  const completedLessonCount = allLessons.filter(lesson => lesson.progress?.completed).length;
  const firstIncomplete = allLessons.find(lesson => !lesson.progress?.completed);
  const recent = allLessons.filter(lesson => lesson.progress).sort((a, b) => Number(b.progress?.lastOpenedAt ?? 0) - Number(a.progress?.lastOpenedAt ?? 0))[0];
  const resumeLesson = recent ?? firstIncomplete ?? allLessons[0] ?? null;
  return {
    id: course.id,
    certificationTitle: course.courseTitle,
    certificationSlug: course.slug,
    certificationSummary: course.summary,
    certificationDuration: course.duration,
    certificationCeus: Number(course.ceus),
    aiInstructorName: course.aiInstructorName,
    aiInstructorWelcome: course.aiInstructorWelcome,
    aiInstructorScope: course.aiInstructorScope,
    enrollment,
    modules: shapedModules,
    totalLessonCount: allLessons.length,
    completedLessonCount,
    completedModuleCount: shapedModules.filter(module => module.isComplete).length,
    resumeLesson,
    progressPercent: allLessons.length ? Math.round((completedLessonCount / allLessons.length) * 100) : 0,
  };
}

export async function listLearnerDashboard(userId: number) {
  const db = await requireDb();
  const enrollments = await db.select({ enrollment: onlineCourseEnrollments, slug: certifications.slug }).from(onlineCourseEnrollments).innerJoin(onlineCourses, eq(onlineCourseEnrollments.courseId, onlineCourses.id)).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(and(eq(onlineCourseEnrollments.userId, userId), inArray(onlineCourseEnrollments.status, ["enrolled", "completed"]))).orderBy(desc(onlineCourseEnrollments.lastAccessedAt));
  const enrolled = await Promise.all(enrollments.map(async row => getLearnerCourseBySlug(row.slug, userId)));
  const available = await db.select({ title: certifications.title, slug: certifications.slug, summary: certifications.summary, duration: certifications.duration, ceus: certifications.ceus }).from(onlineCourses).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(and(eq(onlineCourses.status, "published"), eq(certifications.status, "published"))).orderBy(asc(certifications.title));
  const enrolledSlugs = new Set(enrolled.map(course => course.certificationSlug));
  return { enrolled, available: available.filter(course => !enrolledSlugs.has(course.slug)).map(course => ({ ...course, ceus: Number(course.ceus) })) };
}

async function recomputeCourseCompletion(enrollmentId: number, courseId: number) {
  const db = await requireDb();
  const course = await db.select({ slug: certifications.slug }).from(onlineCourses).innerJoin(certifications, eq(onlineCourses.certificationId, certifications.id)).where(eq(onlineCourses.id, courseId)).limit(1);
  if (!course[0]) return;
  const enrollment = (await db.select({ userId: onlineCourseEnrollments.userId }).from(onlineCourseEnrollments).where(eq(onlineCourseEnrollments.id, enrollmentId)).limit(1))[0];
  if (!enrollment) return;
  const learnerCourse = await getLearnerCourseBySlug(course[0].slug, enrollment.userId);
  const complete = learnerCourse.modules.length > 0 && learnerCourse.modules.every(module => module.isComplete);
  await db.update(onlineCourseEnrollments).set({ status: complete ? "completed" : "enrolled", completedAt: complete ? new Date() : null, lastAccessedAt: new Date() }).where(eq(onlineCourseEnrollments.id, enrollmentId));
}

export async function updateLearnerLessonProgress(courseSlug: string, lessonId: number, completed: boolean, userId: number) {
  const db = await requireDb();
  const course = await findPublishedCourseBySlug(courseSlug);
  if (!course) throw new Error(learnerLearningErrors.courseNotFound);
  const enrollment = await getEnrollment(course.id, userId);
  if (!enrollment || enrollment.status === "withdrawn") throw new Error(learnerLearningErrors.enrollmentNotFound);
  const lesson = (await db.select({ id: onlineCourseLessons.id }).from(onlineCourseLessons).innerJoin(onlineCourseModules, eq(onlineCourseLessons.moduleId, onlineCourseModules.id)).where(and(eq(onlineCourseLessons.id, lessonId), eq(onlineCourseModules.courseId, course.id), eq(onlineCourseLessons.isPublished, true), eq(onlineCourseModules.isPublished, true))).limit(1))[0];
  if (!lesson) throw new Error(learnerLearningErrors.lessonOutsideCourse);
  await db.insert(onlineLessonProgress).values({ enrollmentId: enrollment.id, lessonId, completed, firstCompletedAt: completed ? new Date() : null, lastOpenedAt: new Date() }).onDuplicateKeyUpdate({ set: { completed, firstCompletedAt: completed ? sql`COALESCE(${onlineLessonProgress.firstCompletedAt}, NOW())` : null, lastOpenedAt: new Date() } });
  await db.update(onlineCourseEnrollments).set({ lastAccessedAt: new Date() }).where(eq(onlineCourseEnrollments.id, enrollment.id));
  await recomputeCourseCompletion(enrollment.id, course.id);
  return getLearnerCourseBySlug(courseSlug, userId);
}

export async function submitLearnerModuleQuiz(input: { courseSlug: string; moduleId: number; answers: Array<{ questionId: number; selectedOptionIndex: number }> }, userId: number) {
  const db = await requireDb();
  const course = await findPublishedCourseBySlug(input.courseSlug);
  if (!course) throw new Error(learnerLearningErrors.courseNotFound);
  const enrollment = await getEnrollment(course.id, userId);
  if (!enrollment || enrollment.status === "withdrawn") throw new Error(learnerLearningErrors.enrollmentNotFound);
  const quiz = (await db.select().from(onlineModuleQuizzes).innerJoin(onlineCourseModules, eq(onlineModuleQuizzes.moduleId, onlineCourseModules.id)).where(and(eq(onlineModuleQuizzes.moduleId, input.moduleId), eq(onlineCourseModules.courseId, course.id), eq(onlineModuleQuizzes.isPublished, true), eq(onlineCourseModules.isPublished, true))).limit(1))[0];
  if (!quiz) throw new Error(learnerLearningErrors.quizNotFound);
  const questions = await db.select().from(onlineModuleQuizQuestions).where(and(eq(onlineModuleQuizQuestions.quizId, quiz.online_module_quizzes.id), eq(onlineModuleQuizQuestions.isPublished, true))).orderBy(asc(onlineModuleQuizQuestions.position));
  if (!questions.length) throw new Error(learnerLearningErrors.quizNotReady);
  const answerMap = new Map(input.answers.map(answer => [answer.questionId, answer.selectedOptionIndex]));
  if (answerMap.size !== questions.length || questions.some(question => answerMap.get(question.id) === undefined)) throw new Error(learnerLearningErrors.answersInvalid);
  const feedback = questions.map(question => ({ questionId: question.id, selectedOptionIndex: answerMap.get(question.id)!, correctOptionIndex: question.correctOptionIndex, correct: answerMap.get(question.id) === question.correctOptionIndex, explanation: question.explanation }));
  const correctCount = feedback.filter(item => item.correct).length;
  const score = Math.round((correctCount / questions.length) * 100);
  const passed = score >= quiz.online_module_quizzes.passingScore;
  await db.insert(onlineModuleQuizAttempts).values({ enrollmentId: enrollment.id, quizId: quiz.online_module_quizzes.id, score, passed, answers: input.answers });
  await db.update(onlineCourseEnrollments).set({ lastAccessedAt: new Date() }).where(eq(onlineCourseEnrollments.id, enrollment.id));
  await recomputeCourseCompletion(enrollment.id, course.id);
  return { score, passed, passingScore: quiz.online_module_quizzes.passingScore, feedback };
}

export async function upsertModuleQuiz(input: { moduleId: number; title: string; passingScore: number; isPublished: boolean }) {
  const db = await requireDb();
  const module = (await db.select().from(onlineCourseModules).where(eq(onlineCourseModules.id, input.moduleId)).limit(1))[0];
  if (!module) throw new Error(learnerLearningErrors.moduleNotFound);
  const existing = (await db.select().from(onlineModuleQuizzes).where(eq(onlineModuleQuizzes.moduleId, input.moduleId)).limit(1))[0];
  if (existing) {
    await db.update(onlineModuleQuizzes).set({ title: input.title, passingScore: input.passingScore, isPublished: input.isPublished }).where(eq(onlineModuleQuizzes.id, existing.id));
    return (await db.select().from(onlineModuleQuizzes).where(eq(onlineModuleQuizzes.id, existing.id)).limit(1))[0]!;
  }
  const result = await db.insert(onlineModuleQuizzes).values(input);
  return (await db.select().from(onlineModuleQuizzes).where(eq(onlineModuleQuizzes.id, Number(result[0].insertId))).limit(1))[0]!;
}

export async function createModuleQuizQuestion(input: { quizId: number; position: number; prompt: string; options: string[]; correctOptionIndex: number; explanation: string; isPublished: boolean }) {
  const db = await requireDb();
  const result = await db.insert(onlineModuleQuizQuestions).values(input);
  return (await db.select().from(onlineModuleQuizQuestions).where(eq(onlineModuleQuizQuestions.id, Number(result[0].insertId))).limit(1))[0]!;
}

export async function updateModuleQuizQuestion(input: { id: number; quizId: number; position: number; prompt: string; options: string[]; correctOptionIndex: number; explanation: string; isPublished: boolean }) {
  const db = await requireDb();
  const question = (await db.select({ id: onlineModuleQuizQuestions.id }).from(onlineModuleQuizQuestions).where(and(eq(onlineModuleQuizQuestions.id, input.id), eq(onlineModuleQuizQuestions.quizId, input.quizId))).limit(1))[0];
  if (!question) throw new Error(learnerLearningErrors.quizNotFound);
  await db.update(onlineModuleQuizQuestions).set({ position: input.position, prompt: input.prompt, options: input.options, correctOptionIndex: input.correctOptionIndex, explanation: input.explanation, isPublished: input.isPublished }).where(eq(onlineModuleQuizQuestions.id, input.id));
  return (await db.select().from(onlineModuleQuizQuestions).where(eq(onlineModuleQuizQuestions.id, input.id)).limit(1))[0]!;
}
