import { InquiryForm } from "@/components/contact/InquiryForm";
import { PageHero } from "@/components/public/PageHero";
import { PublicLayout } from "@/components/public/PublicLayout";
import { usePageMeta } from "@/hooks/usePageMeta";
import { useSiteContent } from "@/hooks/useSiteContent";
import { Building2, Clock3, Mail, MapPin, Phone, UserRound } from "lucide-react";

export default function Contact() {
  const { content } = useSiteContent();
  usePageMeta("Contact VIBHA", "Contact VIBHA for certification information, agency workforce training, and institutional partnership inquiries.");
  return (
    <PublicLayout>
      <PageHero eyebrow="Contact" title={content["contact.hero.title"]} description={content["contact.hero.description"]} breadcrumbs={[{ label: "Contact" }]} />
      <section className="bg-[#f6f8fb] py-20 sm:py-24"><div className="container grid gap-10 lg:grid-cols-[0.7fr_1.3fr] lg:items-start"><div><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">VIBHA inquiry center</p><h2 className="mt-4 text-4xl font-bold text-[#071f49]">{content["contact.inquiry.title"]}</h2><p className="mt-5 text-lg leading-8 text-slate-600">{content["contact.inquiry.description"]}</p><div className="mt-8 space-y-4">{[{ icon: Phone, title: "Phone", copy: "804-293-3341", href: "tel:+18042933341" }, { icon: MapPin, title: "Location", copy: "Richmond, Virginia" }, { icon: Mail, title: "Inquiry", copy: "Use the secure form on this page" }, { icon: Clock3, title: "Response process", copy: "Inquiries are reviewed and routed by program type" }].map(item => <div key={item.title} className="flex gap-4 rounded-xl border border-slate-200 bg-white p-5"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-[#071f49] text-white"><item.icon className="h-5 w-5" /></div><div><h3 className="font-sans text-sm font-bold uppercase tracking-wide text-[#071f49]">{item.title}</h3>{item.href ? <a href={item.href} className="mt-1 block text-sm text-slate-600 hover:underline">{item.copy}</a> : <p className="mt-1 text-sm text-slate-600">{item.copy}</p>}</div></div>)}</div><div className="mt-6 grid gap-4 sm:grid-cols-2"><div className="rounded-xl bg-[#071f49] p-5 text-white"><UserRound className="h-5 w-5 text-[#ff9a52]" /><h3 className="mt-3 font-sans font-bold">Individual professionals</h3><p className="mt-2 text-sm leading-6 text-slate-300">{content["contact.professionals.description"]}</p></div><div className="rounded-xl bg-[#071f49] p-5 text-white"><Building2 className="h-5 w-5 text-[#ff9a52]" /><h3 className="mt-3 font-sans font-bold">Organizations</h3><p className="mt-2 text-sm leading-6 text-slate-300">{content["contact.organizations.description"]}</p></div></div></div><InquiryForm /></div></section>
    </PublicLayout>
  );
}
