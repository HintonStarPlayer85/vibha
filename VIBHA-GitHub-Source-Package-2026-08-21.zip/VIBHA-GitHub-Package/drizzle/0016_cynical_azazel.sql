CREATE TABLE `certificate_preview_acknowledgements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cohortStudentId` int NOT NULL,
	`certificationId` int NOT NULL,
	`acknowledgementToken` varchar(64) NOT NULL,
	`previewFingerprint` varchar(64) NOT NULL,
	`previewedByUserId` int NOT NULL,
	`acknowledgedAt` timestamp NOT NULL DEFAULT (now()),
	`expiresAt` timestamp NOT NULL,
	`usedAt` timestamp,
	`usedForCertificateId` int,
	CONSTRAINT `certificate_preview_acknowledgements_id` PRIMARY KEY(`id`),
	CONSTRAINT `certificate_preview_ack_token_unique` UNIQUE(`acknowledgementToken`)
);
--> statement-breakpoint
ALTER TABLE `certificate_program_profiles` ADD `executiveSignatureCrop` json;--> statement-breakpoint
ALTER TABLE `certificate_preview_acknowledgements` ADD CONSTRAINT `cert_preview_ack_student_fk` FOREIGN KEY (`cohortStudentId`) REFERENCES `cohort_students`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_preview_acknowledgements` ADD CONSTRAINT `cert_preview_ack_cert_fk` FOREIGN KEY (`certificationId`) REFERENCES `certifications`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_preview_acknowledgements` ADD CONSTRAINT `cert_preview_ack_actor_fk` FOREIGN KEY (`previewedByUserId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `certificate_preview_acknowledgements` ADD CONSTRAINT `cert_preview_ack_issued_fk` FOREIGN KEY (`usedForCertificateId`) REFERENCES `issued_certificates`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `certificate_preview_ack_candidate_actor_idx` ON `certificate_preview_acknowledgements` (`cohortStudentId`,`previewedByUserId`,`expiresAt`);--> statement-breakpoint
CREATE INDEX `certificate_preview_ack_issued_idx` ON `certificate_preview_acknowledgements` (`usedForCertificateId`);
