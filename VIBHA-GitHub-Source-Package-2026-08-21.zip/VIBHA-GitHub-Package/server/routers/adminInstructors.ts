import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { instructorInputSchema, instructorListQuerySchema } from "../../shared/administration";
import {
  createInstructor,
  getInstructorById,
  getInstructorOptions,
  instructorErrors,
  listInstructors,
  clearInstructorSignature,
  setInstructorStatus,
  setInstructorSignature,
  updateInstructor,
} from "../instructorDb";
import { storagePut } from "../storage";
import { adminProcedure, router } from "../_core/trpc";

function translateInstructorError(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === instructorErrors.slugConflict) throw new TRPCError({ code: "CONFLICT", message: "This instructor URL slug is already in use." });
  if (message === instructorErrors.emailConflict) throw new TRPCError({ code: "CONFLICT", message: "This instructor email is already registered." });
  if (message === instructorErrors.notFound) throw new TRPCError({ code: "NOT_FOUND", message: "Instructor not found." });
  if (message === instructorErrors.signatureMissing) throw new TRPCError({ code: "BAD_REQUEST", message: "This instructor does not have a signature image to remove." });
  throw error;
}

export const adminInstructorsRouter = router({
  list: adminProcedure.input(instructorListQuerySchema).query(({ input }) => listInstructors(input)),
  getById: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
    const instructor = await getInstructorById(input.id);
    if (!instructor) throw new TRPCError({ code: "NOT_FOUND", message: "Instructor not found." });
    return instructor;
  }),
  options: adminProcedure.query(() => getInstructorOptions()),
  create: adminProcedure.input(instructorInputSchema).mutation(async ({ input, ctx }) => {
    try {
      return await createInstructor(input, ctx.user.id);
    } catch (error) {
      translateInstructorError(error);
    }
  }),
  update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: instructorInputSchema })).mutation(async ({ input, ctx }) => {
    try {
      return await updateInstructor(input.id, input.data, ctx.user.id);
    } catch (error) {
      translateInstructorError(error);
    }
  }),
  setStatus: adminProcedure.input(z.object({ id: z.number().int().positive(), isActive: z.boolean() })).mutation(async ({ input, ctx }) => {
    try {
      return await setInstructorStatus(input.id, input.isActive, ctx.user.id);
    } catch (error) {
      translateInstructorError(error);
    }
  }),
  uploadSignature: adminProcedure.input(z.object({ instructorId: z.number().int().positive(), fileName: z.string().trim().min(1).max(320), mimeType: z.enum(["image/png", "image/jpeg"]), dataBase64: z.string().min(1).max(3_000_000), crop: z.object({ x: z.number().min(0).max(1), y: z.number().min(0).max(1), size: z.number().positive().max(1), zoom: z.number().min(1).max(4) }).nullable().optional() })).mutation(async ({ input, ctx }) => {
    try {
      const bytes = Buffer.from(input.dataBase64, "base64");
      if (!bytes.length || bytes.length > 2 * 1024 * 1024) throw new TRPCError({ code: "BAD_REQUEST", message: "Signature images must be PNG or JPEG files no larger than 2 MB." });
      const isPng = bytes.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
      const isJpeg = bytes[0] === 0xff && bytes[1] === 0xd8;
      if ((input.mimeType === "image/png" && !isPng) || (input.mimeType === "image/jpeg" && !isJpeg)) throw new TRPCError({ code: "BAD_REQUEST", message: "The selected file does not match its declared image type." });
      const extension = input.mimeType === "image/png" ? "png" : "jpg";
      const stored = await storagePut(`instructor-signatures/${input.instructorId}/signature.${extension}`, bytes, input.mimeType);
      return await setInstructorSignature({ instructorId: input.instructorId, storageKey: stored.key, url: stored.url, fileName: input.fileName.replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 320), mimeType: input.mimeType, crop: input.crop ?? null, actorUserId: ctx.user.id });
    } catch (error) { translateInstructorError(error); }
  }),
  removeSignature: adminProcedure.input(z.object({ instructorId: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
    try { return await clearInstructorSignature(input.instructorId, ctx.user.id); } catch (error) { translateInstructorError(error); }
  }),
});
