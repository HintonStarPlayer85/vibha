import { TRPCError } from "@trpc/server";
import { randomBytes } from "node:crypto";
import { z } from "zod";
import {
  cohortInputSchema,
  cohortListQuerySchema,
  cohortResourceLinkInputSchema,
  cohortResourceStatusSchema,
  cohortResourceSettingsSchema,
  cohortResourceUploadInputSchema,
  cohortStudentInputSchema,
  cohortStudentUpdateSchema,
} from "../../shared/administration";
import {
  addCohortStudent,
  cohortErrors,
  createCohort,
  createCohortResource,
  createCohortResourceLink,
  getCohortById,
  getCohortOptions,
  listCohorts,
  removeCohortStudent,
  setCohortResourceStatus,
  updateCohort,
  updateCohortStudent,
  updateCohortResourceSettings,
} from "../cohortDb";
import { storagePut } from "../storage";
import { adminProcedure, router } from "../_core/trpc";

function translateCohortError(error: unknown): never {
  const message = error instanceof Error ? error.message : "";
  if (message === cohortErrors.slugConflict) throw new TRPCError({ code: "CONFLICT", message: "This cohort URL slug is already in use." });
  if (message === cohortErrors.notFound) throw new TRPCError({ code: "NOT_FOUND", message: "Cohort not found." });
  if (message === cohortErrors.studentNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "Student roster entry not found." });
  if (message === cohortErrors.duplicateStudent) throw new TRPCError({ code: "CONFLICT", message: "This email address is already registered in the cohort." });
  if (message === cohortErrors.resourceNotFound) throw new TRPCError({ code: "NOT_FOUND", message: "Cohort resource not found." });
  throw error;
}

function safeFileName(value: string) {
  return value.normalize("NFKD").replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/-+/g, "-").slice(0, 180) || "resource";
}

export const adminCohortsRouter = router({
  list: adminProcedure.input(cohortListQuerySchema).query(({ input }) => listCohorts(input)),
  getById: adminProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
    const cohort = await getCohortById(input.id);
    if (!cohort) throw new TRPCError({ code: "NOT_FOUND", message: "Cohort not found." });
    return cohort;
  }),
  options: adminProcedure.query(() => getCohortOptions()),
  create: adminProcedure.input(cohortInputSchema).mutation(async ({ input, ctx }) => {
    try { return await createCohort(input, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  update: adminProcedure.input(z.object({ id: z.number().int().positive(), data: cohortInputSchema })).mutation(async ({ input, ctx }) => {
    try { return await updateCohort(input.id, input.data, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  addStudent: adminProcedure.input(z.object({ cohortId: z.number().int().positive(), data: cohortStudentInputSchema })).mutation(async ({ input, ctx }) => {
    try { return await addCohortStudent(input.cohortId, input.data, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  updateStudent: adminProcedure.input(cohortStudentUpdateSchema).mutation(async ({ input, ctx }) => {
    try { const { id, ...data } = input; return await updateCohortStudent(id, data, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  removeStudent: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input, ctx }) => {
    try { return await removeCohortStudent(input.id, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  addResourceLink: adminProcedure.input(cohortResourceLinkInputSchema).mutation(async ({ input, ctx }) => {
    try { return await createCohortResourceLink(input, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  uploadResource: adminProcedure.input(cohortResourceUploadInputSchema).mutation(async ({ input, ctx }) => {
    const bytes = Buffer.from(input.dataBase64, "base64");
    if (bytes.length === 0 || bytes.length > 10 * 1024 * 1024) {
      throw new TRPCError({ code: "PAYLOAD_TOO_LARGE", message: "Cohort resources must be 10 MB or smaller." });
    }
    const fileName = safeFileName(input.fileName);
    const objectKey = `cohorts/${input.cohortId}/${Date.now()}-${randomBytes(8).toString("hex")}-${fileName}`;
    const stored = await storagePut(objectKey, bytes, input.mimeType);
    try {
      return await createCohortResource({
        cohortId: input.cohortId,
        title: input.title,
        description: input.description,
        resourceType: input.resourceType,
        audience: input.audience,
        sourceType: "file",
        url: stored.url,
        storageKey: stored.key,
        fileName,
        mimeType: input.mimeType,
        fileSize: bytes.length,
        displayOrder: input.displayOrder,
        actorUserId: ctx.user.id,
      });
    } catch (error) {
      translateCohortError(error);
    }
  }),
  setResourceStatus: adminProcedure.input(cohortResourceStatusSchema).mutation(async ({ input, ctx }) => {
    try { return await setCohortResourceStatus(input.id, input.isActive, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
  updateResourceSettings: adminProcedure.input(cohortResourceSettingsSchema).mutation(async ({ input, ctx }) => {
    try { return await updateCohortResourceSettings(input.id, input.audience, input.displayOrder, ctx.user.id); } catch (error) { translateCohortError(error); }
  }),
});
