import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ArrowRight, MapPin, Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { VibhaBrand } from "./VibhaBrand";

export const primaryNavigation = [
  { label: "Home", href: "/" },
  { label: "Certifications", href: "/certifications" },
  { label: "Programs", href: "/programs" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
] as const;

function isActive(location: string, href: string) {
  if (href === "/") return location === "/";
  return location === href || location.startsWith(`${href}/`);
}

export function SiteHeader() {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);

  useEffect(() => setOpen(false), [location]);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#071f49] text-white shadow-[0_6px_24px_rgba(4,22,52,0.18)]">
      <a
        href="#main-content"
        className="sr-only z-[100] rounded-md bg-white px-4 py-3 font-semibold text-[#071f49] focus:not-sr-only focus:fixed focus:left-4 focus:top-4"
      >
        Skip to main content
      </a>
      <div className="hidden border-b border-white/10 bg-[#041634] lg:block">
        <div className="container flex h-9 items-center justify-between text-xs font-medium tracking-wide text-slate-200">
          <span>Behavioral health workforce education for Virginia and beyond</span>
          <span className="inline-flex items-center gap-2">
            <MapPin className="h-3.5 w-3.5 text-[#f47a20]" aria-hidden="true" />
            Richmond, Virginia
          </span>
        </div>
      </div>
      <div className="container flex min-h-[76px] items-center justify-between gap-5">
        <VibhaBrand inverse className="py-3" />
        <nav aria-label="Primary navigation" className="hidden items-center gap-1 lg:flex">
          {primaryNavigation.map(item => (
            <Link
              key={item.href}
              href={item.href}
              aria-current={isActive(location, item.href) ? "page" : undefined}
              className={cn(
                "vibha-control rounded-md px-3 py-2.5 text-sm font-semibold text-slate-100 hover:-translate-y-0.5 hover:bg-white/10 hover:text-white",
                isActive(location, item.href) && "bg-white/10 text-white after:mx-auto after:mt-1 after:block after:h-0.5 after:w-5 after:bg-[#f47a20]",
              )}
            >
              {item.label}
            </Link>
          ))}
          <Button asChild className="vibha-pulse vibha-icon-shift ml-3 bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">
            <Link href="/contact?type=program">
              Request Information <ArrowRight className="ml-1.5 h-4 w-4" />
            </Link>
          </Button>
        </nav>
        <button
          type="button"
          aria-label={open ? "Close navigation menu" : "Open navigation menu"}
          aria-expanded={open}
          aria-controls="mobile-navigation"
          onClick={() => setOpen(value => !value)}
          className="vibha-control inline-flex h-11 w-11 items-center justify-center rounded-md border border-white/20 bg-white/5 hover:rotate-3 hover:bg-white/10 lg:hidden"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      {open ? (
        <nav
          id="mobile-navigation"
          aria-label="Mobile navigation"
          className="border-t border-white/10 bg-[#071f49] px-4 pb-6 pt-3 lg:hidden"
        >
          <div className="mx-auto flex max-w-lg flex-col gap-1">
            {primaryNavigation.map(item => (
              <Link
                key={item.href}
                href={item.href}
                aria-current={isActive(location, item.href) ? "page" : undefined}
                className={cn(
                  "vibha-control rounded-md px-4 py-3 text-base font-semibold text-slate-100 hover:translate-x-1 hover:bg-white/10",
                  isActive(location, item.href) && "bg-white/10 text-white",
                )}
              >
                {item.label}
              </Link>
            ))}
            <Button asChild className="vibha-pulse mt-3 h-12 bg-[#f47a20] font-bold text-[#041634] hover:bg-[#ff9648]">
              <Link href="/contact?type=program">Request Program Information</Link>
            </Button>
          </div>
        </nav>
      ) : null}
    </header>
  );
}
