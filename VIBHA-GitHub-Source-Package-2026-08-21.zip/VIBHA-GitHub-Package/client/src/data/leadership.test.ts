import { describe, expect, it } from "vitest";
import { getLeadershipTeam, leadershipTeam } from "./leadership";

describe("leadership content", () => {
  it("contains exactly four uniquely identified profiles", () => {
    expect(leadershipTeam).toHaveLength(4);
    expect(new Set(leadershipTeam.map(profile => profile.id)).size).toBe(4);
  });

  it("preserves the uploaded names and titles", () => {
    expect(leadershipTeam.map(profile => [profile.name, profile.title])).toEqual([
      ["Jacquese J. Hinton, MS, QMHP", "Founder & Director of Institutional Strategy"],
      ["Candice Womack", "Chancellor"],
      ["Beverly L. Cobbs, MSW, LCSW-S", "Director of Clinical Education, De-Escalation & Forensic Interviewing"],
      ["WL Loftin, M.Ed", "Director of Workforce Education & Business Development"],
    ]);
  });

  it("retains every submitted biography paragraph and responsive portrait", () => {
    expect(leadershipTeam.map(profile => profile.biography.length)).toEqual([5, 4, 4, 4]);
    leadershipTeam.forEach(profile => {
      expect(profile.biography.every(paragraph => paragraph.trim().length > 80)).toBe(true);
      expect(profile.image.small).toMatch(/^\/manus-storage\/.+\.webp$/);
      expect(profile.image.large).toMatch(/^\/manus-storage\/.+\.webp$/);
      expect(profile.image.width).toBeGreaterThan(0);
      expect(profile.image.height).toBeGreaterThan(0);
    });
  });

  it("preserves the revised Beverly leadership wording", () => {
    const beverly = leadershipTeam.find(profile => profile.id === "beverly-cobbs");
    expect(beverly?.biography[1]).toBe(
      "Beverly previously served as Clinical Director at Divine Minds LLC and Chief Therapist at Divine Minds Behavioral Health LLC, where she provided executive clinical leadership across outpatient and community-based behavioral health services, oversees clinical operations and staff supervision, and ensures compliance with ethical, regulatory, and Medicaid standards. Her clinical leadership background also includes serving as Clinical Director at Crossroads Treatment Centers and at L&G Support Services, and as a Senior Foster Care Case Manager at HumanKind. Earlier in her career, she held progressive roles in social work supervision, program leadership, child welfare, and family services with organizations including Alliance Human Services, Jones County Department of Social Services, Seamen's Society, SCO Family Services, The Children's Village, and Duke University.",
    );
  });

  it("preserves the revised Welton academic and institutional wording", () => {
    const welton = leadershipTeam.find(profile => profile.id === "welton-loftin");
    expect(welton?.biography[0]).toBe(
      "WL Loftin leads all Mental Health Agency and Corporate workshops and Mental Health Non-Clinical Cohorts at the Virginia Institute for Behavioral Health & Advancement, while also guiding the Institute's strategic growth, business development, and community partnerships.",
    );
    expect(welton?.biography[1]).toBe(
      "Welton currently serves as an Adjunct Professor teaching Mental Health at both the UNC-G and the UNC-W, ECU, Guilford College and leads Mental Health Forums across North Carolina, Virginia, and Tennessee. He holds a Master of Education in Adult Education with a focus in training and seminar development, and a Bachelor of Arts in Political Science with a minor in Psychology, and is currently pursuing a Doctorate in Education concentrating in Organizational Management. That academic foundation, paired with his work as a life coach and mental health advisor, gives him a practical, adult-learner-centered approach to workforce training. His areas of expertise include cognitive-behavioral approaches, psychological assessment, clinical supervision, conflict resolution, and research methodology and statistical analysis — skills he brings directly into the classroom and into the strategic planning process alike.",
    );
    expect(welton?.biography[3]).toBe(
      "Welton is active in his community, serving on the boards of local community orginatizations, and holding memberships with the National Association of Adult Educators, the National Association of Investors, the Charlotte and Piedmont Boards of Realtors, and Kappa Alpha Psi Fraternity.",
    );
  });

  it("applies approved content-editor overrides while preserving biography paragraph boundaries", () => {
    const [jacquese] = getLeadershipTeam({
      "leadership.profile.jacquese-hinton.name": "Jacquese Hinton, MSHRM",
      "leadership.profile.jacquese-hinton.title": "Founder & Executive Director",
      "leadership.profile.jacquese-hinton.biography": "First approved paragraph.\n\nSecond approved paragraph.",
    });
    expect(jacquese?.name).toBe("Jacquese Hinton, MSHRM");
    expect(jacquese?.title).toBe("Founder & Executive Director");
    expect(jacquese?.biography).toEqual(["First approved paragraph.", "Second approved paragraph."]);
    expect(jacquese?.image.alt).toBe("Portrait of Jacquese Hinton, MSHRM");
  });
});
