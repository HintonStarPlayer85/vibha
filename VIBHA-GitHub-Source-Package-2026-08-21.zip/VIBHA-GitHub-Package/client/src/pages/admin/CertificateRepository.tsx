import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { Award, BarChart3, ClipboardCheck, Download, ExternalLink, Eye, FileCheck2, FileText, Loader2, RefreshCw, Search, ShieldAlert, UserRoundCheck, UserRoundCog } from "lucide-react";
import { useMemo, useState, type Dispatch, type SetStateAction } from "react";
import { toast } from "sonner";

type View = "repository" | "eligible";
type Candidate = { cohortStudentId: number; recipientName: string; recipientEmail: string; credentialTitle: string; cohortTitle: string; ceuValue: string | null };
type Acknowledgement = { token: string; confirmed: boolean; notes: string };
type IssuedCertificate = { id: number; certificateNumber: string; status: "issued" | "revoked" | "superseded"; recipientName: string; credentialTitle: string; cohortTitle: string; ceuValue: string | null; issuedAt: Date; documentUrl: string; reissueOfCertificateId: number | null };
type HistoryEvent = { id: number; action: string; actorName: string | null; createdAt: Date | null; details: string | null };

const historyEventOptions = [
  "certificate.completion.resubmitted",
  "certificate.completion.returned",
  "certificate.completion.first_approved",
  "certificate.completion.approved",
  "certificate.preview.acknowledged",
  "certificate.issued",
  "certificate.reissued",
  "certificate.revoked",
  "certificate.history.exported",
  "certificate.approval.escalated",
  "certificate.approval.escalation_resent",
] as const;
type HistoryEventType = typeof historyEventOptions[number];

const statusClass = (status: IssuedCertificate["status"]) => status === "issued" ? "bg-emerald-100 text-emerald-800" : status === "revoked" ? "bg-rose-100 text-rose-800" : "bg-amber-100 text-amber-800";
const formatDate = (value: Date | null) => value ? new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(new Date(value)) : "Date unavailable";
const historyLabel = (value: string) => value.replaceAll(".", " ").replaceAll("_", " ").replace(/\b\w/g, match => match.toUpperCase());

function Metric({ label, value, detail, accent = false }: { label: string; value: number; detail: string; accent?: boolean }) {
  return <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-sm font-semibold text-slate-600">{label}</p><p className={`mt-2 text-3xl font-bold ${accent ? "text-emerald-700" : "text-[#071f49]"}`}>{value}</p><p className="mt-1 text-xs text-slate-500">{detail}</p></div>;
}

function Loading({ text }: { text: string }) {
  return <p role="status" className="mt-6 flex items-center gap-3 text-sm text-slate-600"><Loader2 className="h-5 w-5 animate-spin" />{text}</p>;
}

function CertificateRepositoryContent() {
  const [view, setView] = useState<View>("repository");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | IssuedCertificate["status"]>("all");
  const [statusMessage, setStatusMessage] = useState("");
  const [acknowledgements, setAcknowledgements] = useState<Record<number, Acknowledgement>>({});
  const [historyId, setHistoryId] = useState<number | null>(null);
  const [historyEventTypes, setHistoryEventTypes] = useState<HistoryEventType[]>([]);
  const [dashboardFromDate, setDashboardFromDate] = useState(() => new Date(Date.now() - 29 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10));
  const [dashboardToDate, setDashboardToDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [reassignTargets, setReassignTargets] = useState<Record<number, number>>({});
  const utils = trpc.useUtils();
  const repositoryQuery = trpc.adminCertificates.list.useQuery(useMemo(() => ({ q: search.trim() || undefined, status: status === "all" ? undefined : status }), [search, status]));
  const eligibleQuery = trpc.adminCertificates.eligible.useQuery();
  const historyQuery = trpc.adminCertificates.approvalHistory.useQuery(useMemo(() => ({ certificateId: historyId ?? 0, eventTypes: historyEventTypes.length ? historyEventTypes : undefined }), [historyId, historyEventTypes]), { enabled: historyId !== null });
  const notificationStatusQuery = trpc.adminCertificates.governanceNotificationStatus.useQuery();
  const governanceDashboardQuery = trpc.adminCertificates.governanceDashboard.useQuery(useMemo(() => ({ fromDate: dashboardFromDate, toDate: dashboardToDate }), [dashboardFromDate, dashboardToDate]));
  const workloadQuery = trpc.adminCertificates.myApprovalWorkload.useQuery();
  const administratorsQuery = trpc.adminCertificates.administratorOptions.useQuery();
  const previewMutation = trpc.adminCertificates.preview.useMutation();
  const confirmMutation = trpc.adminCertificates.confirmPreviewAcknowledgement.useMutation();
  const issueMutation = trpc.adminCertificates.issue.useMutation();
  const reissueMutation = trpc.adminCertificates.reissue.useMutation();
  const revokeMutation = trpc.adminCertificates.revoke.useMutation();
  const exportMutation = trpc.adminCertificates.exportApprovalHistory.useMutation();
  const exportPdfMutation = trpc.adminCertificates.exportApprovalHistoryPdf.useMutation();
  const resendPreviewMutation = trpc.adminCertificates.resendPreviewReminder.useMutation();
  const resendEscalationMutation = trpc.adminCertificates.resendApprovalEscalation.useMutation();
  const reassignEscalationMutation = trpc.adminCertificates.reassignApprovalEscalation.useMutation();
  const dashboardExportMutation = trpc.adminCertificates.exportGovernanceDashboard.useMutation();
  const repository = (repositoryQuery.data ?? []) as unknown as IssuedCertificate[];
  const eligible = (eligibleQuery.data ?? []) as unknown as Candidate[];
  const history = (historyQuery.data ?? []) as unknown as HistoryEvent[];
  const pending = previewMutation.isPending || confirmMutation.isPending || issueMutation.isPending || reissueMutation.isPending || revokeMutation.isPending || exportMutation.isPending || exportPdfMutation.isPending || resendPreviewMutation.isPending || resendEscalationMutation.isPending || reassignEscalationMutation.isPending || dashboardExportMutation.isPending;
  const activeCount = repository.filter(item => item.status === "issued").length;
  const notify = (text: string, failure = false) => { setStatusMessage(text); failure ? toast.error(text) : toast.success(text); };

  async function refresh() {
    await Promise.all([utils.adminCertificates.list.invalidate(), utils.adminCertificates.eligible.invalidate(), utils.adminCertificates.approvalHistory.invalidate()]);
  }

  async function preview(candidate: Candidate) {
    try {
      const result = await previewMutation.mutateAsync({ cohortStudentId: candidate.cohortStudentId });
      const bytes = Uint8Array.from(atob(result.dataBase64), value => value.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
      if (!window.open(url, "_blank", "noopener,noreferrer")) toast.error("Your browser blocked the preview window. Allow pop-ups for VIBHA and try again.");
      window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
      setAcknowledgements(current => ({ ...current, [candidate.cohortStudentId]: { token: result.acknowledgement.acknowledgementToken, confirmed: false, notes: "" } }));
      setStatusMessage("Preview generated. Add an optional acknowledgement note, then confirm the reviewed certificate before issuing.");
    } catch (error) { notify(error instanceof Error ? error.message : "The certificate preview could not be generated.", true); }
  }

  async function confirm(candidate: Candidate) {
    const acknowledgement = acknowledgements[candidate.cohortStudentId];
    if (!acknowledgement) return;
    try {
      await confirmMutation.mutateAsync({ acknowledgementToken: acknowledgement.token, notes: acknowledgement.notes });
      setAcknowledgements(current => ({ ...current, [candidate.cohortStudentId]: { ...acknowledgement, confirmed: true } }));
      notify("Preview acknowledged. Certificate issuance is now enabled for this learner.");
    } catch (error) { notify(error instanceof Error ? error.message : "The acknowledgement could not be saved.", true); }
  }

  async function issue(candidate: Candidate) {
    const acknowledgement = acknowledgements[candidate.cohortStudentId];
    if (!acknowledgement?.confirmed) return notify("Generate and acknowledge a current preview before issuing this certificate.", true);
    if (!window.confirm(`Issue a VIBHA certificate to ${candidate.recipientName}? A permanent credential will be created.`)) return;
    try {
      const result = await issueMutation.mutateAsync({ cohortStudentId: candidate.cohortStudentId, previewAcknowledgementToken: acknowledgement.token });
      setAcknowledgements(current => { const next = { ...current }; delete next[candidate.cohortStudentId]; return next; });
      await refresh(); notify(`Certificate ${result.certificateNumber} issued to ${candidate.recipientName}.`);
    } catch (error) { notify(error instanceof Error ? error.message : "The certificate could not be issued.", true); }
  }

  async function reissue(certificate: IssuedCertificate) {
    if (!window.confirm(`Reissue ${certificate.certificateNumber}? The active certificate will be marked superseded.`)) return;
    try { const result = await reissueMutation.mutateAsync({ certificateId: certificate.id }); await refresh(); notify(`Replacement certificate ${result.certificateNumber} issued.`); } catch (error) { notify(error instanceof Error ? error.message : "The replacement certificate could not be issued.", true); }
  }

  async function revoke(certificate: IssuedCertificate) {
    const reason = window.prompt(`Enter the reason for revoking ${certificate.certificateNumber}.`)?.trim();
    if (!reason) return;
    try { await revokeMutation.mutateAsync({ certificateId: certificate.id, reason }); await refresh(); notify(`${certificate.certificateNumber} revoked.`); } catch (error) { notify(error instanceof Error ? error.message : "The certificate could not be revoked.", true); }
  }

  async function exportHistory() {
    if (historyId === null) return;
    try {
      const result = await exportMutation.mutateAsync({ certificateId: historyId, eventTypes: historyEventTypes.length ? historyEventTypes : undefined });
      const bytes = Uint8Array.from(atob(result.dataBase64), value => value.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: "text/csv;charset=utf-8" }));
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = result.fileName; anchor.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      notify(`Signed approval history exported at ${new Date(result.exportedAt).toLocaleString()} by ${result.exporterName}.`);
    } catch (error) { notify(error instanceof Error ? error.message : "The approval history could not be exported.", true); }
  }

  async function exportHistoryPdf() {
    if (historyId === null) return;
    try {
      const result = await exportPdfMutation.mutateAsync({ certificateId: historyId, eventTypes: historyEventTypes.length ? historyEventTypes : undefined });
      const bytes = Uint8Array.from(atob(result.dataBase64), value => value.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = result.fileName; anchor.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      notify(`Formal approval history report exported at ${new Date(result.exportedAt).toLocaleString()}.`);
    } catch (error) { notify(error instanceof Error ? error.message : "The approval history report could not be exported.", true); }
  }

  async function resendGovernanceNotification(notification: { id: number; type: string }) {
    try {
      if (notification.type === "preview_reminder") await resendPreviewMutation.mutateAsync({ notificationId: notification.id });
      else await resendEscalationMutation.mutateAsync({ escalationId: notification.id });
      await utils.adminCertificates.governanceNotificationStatus.invalidate();
      notify("Notification resend requested and recorded.");
    } catch (error) { notify(error instanceof Error ? error.message : "The notification could not be resent.", true); }
  }

  async function reassignEscalation(notification: { id: number; recipientUserId?: number | null }) {
    const recipientUserId = reassignTargets[notification.id];
    if (!recipientUserId) return notify("Choose an eligible administrator before reassigning this escalation.", true);
    if (recipientUserId === notification.recipientUserId) return notify("Choose a different administrator for reassignment.", true);
    try {
      await reassignEscalationMutation.mutateAsync({ escalationId: notification.id, recipientUserId });
      await Promise.all([utils.adminCertificates.governanceNotificationStatus.invalidate(), utils.adminCertificates.governanceDashboard.invalidate(), utils.adminCertificates.myApprovalWorkload.invalidate()]);
      notify("Escalated approval reassigned and a tracked notice was prepared for the new administrator.");
    } catch (error) { notify(error instanceof Error ? error.message : "The escalation could not be reassigned.", true); }
  }

  async function exportDashboard(format: "csv" | "pdf") {
    try {
      const result = await dashboardExportMutation.mutateAsync({ fromDate: dashboardFromDate, toDate: dashboardToDate, format });
      const bytes = Uint8Array.from(atob(result.dataBase64), value => value.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: format === "csv" ? "text/csv;charset=utf-8" : "application/pdf" }));
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = result.fileName; anchor.click(); window.setTimeout(() => URL.revokeObjectURL(url), 1_000);
      notify(`Signed governance metrics ${format.toUpperCase()} exported at ${new Date(result.exportedAt).toLocaleString()}.`);
    } catch (error) { notify(error instanceof Error ? error.message : "The governance metric export could not be generated.", true); }
  }

  return <main className="mx-auto max-w-7xl pb-12">
    <p role="status" aria-live="polite" className="sr-only">{pending ? "Processing certificate action." : statusMessage}</p>
    <header className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-sm font-bold uppercase tracking-[0.18em] text-[#b94700]">Content Administration</p><h1 className="mt-3 text-4xl font-bold text-[#071f49]">Certificate Repository</h1><p className="mt-3 max-w-3xl text-slate-600">Review, approve, issue, retain, and verify VIBHA completion certificates.</p></div><div className="flex flex-wrap gap-2"><a href="/admin/certificates/approvals" className="admin-link">Completion approvals</a><a href="/admin/certificates/template" className="admin-link">Certificate template</a><a href="/verify-certificate" target="_blank" rel="noreferrer" className="admin-link">Public verifier <ExternalLink className="ml-2 h-4 w-4" /></a></div></header>
    <section className="mt-8 grid gap-4 sm:grid-cols-3"><Metric label="Eligible recipients" value={eligible.length} detail="Completed and administratively approved" /><Metric label="Active certificates" value={activeCount} detail="Visible as valid through public verification" accent /><Metric label="Repository records" value={repository.length} detail="Issued, revoked, and superseded history" /></section>
    <section className="mt-6 rounded-xl border border-[#173b70]/20 bg-[#f7faff] p-5 shadow-sm"><div className="flex flex-wrap items-start justify-between gap-4"><div><h2 className="text-xl font-bold text-[#071f49]">Approval workload and escalation dashboard</h2><p className="mt-1 text-sm text-slate-600">Personal review workload and delayed approvals grouped by certification type. Administrator email addresses are never shown here.</p></div><div className="flex flex-wrap gap-2"><Button type="button" variant="outline" size="sm" disabled={dashboardExportMutation.isPending} onClick={() => void exportDashboard("csv")} className="border-slate-300 bg-white text-[#173b70]"><Download className="mr-1.5 h-4 w-4" />CSV</Button><Button type="button" variant="outline" size="sm" disabled={dashboardExportMutation.isPending} onClick={() => void exportDashboard("pdf")} className="border-slate-300 bg-white text-[#173b70]"><FileText className="mr-1.5 h-4 w-4" />PDF</Button><Button type="button" variant="outline" size="sm" onClick={() => { void utils.adminCertificates.governanceDashboard.invalidate(); void utils.adminCertificates.myApprovalWorkload.invalidate(); }} className="border-slate-300 bg-white text-[#173b70]"><RefreshCw className="mr-1.5 h-4 w-4" />Refresh</Button></div></div><div className="mt-4 grid gap-3 md:grid-cols-[1fr_1fr_auto]"><div><Label htmlFor="dashboard-from">From</Label><Input id="dashboard-from" type="date" className="mt-1" value={dashboardFromDate} max={dashboardToDate} onChange={event => setDashboardFromDate(event.target.value)} /></div><div><Label htmlFor="dashboard-to">To</Label><Input id="dashboard-to" type="date" className="mt-1" value={dashboardToDate} min={dashboardFromDate} onChange={event => setDashboardToDate(event.target.value)} /></div><p className="self-end pb-2 text-xs text-slate-600">Date range filters escalation events and trend activity.</p></div><div className="mt-4 grid gap-3 sm:grid-cols-3"><Metric label="Available reviews" value={workloadQuery.data?.availableReviewTasks ?? 0} detail="Completed learners awaiting a decision" /><Metric label="Second approvals" value={workloadQuery.data?.pendingSecondApprovals ?? 0} detail="High-stakes records you may approve" /><Metric label="Assigned escalations" value={workloadQuery.data?.assignedEscalations ?? 0} detail="Your tracked delayed-approval notices" /></div><div className="mt-5 rounded-lg border border-slate-200 bg-white p-4"><div className="flex items-center gap-2"><BarChart3 className="h-4 w-4 text-[#b94700]" /><h3 className="font-bold text-[#071f49]">Escalation trend</h3></div><div className="mt-4 flex h-32 items-end gap-2" aria-label="Escalation events over selected date range">{(governanceDashboardQuery.data?.trends ?? []).map(row => <div key={row.date} className="flex min-w-8 flex-1 flex-col items-center gap-1"><span className="text-xs font-semibold text-[#071f49]">{row.total}</span><div className="w-full rounded-t bg-[#173b70]" style={{ height: `${Math.max(8, Math.min(96, row.total * 24))}px` }} title={`${row.date}: ${row.total} escalation event${row.total === 1 ? "" : "s"}`} /><span className="text-[10px] text-slate-500">{row.date.slice(5)}</span></div>)}{!governanceDashboardQuery.data?.trends?.length ? <p className="text-sm text-slate-600">No escalation events occurred in this date range.</p> : null}</div></div><div className="mt-5 overflow-x-auto rounded-lg border border-slate-200 bg-white"><table className="min-w-full text-left text-sm"><thead className="bg-slate-50 text-xs uppercase tracking-wide text-slate-500"><tr><th className="px-4 py-3">Certification type</th><th className="px-4 py-3">Delayed approvals</th><th className="px-4 py-3">Escalations</th><th className="px-4 py-3">Delivered</th><th className="px-4 py-3">SLA target</th><th className="px-4 py-3">Oldest request</th></tr></thead><tbody>{(governanceDashboardQuery.data?.byCertification ?? []).map(row => <tr key={row.certificationId} className={`border-t border-slate-100 ${row.slaBreached ? "bg-rose-50" : ""}`}><td className="px-4 py-3 font-semibold text-[#071f49]">{row.certificationTitle}</td><td className="px-4 py-3">{row.delayedApprovals}</td><td className="px-4 py-3">{row.escalationRecords}</td><td className="px-4 py-3">{row.deliveredEscalations}</td><td className={`px-4 py-3 text-xs font-semibold ${row.slaBreached ? "text-rose-800" : "text-slate-600"}`}>{row.slaTargetMinutes ? `${row.elapsedMinutes}/${row.slaTargetMinutes} min${row.slaBreached ? " · BREACHED" : ""}` : "Not set"}</td><td className="px-4 py-3 text-slate-600">{formatDate(row.oldestRequestedAt)}</td></tr>)}{!governanceDashboardQuery.data?.byCertification.length ? <tr><td colSpan={6} className="px-4 py-6 text-center text-slate-600">No delayed-approval escalation records are currently active.</td></tr> : null}</tbody></table></div></section>
    <section className="mt-8 rounded-xl border border-[#f47a20]/35 bg-[#fff7f2] p-5 text-sm leading-6 text-[#5a2a07]"><strong className="block text-[#8f3d00]">Credential controls</strong>Generate a current preview, optionally document the review rationale, then acknowledge the preview before issuing the permanent credential. Preview duration and automatic expiry reminders are configured per certification.</section>
    <section className="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-xl font-bold text-[#071f49]">Governance notification status</h2><p className="mt-1 text-sm text-slate-600">Tracked preview reminders and delayed-approval escalations. Recipient addresses remain private.</p></div><Button type="button" variant="outline" size="sm" onClick={() => void utils.adminCertificates.governanceNotificationStatus.invalidate()} className="border-slate-300 bg-white text-[#173b70]"><RefreshCw className="mr-1.5 h-4 w-4" />Refresh</Button></div><div className="mt-4 grid gap-3 md:grid-cols-2">{(notificationStatusQuery.data ?? []).slice(0, 8).map(notification => <div key={`${notification.type}-${notification.id}`} className="rounded-lg border border-slate-200 p-3"><div className="flex items-center justify-between gap-2"><p className="text-sm font-bold text-[#071f49]">{notification.type === "approval_escalation" ? "Delayed approval escalation" : "Preview reminder"}</p><Badge className={notification.status === "accepted" ? "bg-emerald-100 text-emerald-800" : notification.status === "failed" ? "bg-rose-100 text-rose-800" : "bg-amber-100 text-amber-800"}>{notification.status}</Badge></div><p className="mt-1 text-xs text-slate-600">{notification.credentialTitle} · {notification.cohortTitle}</p><p className="mt-1 text-xs text-slate-500">Recipient: {notification.recipientName} · retries: {notification.retryCount}</p>{notification.errorMessage ? <p className="mt-1 text-xs text-rose-700">{notification.errorMessage}</p> : null}<Button type="button" size="sm" variant="outline" disabled={pending} onClick={() => void resendGovernanceNotification(notification)} className="mt-3 border-slate-300 bg-white text-[#173b70]"><RefreshCw className="mr-1.5 h-3.5 w-3.5" />Manual resend</Button>{notification.type === "approval_escalation" ? <div className="mt-3 rounded-md bg-slate-50 p-3"><Label htmlFor={`reassign-${notification.id}`} className="text-xs">Reassign delayed approval</Label><div className="mt-2 flex flex-wrap gap-2"><select id={`reassign-${notification.id}`} value={reassignTargets[notification.id] ?? ""} onChange={event => setReassignTargets(current => ({ ...current, [notification.id]: Number(event.target.value) }))} className="min-h-9 flex-1 rounded-md border border-slate-300 bg-white px-2 text-xs"><option value="">Select administrator</option>{administratorsQuery.data?.filter(administrator => administrator.id !== notification.recipientUserId).map(administrator => <option key={administrator.id} value={administrator.id}>{administrator.name ?? `Administrator ${administrator.id}`}</option>)}</select><Button type="button" size="sm" variant="outline" disabled={pending} onClick={() => void reassignEscalation(notification)} className="border-slate-300 bg-white text-[#173b70]"><UserRoundCog className="mr-1 h-3.5 w-3.5" />Reassign</Button></div></div> : null}</div>)}{!notificationStatusQuery.data?.length ? <p className="text-sm text-slate-600">No preview reminders or delayed approval escalations have been recorded yet.</p> : null}</div></section>
    <div className="mt-6 flex flex-wrap gap-2" role="tablist"><Button type="button" role="tab" aria-selected={view === "repository"} onClick={() => setView("repository")} className={view === "repository" ? "bg-[#071f49] text-white hover:bg-[#173b70]" : "border border-slate-300 bg-white text-[#173b70]"}><Award className="mr-2 h-4 w-4" />Issued repository</Button><Button type="button" role="tab" aria-selected={view === "eligible"} variant="outline" onClick={() => setView("eligible")} className={view === "eligible" ? "bg-[#071f49] text-white hover:bg-[#173b70]" : "border-slate-300 bg-white text-[#173b70]"}><UserRoundCheck className="mr-2 h-4 w-4" />Eligible to issue</Button></div>
    {view === "repository" ? <RepositoryRecords repository={repository} search={search} status={status} setSearch={setSearch} setStatus={setStatus} historyId={historyId} setHistoryId={setHistoryId} history={history} historyEventTypes={historyEventTypes} setHistoryEventTypes={setHistoryEventTypes} historyLoading={historyQuery.isLoading} pending={pending} exportPending={exportMutation.isPending || exportPdfMutation.isPending} onExport={exportHistory} onExportPdf={exportHistoryPdf} onReissue={reissue} onRevoke={revoke} /> : <EligibleCandidates candidates={eligible} acknowledgements={acknowledgements} setAcknowledgements={setAcknowledgements} pending={pending} onPreview={preview} onConfirm={confirm} onIssue={issue} />}
  </main>;
}

function RepositoryRecords({ repository, search, status, setSearch, setStatus, historyId, setHistoryId, history, historyEventTypes, setHistoryEventTypes, historyLoading, pending, exportPending, onExport, onExportPdf, onReissue, onRevoke }: { repository: IssuedCertificate[]; search: string; status: "all" | IssuedCertificate["status"]; setSearch: Dispatch<SetStateAction<string>>; setStatus: Dispatch<SetStateAction<"all" | IssuedCertificate["status"]>>; historyId: number | null; setHistoryId: Dispatch<SetStateAction<number | null>>; history: HistoryEvent[]; historyEventTypes: HistoryEventType[]; setHistoryEventTypes: Dispatch<SetStateAction<HistoryEventType[]>>; historyLoading: boolean; pending: boolean; exportPending: boolean; onExport: () => Promise<void>; onExportPdf: () => Promise<void>; onReissue: (certificate: IssuedCertificate) => Promise<void>; onRevoke: (certificate: IssuedCertificate) => Promise<void> }) {
  return <section className="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
    <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between"><div><h2 className="text-2xl font-bold text-[#071f49]">Issued certificate records</h2><p className="mt-1 text-sm text-slate-600">Search by certificate number, recipient, credential, or cohort.</p></div><div className="grid gap-3 sm:grid-cols-[minmax(240px,1fr)_160px]"><div className="relative"><Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-500" /><Input value={search} onChange={event => setSearch(event.target.value)} className="pl-9" placeholder="Search records" aria-label="Search certificate records" /></div><select value={status} onChange={event => setStatus(event.target.value as "all" | IssuedCertificate["status"])} className="min-h-11 rounded-md border border-slate-300 bg-white px-3 text-sm font-semibold text-[#071f49]"><option value="all">All statuses</option><option value="issued">Issued</option><option value="revoked">Revoked</option><option value="superseded">Superseded</option></select></div></div>
    <div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">{repository.map(certificate => <article key={certificate.id} className="grid gap-4 p-5 lg:grid-cols-[1.2fr_1fr_auto] lg:items-center"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-mono text-sm font-bold text-[#071f49]">{certificate.certificateNumber}</h3><Badge className={statusClass(certificate.status)}>{certificate.status}</Badge></div><p className="mt-2 font-bold text-[#071f49]">{certificate.recipientName}</p><p className="mt-1 text-sm text-slate-600">{certificate.credentialTitle}</p><p className="mt-1 text-xs text-slate-500">Issued {formatDate(certificate.issuedAt)} · {certificate.cohortTitle}</p></div><div className="text-sm text-slate-600"><p>{certificate.ceuValue ? `${certificate.ceuValue} CEUs` : "CEU value not recorded"}</p>{certificate.reissueOfCertificateId ? <p className="mt-1 text-xs text-amber-700">Replacement certificate</p> : null}</div><div className="flex flex-wrap gap-2 lg:justify-end"><a href={certificate.documentUrl} target="_blank" rel="noreferrer" className="admin-link"><Download className="mr-1.5 h-4 w-4" />PDF</a><Button type="button" variant="outline" size="sm" onClick={() => { setHistoryId(current => current === certificate.id ? null : certificate.id); setHistoryEventTypes([]); }} className="border-slate-300 bg-white text-[#173b70]"><ClipboardCheck className="mr-1.5 h-4 w-4" />History</Button>{certificate.status === "issued" ? <><Button type="button" variant="outline" size="sm" disabled={pending} onClick={() => void onReissue(certificate)} className="border-slate-300 bg-white text-[#173b70]"><RefreshCw className="mr-1.5 h-4 w-4" />Reissue</Button><Button type="button" variant="outline" size="sm" disabled={pending} onClick={() => void onRevoke(certificate)} className="border-rose-200 bg-white text-rose-800 hover:bg-rose-50"><ShieldAlert className="mr-1.5 h-4 w-4" />Revoke</Button></> : null}</div>{historyId === certificate.id ? <div className="lg:col-span-3 rounded-lg border border-[#173b70]/15 bg-[#f7faff] p-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><h4 className="font-bold text-[#071f49]">Approval and certificate history</h4><p className="mt-1 text-xs text-slate-600">Filter events before reviewing or exporting this certificate-only audit log.</p></div><div className="flex flex-wrap gap-2"><Button type="button" size="sm" variant="outline" disabled={!history.length || exportPending} onClick={() => void onExport()} className="border-[#173b70]/30 bg-white text-[#173b70]"><Download className="mr-1.5 h-4 w-4" />Signed CSV</Button><Button type="button" size="sm" variant="outline" disabled={!history.length || exportPending} onClick={() => void onExportPdf()} className="border-[#173b70]/30 bg-white text-[#173b70]"><FileText className="mr-1.5 h-4 w-4" />Formal PDF</Button></div></div><fieldset className="mt-4 flex flex-wrap gap-2"><legend className="sr-only">Approval history event filters</legend>{historyEventOptions.map(eventType => <label key={eventType} className="inline-flex items-center gap-2 rounded-full border border-[#173b70]/20 bg-white px-3 py-2 text-xs font-semibold text-[#173b70]"><input type="checkbox" checked={historyEventTypes.includes(eventType)} onChange={event => setHistoryEventTypes(current => event.target.checked ? [...current, eventType] : current.filter(value => value !== eventType))} className="h-4 w-4 accent-[#071f49]" />{historyLabel(eventType)}</label>)}</fieldset>{historyLoading ? <Loading text="Loading history…" /> : <ol className="mt-3 space-y-2">{history.map(event => <li key={event.id} className="rounded-md border border-slate-200 bg-white p-3 text-sm"><p className="font-semibold text-[#071f49]">{historyLabel(event.action)}</p><p className="mt-1 text-slate-600">{event.actorName ?? "Former administrator"} · {formatDate(event.createdAt)}</p>{event.details ? <p className="mt-2 border-l-2 border-[#f47a20] pl-3 text-slate-700">{event.details}</p> : null}</li>)}</ol>}</div> : null}</article>)}{!repository.length ? <div className="p-8 text-center"><FileCheck2 className="mx-auto h-8 w-8 text-slate-400" /><p className="mt-3 font-bold text-[#071f49]">No certificate records match this view.</p><p className="mt-1 text-sm text-slate-600">Completed students appear in the Eligible to issue view.</p></div> : null}</div>
  </section>;
}

function EligibleCandidates({ candidates, acknowledgements, setAcknowledgements, pending, onPreview, onConfirm, onIssue }: { candidates: Candidate[]; acknowledgements: Record<number, Acknowledgement>; setAcknowledgements: Dispatch<SetStateAction<Record<number, Acknowledgement>>>; pending: boolean; onPreview: (candidate: Candidate) => Promise<void>; onConfirm: (candidate: Candidate) => Promise<void>; onIssue: (candidate: Candidate) => Promise<void> }) {
  return <section className="mt-6 rounded-xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7"><div><h2 className="text-2xl font-bold text-[#071f49]">Eligible completed students</h2><p className="mt-1 text-sm text-slate-600">Preview the final layout, optionally document the review rationale, then acknowledge it before issuing.</p></div><div className="mt-6 divide-y divide-slate-200 rounded-lg border border-slate-200">{candidates.map(candidate => { const acknowledgement = acknowledgements[candidate.cohortStudentId]; return <article key={candidate.cohortStudentId} className="grid gap-4 p-5 md:grid-cols-[1.2fr_1fr_auto] md:items-center"><div><p className="font-bold text-[#071f49]">{candidate.recipientName}</p><p className="mt-1 text-sm text-slate-600">{candidate.recipientEmail}</p></div><div><p className="font-semibold text-[#071f49]">{candidate.credentialTitle}</p><p className="mt-1 text-sm text-slate-600">{candidate.cohortTitle}{candidate.ceuValue ? ` · ${candidate.ceuValue} CEUs` : ""}</p>{acknowledgement ? <div className="mt-3 rounded-md border border-[#173b70]/20 bg-[#f7faff] p-3"><Label htmlFor={`ack-note-${candidate.cohortStudentId}`} className="text-xs">Approval note <span className="font-normal text-slate-500">(optional)</span></Label><Textarea id={`ack-note-${candidate.cohortStudentId}`} value={acknowledgement.notes} disabled={acknowledgement.confirmed} onChange={event => setAcknowledgements(current => ({ ...current, [candidate.cohortStudentId]: { ...acknowledgement, notes: event.target.value } }))} className="mt-1 min-h-20 text-sm" placeholder="Document any specific reason for approving this preview." maxLength={1000} /><label className="mt-3 flex items-start gap-2 text-xs font-semibold text-[#071f49]"><input type="checkbox" checked={acknowledgement.confirmed} disabled={acknowledgement.confirmed || pending} onChange={event => event.target.checked ? void onConfirm(candidate) : undefined} className="mt-0.5 h-4 w-4 accent-[#071f49]" />I reviewed this preview and confirm the certificate layout, signatories, and course details are accurate.</label></div> : <p className="mt-3 text-xs text-amber-700">Generate a current preview to unlock acknowledgement.</p>}</div><div className="flex flex-wrap gap-2 md:justify-end"><Button type="button" variant="outline" disabled={pending} onClick={() => void onPreview(candidate)} className="border-slate-300 bg-white text-[#173b70]"><Eye className="mr-2 h-4 w-4" />Preview</Button><Button type="button" disabled={pending || !acknowledgement?.confirmed} onClick={() => void onIssue(candidate)} className="min-h-11 bg-[#071f49] font-bold text-white hover:bg-[#173b70]"><Award className="mr-2 h-4 w-4" />Issue certificate</Button></div></article>; })}{!candidates.length ? <div className="p-8 text-center"><UserRoundCheck className="mx-auto h-8 w-8 text-slate-400" /><p className="mt-3 font-bold text-[#071f49]">No students are currently eligible.</p><p className="mt-1 text-sm text-slate-600">Mark the cohort and roster student as completed to make certificate issuance available.</p></div> : null}</div></section>;
}

export default function CertificateRepository() { return <DashboardLayout><CertificateRepositoryContent /></DashboardLayout>; }
