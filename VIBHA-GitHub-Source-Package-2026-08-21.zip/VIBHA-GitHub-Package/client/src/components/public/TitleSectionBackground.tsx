const backgroundSources = {
  mobileCompact: "/manus-storage/VIBHAHEROIMAGE-mobile-overlay-640_b193474c.webp",
  mobile: "/manus-storage/VIBHAHEROIMAGE-mobile-overlay_6813da3c.webp",
  tabletCompact: "/manus-storage/VIBHAHEROIMAGE-tablet-overlay-1024_eb7d60ee.webp",
  tablet: "/manus-storage/VIBHAHEROIMAGE-tablet-overlay_7de15215.webp",
  desktop: "/manus-storage/VIBHAHEROIMAGE-1280_2cdfa16c.webp",
};

export function TitleSectionBackground() {
  return (
    <picture className="absolute inset-0 block h-full w-full" aria-hidden="true">
      <source
        media="(max-width: 639px)"
        type="image/webp"
        srcSet={`${backgroundSources.mobileCompact} 640w, ${backgroundSources.mobile} 960w`}
        sizes="100vw"
      />
      <source
        media="(max-width: 1279px)"
        type="image/webp"
        srcSet={`${backgroundSources.tabletCompact} 1024w, ${backgroundSources.tablet} 1536w`}
        sizes="100vw"
      />
      <source media="(min-width: 1280px)" type="image/webp" srcSet={backgroundSources.desktop} />
      <img
        src={backgroundSources.desktop}
        alt=""
        width="1280"
        height="720"
        fetchPriority="high"
        loading="eager"
        decoding="async"
        className="block h-full w-full object-cover object-left-top"
      />
    </picture>
  );
}
