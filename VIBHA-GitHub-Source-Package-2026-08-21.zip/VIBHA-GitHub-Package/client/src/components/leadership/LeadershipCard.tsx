import { ArrowRight } from "lucide-react";
import { Link } from "wouter";
import type { LeadershipProfile } from "@/data/leadership";

export function LeadershipCard({ profile }: { profile: LeadershipProfile }) {
  return (
    <article className="group overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="aspect-[4/5] overflow-hidden bg-[#e8edf4]">
        <img
          src={profile.image.large}
          srcSet={`${profile.image.small} 480w, ${profile.image.large} 960w`}
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
          width={profile.image.width}
          height={profile.image.height}
          alt={profile.image.alt}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover object-top transition-transform duration-300 group-hover:scale-[1.025] motion-reduce:transform-none"
        />
      </div>
      <div className="flex min-h-56 flex-col p-6">
        <h3 className="text-2xl font-bold leading-tight text-[#071f49]">{profile.name}</h3>
        <p className="mt-3 text-sm font-semibold leading-6 text-[#b94700]">{profile.title}</p>
        <Link
          href={`/about/leadership#${profile.id}`}
          className="mt-auto inline-flex min-h-11 items-center pt-6 text-sm font-bold text-[#071f49] hover:text-[#b94700]"
        >
          Read complete biography <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1 motion-reduce:transform-none" />
        </Link>
      </div>
    </article>
  );
}

