export type AdministratorInvitationStatus = "pending" | "accepted" | "revoked" | "expired";

export function invitationStatusGuidance(status: AdministratorInvitationStatus) {
  if (status === "expired") {
    return {
      title: "This invitation has expired.",
      message: "Ask the VIBHA owner to issue a new administrator invitation before attempting registration again.",
    };
  }
  if (status === "revoked") {
    return {
      title: "This invitation was revoked.",
      message: "Contact the VIBHA owner if you still require Content Administration access.",
    };
  }
  if (status === "accepted") {
    return {
      title: "This invitation has already been used.",
      message: "Sign in through Administrator Access. If you did not accept this invitation, contact the VIBHA owner.",
    };
  }
  return null;
}
