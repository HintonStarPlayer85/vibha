import { describe, expect, it, vi } from "vitest";

const dbMocks = vi.hoisted(() => ({
  getCompletionNotificationDelivery: vi.fn(),
  markCompletionNotificationAccepted: vi.fn(),
  markCompletionNotificationFailed: vi.fn(),
  prepareCompletionNotificationRetry: vi.fn(),
}));
const resendMocks = vi.hoisted(() => ({ send: vi.fn(), getResendConfiguration: vi.fn(), verifyResendSenderDomain: vi.fn() }));

vi.mock("./certificateDb", () => dbMocks);
vi.mock("./resendCohort", () => ({ getResendConfiguration: resendMocks.getResendConfiguration, verifyResendSenderDomain: resendMocks.verifyResendSenderDomain }));
vi.mock("resend", () => ({ Resend: class { emails = { send: resendMocks.send }; } }));

import { deliverCompletionNotification } from "./completionNotificationService";

const notification = { id: 8, decision: "approved" as const, recipientName: "Jordan Avery", recipientEmail: "jordan@example.com", subject: "Completion approved", idempotencyKey: "completion/8/approved/1/2", retryCount: 0, status: "queued" as const, reviewNotes: null, cohortTitle: "Spring Cohort", credentialTitle: "Behavioral Health Foundations" };

describe("completion decision notification delivery", () => {
  it("persists a failure and automatically retries once before accepting delivery", async () => {
    dbMocks.getCompletionNotificationDelivery.mockResolvedValue(notification);
    resendMocks.getResendConfiguration.mockReturnValue({ readyToSend: true, apiKey: "key", from: "VIBHA <learn@thevibha.org>", replyTo: "support@thevibha.org", missing: [] });
    resendMocks.verifyResendSenderDomain.mockResolvedValue({ verified: true, domain: "thevibha.org", status: "verified" });
    resendMocks.send.mockResolvedValueOnce({ error: { name: "rate_limit", message: "Retry later" } }).mockResolvedValueOnce({ data: { id: "msg_123" } });
    await expect(deliverCompletionNotification(8)).resolves.toMatchObject({ status: "accepted", retried: true });
    expect(dbMocks.markCompletionNotificationFailed).toHaveBeenCalledWith(8, "rate_limit", "Retry later", false);
    expect(dbMocks.markCompletionNotificationAccepted).toHaveBeenCalledWith(8, "msg_123");
  });
});
