import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";

type InquiryType = "program" | "agency" | "general";

type InquiryState = {
  inquiryType: InquiryType;
  name: string;
  email: string;
  phone: string;
  organization: string;
  programRoute: string;
  organizationType: string;
  workforceSize: string;
  priority: string;
  timeline: string;
  message: string;
  consent: boolean;
  website: string;
};

function initialType(): InquiryType {
  if (typeof window === "undefined") return "general";
  const type = new URLSearchParams(window.location.search).get("type");
  return type === "agency" || type === "program" ? type : "general";
}

export function InquiryForm({
  certificationId,
  certificationTitle,
}: {
  certificationId?: number;
  certificationTitle?: string;
}) {
  const defaultType = certificationId ? "program" : initialType();
  const [state, setState] = useState<InquiryState>({
    inquiryType: defaultType,
    name: "",
    email: "",
    phone: "",
    organization: "",
    programRoute: certificationTitle ?? (defaultType === "agency" ? "Agency training consultation" : ""),
    organizationType: "",
    workforceSize: "",
    priority: "",
    timeline: "",
    message: certificationTitle ? `I would like information about ${certificationTitle}.` : "",
    consent: false,
    website: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const mutation = trpc.inquiries.submit.useMutation({ onSuccess: () => setSubmitted(true) });
  const isAgency = state.inquiryType === "agency";
  const routeOptions = useMemo(
    () => [
      ["", "Select an inquiry route"],
      ["Certification program information", "Certification program information"],
      ["Agency training consultation", "Agency training consultation"],
      ["Institutional partnership", "Institutional partnership"],
      ["General information", "General information"],
    ],
    [],
  );

  function update<K extends keyof InquiryState>(key: K, value: InquiryState[K]) {
    setState(current => ({ ...current, [key]: value }));
    setErrors(current => ({ ...current, [key]: "" }));
  }

  function validate() {
    const next: Record<string, string> = {};
    if (state.name.trim().length < 2) next.name = "Enter your full name.";
    if (!/^\S+@\S+\.\S+$/.test(state.email)) next.email = "Enter a valid email address.";
    if (!state.programRoute) next.programRoute = "Select the best inquiry route.";
    if (state.message.trim().length < 10) next.message = "Provide at least 10 characters so our team can route your inquiry.";
    if (!state.consent) next.consent = "Consent is required before submitting.";
    setErrors(next);
    const firstInvalidField = Object.keys(next)[0];
    if (firstInvalidField) {
      const fieldId = firstInvalidField === "programRoute" ? "inquiry-route" : firstInvalidField;
      requestAnimationFrame(() => document.getElementById(fieldId)?.focus());
    }
    return Object.keys(next).length === 0;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!validate()) return;
    await mutation.mutateAsync({
      inquiryType: state.inquiryType,
      certificationId,
      programRoute: state.programRoute,
      name: state.name,
      email: state.email,
      phone: state.phone || null,
      organization: state.organization || null,
      organizationType: state.organizationType || null,
      workforceSize: state.workforceSize || null,
      priority: state.priority || null,
      timeline: state.timeline || null,
      message: state.message,
      consent: true,
      sourcePath: window.location.pathname,
      website: state.website,
    });
  }

  if (submitted) {
    return (
      <div role="status" aria-live="polite" className="rounded-xl border border-emerald-200 bg-emerald-50 p-8 text-emerald-950">
        <CheckCircle2 className="h-10 w-10 text-emerald-700" aria-hidden="true" />
        <h2 className="mt-4 text-3xl font-bold">Inquiry received</h2>
        <p className="mt-3 max-w-xl leading-7">
          Thank you for contacting VIBHA. Your inquiry has been routed for review. A team member will follow up using the email address you provided.
        </p>
        <Button type="button" variant="outline" className="mt-6 border-emerald-300 bg-white" onClick={() => setSubmitted(false)}>
          Submit another inquiry
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="rounded-xl border border-slate-200 bg-white p-5 shadow-institutional sm:p-8">
      {Object.keys(errors).length ? <p role="alert" className="sr-only">{Object.values(errors).join(" ")}</p> : null}
      {mutation.error ? (
        <div role="alert" className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          We could not submit your inquiry. Review the form and try again. If the problem continues, call VIBHA at (434) 865-1048.
        </div>
      ) : null}
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <Label htmlFor="inquiry-route">Inquiry route <span aria-hidden="true">*</span></Label>
          <select
            id="inquiry-route"
            value={state.programRoute}
            onChange={event => {
              const value = event.target.value;
              update("programRoute", value);
              update("inquiryType", value === "Agency training consultation" ? "agency" : value === "General information" ? "general" : "program");
            }}
            aria-invalid={Boolean(errors.programRoute)}
            aria-describedby={errors.programRoute ? "inquiry-route-error" : undefined}
            className="mt-2 h-11 w-full rounded-md border border-input bg-white px-3 text-sm text-slate-900"
          >
            {certificationTitle ? <option value={certificationTitle}>{certificationTitle}</option> : routeOptions.map(([value, label]) => <option key={value || "placeholder"} value={value}>{label}</option>)}
          </select>
          {errors.programRoute ? <p id="inquiry-route-error" className="mt-1 text-sm text-red-700">{errors.programRoute}</p> : null}
        </div>
        <div>
          <Label htmlFor="name">Name <span aria-hidden="true">*</span></Label>
          <Input id="name" autoComplete="name" className="mt-2" value={state.name} onChange={event => update("name", event.target.value)} aria-invalid={Boolean(errors.name)} aria-describedby={errors.name ? "name-error" : undefined} />
          {errors.name ? <p id="name-error" className="mt-1 text-sm text-red-700">{errors.name}</p> : null}
        </div>
        <div>
          <Label htmlFor="email">Email <span aria-hidden="true">*</span></Label>
          <Input id="email" type="email" autoComplete="email" className="mt-2" value={state.email} onChange={event => update("email", event.target.value)} aria-invalid={Boolean(errors.email)} aria-describedby={errors.email ? "email-error" : undefined} />
          {errors.email ? <p id="email-error" className="mt-1 text-sm text-red-700">{errors.email}</p> : null}
        </div>
        <div>
          <Label htmlFor="phone">Phone</Label>
          <Input id="phone" type="tel" autoComplete="tel" className="mt-2" value={state.phone} onChange={event => update("phone", event.target.value)} />
        </div>
        <div>
          <Label htmlFor="organization">Organization</Label>
          <Input id="organization" autoComplete="organization" className="mt-2" value={state.organization} onChange={event => update("organization", event.target.value)} />
        </div>
        {isAgency ? (
          <>
            <div>
              <Label htmlFor="organization-type">Organization type</Label>
              <Input id="organization-type" className="mt-2" value={state.organizationType} onChange={event => update("organizationType", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="workforce-size">Approximate workforce size</Label>
              <Input id="workforce-size" className="mt-2" value={state.workforceSize} onChange={event => update("workforceSize", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="priority">Primary workforce priority</Label>
              <Input id="priority" className="mt-2" value={state.priority} onChange={event => update("priority", event.target.value)} />
            </div>
            <div>
              <Label htmlFor="timeline">Preferred timeline</Label>
              <Input id="timeline" className="mt-2" value={state.timeline} onChange={event => update("timeline", event.target.value)} />
            </div>
          </>
        ) : null}
        <div className="sm:col-span-2">
          <Label htmlFor="message">How can VIBHA help? <span aria-hidden="true">*</span></Label>
          <Textarea id="message" rows={6} className="mt-2 resize-y" value={state.message} onChange={event => update("message", event.target.value)} aria-invalid={Boolean(errors.message)} aria-describedby={errors.message ? "message-error" : "message-help"} />
          <p id="message-help" className="mt-1 text-xs text-slate-500">Do not include protected health information or sensitive client details.</p>
          {errors.message ? <p id="message-error" className="mt-1 text-sm text-red-700">{errors.message}</p> : null}
        </div>
        <div className="absolute -left-[10000px]" aria-hidden="true">
          <Label htmlFor="website">Website</Label>
          <Input id="website" tabIndex={-1} autoComplete="off" value={state.website} onChange={event => update("website", event.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <label className="flex cursor-pointer items-start gap-3 rounded-lg bg-slate-50 p-4 text-sm leading-6 text-slate-700">
            <input id="consent" type="checkbox" checked={state.consent} onChange={event => update("consent", event.target.checked)} className="mt-1 h-5 w-5 shrink-0 accent-[#071f49]" aria-invalid={Boolean(errors.consent)} aria-describedby={errors.consent ? "consent-error" : undefined} />
            <span>I consent to VIBHA using the information provided to respond to this inquiry. I understand this form is not for emergencies or clinical services. <span aria-hidden="true">*</span></span>
          </label>
          {errors.consent ? <p id="consent-error" className="mt-1 text-sm text-red-700">{errors.consent}</p> : null}
        </div>
      </div>
      <Button type="submit" disabled={mutation.isPending} className="mt-6 h-12 bg-[#f47a20] px-6 font-bold text-[#041634] hover:bg-[#ff9648]">
        {mutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
        Submit inquiry
      </Button>
    </form>
  );
}
